import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, adminProcedure, router } from "./_core/trpc";
import {
  addToWaitlist, getWaitlistCount,
  createAssessment, getAssessmentById, getLatestAssessment, updateAssessmentStatus,
  incrementCompletedQuestions, saveResponse, getResponsesByAssessment,
  saveScores, getScoresByAssessment, savePowerCombinations, getPowerCombinationsByAssessment,
  validatePromoCode, incrementPromoCodeUsage, createPromoCode, getAllPromoCodes,
  saveEvidence, getEvidenceByAssessment,
  getAllUsers, getAllAssessments, getAdminStats,
  getAllEvidence, updateEvidenceStatus,
  updateUserRole, updateUserTier, togglePromoCode,
  getInfluencerStatsByCode,
  addToLeaderboard, getLeaderboard, toggleLeaderboardVisibility, getUserLeaderboardEntry,
  createChallengeInvite, getChallengeByToken, acceptChallenge, getChallengesBySender,
  getUserComparison,
  saveNlpProfile, getNlpProfile,
  saveCoachingLetter, getCoachingLetters, markLetterRead,
} from "./db";
import { storagePut } from "./storage";
import { invokeLLM } from "./_core/llm";
import { generateSocialCardSVG } from "./socialCard";
import { transcribeAudio } from "./_core/voiceTranscription";
import { z } from "zod";

const AXIS_LABELS = [
  "Logical", "Mathematical", "Spatial", "Linguistic", "Interpersonal",
  "Intrapersonal", "Musical", "Kinesthetic", "Naturalistic", "Strategic",
  "Tactical", "Adaptive", "Resilient", "Systematic", "Architectural",
  "Empathic", "Intuitive", "Meta-Cognitive", "Reflective", "Existential",
  "Philosophical", "Integrative"
];

// ============================================================
// RARITY CALCULATION ENGINE
// Based on Spiral Dynamics population distribution research
// ============================================================

/**
 * Maps a 0.0-1.0 axis score to a rarity value (1 in X people)
 * using Spiral Dynamics population distribution:
 *
 * Score 0.0-0.3  → Blue (40% of pop)        → rarity 1-2
 * Score 0.3-0.5  → Orange (30% of pop)       → rarity 2-5
 * Score 0.5-0.7  → Green (10% of pop)        → rarity 5-20
 * Score 0.7-0.85 → Yellow (1% of pop)        → rarity 20-200
 * Score 0.85-0.95→ Turquoise (0.1% of pop)   → rarity 200-2,000
 * Score 0.95-1.0 → Coral (emerging, <0.01%)  → rarity 2,000-10,000
 *
 * Uses a piecewise exponential curve that maps developmental
 * altitude to population rarity.
 */
export function scoreToRarity(score: number): number {
  // Clamp to valid range
  const s = Math.max(0, Math.min(1, score));

  // Curve anchored to Spiral Dynamics population distributions:
  // Blue (~40% of pop) → rarity 1-3
  // Orange (~30% of pop) → rarity 3-10
  // Green (~10% of pop) → rarity 10-100
  // Yellow (~1% of pop) → rarity 100-1,000
  // Turquoise (~0.1% of pop) → rarity 1,000-10,000
  // Coral (~0.01% of pop) → rarity 10,000-100,000

  if (s <= 0.3) {
    // Blue range: 0.0-0.3 → rarity 1.0 to 3.0
    // ~40% of global population lives here (conventional thinking)
    return 1.0 + (s / 0.3) * 2.0;
  } else if (s <= 0.5) {
    // Orange range: 0.3-0.5 → rarity 3.0 to 10.0
    // ~30% of population (rational-achievement, most professionals)
    const t = (s - 0.3) / 0.2;
    return 3.0 + t * 7.0;
  } else if (s <= 0.7) {
    // Green range: 0.5-0.7 → rarity 10.0 to 100.0
    // ~10% of population (pluralistic, academics, therapists)
    // Exponential: 10 → 100 (one order of magnitude)
    const t = (s - 0.5) / 0.2;
    return 10.0 * Math.pow(10, t); // 10 → 100
  } else if (s <= 0.85) {
    // Yellow range: 0.7-0.85 → rarity 100.0 to 1,000.0
    // ~1% of population (integrative, systems thinkers)
    const t = (s - 0.7) / 0.15;
    return 100.0 * Math.pow(10, t); // 100 → 1,000
  } else if (s <= 0.95) {
    // Turquoise range: 0.85-0.95 → rarity 1,000 to 10,000
    // ~0.1% of population (holistic, rare)
    const t = (s - 0.85) / 0.10;
    return 1000.0 * Math.pow(10, t); // 1,000 → 10,000
  } else {
    // Coral range: 0.95-1.0 → rarity 10,000 to 100,000
    // ~0.01% of population (emerging 3rd tier)
    const t = (s - 0.95) / 0.05;
    return 10000.0 * Math.pow(10, t); // 10,000 → 100,000
  }
}

/**
 * Calculate composite rarity from all 22 axis scores.
 *
 * Uses GEOMETRIC MEAN of individual axis rarities (not product,
 * which would be too extreme, and not arithmetic mean, which would
 * be too forgiving).
 *
 * The geometric mean naturally rewards consistent high performance
 * across axes while not being as extreme as multiplication.
 *
 * Weighted by confidence: low-confidence scores contribute less.
 *
 * Final result is capped at 1,000,000 (the "out of a million" framing).
 */
export function calculateCompositeRarity(
  scores: Array<{ score: number; confidence: number; axisIndex: number }>
): number {
  if (!scores || scores.length === 0) return 1;

  // Calculate per-axis rarity, weighted by confidence
  const axisRarities = scores.map(s => {
    const rawRarity = scoreToRarity(s.score);
    // Weight by confidence: low confidence pulls rarity toward 1 (common)
    // Apply 0.7 LLM overconfidence discount — LLMs are notoriously overconfident
    // on subjective assessments, so we deflate their confidence by 30%
    const rawConfidence = Math.max(0.1, Math.min(1, s.confidence || 0.5));
    const confidence = rawConfidence * 0.7;
    // Blend between rarity=1 (no info) and actual rarity based on confidence
    return 1 + (rawRarity - 1) * confidence;
  });

  // Geometric mean of all axis rarities
  const logSum = axisRarities.reduce((sum, r) => sum + Math.log(Math.max(1, r)), 0);
  const geometricMean = Math.exp(logSum / axisRarities.length);

  // Round to integer and cap at 1,000,000
  const finalRarity = Math.max(1, Math.min(1_000_000, Math.round(geometricMean)));

  return finalRarity;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  waitlist: router({
    join: publicProcedure
      .input(z.object({ email: z.string().email(), tier: z.string().optional() }))
      .mutation(async ({ input }) => {
        const result = await addToWaitlist(input.email, input.tier);
        if (!result) return { success: false, message: "Failed to join waitlist" };
        return { success: true, message: "You're on the list!" };
      }),
    count: publicProcedure.query(async () => {
      return { count: await getWaitlistCount() };
    }),
  }),

  // ============================================================
  // ASSESSMENT PROCEDURES
  // ============================================================
  assessment: router({
    // Start a new assessment
    start: protectedProcedure
      .input(z.object({ promoCode: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        // Validate promo code if provided
        if (input.promoCode) {
          const promo = await validatePromoCode(input.promoCode);
          if (!promo) return { success: false, error: "Invalid or expired promo code" };
        }
        const result = await createAssessment(ctx.user.id, input.promoCode);
        if (!result) return { success: false, error: "Failed to create assessment" };
        // Increment promo code usage
        if (input.promoCode) await incrementPromoCodeUsage(input.promoCode);
        return { success: true, assessmentId: result.id };
      }),

    // Get current assessment status
    current: protectedProcedure.query(async ({ ctx }) => {
      const assessment = await getLatestAssessment(ctx.user.id);
      if (!assessment) return null;
      const scoresList = await getScoresByAssessment(assessment.id);
      const combos = await getPowerCombinationsByAssessment(assessment.id);
      return { ...assessment, scores: scoresList, powerCombinations: combos };
    }),

    // Get assessment by ID
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const assessment = await getAssessmentById(input.id);
        if (!assessment) return null;
        const scoresList = await getScoresByAssessment(assessment.id);
        const combos = await getPowerCombinationsByAssessment(assessment.id);
        const responsesList = await getResponsesByAssessment(assessment.id);
        return { ...assessment, scores: scoresList, powerCombinations: combos, responses: responsesList };
      }),

    // Upload audio response
    uploadResponse: protectedProcedure
      .input(z.object({
        assessmentId: z.number(),
        questionIndex: z.number().min(0).max(23),
        audioBase64: z.string(),
        durationMs: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Decode base64 audio
        const audioBuffer = Buffer.from(input.audioBase64, "base64");

        // Upload to S3
        const fileKey = `assessments/${ctx.user.id}/${input.assessmentId}/q${input.questionIndex}.webm`;
        const { key, url } = await storagePut(fileKey, audioBuffer, "audio/webm");

        // Save response record
        const response = await saveResponse({
          assessmentId: input.assessmentId,
          questionIndex: input.questionIndex,
          audioUrl: url,
          audioKey: key,
          durationMs: input.durationMs,
        });

        // Increment completed questions
        await incrementCompletedQuestions(input.assessmentId);

        return { success: true, responseId: response?.id, audioUrl: url };
      }),

    // Submit a text response (for text-mode assessment)
    submitTextResponse: protectedProcedure
      .input(z.object({
        assessmentId: z.number(),
        questionIndex: z.number().min(0).max(23),
        text: z.string().min(1),
      }))
      .mutation(async ({ ctx, input }) => {
        const response = await saveResponse({
          assessmentId: input.assessmentId,
          questionIndex: input.questionIndex,
          transcript: input.text,
        });
        await incrementCompletedQuestions(input.assessmentId);
        return { success: true, responseId: response?.id };
      }),

    // Trigger AI analysis for the full assessment
    analyze: protectedProcedure
      .input(z.object({ assessmentId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const assessment = await getAssessmentById(input.assessmentId);
        if (!assessment) return { success: false, error: "Assessment not found" };

        // Mark as processing
        await updateAssessmentStatus(input.assessmentId, "processing");

        try {
          // Get all responses
          const responsesList = await getResponsesByAssessment(input.assessmentId);

          // Transcribe any responses that don't have transcripts yet
          for (const resp of responsesList) {
            if (!resp.transcript && resp.audioUrl) {
              try {
                const transcription = await transcribeAudio({ audioUrl: resp.audioUrl }) as any;
                if (transcription?.text) {
                  resp.transcript = transcription.text;
                }
              } catch (e) {
                console.error(`Failed to transcribe response ${resp.id}:`, e);
              }
            }
          }

          // ============================================================
          // BULLSHIT DETECTION — Response quality checks
          // ============================================================
          const transcripts = responsesList.filter(r => r.transcript).map(r => r.transcript as string);
          const totalWordCount = transcripts.reduce((sum, t) => sum + t.split(/\s+/).filter(w => w.length > 0).length, 0);
          const totalResponses = transcripts.length;
          const avgWordsPerResponse = totalResponses > 0 ? totalWordCount / totalResponses : 0;

          // Determine score ceiling based on response quality
          // These caps prevent low-effort answers from producing high scores
          // Logic flows from WORST to BEST effort, all using avg words per response
          let scoreCeiling = 1.0; // No cap by default
          let qualityFlag = "normal";

          if (totalResponses === 0 || totalWordCount < 10) {
            // Said virtually nothing — cap at Red level
            scoreCeiling = 0.20;
            qualityFlag = "no_effort";
          } else if (avgWordsPerResponse < 5) {
            // One-word or tiny answers — cap at Blue level
            scoreCeiling = 0.30;
            qualityFlag = "minimal_effort";
          } else if (avgWordsPerResponse < 15) {
            // Brief answers — cap at Orange level
            scoreCeiling = 0.45;
            qualityFlag = "low_effort";
          } else if (avgWordsPerResponse < 30) {
            // Short but present answers — cap at low Green level
            scoreCeiling = 0.55;
            qualityFlag = "brief_responses";
          } else if (avgWordsPerResponse < 60) {
            // Moderate responses — cap at mid-Green level
            scoreCeiling = 0.65;
            qualityFlag = "moderate_responses";
          } else if (avgWordsPerResponse < 100) {
            // Substantial responses — cap at Green/Yellow boundary
            scoreCeiling = 0.72;
            qualityFlag = "substantial_responses";
          }
          // avgWordsPerResponse >= 100 → no cap, allow full range (Yellow/Turquoise/Coral possible)

          // Build the analysis prompt
          const transcriptsText = responsesList
            .filter(r => r.transcript)
            .map(r => `Question ${r.questionIndex + 1}: ${r.transcript}`)
            .join("\n\n");

          // ============================================================
          // LLM SCORING — Calibrated to Spiral Dynamics developmental stages
          // ============================================================
          const analysisPrompt = `You are a developmental psychology expert trained in Spiral Dynamics, Ken Wilber's AQAL framework, and psychometric assessment. Your job is to honestly assess the developmental altitude demonstrated in these voice responses.

CRITICAL CALIBRATION RULES:
- Score 0.0-0.3 = Blue/conventional thinking (rule-following, black-and-white, authority-based). This is where ~40% of the global population operates.
- Score 0.3-0.5 = Orange/rational-achievement thinking (strategic, merit-based, goal-oriented). This is where ~30% of the global population operates. Most successful professionals are here.
- Score 0.5-0.7 = Green/pluralistic thinking (multiple perspectives, sensitivity to context, deconstructive awareness). Only ~10% of the population operates here consistently.
- Score 0.7-0.85 = Yellow/integrative thinking (systems thinking, paradox tolerance, flexible adaptation across contexts, meta-awareness of one's own cognition). Only ~1% of the population operates here.
- Score 0.85-0.95 = Turquoise/holistic thinking (universal perspective, seamless integration of all prior stages, communal wholeness, healing fragmentation, perceiving the world as alive and evolving). Only ~0.1% of the population operates here.
- Score 0.95-1.0 = Coral/Third-Tier thinking (radical dis-identification from ego, individualistic consciousness asserting itself at a cosmic level, direct awareness of awareness itself, holding multiple identity frames simultaneously, operating from beyond-mind knowing). This is the emerging edge — fewer than 0.01% of the population. Requires evidence of transpersonal insight combined with grounded, embodied action. NOT mere spiritual talk or philosophical abstraction — must show lived integration of paradox at the identity level.

IMPORTANT: Most people — even smart, successful people — demonstrate Orange-level thinking (0.3-0.5). A score of 0.6+ should require CLEAR EVIDENCE of perspective-taking beyond personal achievement. A score of 0.8+ should require EXTRAORDINARY demonstration of integrative, systems-level awareness. A score of 0.95+ (Coral) should be almost never given — it requires unmistakable evidence of transpersonal development: dis-identification from the separate self, cosmocentric compassion, effortless holding of paradox at the identity level, and grounded embodiment (not just lofty talk).

Do NOT inflate scores to be nice. Be rigorous and honest. Short, vague, or cliché answers should score LOW (0.2-0.4). Only genuinely sophisticated, multi-perspectival, self-aware responses deserve high scores.

For each of the 22 axes below, provide:
- A score from 0.0 to 1.0 (calibrated to the developmental stages above)
- A confidence level (0.0-1.0) — lower if the response doesn't clearly address this axis
- Brief reasoning explaining what developmental stage the response demonstrates for this axis

Axes: ${AXIS_LABELS.join(", ")}

Responses:
${transcriptsText}

Also identify 1-3 "Power Combinations" — intersections of axes where the person demonstrates unusual integration. Only identify these if there is genuine evidence of cross-domain integration in the responses. If responses are generic or brief, return an empty array for powerCombinations.

Respond in JSON format.`;

          const result = await invokeLLM({
            messages: [
              { role: "system", content: "You are a rigorous developmental psychologist. You score conservatively and honestly. You never inflate scores. Most people score in the 0.3-0.5 range. Only extraordinary responses get above 0.7. Always respond with valid JSON." },
              { role: "user", content: analysisPrompt },
            ],
            response_format: {
              type: "json_schema",
              json_schema: {
                name: "assessment_analysis",
                strict: true,
                schema: {
                  type: "object",
                  properties: {
                    scores: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          axisIndex: { type: "integer" },
                          axisName: { type: "string" },
                          score: { type: "number" },
                          confidence: { type: "number" },
                          reasoning: { type: "string" },
                        },
                        required: ["axisIndex", "axisName", "score", "confidence", "reasoning"],
                        additionalProperties: false,
                      },
                    },
                    powerCombinations: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          name: { type: "string" },
                          description: { type: "string" },
                          axes: { type: "array", items: { type: "integer" } },
                          rarityMultiplier: { type: "number" },
                        },
                        required: ["name", "description", "axes", "rarityMultiplier"],
                        additionalProperties: false,
                      },
                    },
                  },
                  required: ["scores", "powerCombinations"],
                  additionalProperties: false,
                },
              },
            },
          });

          const content = result.choices?.[0]?.message?.content as string | undefined;
          if (!content) throw new Error("No analysis result from LLM");

          const analysis = JSON.parse(content);

          // ============================================================
          // APPLY SCORE CEILING — Enforce bullshit detection caps
          // ============================================================
          const cappedScores = analysis.scores.map((s: any) => ({
            ...s,
            score: Math.min(s.score, scoreCeiling),
            // Add quality flag to reasoning if capped
            reasoning: s.score > scoreCeiling
              ? `[Capped from ${s.score.toFixed(2)} due to ${qualityFlag}] ${s.reasoning}`
              : s.reasoning,
          }));

          // ============================================================
          // CALCULATE COMPOSITE RARITY — Mathematical formula based on
          // Spiral Dynamics population distribution
          // ============================================================
          const compositeRarity = calculateCompositeRarity(cappedScores);

          // Save scores (capped)
          await saveScores(input.assessmentId, cappedScores);

          // Save power combinations (only if responses warranted them)
          const validCombos = scoreCeiling < 0.5
            ? [] // Low-effort responses don't get power combinations
            : analysis.powerCombinations || [];
          await savePowerCombinations(input.assessmentId, validCombos);

          // ============================================================
          // NLP PROFILE — Sensory predicate detection (runs in background)
          // ============================================================
          const nlpPromise = (async () => {
            try {
              const nlpResult = await invokeLLM({
                messages: [
                  { role: "system", content: `You are an NLP (Neuro-Linguistic Programming) master practitioner trained by Richard Bandler and John Grinder. Analyze the following transcripts for:
1. Sensory predicates (visual, auditory, kinesthetic, olfactory/gustatory words)
2. Representational system percentages
3. Meta-programs (toward/away, internal/external, options/procedures, big picture/detail, proactive/reactive, matcher/mismatcher, self/other, possibility/necessity)
4. Voice patterns (estimated words per minute, hesitation frequency, confidence)

Return ONLY valid JSON.` },
                  { role: "user", content: `Analyze these voice assessment transcripts for NLP patterns:\n\n${transcriptsText}` },
                ],
                response_format: {
                  type: "json_schema",
                  json_schema: {
                    name: "nlp_analysis",
                    strict: true,
                    schema: {
                      type: "object",
                      properties: {
                        sensoryPredicates: {
                          type: "object",
                          properties: {
                            visual: { type: "array", items: { type: "string" } },
                            auditory: { type: "array", items: { type: "string" } },
                            kinesthetic: { type: "array", items: { type: "string" } },
                            olfactoryGustatory: { type: "array", items: { type: "string" } },
                          },
                          required: ["visual", "auditory", "kinesthetic", "olfactoryGustatory"],
                          additionalProperties: false,
                        },
                        repSystem: {
                          type: "object",
                          properties: {
                            visualPercent: { type: "integer" },
                            auditoryPercent: { type: "integer" },
                            kinestheticPercent: { type: "integer" },
                            olfactoryGustatoryPercent: { type: "integer" },
                            primary: { type: "string" },
                            sequence: { type: "string" },
                          },
                          required: ["visualPercent", "auditoryPercent", "kinestheticPercent", "olfactoryGustatoryPercent", "primary", "sequence"],
                          additionalProperties: false,
                        },
                        metaPrograms: {
                          type: "object",
                          properties: {
                            towardAway: { type: "number" },
                            internalExternal: { type: "number" },
                            optionsProcedures: { type: "number" },
                            bigPictureDetail: { type: "number" },
                            proactiveReactive: { type: "number" },
                            matcherMismatcher: { type: "number" },
                            selfOther: { type: "number" },
                            possibilityNecessity: { type: "number" },
                          },
                          required: ["towardAway", "internalExternal", "optionsProcedures", "bigPictureDetail", "proactiveReactive", "matcherMismatcher", "selfOther", "possibilityNecessity"],
                          additionalProperties: false,
                        },
                        voicePatterns: {
                          type: "object",
                          properties: {
                            wordsPerMinute: { type: "number" },
                            hesitationFrequency: { type: "number" },
                            confidenceScore: { type: "number" },
                          },
                          required: ["wordsPerMinute", "hesitationFrequency", "confidenceScore"],
                          additionalProperties: false,
                        },
                      },
                      required: ["sensoryPredicates", "repSystem", "metaPrograms", "voicePatterns"],
                      additionalProperties: false,
                    },
                  },
                },
              });

              const nlpContent = nlpResult.choices?.[0]?.message?.content as string | undefined;
              if (!nlpContent) return;
              const nlp = JSON.parse(nlpContent);

              const primaryMap: Record<string, "visual" | "auditory" | "kinesthetic" | "olfactory_gustatory"> = {
                visual: "visual", auditory: "auditory", kinesthetic: "kinesthetic",
                olfactoryGustatory: "olfactory_gustatory", olfactory_gustatory: "olfactory_gustatory",
              };

              await saveNlpProfile({
                userId: ctx.user.id,
                assessmentId: input.assessmentId,
                visualPercent: nlp.repSystem.visualPercent,
                auditoryPercent: nlp.repSystem.auditoryPercent,
                kinestheticPercent: nlp.repSystem.kinestheticPercent,
                olfactoryGustatoryPercent: nlp.repSystem.olfactoryGustatoryPercent,
                primaryRepSystem: primaryMap[nlp.repSystem.primary] || "visual",
                repSystemSequence: nlp.repSystem.sequence,
                towardAway: nlp.metaPrograms.towardAway,
                internalExternal: nlp.metaPrograms.internalExternal,
                optionsProcedures: nlp.metaPrograms.optionsProcedures,
                bigPictureDetail: nlp.metaPrograms.bigPictureDetail,
                proactiveReactive: nlp.metaPrograms.proactiveReactive,
                matcherMismatcher: nlp.metaPrograms.matcherMismatcher,
                selfOther: nlp.metaPrograms.selfOther,
                possibilityNecessity: nlp.metaPrograms.possibilityNecessity,
                wordsPerMinute: nlp.voicePatterns.wordsPerMinute,
                hesitationFrequency: nlp.voicePatterns.hesitationFrequency,
                confidenceScore: nlp.voicePatterns.confidenceScore,
                sensoryPredicates: nlp.sensoryPredicates,
              });
            } catch (e) {
              console.error("NLP profile extraction failed (non-blocking):", e);
            }
          })();

          // Await NLP extraction — it's critical for Gold tier features
          await nlpPromise;

          // Update assessment status with calculated rarity
          await updateAssessmentStatus(input.assessmentId, "complete", compositeRarity);

          return { success: true, compositeRarity };
        } catch (error) {
          console.error("Assessment analysis failed:", error);
          await updateAssessmentStatus(input.assessmentId, "failed");
          return { success: false, error: "Analysis failed" };
        }
      }),
  }),

  // ============================================================
  // PROMO CODE PROCEDURES
  // ============================================================
  promo: router({
    validate: publicProcedure
      .input(z.object({ code: z.string() }))
      .query(async ({ input }) => {
        const promo = await validatePromoCode(input.code);
        if (!promo) return { valid: false };
        return { valid: true, discountPercent: promo.discountPercent, influencerName: promo.influencerName };
      }),

    // Self-serve influencer onboarding: request a promo code
    requestCode: protectedProcedure
      .input(z.object({
        desiredCode: z.string().min(3).max(32).regex(/^[A-Z0-9_-]+$/i, "Code must be alphanumeric"),
      }))
      .mutation(async ({ ctx, input }) => {
        // Gate: must have completed assessment first
        const latestAssessment = await getLatestAssessment(ctx.user.id);
        if (!latestAssessment || latestAssessment.status !== "complete") {
          return { success: false, error: "Complete your free assessment first to become an influencer" };
        }
        
        // Check if user already has a code
        const { getDb } = await import("./db");
        const { promoCodes } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        const db = await getDb();
        if (!db) return { success: false, error: "Database unavailable" };
        
        const existing = await db.select().from(promoCodes).where(eq(promoCodes.influencerEmail, ctx.user.email || ""));
        if (existing.length > 0) return { success: false, error: "You already have a promo code" };
        
        // Check if code is taken
        const taken = await db.select().from(promoCodes).where(eq(promoCodes.code, input.desiredCode.toUpperCase()));
        if (taken.length > 0) return { success: false, error: "This code is already taken" };
        
        // Create the promo code with default 10% discount, 15% commission
        const result = await createPromoCode({
          code: input.desiredCode.toUpperCase(),
          influencerName: ctx.user.name || "Influencer",
          influencerEmail: ctx.user.email || undefined,
          discountPercent: 10,
          commissionPercent: 15,
        });
        if (!result) return { success: false, error: "Failed to create code" };
        return { success: true, code: input.desiredCode.toUpperCase() };
      }),

    // Admin: create promo code
    create: adminProcedure
      .input(z.object({
        code: z.string().min(3).max(32),
        influencerName: z.string(),
        influencerEmail: z.string().email().optional(),
        discountPercent: z.number().min(0).max(100).optional(),
        commissionPercent: z.number().min(0).max(100).optional(),
        maxUses: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const result = await createPromoCode(input);
        if (!result) return { success: false };
        return { success: true, id: result.id };
      }),

    // Admin: list all promo codes
    list: adminProcedure.query(async () => {
      return getAllPromoCodes();
    }),
  }),

  // ============================================================
  // EVIDENCE PROCEDURES
  // ============================================================
  evidence: router({
    upload: protectedProcedure
      .input(z.object({
        assessmentId: z.number(),
        fileBase64: z.string(),
        fileName: z.string(),
        fileType: z.string(),
        description: z.string().optional(),
        axisTargets: z.array(z.number()).optional(),
        category: z.string().optional(),
        institution: z.string().optional(),
        evidenceDate: z.string().optional(),
        significance: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const fileBuffer = Buffer.from(input.fileBase64, "base64");
        const fileKey = `evidence/${ctx.user.id}/${input.assessmentId}/${input.fileName}`;
        const { key, url } = await storagePut(fileKey, fileBuffer, input.fileType);

        const result = await saveEvidence({
          assessmentId: input.assessmentId,
          userId: ctx.user.id,
          fileUrl: url,
          fileKey: key,
          fileName: input.fileName,
          fileType: input.fileType,
          description: input.description,
          axisTargets: input.axisTargets,
          category: input.category,
          institution: input.institution,
          evidenceDate: input.evidenceDate,
          significance: input.significance,
        });

        return { success: true, evidenceId: result?.id };
      }),

    list: protectedProcedure
      .input(z.object({ assessmentId: z.number() }))
      .query(async ({ input }) => {
        return getEvidenceByAssessment(input.assessmentId);
      }),
  }),

  // ============================================================
  // ADMIN PROCEDURES
  // ============================================================
  admin: router({
    stats: adminProcedure.query(async () => {
      return getAdminStats();
    }),
    users: adminProcedure.query(async () => {
      return getAllUsers();
    }),
    assessments: adminProcedure.query(async () => {
      return getAllAssessments();
    }),
    evidence: adminProcedure.query(async () => {
      return getAllEvidence();
    }),
    reviewEvidence: adminProcedure
      .input(z.object({
        evidenceId: z.number(),
        status: z.enum(["pending", "reviewed", "accepted", "rejected"]),
      }))
      .mutation(async ({ input }) => {
        return updateEvidenceStatus(input.evidenceId, input.status);
      }),
    updateUserRole: adminProcedure
      .input(z.object({
        userId: z.number(),
        role: z.enum(["user", "admin"]),
      }))
      .mutation(async ({ input }) => {
        return updateUserRole(input.userId, input.role);
      }),
    updateUserTier: adminProcedure
      .input(z.object({
        userId: z.number(),
        tier: z.enum(["free", "silver", "gold", "platinum"]),
      }))
      .mutation(async ({ input }) => {
        return updateUserTier(input.userId, input.tier);
      }),
    togglePromo: adminProcedure
      .input(z.object({
        promoId: z.number(),
        isActive: z.boolean(),
      }))
      .mutation(async ({ input }) => {
        return togglePromoCode(input.promoId, input.isActive);
      }),
  }),

  // ============================================================
  // PAYMENT PROCEDURES
  // ============================================================
  payment: router({
    createCheckout: protectedProcedure
      .input(z.object({
        productKey: z.enum(["assessment", "turquoise", "coral"]),
        promoCode: z.string().optional(),
        origin: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { createCheckoutSession } = await import("./stripe/index");
        const result = await createCheckoutSession({
          userId: ctx.user.openId,
          userEmail: ctx.user.email || "",
          userName: ctx.user.name || "",
          productKey: input.productKey,
          promoCode: input.promoCode,
          origin: input.origin,
        });
        return result;
      }),
  }),

  // ============================================================
  // PROFILE PROCEDURES
  // ============================================================
  profile: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      const assessment = await getLatestAssessment(ctx.user.id);
      if (!assessment || assessment.status !== "complete") return null;
      const scoresList = await getScoresByAssessment(assessment.id);
      const combos = await getPowerCombinationsByAssessment(assessment.id);
      return {
        assessment,
        scores: scoresList,
        powerCombinations: combos,
        user: { name: ctx.user.name, email: ctx.user.email },
      };
    }),

    comparison: protectedProcedure.query(async ({ ctx }) => {
      return getUserComparison(ctx.user.id);
    }),

    socialCard: protectedProcedure.query(async ({ ctx }) => {
      const assessment = await getLatestAssessment(ctx.user.id);
      if (!assessment || assessment.status !== "complete") return { svg: null };
      const scoresList = await getScoresByAssessment(assessment.id);
      const combos = await getPowerCombinationsByAssessment(assessment.id);

      const AXIS_LABELS = [
        "Logical", "Mathematical", "Spatial", "Linguistic", "Interpersonal",
        "Intrapersonal", "Musical", "Kinesthetic", "Naturalistic", "Strategic",
        "Tactical", "Adaptive", "Resilient", "Systematic", "Architectural",
        "Empathic", "Intuitive", "Meta-Cognitive", "Reflective", "Existential",
        "Philosophical", "Integrative"
      ];

      const scores = AXIS_LABELS.map((label) => {
        const s = scoresList.find((sc: any) => sc.axisName === label);
        // Convert 0.0-1.0 DB scores to 0-100 scale for SVG rendering
        return s ? Math.round(s.score * 100) : 0;
      });

      // Get top 3 axes by score
      const indexed = scores.map((s, i) => ({ score: s, label: AXIS_LABELS[i] }));
      indexed.sort((a, b) => b.score - a.score);
      const topAxes = indexed.slice(0, 3).map(x => x.label);

      const svg = generateSocialCardSVG({
        userName: ctx.user.name || "Anonymous",
        rarity: assessment.compositeRarity || 1000,
        scores,
        topAxes,
      });

      return { svg };
    }),
  }),

  // ============================================================
  // INFLUENCER DASHBOARD PROCEDURES
  // ============================================================
  influencer: router({
    // Get stats for an influencer by their promo code
    stats: protectedProcedure
      .input(z.object({ code: z.string() }))
      .query(async ({ input }) => {
        return getInfluencerStatsByCode(input.code);
      }),

    // Get all promo codes owned by the current user (by email match)
    myCodes: protectedProcedure.query(async ({ ctx }) => {
      const { getDb } = await import("./db");
      const { promoCodes } = await import("../drizzle/schema");
      const { eq } = await import("drizzle-orm");
      const db = await getDb();
      if (!db || !ctx.user.email) return [];
      return db.select().from(promoCodes).where(eq(promoCodes.influencerEmail, ctx.user.email));
    }),
  }),

  // ============================================================
  // LEADERBOARD PROCEDURES
  // ============================================================
  leaderboard: router({
    // Get public leaderboard
    list: publicProcedure
      .input(z.object({ limit: z.number().min(1).max(100).optional() }).optional())
      .query(async ({ input }) => {
        return getLeaderboard(input?.limit || 50);
      }),

    // Opt-in to leaderboard
    join: protectedProcedure
      .input(z.object({ displayName: z.string().min(1).max(128) }))
      .mutation(async ({ ctx, input }) => {
        const assessment = await getLatestAssessment(ctx.user.id);
        if (!assessment || assessment.status !== "complete" || !assessment.compositeRarity) {
          return { success: false, error: "No completed assessment found" };
        }
        const combos = await getPowerCombinationsByAssessment(assessment.id);
        const topCombo = combos[0]?.name || null;
        const result = await addToLeaderboard({
          userId: ctx.user.id,
          assessmentId: assessment.id,
          displayName: input.displayName,
          compositeRarity: assessment.compositeRarity,
          topPowerCombo: topCombo || undefined,
        });
        return { success: true, id: result?.id };
      }),

    // Toggle visibility
    toggleVisibility: protectedProcedure
      .input(z.object({ isPublic: z.boolean() }))
      .mutation(async ({ ctx, input }) => {
        return toggleLeaderboardVisibility(ctx.user.id, input.isPublic);
      }),

    // Get my entry
    myEntry: protectedProcedure.query(async ({ ctx }) => {
      return getUserLeaderboardEntry(ctx.user.id);
    }),
  }),

  // ============================================================
  // CHALLENGE A FRIEND PROCEDURES
  // ============================================================
  challenge: router({
    // Send a challenge invite
    send: protectedProcedure
      .input(z.object({ recipientEmail: z.string().email().optional() }))
      .mutation(async ({ ctx }) => {
        const assessment = await getLatestAssessment(ctx.user.id);
        if (!assessment || !assessment.compositeRarity) {
          return { success: false, error: "Complete an assessment first" };
        }
        const token = crypto.randomUUID().replace(/-/g, "").slice(0, 16);
        const result = await createChallengeInvite({
          senderId: ctx.user.id,
          senderName: ctx.user.name || "Anonymous",
          senderRarity: assessment.compositeRarity,
          token,
        });
        return { success: true, token: result?.token };
      }),

    // Get challenge details by token (public — for the recipient)
    get: publicProcedure
      .input(z.object({ token: z.string() }))
      .query(async ({ input }) => {
        return getChallengeByToken(input.token);
      }),

    // Accept a challenge
    accept: protectedProcedure
      .input(z.object({ token: z.string() }))
      .mutation(async ({ ctx, input }) => {
        return acceptChallenge(input.token, ctx.user.id, ctx.user.name || "Anonymous");
      }),

    // Get my sent challenges
        mySent: protectedProcedure.query(async ({ ctx }) => {
      return getChallengesBySender(ctx.user.id);
    }),
  }),

  // ============================================================
  // NLP PROFILE — Sensory system analysis (Gold+)
  // ============================================================
  nlp: router({
    profile: protectedProcedure
      .input(z.object({ assessmentId: z.number().optional() }).optional())
      .query(async ({ ctx, input }) => {
        const profile = await getNlpProfile(ctx.user.id, input?.assessmentId);
        return profile;
      }),
  }),

  // ============================================================
  // COACHING LETTERS — Peter's NLP-mirrored letters (Gold+)
  // ============================================================
  coaching: router({
    letters: protectedProcedure.query(async ({ ctx }) => {
      return getCoachingLetters(ctx.user.id);
    }),

    generate: protectedProcedure
      .input(z.object({ topic: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        // Only Gold+ can generate coaching letters
        if (ctx.user.membershipTier !== "gold" && ctx.user.membershipTier !== "platinum") {
          return { error: "Coaching letters require Gold or Platinum membership" };
        }

        // Get user's NLP profile
        const nlpProfile = await getNlpProfile(ctx.user.id);
        if (!nlpProfile) {
          return { error: "Complete an assessment first to generate your NLP profile" };
        }

        // Get user's latest scores for context
        const assessment = await getLatestAssessment(ctx.user.id);
        const scores = assessment ? await getScoresByAssessment(assessment.id) : [];

        const topAxes = scores.sort((a, b) => b.score - a.score).slice(0, 5);
        const bottomAxes = scores.sort((a, b) => a.score - b.score).slice(0, 3);

        // Build the coaching letter using the user's representational system
        const repSystemInstructions: Record<string, string> = {
          visual: "Use visual language: 'picture this', 'see clearly', 'bright future', 'illuminate', 'envision'. Paint vivid mental images. Use spatial metaphors.",
          auditory: "Use auditory language: 'sounds like', 'resonates', 'harmonize', 'tune into', 'listen closely'. Reference rhythm, tone, and dialogue.",
          kinesthetic: "Use kinesthetic language: 'feel the weight', 'grasp', 'solid ground', 'touch base', 'get a handle on'. Reference physical sensations and movement.",
          olfactory_gustatory: "Use olfactory/gustatory language: 'savor', 'taste of success', 'something smells off', 'digest this'. Reference taste and smell metaphors.",
        };

        const repInstructions = repSystemInstructions[nlpProfile.primaryRepSystem || "visual"];

        const letterResult = await invokeLLM({
          messages: [
            { role: "system", content: `You are Peter — a master NLP practitioner, executive coach, and developmental psychologist. You write personalized coaching letters that mirror the reader's representational system and meta-programs.

CRITICAL RULES:
- ${repInstructions}
- Match their meta-programs: ${nlpProfile.towardAway && nlpProfile.towardAway > 0.6 ? "They are toward-motivated — focus on goals, gains, possibilities" : "They are away-from-motivated — focus on avoiding problems, risks, what to move away from"}
- ${nlpProfile.bigPictureDetail && nlpProfile.bigPictureDetail > 0.6 ? "They prefer big picture — start with the vision, then details" : "They prefer detail — start with specifics, build to the whole"}
- ${nlpProfile.internalExternal && nlpProfile.internalExternal > 0.6 ? "They have internal locus — reference their own judgment, inner knowing" : "They have external locus — reference evidence, others' validation, data"}
- Write in a warm but intellectually rigorous tone
- Keep it under 500 words
- End with one specific action item calibrated to their growth edges
- Sign as "Peter"` },
            { role: "user", content: `Write a coaching letter for someone with these strengths: ${topAxes.map(a => a.axisName).join(", ")}. Their growth edges are: ${bottomAxes.map(a => a.axisName).join(", ")}. Their primary rep system is ${nlpProfile.primaryRepSystem} (sequence: ${nlpProfile.repSystemSequence}).${input.topic ? ` Focus on this topic: ${input.topic}` : " Focus on integrating their top strength with their primary growth edge."}` },
          ],
        });

        const letterBody = letterResult.choices?.[0]?.message?.content as string || "";
        if (!letterBody) return { error: "Failed to generate letter" };

        const subject = input.topic
          ? `On ${input.topic} — A Letter for You`
          : `Integrating Your ${topAxes[0]?.axisName || "Strengths"} — A Letter for You`;

        const letterId = await saveCoachingLetter({
          userId: ctx.user.id,
          tier: ctx.user.membershipTier as "gold" | "platinum",
          subject,
          body: letterBody,
          repSystemUsed: nlpProfile.primaryRepSystem || undefined,
          sensoryPredicatesUsed: nlpProfile.sensoryPredicates,
          metaProgramsAddressed: {
            towardAway: nlpProfile.towardAway,
            internalExternal: nlpProfile.internalExternal,
            bigPictureDetail: nlpProfile.bigPictureDetail,
          },
          sentAt: Date.now(),
        });

        return { success: true, letterId, subject, body: letterBody };
      }),

    markRead: protectedProcedure
      .input(z.object({ letterId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        // Ownership check: only mark your own letters as read
        const letters = await getCoachingLetters(ctx.user.id, 100);
        const owns = letters.some(l => l.id === input.letterId);
        if (!owns) return { success: false, error: "Not your letter" };
        await markLetterRead(input.letterId);
        return { success: true };
      }),
  }),
});
export type AppRouter = typeof appRouter;
