import { describe, it, expect } from "vitest";
import { PRODUCTS } from "./stripe/products";

describe("Stripe Products Configuration", () => {
  it("assessment product is priced at $299 (29900 cents)", () => {
    expect(PRODUCTS.assessment.price).toBe(29900);
    expect(PRODUCTS.assessment.mode).toBe("payment");
  });

  it("assessment product includes correct founding member naming", () => {
    expect(PRODUCTS.assessment.name).toContain("Founding Member");
  });

  it("turquoise circle is a monthly subscription at $149", () => {
    expect(PRODUCTS.turquoise.price).toBe(14900);
    expect(PRODUCTS.turquoise.mode).toBe("subscription");
    expect(PRODUCTS.turquoise.interval).toBe("month");
  });

  it("coral circle is a monthly subscription at $499", () => {
    expect(PRODUCTS.coral.price).toBe(49900);
    expect(PRODUCTS.coral.mode).toBe("subscription");
    expect(PRODUCTS.coral.interval).toBe("month");
  });

  it("only has assessment, turquoise, and coral product keys", () => {
    const keys = Object.keys(PRODUCTS);
    expect(keys).toEqual(["assessment", "turquoise", "coral"]);
    expect(keys).not.toContain("silver");
    expect(keys).not.toContain("gold");
    expect(keys).not.toContain("platinum");
  });
});
