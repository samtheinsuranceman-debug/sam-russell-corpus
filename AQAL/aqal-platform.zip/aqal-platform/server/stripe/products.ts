// AQAL Intelligence Platform — Stripe Product Configuration
// Simplified: single $299 founding-member assessment + network circle upgrades

export const PRODUCTS = {
  assessment: {
    name: "AQAL Intelligence Assessment — Founding Member",
    description: "Complete 22-axis voice intelligence assessment with Five-AI consensus scoring, rarity underwriting report, and Yellow Circle network access.",
    price: 29900, // $299.00 in cents (founding member rate, normally $499)
    mode: "payment" as const,
  },
  // Network Circle upgrades — post-assessment upsells
  turquoise: {
    name: "AQAL Turquoise Circle",
    description: "5 curated introductions per month, group masterminds, and growth tracking.",
    price: 14900, // $149.00/month in cents
    mode: "subscription" as const,
    interval: "month" as const,
  },
  coral: {
    name: "AQAL Coral Circle",
    description: "Concierge matching, private events, executive briefings, and unlimited introductions.",
    price: 49900, // $499.00/month in cents
    mode: "subscription" as const,
    interval: "month" as const,
  },
} as const;

export type ProductKey = keyof typeof PRODUCTS;
