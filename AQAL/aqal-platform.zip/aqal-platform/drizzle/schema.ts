import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json, float, bigint } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
  stripeCustomerId: varchar("stripe_customer_id", { length: 255 }),
  stripeSubscriptionId: varchar("stripe_subscription_id", { length: 255 }),
  membershipTier: mysqlEnum("membership_tier", ["free", "silver", "gold", "platinum"]).default("free").notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Waitlist signups
export const waitlist = mysqlTable("waitlist", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  tier: varchar("tier", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WaitlistEntry = typeof waitlist.$inferSelect;
export type InsertWaitlistEntry = typeof waitlist.$inferInsert;

// ============================================================
// ASSESSMENTS — One per user attempt
// ============================================================
export const assessments = mysqlTable("assessments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  status: mysqlEnum("status", ["in_progress", "processing", "complete", "failed"]).default("in_progress").notNull(),
  totalQuestions: int("totalQuestions").default(24).notNull(),
  completedQuestions: int("completedQuestions").default(0).notNull(),
  compositeRarity: int("compositeRarity"), // e.g. 47000 means "1 in 47,000"
  promoCode: varchar("promoCode", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Assessment = typeof assessments.$inferSelect;
export type InsertAssessment = typeof assessments.$inferInsert;

// ============================================================
// RESPONSES — One per question per assessment
// ============================================================
export const responses = mysqlTable("responses", {
  id: int("id").autoincrement().primaryKey(),
  assessmentId: int("assessmentId").notNull(),
  questionIndex: int("questionIndex").notNull(), // 0-23
  audioUrl: text("audioUrl"), // S3 storage URL
  audioKey: varchar("audioKey", { length: 256 }),
  transcript: text("transcript"),
  durationMs: int("durationMs"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Response = typeof responses.$inferSelect;
export type InsertResponse = typeof responses.$inferInsert;

// ============================================================
// SCORES — 22 axis scores per assessment
// ============================================================
export const scores = mysqlTable("scores", {
  id: int("id").autoincrement().primaryKey(),
  assessmentId: int("assessmentId").notNull(),
  axisIndex: int("axisIndex").notNull(), // 0-21
  axisName: varchar("axisName", { length: 64 }).notNull(),
  score: float("score").notNull(), // 0.0 to 1.0
  confidence: float("confidence"), // AI confidence level
  reasoning: text("reasoning"), // AI reasoning for this score
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Score = typeof scores.$inferSelect;
export type InsertScore = typeof scores.$inferInsert;

// ============================================================
// POWER COMBINATIONS — Detected multi-axis strengths
// ============================================================
export const powerCombinations = mysqlTable("power_combinations", {
  id: int("id").autoincrement().primaryKey(),
  assessmentId: int("assessmentId").notNull(),
  name: varchar("name", { length: 128 }).notNull(), // e.g. "Strategic Visionary"
  description: text("description"),
  axes: text("axes"), // JSON array of axis indices
  rarityMultiplier: float("rarityMultiplier"), // How much rarer this combo makes them
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PowerCombination = typeof powerCombinations.$inferSelect;
export type InsertPowerCombination = typeof powerCombinations.$inferInsert;

// ============================================================
// PROMO CODES — Influencer referral system
// ============================================================
export const promoCodes = mysqlTable("promo_codes", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(),
  influencerName: varchar("influencerName", { length: 128 }).notNull(),
  influencerEmail: varchar("influencerEmail", { length: 320 }),
  discountPercent: int("discountPercent").default(0).notNull(), // 0-100
  commissionPercent: int("commissionPercent").default(10).notNull(), // Revenue share %
  usageCount: int("usageCount").default(0).notNull(),
  maxUses: int("maxUses"), // null = unlimited
  isActive: int("isActive").default(1).notNull(), // 1 = active, 0 = disabled
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PromoCode = typeof promoCodes.$inferSelect;
export type InsertPromoCode = typeof promoCodes.$inferInsert;

// ============================================================
// EVIDENCE — Uploaded artifacts to boost scores
// ============================================================
export const evidence = mysqlTable("evidence", {
  id: int("id").autoincrement().primaryKey(),
  assessmentId: int("assessmentId").notNull(),
  userId: int("userId").notNull(),
  fileUrl: text("fileUrl").notNull(),
  fileKey: varchar("fileKey", { length: 256 }).notNull(),
  fileName: varchar("fileName", { length: 256 }),
  fileType: varchar("fileType", { length: 64 }), // pdf, image, video, etc.
  category: varchar("category", { length: 64 }), // cognitive, creative, interpersonal, etc.
  description: text("description"),
  axisTargets: text("axisTargets"), // JSON array of axis indices this evidence supports
  institution: varchar("institution", { length: 256 }), // e.g. MIT, Google, etc.
  evidenceDate: varchar("evidence_date", { length: 32 }), // YYYY-MM-DD or YYYY
  significance: text("significance"), // brief note on why this matters
  status: mysqlEnum("evidenceStatus", ["pending", "reviewed", "accepted", "rejected"]).default("pending").notNull(),
  reviewerNotes: text("reviewer_notes"), // feedback from reviewer
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Evidence = typeof evidence.$inferSelect;
export type InsertEvidence = typeof evidence.$inferInsert;

// ============================================================
// NLP PROFILES — Silent NLP metadata extracted during scoring
// ============================================================
export const nlpProfiles = mysqlTable("nlp_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  assessmentId: int("assessmentId").notNull(),

  // Representational System
  visualPercent: int("visualPercent").default(0).notNull(),
  auditoryPercent: int("auditoryPercent").default(0).notNull(),
  kinestheticPercent: int("kinestheticPercent").default(0).notNull(),
  olfactoryGustatoryPercent: int("olfactoryGustatoryPercent").default(0).notNull(),
  primaryRepSystem: mysqlEnum("primaryRepSystem", ["visual", "auditory", "kinesthetic", "olfactory_gustatory"]),
  repSystemSequence: varchar("repSystemSequence", { length: 20 }), // e.g. "V-K-A"

  // Meta-Programs (0.0 = left pole, 1.0 = right pole)
  towardAway: float("towardAway"), // 0=away, 1=toward
  internalExternal: float("internalExternal"), // 0=external, 1=internal
  optionsProcedures: float("optionsProcedures"), // 0=procedures, 1=options
  bigPictureDetail: float("bigPictureDetail"), // 0=detail, 1=big picture
  proactiveReactive: float("proactiveReactive"), // 0=reactive, 1=proactive
  matcherMismatcher: float("matcherMismatcher"), // 0=mismatcher, 1=matcher
  selfOther: float("selfOther"), // 0=other, 1=self
  possibilityNecessity: float("possibilityNecessity"), // 0=necessity, 1=possibility

  // Voice Patterns
  wordsPerMinute: float("wordsPerMinute"),
  avgPauseDurationMs: int("avgPauseDurationMs"),
  hesitationFrequency: float("hesitationFrequency"),
  confidenceScore: float("confidenceScore"),

  // Sensory Predicates (raw extracted JSON)
  sensoryPredicates: json("sensoryPredicates"), // {"visual": [...], "auditory": [...], ...}

  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type NlpProfile = typeof nlpProfiles.$inferSelect;
export type InsertNlpProfile = typeof nlpProfiles.$inferInsert;

// ============================================================
// COACHING LETTERS — Peter's NLP-mirrored weekly letters (Gold+)
// ============================================================
export const coachingLetters = mysqlTable("coaching_letters", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  tier: mysqlEnum("letterTier", ["silver", "gold", "platinum"]).notNull(),

  // Content
  subject: varchar("subject", { length: 200 }).notNull(),
  body: text("body").notNull(),

  // NLP calibration used
  repSystemUsed: varchar("repSystemUsed", { length: 20 }),
  sensoryPredicatesUsed: json("sensoryPredicatesUsed"),
  metaProgramsAddressed: json("metaProgramsAddressed"),

  sentAt: bigint("sentAt", { mode: "number" }),
  readAt: bigint("readAt", { mode: "number" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CoachingLetter = typeof coachingLetters.$inferSelect;
export type InsertCoachingLetter = typeof coachingLetters.$inferInsert;

// ============================================================
// REFERRAL PAYMENTS — Revenue share tracking per influencer
// ============================================================
export const referralPayments = mysqlTable("referral_payments", {
  id: int("id").autoincrement().primaryKey(),
  promoCodeId: int("promoCodeId").notNull(),
  userId: int("userId").notNull(), // The user who paid
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }),
  amountCents: int("amountCents").notNull(), // Total payment amount
  commissionCents: int("commissionCents").notNull(), // Influencer's share
  commissionPercent: int("commissionPercent").notNull(),
  status: mysqlEnum("referralStatus", ["pending", "paid", "cancelled"]).default("pending").notNull(),
  paidAt: bigint("paidAt", { mode: "number" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ReferralPayment = typeof referralPayments.$inferSelect;
export type InsertReferralPayment = typeof referralPayments.$inferInsert;

// ============================================================
// LEADERBOARD — Opt-in public rarity rankings
// ============================================================
export const leaderboardEntries = mysqlTable("leaderboard_entries", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  assessmentId: int("assessmentId").notNull(),
  displayName: varchar("displayName", { length: 128 }).notNull(),
  compositeRarity: int("compositeRarity").notNull(), // Higher = rarer
  topPowerCombo: varchar("topPowerCombo", { length: 128 }),
  isPublic: int("isPublic").default(1).notNull(), // 1 = visible, 0 = hidden
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LeaderboardEntry = typeof leaderboardEntries.$inferSelect;
export type InsertLeaderboardEntry = typeof leaderboardEntries.$inferInsert;

// ============================================================
// CHALLENGE INVITES — "Challenge a Friend" viral mechanic
// ============================================================
export const challengeInvites = mysqlTable("challenge_invites", {
  id: int("id").autoincrement().primaryKey(),
  senderId: int("senderId").notNull(),
  senderName: varchar("senderName", { length: 128 }).notNull(),
  senderRarity: int("senderRarity").notNull(),
  recipientEmail: varchar("recipientEmail", { length: 320 }),
  recipientId: int("recipientId"),
  recipientName: varchar("recipientName", { length: 128 }),
  recipientRarity: int("recipientRarity"),
  token: varchar("token", { length: 64 }).notNull().unique(),
  status: mysqlEnum("challengeStatus", ["pending", "accepted", "completed", "expired"]).default("pending").notNull(),
  acceptedAt: bigint("acceptedAt", { mode: "number" }),
  completedAt: bigint("completedAt", { mode: "number" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChallengeInvite = typeof challengeInvites.$inferSelect;
export type InsertChallengeInvite = typeof challengeInvites.$inferInsert;
