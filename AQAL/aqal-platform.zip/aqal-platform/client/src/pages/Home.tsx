import { Button } from "@/components/ui/button";
import { motion, useInView } from "framer-motion";
import { useEffect, useRef, useState, useCallback, useMemo } from "react";
import { Mic } from "lucide-react";
import { Link } from "wouter";
import { playClick } from "@/lib/audio";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { useParallax } from "@/hooks/useParallax";
import { PrefetchLink } from "@/components/PrefetchLink";
import { PublicHeader, PublicFooter } from "@/components/PublicLayout";


// ============================================================
// AQAL FOUR-QUADRANT DIAGRAM — I, IT, WE, ITS
// Animated concentric rings with four quadrant labels.
// Accurately represents what we measure across 22 dimensions.
// ============================================================
function AQALQuadrants() {
  return (
    <div className="relative w-full max-w-[420px] mx-auto" style={{ perspective: '800px' }}>
      {/* Deep glow — quadrant energy */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <motion.div
          className="w-[360px] h-[360px] rounded-full"
          style={{ background: 'radial-gradient(circle, oklch(0.5 0.15 240 / 0.12) 0%, transparent 70%)' }}
          animate={{ scale: [1, 1.1, 1], opacity: [0.5, 0.9, 0.5] }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
        />
      </div>

      {/* 3D subtle rotation */}
      <motion.div
        style={{ transformStyle: 'preserve-3d' }}
        animate={{ rotateY: [0, 2, 0, -2, 0], rotateX: [0, -1.5, 0, 1.5, 0] }}
        transition={{ duration: 24, repeat: Infinity, ease: 'easeInOut' }}
      >
        <svg viewBox="0 0 400 400" className="w-full relative z-10">
          {/* Concentric developmental rings */}
          {[140, 115, 90, 65, 40].map((r, i) => (
            <motion.circle
              key={`ring-${i}`}
              cx={200} cy={200} r={r}
              fill="none"
              stroke={`oklch(${0.45 + i * 0.08} 0.12 ${220 + i * 20})`}
              strokeWidth={i === 0 ? 0.8 : 0.4}
              strokeDasharray={i === 0 ? 'none' : `${3 + i} ${4 + i * 2}`}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 0.5 + i * 0.1, scale: 1 }}
              transition={{ duration: 1, delay: 0.3 + i * 0.2, ease: [0.23, 1, 0.32, 1] }}
            />
          ))}

          {/* Outer rotating ring */}
          <motion.circle
            cx={200} cy={200} r={160}
            fill="none"
            stroke="oklch(0.5 0.12 240)"
            strokeWidth="0.4"
            strokeDasharray="2 8"
            animate={{ rotate: 360 }}
            transition={{ duration: 60, repeat: Infinity, ease: 'linear' }}
            style={{ transformOrigin: '200px 200px' }}
          />

          {/* Cross-hair axes */}
          <motion.line
            x1={200} y1={45} x2={200} y2={355}
            stroke="oklch(0.6 0.08 240)"
            strokeWidth="1"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 0.7 }}
            transition={{ duration: 1.5, delay: 0.5 }}
          />
          <motion.line
            x1={45} y1={200} x2={355} y2={200}
            stroke="oklch(0.6 0.08 240)"
            strokeWidth="1"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 0.7 }}
            transition={{ duration: 1.5, delay: 0.7 }}
          />

          {/* Quadrant fill glows */}
          <motion.rect x={45} y={45} width={155} height={155} rx={4}
            fill="oklch(0.5 0.15 280)" fillOpacity={0.04}
            animate={{ fillOpacity: [0.03, 0.07, 0.03] }}
            transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
          />
          <motion.rect x={200} y={45} width={155} height={155} rx={4}
            fill="oklch(0.5 0.15 195)" fillOpacity={0.04}
            animate={{ fillOpacity: [0.03, 0.07, 0.03] }}
            transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut', delay: 1.5 }}
          />
          <motion.rect x={45} y={200} width={155} height={155} rx={4}
            fill="oklch(0.6 0.15 85)" fillOpacity={0.04}
            animate={{ fillOpacity: [0.03, 0.07, 0.03] }}
            transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut', delay: 3 }}
          />
          <motion.rect x={200} y={200} width={155} height={155} rx={4}
            fill="oklch(0.5 0.15 150)" fillOpacity={0.04}
            animate={{ fillOpacity: [0.03, 0.07, 0.03] }}
            transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut', delay: 4.5 }}
          />

          {/* Center integrative point */}
          <motion.circle
            cx={200} cy={200} r={6}
            fill="oklch(0.9 0.18 85)"
            fillOpacity={0.2}
            stroke="oklch(0.9 0.18 85)"
            strokeWidth="1"
            animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
          />
          <motion.circle cx={200} cy={200} r={2.5} fill="oklch(0.95 0.15 85)"
            animate={{ scale: [1, 1.4, 1] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut', delay: 0.5 }}
          />

          {/* Energy pulse along axes */}
          <motion.circle r={4} fill="oklch(0.8 0.2 240)"
            animate={{ opacity: [0, 0.8, 0], cy: [200, 60, 200] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
            cx={200}
          />
          <motion.circle r={4} fill="oklch(0.8 0.2 195)"
            animate={{ opacity: [0, 0.8, 0], cx: [200, 340, 200] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
            cy={200}
          />
          <motion.circle r={4} fill="oklch(0.75 0.15 85)"
            animate={{ opacity: [0, 0.8, 0], cy: [200, 340, 200] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut', delay: 2 }}
            cx={200}
          />
          <motion.circle r={4} fill="oklch(0.7 0.15 150)"
            animate={{ opacity: [0, 0.8, 0], cx: [200, 60, 200] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut', delay: 3 }}
            cy={200}
          />

          {/* QUADRANT LABELS */}
          {/* UL — I */}
          <motion.text x={120} y={85} textAnchor="middle"
            fill="oklch(0.9 0.18 280)" fontSize="18" fontFamily="'Orbitron', sans-serif"
            fontWeight="bold" letterSpacing="0.15em"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.2 }}
          >I</motion.text>
          <motion.text x={120} y={105} textAnchor="middle"
            fill="oklch(0.85 0.12 280)" fontSize="9" fontWeight="600" fontFamily="'Inter', sans-serif"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.5 }}
          >How You Think</motion.text>

          {/* UR — IT */}
          <motion.text x={280} y={85} textAnchor="middle"
            fill="oklch(0.9 0.16 195)" fontSize="18" fontFamily="'Orbitron', sans-serif"
            fontWeight="bold" letterSpacing="0.15em"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.4 }}
          >IT</motion.text>
          <motion.text x={280} y={105} textAnchor="middle"
            fill="oklch(0.85 0.12 195)" fontSize="9" fontWeight="600" fontFamily="'Inter', sans-serif"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.7 }}
          >How You Show Up</motion.text>

          {/* LL — WE */}
          <motion.text x={120} y={320} textAnchor="middle"
            fill="oklch(0.9 0.15 85)" fontSize="18" fontFamily="'Orbitron', sans-serif"
            fontWeight="bold" letterSpacing="0.15em"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.6 }}
          >WE</motion.text>
          <motion.text x={120} y={340} textAnchor="middle"
            fill="oklch(0.85 0.12 85)" fontSize="9" fontWeight="600" fontFamily="'Inter', sans-serif"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.9 }}
          >How You Connect</motion.text>

          {/* LR — ITS */}
          <motion.text x={280} y={320} textAnchor="middle"
            fill="oklch(0.9 0.14 150)" fontSize="18" fontFamily="'Orbitron', sans-serif"
            fontWeight="bold" letterSpacing="0.15em"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.8 }}
          >ITS</motion.text>
          <motion.text x={280} y={340} textAnchor="middle"
            fill="oklch(0.85 0.12 150)" fontSize="9" fontWeight="600" fontFamily="'Inter', sans-serif"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 2.1 }}
          >How You See Systems</motion.text>

          {/* Axis labels */}
          <motion.text x={200} y={30} textAnchor="middle"
            fill="oklch(0.7 0.08 240)" fontSize="7" letterSpacing="0.2em"
            fontFamily="'Orbitron', sans-serif"
            initial={{ opacity: 0 }} animate={{ opacity: 0.8 }} transition={{ delay: 2.3 }}
          >INTERIOR</motion.text>
          <motion.text x={200} y={385} textAnchor="middle"
            fill="oklch(0.7 0.08 240)" fontSize="7" letterSpacing="0.2em"
            fontFamily="'Orbitron', sans-serif"
            initial={{ opacity: 0 }} animate={{ opacity: 0.8 }} transition={{ delay: 2.3 }}
          >EXTERIOR</motion.text>
          <motion.text x={25} y={203} textAnchor="middle"
            fill="oklch(0.7 0.08 240)" fontSize="7" letterSpacing="0.1em"
            fontFamily="'Orbitron', sans-serif"
            initial={{ opacity: 0 }} animate={{ opacity: 0.8 }} transition={{ delay: 2.5 }}
            style={{ writingMode: 'vertical-rl' } as any}
          >INDIVIDUAL</motion.text>
          <motion.text x={385} y={203} textAnchor="middle"
            fill="oklch(0.7 0.08 240)" fontSize="7" letterSpacing="0.1em"
            fontFamily="'Orbitron', sans-serif"
            initial={{ opacity: 0 }} animate={{ opacity: 0.8 }} transition={{ delay: 2.5 }}
            style={{ writingMode: 'vertical-rl' } as any}
          >COLLECTIVE</motion.text>
        </svg>
      </motion.div>

      <motion.p
        className="text-center text-white text-base mt-6 leading-relaxed max-w-[380px] mx-auto font-semibold"
        style={{ textShadow: '0 0 15px oklch(0.7 0.15 240 / 0.6), 0 2px 6px oklch(0 0 0 / 0.5)' }}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 3, duration: 1 }}
      >
        Four quadrants. 22 dimensions. One voice assessment maps your entire cognitive architecture.
      </motion.p>
    </div>
  );
}

// ============================================================
// COMPLEMENTARY MATCHING SECTION — The Network Effect
// ============================================================
function ComplementaryMatching() {
  return (
    <section className="py-28 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-aqal-cyan/[0.015] to-transparent" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[70%] h-px bg-gradient-to-r from-transparent via-aqal-cyan/20 to-transparent" />

      <div className="container relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7, ease: [0.23, 1, 0.32, 1] }}
          className="text-center mb-16"
        >
          <h2
            className="text-3xl sm:text-4xl md:text-5xl text-foreground mb-4"
            style={{ fontFamily: "'Playfair Display', serif", letterSpacing: "-0.02em", fontWeight: 600 }}
          >
            You're not looking for people like you.
          </h2>
          <p
            className="text-xl sm:text-2xl md:text-3xl text-white mb-6"
            style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, textShadow: '0 0 20px oklch(0.82 0.16 195 / 0.8), 0 0 40px oklch(0.82 0.16 195 / 0.4), 0 2px 8px oklch(0 0 0 / 0.6)' }}
          >
            You're looking for <span className="underline decoration-aqal-cyan decoration-2 underline-offset-4" style={{ color: 'oklch(0.88 0.18 195)' }}>people who complete you.</span>
          </p>
        </motion.div>

        {/* Complementary radar visualization */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2, duration: 1 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-6 sm:gap-12 mb-16"
        >
          {/* Left radar — "Your shape" */}
          <div className="relative">
            <svg viewBox="0 0 160 160" className="w-32 h-32 sm:w-40 sm:h-40">
              <polygon
                points={Array.from({ length: 22 }, (_, i) => {
                  const angle = (Math.PI * 2 * i) / 22 - Math.PI / 2;
                  const r = 60;
                  return `${80 + Math.cos(angle) * r},${80 + Math.sin(angle) * r}`;
                }).join(" ")}
                fill="none" stroke="oklch(0.3 0.03 260)" strokeWidth="0.5" opacity={0.3}
              />
              <polygon
                points={[0.9,0.7,0.85,0.6,0.3,0.4,0.2,0.35,0.5,0.8,0.75,0.9,0.65,0.4,0.3,0.25,0.5,0.7,0.8,0.6,0.45,0.85].map((v, i) => {
                  const angle = (Math.PI * 2 * i) / 22 - Math.PI / 2;
                  return `${80 + Math.cos(angle) * 60 * v},${80 + Math.sin(angle) * 60 * v}`;
                }).join(" ")}
                fill="oklch(0.7 0.2 240)" fillOpacity={0.15}
                stroke="oklch(0.7 0.2 240)" strokeWidth="1.5"
              />
            </svg>
            <p className="text-center text-xs text-aqal-blue font-medium mt-1">Your shape</p>
          </div>

          {/* Connection icon */}
          <motion.div
            className="flex flex-col items-center gap-1"
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
          >
            <svg viewBox="0 0 24 24" className="w-6 h-6 text-aqal-cyan/60" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M8 12h8M12 8v8" strokeLinecap="round" />
            </svg>
            <span className="text-[10px] text-white/60 uppercase tracking-wider font-medium">Completes</span>
          </motion.div>

          {/* Right radar — "Their shape" (inverse) */}
          <div className="relative">
            <svg viewBox="0 0 160 160" className="w-32 h-32 sm:w-40 sm:h-40">
              <polygon
                points={Array.from({ length: 22 }, (_, i) => {
                  const angle = (Math.PI * 2 * i) / 22 - Math.PI / 2;
                  const r = 60;
                  return `${80 + Math.cos(angle) * r},${80 + Math.sin(angle) * r}`;
                }).join(" ")}
                fill="none" stroke="oklch(0.3 0.03 260)" strokeWidth="0.5" opacity={0.3}
              />
              <polygon
                points={[0.25,0.4,0.3,0.5,0.85,0.7,0.9,0.8,0.6,0.3,0.35,0.2,0.45,0.75,0.85,0.9,0.6,0.4,0.3,0.5,0.7,0.25].map((v, i) => {
                  const angle = (Math.PI * 2 * i) / 22 - Math.PI / 2;
                  return `${80 + Math.cos(angle) * 60 * v},${80 + Math.sin(angle) * 60 * v}`;
                }).join(" ")}
                fill="oklch(0.82 0.16 195)" fillOpacity={0.15}
                stroke="oklch(0.82 0.16 195)" strokeWidth="1.5"
              />
            </svg>
            <p className="text-center text-xs text-aqal-cyan font-medium mt-1">Their shape</p>
          </div>
        </motion.div>

        {/* Copy */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="max-w-2xl mx-auto text-center mb-12"
        >
          <p className="text-white/80 leading-relaxed mb-6 font-medium" style={{ textShadow: '0 1px 4px oklch(0 0 0 / 0.5)' }}>
            Every rare mind has a shape. Peaks of brilliance. Valleys of growth. The AQAL Rare-Minds Network doesn't match you with mirrors — it matches you with <strong className="text-foreground">complements.</strong>
          </p>
          <p className="text-white/70 text-sm leading-relaxed font-medium" style={{ textShadow: '0 1px 3px oklch(0 0 0 / 0.5)' }}>
            Your strategic thinking pairs with someone's creative intuition. Their emotional intelligence fills your analytical blind spot. Together, you're not two incomplete people — you're one extraordinary system.
          </p>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="text-center"
        >
          <PrefetchLink href="/assessment">
            <button
              onClick={() => playClick()}
              className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-aqal-cyan/10 border border-aqal-cyan/20 text-aqal-cyan font-medium hover:bg-aqal-cyan/15 hover:translate-y-[-1px] active:scale-[0.97] transition-all duration-150"
            >
              See Who Completes You
              <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M5 12h14M12 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
          </PrefetchLink>
        </motion.div>
      </div>
    </section>
  );
}

// ============================================================
// MIC BUTTON — A portal. Magnetic. Alive. Breathing.
// Concentric rings rotating in opposite directions.
// The icon floats. The glow intensifies on hover.
// ============================================================
function MicButton() {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div className="flex flex-col items-center gap-8">
      <Link href="/assessment">
        <motion.div
          className="relative cursor-pointer"
          onHoverStart={() => setIsHovered(true)}
          onHoverEnd={() => setIsHovered(false)}
          whileTap={{ scale: 0.97 }}
          transition={{ duration: 0.16, ease: [0.23, 1, 0.32, 1] }}
        >
          {/* Light source behind the mic */}
          <div
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full pointer-events-none"
            style={{
              background: `radial-gradient(circle, oklch(0.7 0.2 240 / ${isHovered ? 0.12 : 0.07}) 0%, oklch(0.7 0.2 240 / 0.02) 45%, transparent 70%)`,
              transition: "background 0.4s ease",
            }}
          />

          {/* Ring 3 — outermost, barely visible, rotating clockwise slowly */}
          <motion.div
            className="absolute inset-[-40px] rounded-full border border-aqal-blue/[0.08]"
            animate={{ rotate: 360 }}
            transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
            style={{ scale: isHovered ? 0.95 : 1, transition: "scale 0.4s cubic-bezier(0.23, 1, 0.32, 1)" }}
          />

          {/* Ring 2 — middle, subtle, rotating counter-clockwise */}
          <motion.div
            className="absolute inset-[-20px] rounded-full border border-aqal-blue/[0.15]"
            animate={{ rotate: -360 }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
            style={{ scale: isHovered ? 0.96 : 1, transition: "scale 0.4s cubic-bezier(0.23, 1, 0.32, 1)" }}
          />

          {/* Pulse glow */}
          <div className="absolute inset-[-15px] rounded-full mic-pulse" />

          {/* Ring 1 — the main border */}
          <motion.div
            className="w-44 h-44 sm:w-52 sm:h-52 rounded-full border-2 flex items-center justify-center relative overflow-hidden"
            animate={{
              borderColor: isHovered ? "oklch(0.82 0.16 195)" : "oklch(0.7 0.2 240 / 0.8)",
            }}
            transition={{ duration: 0.3 }}
          >
            {/* Inner gradient — the depth inside the portal */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-b from-aqal-blue/[0.15] via-transparent to-aqal-navy/80" />

            {/* Inner subtle rings */}
            <div className="absolute inset-4 rounded-full border border-aqal-blue/[0.12]" />
            <div className="absolute inset-8 rounded-full border border-aqal-blue/[0.06]" />

            {/* Mic icon — floating, alive */}
            <motion.div
              animate={{ y: [0, -3, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="relative z-10"
            >
              <Mic className="w-12 h-12 sm:w-14 sm:h-14 text-white" strokeWidth={1.5} />
            </motion.div>
          </motion.div>
        </motion.div>
      </Link>

      <motion.p
        className="text-xs tracking-[0.2em] uppercase"
        style={{ fontFamily: "'Orbitron', sans-serif", color: "oklch(0.85 0.16 195)", textShadow: '0 0 10px oklch(0.82 0.16 195 / 0.5)' }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 1.5 }}
      >
        Tap to begin
      </motion.p>
    </div>
  );
}

// ============================================================
// COUNTING NUMBER — Animates from start to end on scroll
// ============================================================
function CountingNumber({ end, prefix = "", suffix = "", duration = 2500 }: {
  end: number; prefix?: string; suffix?: string; duration?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const [value, setValue] = useState(0);

  useEffect(() => {
    if (!inView) return;
    const start = Math.floor(end * 0.02); // Start from ~2% to feel like it's already moving
    const startTime = Date.now();
    const timer = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Deceleration easing — lands softly
      const eased = 1 - Math.pow(1 - progress, 4);
      setValue(Math.floor(start + eased * (end - start)));
      if (progress >= 1) clearInterval(timer);
    }, 16);
    return () => clearInterval(timer);
  }, [inView, end, duration]);

  return (
    <span ref={ref}>
      {inView ? `${prefix}${value.toLocaleString()}${suffix}` : `${prefix}—${suffix}`}
    </span>
  );
}

// ============================================================
// HERO SECTION — The full opening experience.
// You're floating in space. The mic is a portal of light.
// ============================================================
function HeroSection() {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden px-4">


      {/* Content */}
      <div className="relative z-10 flex flex-col items-center text-center max-w-4xl mx-auto">
        {/* Headline */}
        <motion.h1
          className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl text-foreground leading-tight mb-2"
          style={{ fontFamily: "'Playfair Display', serif", letterSpacing: "-0.02em", fontWeight: 500, textShadow: '0 2px 10px oklch(0 0 0 / 0.6), 0 0 30px oklch(0.7 0.15 240 / 0.15)' }}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.23, 1, 0.32, 1] }}
        >
          Out of a million people...
        </motion.h1>
        <motion.h2
          className="text-2xl sm:text-4xl md:text-5xl lg:text-6xl font-semibold text-glow-blue mb-20"
          style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.75 0.18 240)", letterSpacing: "-0.02em" }}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.23, 1, 0.32, 1], delay: 0.3 }}
        >
          how smart are you, really?
        </motion.h2>
        <motion.p
          className="text-sm sm:text-base md:text-lg tracking-[0.25em] uppercase text-white/80 mb-16 font-medium text-glow-soft"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.6 }}
        >
          22 dimensions. 5 AI minds. People who complete you.
        </motion.p>

        {/* The Mic — centerpiece */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, ease: [0.23, 1, 0.32, 1], delay: 0.7 }}
        >
          <MicButton />
        </motion.div>

        {/* Radar Chart Teaser */}
        <motion.div
          className="mt-20 w-full max-w-sm"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 1.5, ease: [0.23, 1, 0.32, 1] }}
        >
          <AQALQuadrants />
        </motion.div>
      </div>
    </section>
  );
}

// ============================================================
// STATS ROW — Numbers that count up. Orbitron font. Glowing.
// ============================================================
function StatsRow() {
  const stats = [
    { value: 22, label: "Intelligence Axes", color: "text-aqal-gold text-glow-gold" },
    { value: 5, label: "AI Consensus Systems", color: "text-aqal-blue text-glow-blue" },
    { value: 1000000, label: "Statistical Baseline", color: "text-aqal-cyan text-glow-cyan", display: "1M" },
    { value: 7, label: "Patents Pending", color: "text-aqal-purple" },
  ];

  return (
    <motion.section
      className="py-16 relative"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.8 }}
    >
      {/* Gradient lines above and below */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[80%] h-px bg-gradient-to-r from-transparent via-aqal-blue/30 to-transparent" />
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[80%] h-px bg-gradient-to-r from-transparent via-aqal-blue/30 to-transparent" />

      <div className="container">
        <div className="flex flex-wrap justify-center items-center gap-10 sm:gap-16">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              className="flex flex-col items-center gap-2"
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
            >
              {/* Subtle glow behind number */}
              <div className="relative">
                <div className="absolute inset-0 blur-[20px] bg-aqal-cyan/[0.08] rounded-full" />
                <span
                  className={`relative text-3xl font-bold ${stat.color}`}
                  style={{ fontFamily: "'Orbitron', sans-serif" }}
                >
                  {stat.display || <CountingNumber end={stat.value} />}
                </span>
              </div>
              <span className="text-white/70 text-sm font-medium text-glow-soft">{stat.label}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.section>
  );
}

// ============================================================
// HOW IT WORKS — Three frosted glass cards with icons, flow arrows,
// trust microcopy. Refactoring UI: visual hierarchy through weight,
// not just size. Influence: authority cues in sub-labels.
// ============================================================
function HowItWorks() {
  const steps = [
    {
      number: "01",
      title: "Just Talk",
      desc: "Twelve questions. No right answers. No checkboxes. Just you, speaking naturally about how you actually think, move, and make sense of things.",
      sublabel: "30–60 min • At the bar with an old friend conversational assessment",
      icon: (
        <svg viewBox="0 0 24 24" className="w-7 h-7" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" strokeLinecap="round" />
          <path d="M19 10v2a7 7 0 0 1-14 0v-2" strokeLinecap="round" />
          <line x1="12" y1="19" x2="12" y2="23" strokeLinecap="round" />
        </svg>
      ),
    },
    {
      number: "02",
      title: "Five Minds Listen",
      desc: "Five independent AI systems hear what you said — and what you meant beneath it. They map your responses across 22 dimensions. No single system decides your score.",
      sublabel: "5 AI models • Consensus scoring",
      icon: (
        <svg viewBox="0 0 24 24" className="w-7 h-7" fill="none" stroke="currentColor" strokeWidth="1.5">
          <circle cx="12" cy="12" r="3" />
          <circle cx="4" cy="8" r="2" />
          <circle cx="20" cy="8" r="2" />
          <circle cx="4" cy="16" r="2" />
          <circle cx="20" cy="16" r="2" />
          <path d="M6 8.5l4 2.5M18 8.5l-4 2.5M6 15.5l4-2.5M18 15.5l-4-2.5" opacity="0.5" />
        </svg>
      ),
    },
    {
      number: "03",
      title: "See Your Number",
      desc: "Out of a million people, how many share your exact combination? You'll see the answer — and understand why certain things have always come naturally to you.",
      sublabel: "22 axes • 1-in-N rarity",
      icon: (
        <svg viewBox="0 0 24 24" className="w-7 h-7" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M12 2L2 7l10 5 10-5-10-5z" />
          <path d="M2 17l10 5 10-5" />
          <path d="M2 12l10 5 10-5" />
        </svg>
      ),
    },
  ];

  return (
    <section className="py-28 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-aqal-blue/[0.015] to-transparent" />
      <div className="container relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7, ease: [0.23, 1, 0.32, 1] }}
          className="text-center mb-20"
        >
          <p className="text-xs uppercase tracking-[0.25em] text-aqal-cyan/60 mb-4" style={{ fontFamily: "'Orbitron', sans-serif" }}>
            The Process
          </p>
          <h2
            className="text-3xl sm:text-4xl md:text-5xl text-foreground mb-4"
            style={{ fontFamily: "'Playfair Display', serif", letterSpacing: "-0.02em", fontWeight: 600 }}
          >
            How It Works
          </h2>
          <p className="text-white/80 text-lg max-w-xl mx-auto leading-relaxed font-medium text-glow-soft">
            Fifteen minutes. Your voice. A map of who you actually are.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {steps.map((step, i) => (
            <motion.div
              key={step.number}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15, duration: 0.6, ease: [0.23, 1, 0.32, 1] }}
              className="glass-card relative p-8 rounded-2xl group hover:border-aqal-blue/20 transition-colors duration-300"
            >
              {/* Step number watermark */}
              <span
                className="text-6xl font-black absolute top-4 right-6 text-aqal-blue/[0.06]"
                style={{ fontFamily: "'Orbitron', sans-serif" }}
              >
                {step.number}
              </span>

              {/* Icon */}
              <div className="w-12 h-12 rounded-xl bg-aqal-blue/[0.08] border border-aqal-blue/10 flex items-center justify-center text-aqal-blue mb-5 group-hover:bg-aqal-blue/[0.12] transition-colors duration-300">
                {step.icon}
              </div>

              <h3 className="text-xl font-semibold text-foreground mb-2 relative z-10">
                {step.title}
              </h3>

              {/* Sub-label — authority cue */}
              <p className="text-xs text-aqal-cyan/60 uppercase tracking-wider mb-3 relative z-10" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                {step.sublabel}
              </p>

              <p className="text-white/75 text-sm leading-relaxed relative z-10 font-medium" style={{ lineHeight: 1.7, textShadow: '0 1px 3px oklch(0 0 0 / 0.6)' }}>
                {step.desc}
              </p>

              {/* Flow arrow (between cards on desktop) */}
              {i < 2 && (
                <div className="hidden md:block absolute -right-4 top-1/2 -translate-y-1/2 z-20">
                  <svg viewBox="0 0 16 16" className="w-4 h-4 text-aqal-blue/30">
                    <path d="M3 8h10M10 5l3 3-3 3" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Trust microcopy below steps */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6, duration: 0.5 }}
          className="text-center text-white/50 text-xs mt-10 tracking-wide font-medium"
        >
          No typing. No multiple choice. No right answers. Just your natural voice.
        </motion.p>
      </div>
    </section>
  );
}

// ============================================================
// RARITY PREVIEW — The big number. The hook.
// Shows "1 in ???,???" until scrolled into view, then counts up.
// ============================================================
function RarityPreview() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!inView) return;
    const end = 47000;
    const start = 1000;
    const duration = 2800;
    const startTime = Date.now();
    const timer = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Deceleration — fast start, soft landing
      const eased = 1 - Math.pow(1 - progress, 4);
      setCount(Math.floor(start + eased * (end - start)));
      if (progress >= 1) clearInterval(timer);
    }, 16);
    return () => clearInterval(timer);
  }, [inView]);

  return (
    <section className="py-28 relative" ref={ref}>
      {/* Gold radial glow */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-[500px] h-[300px] rounded-full bg-aqal-gold/[0.04] blur-[80px]" />
      </div>

      <div className="container relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease: [0.23, 1, 0.32, 1] }}
        >
          <p
            className="text-muted-foreground/60 text-xs uppercase tracking-[0.2em] mb-6"
            style={{ fontFamily: "'Orbitron', sans-serif" }}
          >
            Your Composite Rarity Score
          </p>

          <div
            className="text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-bold text-glow-gold"
            style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.78 0.15 85)" }}
          >
            {inView ? (
              <>1 in {count.toLocaleString()}</>
            ) : (
              <motion.span
                animate={{ opacity: [0.4, 0.8, 0.4] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                1 in ???,???
              </motion.span>
            )}
          </div>

          <p className="text-white/80 mt-8 max-w-lg mx-auto text-lg leading-relaxed font-medium text-glow-soft">
            The way your mind works across 22 dimensions creates a combination
            that has never existed before — and never will again.
          </p>

          <PrefetchLink href="/assessment">
            <Button
              size="lg"
              onClick={() => playClick()}
              className="mt-12 text-lg px-10 py-6 bg-aqal-gold text-background font-semibold glow-gold hover:translate-y-[-1px] active:scale-[0.97] transition-all duration-150"
            >
              Discover Your Rarity
            </Button>
          </PrefetchLink>
        </motion.div>
      </div>
    </section>
  );
}

// ============================================================
// CTA SECTION — Final push. Urgency. Scarcity.
// ============================================================
function CTASection() {
  return (
    <section className="py-28 relative">
      <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
      <div className="container relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, ease: [0.23, 1, 0.32, 1] }}
          className="max-w-2xl mx-auto"
        >
          <h2
            className="text-3xl sm:text-4xl md:text-5xl text-foreground mb-6"
            style={{ fontFamily: "'Playfair Display', serif", letterSpacing: "-0.02em", fontWeight: 600 }}
          >
            Ready to find out?
          </h2>
          <p className="text-white/80 text-lg mb-12 leading-relaxed font-medium text-glow-soft">
            Founding member spots are limited to the first 100 people.
            After that, the price goes up and stays up.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <PrefetchLink href="/assessment">
              <Button
                size="lg"
                onClick={() => playClick()}
                className="text-lg px-10 py-6 bg-aqal-blue text-white font-semibold glow-blue hover:translate-y-[-1px] active:scale-[0.97] transition-all duration-150"
              >
                Begin Assessment
              </Button>
            </PrefetchLink>
            <PrefetchLink href="/pricing">
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-10 py-6 border-aqal-gold/40 text-aqal-gold hover:bg-aqal-gold/[0.08] hover:translate-y-[-1px] active:scale-[0.97] transition-all duration-150"
              >
                View Pricing
              </Button>
            </PrefetchLink>
          </div>
<p className="text-white/50 text-xs mt-10 tracking-wide font-medium">
            Your voice. Five AI minds. Twenty-two dimensions. One number that's yours alone.
          </p>
        </motion.div>
      </div>
    </section>
  );
}

// ============================================================
// FOOTER — Use shared PublicFooter for consistency.
// ============================================================
function Footer() {
  return (
    <footer className="relative py-10">
      {/* Gradient top border */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[60%] h-px bg-gradient-to-r from-transparent via-aqal-cyan/30 to-transparent" />

      <div className="container flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground/50">
        <div className="flex items-center gap-3">
          <span
            className="text-aqal-blue font-bold text-sm text-glow-blue"
            style={{ fontFamily: "'Orbitron', sans-serif" }}
          >
            AQAL
          </span>
          <span className="tracking-wider text-xs uppercase">Intelligence Platform</span>
        </div>
        <nav className="flex gap-6">
          <PrefetchLink href="/science" className="relative hover:text-foreground transition-colors duration-200 after:content-[''] after:absolute after:bottom-[-2px] after:left-0 after:w-0 after:h-px after:bg-aqal-blue after:transition-[width] after:duration-200 hover:after:w-full">
            Science
          </PrefetchLink>
          <PrefetchLink href="/pricing" className="relative hover:text-foreground transition-colors duration-200 after:content-[''] after:absolute after:bottom-[-2px] after:left-0 after:w-0 after:h-px after:bg-aqal-blue after:transition-[width] after:duration-200 hover:after:w-full">
            Pricing
          </PrefetchLink>
          <span className="text-muted-foreground/30 italic">7 Patents Pending</span>
        </nav>
      </div>
      <p className="text-center text-muted-foreground/25 text-[0.65rem] mt-6 tracking-widest uppercase">
        Voice-first. Evidence-verified. Five AI systems. Zero bias.
      </p>
    </footer>
  );
}

// ============================================================
// HOME PAGE — The composed experience.
// Cosmos → Hero → Stats → Steps → Rarity → CTA → Footer
// ============================================================
export default function Home() {
  useScrollReveal();
  useParallax();

  return (
    <div className="min-h-screen relative">


      {/* Global nav */}
      <PublicHeader />

      {/* The experience */}
      <div className="relative z-10">
        <HeroSection />
        <div data-reveal><StatsRow /></div>
        <div data-reveal><HowItWorks /></div>
        <div data-reveal><ComplementaryMatching /></div>
        <div data-reveal="scale"><RarityPreview /></div>
        <div data-reveal><CTASection /></div>
        <PublicFooter />
      </div>
    </div>
  );
}
