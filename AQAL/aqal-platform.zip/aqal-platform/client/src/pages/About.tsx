import { motion } from "framer-motion";
import { PublicHeader, PublicFooter } from "@/components/PublicLayout";
import { PrefetchLink } from "@/components/PrefetchLink";
import { Button } from "@/components/ui/button";
import { Shield, Brain, Users, Zap, Lock, BarChart3 } from "lucide-react";

const PRINCIPLES = [
  {
    icon: <Brain className="w-6 h-6" />,
    title: "Voice-First Intelligence",
    description: "Your voice carries more signal than any multiple-choice test. Micro-hesitations, tonal shifts, word choice patterns, and structural complexity reveal cognitive architecture that questionnaires miss entirely.",
  },
  {
    icon: <Users className="w-6 h-6" />,
    title: "Five-AI Consensus",
    description: "No single model decides your score. Five independent AI systems analyze your responses separately, then converge through weighted consensus. This eliminates the single-point-of-failure that plagues traditional psychometrics.",
  },
  {
    icon: <BarChart3 className="w-6 h-6" />,
    title: "22-Axis Framework",
    description: "Built on Ken Wilber's AQAL (All Quadrants, All Levels) integral theory. We measure cognitive, emotional, interpersonal, creative, and adaptive intelligences — the full spectrum of human capability, not just IQ.",
  },
  {
    icon: <Shield className="w-6 h-6" />,
    title: "Evidence-Based Scoring",
    description: "Every axis score is grounded in observable linguistic markers. We don't ask you to self-report — we measure what your language actually reveals about how your mind processes information.",
  },
  {
    icon: <Lock className="w-6 h-6" />,
    title: "Privacy by Design",
    description: "Your voice recordings are processed and discarded. Only the extracted scores persist. We never sell data, never share profiles without consent, and never use your responses to train models.",
  },
  {
    icon: <Zap className="w-6 h-6" />,
    title: "Complementary Matching",
    description: "Your weaknesses are someone else's strengths. AQAL doesn't just score you — it finds the people whose cognitive profiles complement yours, creating partnerships where both parties grow.",
  },
];

const TIMELINE = [
  { year: "2023", event: "Initial research into voice-based cognitive assessment" },
  { year: "2024", event: "22-axis framework validated against existing psychometric instruments" },
  { year: "2025", event: "Five-AI consensus system developed and tested" },
  { year: "2026", event: "Founding member program launched — first 100 users" },
];

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      <PublicHeader />

      {/* Hero */}
      <section className="pt-32 pb-20 px-4 relative">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-[20%] left-[20%] w-[400px] h-[400px] rounded-full bg-aqal-blue/[0.03] blur-[100px]" />
          <div className="absolute bottom-[10%] right-[20%] w-[300px] h-[300px] rounded-full bg-aqal-gold/[0.03] blur-[80px]" />
        </div>

        <div className="container relative z-10 max-w-4xl mx-auto text-center">
          <motion.p
            className="text-xs uppercase tracking-[0.25em] text-aqal-cyan/60 mb-4"
            style={{ fontFamily: "'Orbitron', sans-serif" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
          >
            About AQAL Intelligence
          </motion.p>
          <motion.h1
            className="text-4xl sm:text-5xl md:text-6xl text-foreground mb-6"
            style={{ fontFamily: "'Playfair Display', serif", letterSpacing: "-0.02em", fontWeight: 300 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.23, 1, 0.32, 1] }}
          >
            The science of who you are
          </motion.h1>
          <motion.p
            className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.23, 1, 0.32, 1] }}
          >
            AQAL Intelligence is the first platform to map human cognitive architecture
            through voice analysis. Not what you think you are — what your language reveals you to be.
          </motion.p>
        </div>
      </section>

      {/* Principles Grid */}
      <section className="py-20 px-4">
        <div className="container max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <p
              className="text-xs uppercase tracking-[0.25em] text-aqal-cyan/60 mb-4"
              style={{ fontFamily: "'Orbitron', sans-serif" }}
            >
              Core Principles
            </p>
            <h2
              className="text-3xl sm:text-4xl text-foreground"
              style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600 }}
            >
              How we measure intelligence differently
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {PRINCIPLES.map((principle, i) => (
              <motion.div
                key={principle.title}
                className="glass-card p-7 rounded-2xl"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
              >
                <div className="w-11 h-11 rounded-xl bg-aqal-blue/[0.08] border border-aqal-blue/10 flex items-center justify-center text-aqal-blue mb-4">
                  {principle.icon}
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {principle.title}
                </h3>
                <p className="text-muted-foreground/80 text-sm leading-relaxed">
                  {principle.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* The Framework */}
      <section className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-aqal-blue/[0.01] to-transparent" />
        <div className="container relative z-10 max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <p
              className="text-xs uppercase tracking-[0.25em] text-aqal-gold/60 mb-4"
              style={{ fontFamily: "'Orbitron', sans-serif" }}
            >
              Theoretical Foundation
            </p>
            <h2
              className="text-3xl sm:text-4xl text-foreground mb-4"
              style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600 }}
            >
              Built on integral theory
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto leading-relaxed">
              Ken Wilber's AQAL framework maps human development across four quadrants:
              individual-interior (consciousness), individual-exterior (behavior),
              collective-interior (culture), and collective-exterior (systems).
              Our 22 axes span all four.
            </p>
          </div>

          <div className="glass-card p-8 rounded-2xl">
            <div className="grid grid-cols-2 gap-6">
              <div className="p-4 rounded-xl bg-aqal-blue/[0.05] border border-aqal-blue/10">
                <h4 className="text-xs uppercase tracking-wider text-aqal-blue mb-2" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                  Interior-Individual
                </h4>
                <p className="text-sm text-muted-foreground">
                  Logical, Mathematical, Philosophical, Reflective, Intuitive intelligence
                </p>
              </div>
              <div className="p-4 rounded-xl bg-aqal-cyan/[0.05] border border-aqal-cyan/10">
                <h4 className="text-xs uppercase tracking-wider text-aqal-cyan mb-2" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                  Exterior-Individual
                </h4>
                <p className="text-sm text-muted-foreground">
                  Kinesthetic, Spatial, Musical, Neo-Cognitive, Adaptive intelligence
                </p>
              </div>
              <div className="p-4 rounded-xl bg-aqal-gold/[0.05] border border-aqal-gold/10">
                <h4 className="text-xs uppercase tracking-wider text-aqal-gold mb-2" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                  Interior-Collective
                </h4>
                <p className="text-sm text-muted-foreground">
                  Interpersonal, Intrapersonal, Linguistic, Empathic, Creative intelligence
                </p>
              </div>
              <div className="p-4 rounded-xl bg-aqal-purple/[0.05] border border-aqal-purple/10">
                <h4 className="text-xs uppercase tracking-wider text-aqal-purple mb-2" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                  Exterior-Collective
                </h4>
                <p className="text-sm text-muted-foreground">
                  Strategic, Ecological, Resilient, Architectural, Naturalistic intelligence
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20 px-4">
        <div className="container max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <h2
              className="text-3xl sm:text-4xl text-foreground"
              style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600 }}
            >
              Our journey
            </h2>
          </div>

          <div className="relative">
            {/* Vertical line */}
            <div className="absolute left-[22px] top-0 bottom-0 w-px bg-gradient-to-b from-aqal-blue/40 via-aqal-gold/30 to-transparent" />

            <div className="space-y-8">
              {TIMELINE.map((item, i) => (
                <motion.div
                  key={item.year}
                  className="flex items-start gap-6 pl-2"
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.15, duration: 0.5 }}
                >
                  <div className="w-11 h-11 rounded-full bg-aqal-blue/[0.1] border border-aqal-blue/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-aqal-blue" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                      {item.year.slice(2)}
                    </span>
                  </div>
                  <div className="pt-2">
                    <span className="text-sm font-semibold text-foreground">{item.year}</span>
                    <p className="text-muted-foreground text-sm mt-1">{item.event}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4">
        <div className="container max-w-2xl mx-auto text-center">
          <h2
            className="text-3xl sm:text-4xl text-foreground mb-4"
            style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600 }}
          >
            Ready to discover your shape?
          </h2>
          <p className="text-muted-foreground text-lg mb-10 leading-relaxed">
            Fifteen minutes. Your voice. A map of who you actually are.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <PrefetchLink href="/assessment">
              <Button
                size="lg"
                className="text-lg px-10 py-6 bg-aqal-blue text-white font-semibold glow-blue"
              >
                Begin Assessment
              </Button>
            </PrefetchLink>
            <PrefetchLink href="/science">
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-10 py-6 border-aqal-cyan/30 text-aqal-cyan"
              >
                Read the Science
              </Button>
            </PrefetchLink>
          </div>
        </div>
      </section>

      <PublicFooter />
    </div>
  );
}
