import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { BookOpen, Brain, Layers, Shield } from "lucide-react";
import { PublicHeader, PublicFooter } from "@/components/PublicLayout";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { PrefetchLink } from "@/components/PrefetchLink";

const AXES = [
  "Logical", "Mathematical", "Spatial", "Linguistic", "Interpersonal",
  "Intrapersonal", "Musical", "Kinesthetic", "Naturalistic", "Strategic",
  "Tactical", "Adaptive", "Resilient", "Systematic", "Architectural",
  "Empathic", "Intuitive", "Meta-Cognitive", "Reflective", "Existential",
  "Philosophical", "Integrative"
];

const FOUNDATIONS = [
  {
    title: "Howard Gardner",
    subtitle: "Multiple Intelligences Theory",
    desc: "The foundational framework recognizing that intelligence is not a single number but a constellation of distinct cognitive abilities.",
  },
  {
    title: "Robert Sternberg",
    subtitle: "Triarchic Theory of Intelligence",
    desc: "Analytical, creative, and practical intelligence working in concert \u2014 the basis for our multi-dimensional scoring.",
  },
  {
    title: "Daniel Goleman",
    subtitle: "Emotional Intelligence",
    desc: "The recognition that interpersonal and intrapersonal awareness are measurable, trainable forms of intelligence.",
  },
  {
    title: "Ken Wilber",
    subtitle: "AQAL Framework",
    desc: "All Quadrants, All Levels \u2014 the integral theory that maps human development across every dimension simultaneously.",
  },
];

const METHODOLOGY = [
  {
    step: "01",
    title: "Voice Capture",
    desc: "Open-ended questions answered by voice eliminate the bias of multiple-choice testing. Your natural language reveals cognitive patterns invisible to traditional assessments.",
  },
  {
    step: "02",
    title: "Multi-Model Consensus",
    desc: "Five independent AI systems analyze each response. No single model can bias your score. Consensus scoring eliminates individual model hallucination.",
  },
  {
    step: "03",
    title: "22-Axis Mapping",
    desc: "Each response is scored across all 22 intelligence dimensions simultaneously, creating a high-resolution cognitive fingerprint.",
  },
  {
    step: "04",
    title: "Statistical Placement",
    desc: "Your composite profile is compared against a baseline population of 1,000,000 to determine your statistical rarity \u2014 how many people share your exact combination.",
  },
  {
    step: "05",
    title: "Evidence Verification",
    desc: "Optional document upload allows AI and human reviewers to verify and boost scores based on real-world accomplishments.",
  },
];

export default function Science() {
  useScrollReveal();
  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Background depth */}
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          background: `radial-gradient(ellipse at 50% 20%, oklch(0.17 0.04 260) 0%, oklch(0.15 0.04 260) 50%, oklch(0.12 0.04 260) 100%)`,
        }}
      />
      {/* Gradient mesh overlay */}
      <div className="gradient-mesh" />

      <PublicHeader />

      <main className="relative z-10 container section-spacing max-w-4xl px-4">
        {/* Hero */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.23, 1, 0.32, 1] }}
        >
          <div className="w-16 h-16 rounded-full bg-aqal-blue/[0.1] border border-aqal-blue/30 flex items-center justify-center mx-auto mb-6">
            <BookOpen className="w-8 h-8 text-aqal-blue" />
          </div>
          <h1 className="display-1 text-foreground mb-4">
            The Science Behind AQAL
          </h1>
          <p className="text-muted-foreground/70 max-w-xl mx-auto text-lg leading-relaxed">
            22 dimensions of intelligence, grounded in decades of research, measured through voice,
            verified through evidence.
          </p>
        </motion.div>

        {/* 22 Intelligence Axes */}
        <motion.section
          className="mb-24"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, ease: [0.23, 1, 0.32, 1] }}
        >
          <h2 className="display-2 text-foreground mb-8">
            The 22 Intelligence Axes
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {AXES.map((axis, i) => (
              <motion.div
                key={axis}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.03, duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
                className="glass-card rounded-xl p-4 text-center group"
              >
                <span
                  className="text-aqal-cyan/60 text-[0.6rem] block mb-1"
                  style={{ fontFamily: "'Orbitron', sans-serif" }}
                >
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span className="text-foreground/90 text-sm font-medium">{axis}</span>
              </motion.div>
            ))}
          </div>
        </motion.section>

        <div className="section-divider" />

        {/* Academic Foundations */}
        <motion.section
          className="mb-24"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, ease: [0.23, 1, 0.32, 1] }}
        >
          <div className="flex items-center gap-3 mb-8">
            <Brain className="w-5 h-5 text-aqal-gold" />
            <h2 className="display-2 text-foreground">
              Academic Foundations
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {FOUNDATIONS.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
                className="glass-card rounded-2xl p-6"
              >
                <h3 className="text-foreground font-semibold text-lg mb-1">{f.title}</h3>
                <p className="text-aqal-cyan/70 text-xs mb-3 tracking-wide">{f.subtitle}</p>
                <p className="text-muted-foreground/60 text-sm leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </motion.section>

        <div className="section-divider" />

        {/* Methodology */}
        <motion.section
          className="mb-24"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, ease: [0.23, 1, 0.32, 1] }}
        >
          <div className="flex items-center gap-3 mb-8">
            <Layers className="w-5 h-5 text-aqal-blue" />
            <h2 className="display-2 text-foreground">
              Methodology
            </h2>
          </div>
          <div className="space-y-5">
            {METHODOLOGY.map((m, i) => (
              <motion.div
                key={m.step}
                initial={{ opacity: 0, x: -15 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08, duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
                className="glass-card rounded-2xl p-6 flex gap-5"
              >
                <span
                  className="text-3xl font-black text-aqal-blue/[0.15] shrink-0"
                  style={{ fontFamily: "'Orbitron', sans-serif" }}
                >
                  {m.step}
                </span>
                <div>
                  <h3 className="text-foreground font-semibold mb-2">{m.title}</h3>
                  <p className="text-muted-foreground/60 text-sm leading-relaxed">{m.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.section>

        <div className="section-divider-gold" />

        {/* Rarity Formula */}
        <motion.section
          className="mb-24"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, ease: [0.23, 1, 0.32, 1] }}
        >
          <div className="glass-card rounded-2xl p-8 text-center">
            <div className="flex items-center gap-3 justify-center mb-6">
              <Shield className="w-5 h-5 text-aqal-gold" />
              <h2 className="display-3 text-foreground">
                The Rarity Formula
              </h2>
            </div>
            <div
              className="text-xl sm:text-2xl font-mono text-aqal-cyan/80 mb-6 py-4 px-6 rounded-xl bg-muted/10 border border-muted/20 inline-block"
            >
              R = &Pi;(1/P<sub>i</sub>) &times; C<sub>synergy</sub> &times; W<sub>evidence</sub>
            </div>
            <p className="text-muted-foreground/60 text-sm max-w-lg mx-auto leading-relaxed">
              Your rarity score is the product of individual axis percentiles, multiplied by a synergy
              coefficient for rare combinations, and weighted by evidence verification strength.
              The result represents how many people in a population of 1,000,000 share your exact profile.
            </p>
          </div>
        </motion.section>

        {/* Developmental Stages */}
        <motion.section
          className="mb-24"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, ease: [0.23, 1, 0.32, 1] }}
        >
          <div className="text-center mb-10">
            <p className="section-label text-aqal-cyan/60 mb-2">Developmental Mapping</p>
            <h2 className="display-3 text-foreground">Stages of Consciousness</h2>
            <p className="text-muted-foreground/60 text-sm max-w-lg mx-auto mt-3">
              Your responses are mapped against the full spectrum of human developmental stages,
              from conventional to post-conventional to transpersonal.
            </p>
          </div>
          <div className="grid gap-3 max-w-3xl mx-auto">
            {[
              { stage: "Blue", color: "#3b82f6", range: "0.10–0.25", pop: "~30%", desc: "Rule-based, conventional thinking. Loyalty to systems and authority." },
              { stage: "Orange", color: "#f97316", range: "0.25–0.50", pop: "~30%", desc: "Achievement-driven, strategic, scientific rationality. Most 'successful' people." },
              { stage: "Green", color: "#22c55e", range: "0.50–0.65", pop: "~20%", desc: "Pluralistic, empathic, egalitarian. Values community and shared meaning." },
              { stage: "Yellow", color: "#eab308", range: "0.65–0.85", pop: "~5%", desc: "Integrative, systemic, autonomous. Sees and synthesizes across all prior stages." },
              { stage: "Turquoise", color: "#06b6d4", range: "0.85–0.95", pop: "~0.1%", desc: "Holistic, communal wholeness. Perceives the world as a living, evolving system." },
              { stage: "Coral", color: "#f43f5e", range: "0.95–1.0", pop: "<0.01%", desc: "Third-Tier. Radical dis-identification from ego. Cosmocentric awareness with grounded embodiment. Holds paradox at the identity level." },
            ].map((s) => (
              <div key={s.stage} className="glass-card rounded-xl p-4 flex items-center gap-4">
                <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: s.color, boxShadow: `0 0 8px ${s.color}40` }} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline gap-2 mb-0.5">
                    <span className="font-semibold text-foreground">{s.stage}</span>
                    <span className="text-xs font-mono text-muted-foreground/50">{s.range}</span>
                    <span className="text-xs text-muted-foreground/40 ml-auto">{s.pop} of population</span>
                  </div>
                  <p className="text-xs text-muted-foreground/60 leading-relaxed">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.section>

        {/* CTA */}
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease: [0.23, 1, 0.32, 1] }}
        >
          <h2 className="display-2 text-foreground mb-4">
            Ready to discover your rarity?
          </h2>
          <p className="text-muted-foreground/60 mb-8 max-w-md mx-auto">
            The most comprehensive intelligence assessment ever created &mdash; completed in under 15 minutes.
          </p>
          <PrefetchLink href="/assessment">
            <Button className="text-lg px-10 py-6 bg-aqal-blue text-white glow-blue hover:translate-y-[-1px] active:scale-[0.97] transition-all duration-150">
              Begin Assessment
            </Button>
          </PrefetchLink>
        </motion.div>
      </main>

      {/* Footer */}
      <div className="relative z-10">
        <PublicFooter />
      </div>
    </div>
  );
}
