import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Brain, Menu, X, User } from "lucide-react";
import { useState, useEffect } from "react";

// ============================================================
// PUBLIC LAYOUT — Shared header + footer for consumer-facing pages.
// Applies Refactoring UI: consistent navigation, clear hierarchy.
// Applies Influence: authority signals in footer, social proof.
// ============================================================

const navLinks = [
  { href: "/about", label: "About" },
  { href: "/science", label: "Science" },
  { href: "/pricing", label: "Pricing" },
  { href: "/assessment", label: "Assessment" },
  { href: "/leaderboard", label: "Leaderboard" },
];

export function PublicHeader() {
  const { user, loading } = useAuth();
  const [location] = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-300 ${
          scrolled
            ? "bg-background/80 backdrop-blur-xl border-b border-white/[0.04] shadow-lg shadow-black/10"
            : "bg-transparent"
        }`}
      >
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          {/* Logo */}
          <Link href="/">
            <span
              className="text-xl font-bold tracking-tight text-foreground hover:text-aqal-cyan transition-colors cursor-pointer"
              style={{ fontFamily: "'Orbitron', sans-serif" }}
            >
              AQAL
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                    location === link.href
                      ? "text-aqal-cyan bg-aqal-cyan/[0.08]"
                      : "text-muted-foreground hover:text-foreground hover:bg-white/[0.04]"
                  }`}
                >
                  {link.label}
                </span>
              </Link>
            ))}
          </nav>

          {/* Auth CTA */}
          <div className="hidden md:flex items-center gap-3">
            {loading ? (
              <div className="w-20 h-9 rounded-lg bg-white/[0.04] animate-pulse" />
            ) : user ? (
              <Link href="/profile">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-aqal-cyan/20 text-aqal-cyan hover:bg-aqal-cyan/10 gap-2"
                >
                  <User className="w-4 h-4" />
                  {user.name?.split(" ")[0] || "Profile"}
                </Button>
              </Link>
            ) : (
              <Button
                onClick={() => (window.location.href = getLoginUrl())}
                size="sm"
                className="bg-gradient-to-r from-aqal-blue to-aqal-cyan hover:from-aqal-blue/90 hover:to-aqal-cyan/90 text-white border-0 shadow-md shadow-aqal-blue/20"
              >
                Sign In
              </Button>
            )}
          </div>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden p-2 text-muted-foreground hover:text-foreground transition-colors"
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Mobile dropdown */}
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
            className="md:hidden bg-background/95 backdrop-blur-xl border-b border-white/[0.04] px-4 pb-4"
          >
            <nav className="flex flex-col gap-1 pt-2">
              {navLinks.map((link) => (
                <Link key={link.href} href={link.href}>
                  <span
                    className={`block px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                      location === link.href
                        ? "text-aqal-cyan bg-aqal-cyan/[0.08]"
                        : "text-muted-foreground hover:text-foreground hover:bg-white/[0.04]"
                    }`}
                  >
                    {link.label}
                  </span>
                </Link>
              ))}
              <div className="pt-2 mt-2 border-t border-white/[0.06]">
                {user ? (
                  <Link href="/profile">
                    <span className="block px-3 py-2.5 rounded-lg text-sm font-medium text-aqal-cyan">
                      My Profile
                    </span>
                  </Link>
                ) : (
                  <Button
                    onClick={() => (window.location.href = getLoginUrl())}
                    className="w-full bg-gradient-to-r from-aqal-blue to-aqal-cyan text-white border-0"
                  >
                    Sign In
                  </Button>
                )}
              </div>
            </nav>
          </motion.div>
        )}
      </header>
      {/* Spacer so content doesn't hide behind fixed header */}
      <div className="h-16" />
    </>
  );
}

export function PublicFooter() {
  return (
    <footer className="border-t border-white/[0.04] mt-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand */}
          <div>
            <span
              className="text-lg font-bold text-foreground"
              style={{ fontFamily: "'Orbitron', sans-serif" }}
            >
              AQAL
            </span>
            <p className="mt-2 text-sm text-muted-foreground/60 leading-relaxed max-w-xs">
              Voice-first. Evidence-verified. Five AI systems. Zero bias.
            </p>
          </div>

          {/* Links */}
          <div className="flex flex-col gap-2">
            <span className="text-xs uppercase tracking-wider text-muted-foreground/40 font-medium mb-1">
              Platform
            </span>
            <Link href="/science">
              <span className="text-sm text-muted-foreground hover:text-foreground transition-colors cursor-pointer">
                Science
              </span>
            </Link>
            <Link href="/pricing">
              <span className="text-sm text-muted-foreground hover:text-foreground transition-colors cursor-pointer">
                Pricing
              </span>
            </Link>
            <Link href="/assessment">
              <span className="text-sm text-muted-foreground hover:text-foreground transition-colors cursor-pointer">
                Assessment
              </span>
            </Link>
            <Link href="/leaderboard">
              <span className="text-sm text-muted-foreground hover:text-foreground transition-colors cursor-pointer">
                Leaderboard
              </span>
            </Link>
          </div>

          {/* Trust & Legal */}
          <div className="flex flex-col gap-2">
            <span className="text-xs uppercase tracking-wider text-muted-foreground/40 font-medium mb-1">
              Trust & Security
            </span>
            <span className="text-sm text-muted-foreground/60">HIPAA Compliant</span>
            <span className="text-sm text-muted-foreground/60">Bank-Grade Encryption</span>
            <span className="text-sm text-muted-foreground/60">7 Patents Pending</span>
            <Link href="/terms">
              <span className="text-sm text-muted-foreground hover:text-foreground transition-colors cursor-pointer">
                Terms of Service
              </span>
            </Link>
            <Link href="/privacy">
              <span className="text-sm text-muted-foreground hover:text-foreground transition-colors cursor-pointer">
                Privacy Policy
              </span>
            </Link>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-white/[0.04] flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground/40">
            &copy; {new Date().getFullYear()} AQAL Intelligence. 7 Patents Pending.
          </p>
          <div className="flex items-center gap-4">
            <Link href="/terms">
              <span className="text-xs text-muted-foreground/40 hover:text-muted-foreground transition-colors cursor-pointer">
                Terms
              </span>
            </Link>
            <Link href="/privacy">
              <span className="text-xs text-muted-foreground/40 hover:text-muted-foreground transition-colors cursor-pointer">
                Privacy
              </span>
            </Link>
            <Link href="/login">
              <span className="text-xs text-muted-foreground/40 hover:text-muted-foreground transition-colors cursor-pointer">
                Sign In
              </span>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

export function PublicLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <PublicHeader />
      {children}
      <PublicFooter />
    </>
  );
}
