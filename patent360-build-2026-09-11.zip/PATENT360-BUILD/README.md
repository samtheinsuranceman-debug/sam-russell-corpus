# Patent360 — complete build

Packaged 11 September 2026 from commit `1f0ce30` on
`samtheinsuranceman-debug/sam-russell-corpus`, branch `claude/claude-md-docs-0qgcvw`.

Live at https://patent360-production.up.railway.app

---

## What is in here

| Folder | What it is |
|---|---|
| `01-source/` | The whole deployable service. Client source, FastAPI app, MCP server, two-stage Dockerfile, tests. This is what Railway builds. |
| `02-compiled-web/` | The application already compiled. Open `index.html` from any static server and it runs — no build step. |
| `03-rcs-interior-design/` | The Russell Capital Systems interior design system (`interior.css` + the showcase page). A separate product; included because it is the other interior work from this session. |
| `04-interior-design-system/` | Patent360's stylesheets on their own, for reference: tokens, the seven light skins, app, backdrop, variants. |

## Running it

**Just look at it** — serve `02-compiled-web/` with any static server:

    cd 02-compiled-web && python3 -m http.server 8080

**Build and run the real thing** — Docker, from `01-source/Patent360`:

    docker build -t patent360 . && docker run -p 8000:8000 patent360

**Develop the client** — from `01-source/Patent360/client`:

    npm ci && npm run dev

## The three surfaces, one service

- `/` and `/app/*` — the application
- `/health`, `/api/*` — the REST API
- `/mcp` — a Model Context Protocol server, four read-only tools, bearer auth.
  Set `MCP_API_KEY`; with no key it answers 503 rather than serving openly.

Route order is deliberate: the API and MCP paths bind before the client
catch-all, reserved prefixes return a JSON 404 rather than an HTML page, and
the catch-all refuses anything resolving outside the build directory. If the
client build is missing the service still starts and still serves the API and
the connector.

## The interior

Seven light skins, set with `data-skin="1".."7"` on `<html>`:

| | Paper | Ink | Accent |
|---|---|---|---|
| 1 Vellum & Navy *(default)* | `#F4F0E6` | `#12284C` | royal blue |
| 2 Drafting Paper | `#EAEFF5` | `#0F2A4E` | bright blue |
| 3 Bond & Emerald | `#F1F1EB` | `#10291F` | emerald |
| 4 Court Grey | `#EEEDE9` | `#1C1A17` | oxblood |
| 5 Linen & Brass | `#F4EFE3` | `#241F18` | brass |
| 6 Cobalt Slate | `#EBEEF3` | `#131E2C` | cobalt |
| 7 Sage Study | `#EEF1EA` | `#16261E` | teal |

The dark marketing homepage is unchanged; the skins apply behind the sign-in,
where an attorney spends hours.

## Verification behind this package

Seventeen interior routes rendered at 360, 390, 820 and 1440 px — fifty-one
combinations, none overflowing horizontally, no JS errors on any route, the
ground colour consistent on every page with no dark block bleeding through.
All seven skins resolve their own ink and accent. The 36-check MCP suite
passes. The client builds clean from a fresh `npm ci`.

## Honest notes

- The demonstration dataset is invented. No client, matter, examiner, board
  member, figure or date in this build is real, and nothing here is legal advice.
- The prosecution figures on the office-action screens come from a stated
  model in `client/src/lib/oa.ts`, checked by a 10,000-run simulation in
  `client/sim/simulate.ts`. They are expected values, not forecasts.
- Two MCP implementations exist. This package ships the Python one, which is
  live and has four working tools. A Node hub using the official MCP SDK sits
  in the `Patent360` repo with `health_check` and `echo`; it is not deployed.
