# Patent360 — master build

This archive is the state of `Patent360/` on `master` at the commit that added it.
It carries no other product: no Russell Capital Systems, no AQAL, nothing else.

## Layout

| Path | What |
|---|---|
| `client/` | React application source — 23 pages, 6 engines, the simulation harness |
| `app/` | FastAPI service: REST API and the MCP server at `/mcp` |
| `compiled-web/` | The client already built. Serve it and it runs; no build step. |
| `Dockerfile` | Two stages: node compiles the client, python serves it with the API |
| `tests/` | The 36-check MCP conformance suite |

## Running it

    docker build -t patent360 . && docker run -p 8000:8000 patent360

Or the client alone, from `client/`: `npm ci && npm run dev`.
Or just open `compiled-web/index.html` from any static server.

## The three surfaces, one service

- `/` and `/app/*` — the application
- `/health`, `/api/*` — the REST API
- `/mcp` — Model Context Protocol, four read-only tools, bearer auth.
  Set `MCP_API_KEY`; with no key it answers 503 rather than serving openly.

## What is verified about this build

- **Every control works.** 57 interactive elements: 51 carry a handler, 6 navigate,
  0 are dead. A click harness pressed 40 of them across 21 routes at every tab
  state; all 40 produced a visible effect with no JS errors.
- **Eight buttons produce real files** — RFC 4180 CSV with a BOM, RFC 5545
  iCalendar folded to 75 octets with exclusive all-day DTEND, and a document Word
  opens. All eight were downloaded and their contents checked.
- **Five simulation passes at five seeds: 1,687,547 checks, 0 failures.**
  Deadline arithmetic, the fee calculator, whole-path prosecution cost, the
  revenue and relationship models, prior art, and 10,000 hostile strings through
  the file writers.
- **Seventeen interior routes fit 360 to 1440px** with no horizontal scroll.
- The MCP suite passes from a clean extraction of this archive.

## Honest notes

- The dataset is invented. No client, matter, examiner, board member, figure or
  date here is real, and nothing in it is legal advice.
- Prosecution figures come from a stated model in `client/src/lib/oa.ts`, checked
  by `client/sim/simulate.ts`. They are expected values, not forecasts.
- Actions that need a server this build does not have — filing to Patent Center,
  sending mail, a live prior-art search — say so precisely when pressed. They do
  not fake success.
