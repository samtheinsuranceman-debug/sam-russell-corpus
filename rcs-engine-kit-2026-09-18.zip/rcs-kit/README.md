# Russell Capital Systems — Engine Kit

Working, tested code. 10,082 lines of TypeScript across 26 engine and test files,
plus a self-contained showcase page and a legal memo. Nothing here is a mockup.

Hand this whole folder to the build chat and it drops straight in.

---

## Start here

| File | What to do with it |
|---|---|
| `time-machine.html` | **Double-click it.** No server, no build, no internet. Prints to PDF. |
| `docs/SMALL_BUSINESS_LENDING_LEGAL.md` | **Read it before originating anything.** What's allowed, what isn't, what to do instead. |
| `engines/` | Drop into `shared/`. Tests go in `server/`. |

---

## The platform layer

### `factFinder.ts` — one client record, every calculator

Enter the assets, income, expenses, and liabilities once. `hydrate()` fills every
calculator from it. No more typing the mortgage balance four times and getting three
different answers.

**Provenance is a real field.** Every figure records whether it was read off a statement,
stated by the client, or inferred. The weakest provenance in the inputs propagates to the
output, so a projection built on one guess reports itself as a guess. Prefills also name
what's missing rather than defaulting to zero and producing a confident wrong answer.

Capital only counts as *deployable* after a six-month essential-expense reserve is held
back. Everything downstream is gated on that.

### `nextBestAction.ts` — the green button

Twelve scoring lenses. Liquidity, tax efficiency, growth, downside protection, legacy,
simplicity, reversibility, timing, concentration, leverage safety, cash flow, compliance.
They disagree by construction — the liquidity lens hates what the growth lens loves — and
the weighted vote produces the ranking. `lensScores` comes back with the result so you can
see exactly which lens objected and answer it in the meeting.

Deterministic scorers, not twelve model calls. Same answer twice, testable, traceable.

**Risk appetite moves the growth/liquidity trade. It does not move compliance or
leverage-safety** — those carry identical weight at every appetite. An aggressive client
doesn't get to down-weight the lens asking whether something is legal.

`transferRisk()` is the one a stack of separate calculators structurally cannot do: what
it costs to move money from strategy A to strategy B. Protections lost are **itemized, not
netted into the spread** — the floor, the death benefit, the tax treatment, the liquidity.
A client who knows he's trading a floor for two points of spread can make that call. One
shown only the two points can't.

`sequence()` puts strategies on a calendar instead of a list. Prerequisites are honored
*with seasoning* — you can't borrow against a policy the month it's funded. Repeating
cycles lay down automatically: a new policy every two years, each entering its own
surrender schedule on its own clock, so by the time the first is free the third is funded.

### `scenarioEngine.ts` — inflation, tax policy, 36 years of local history

Nominal-dollar projections at today's tax rates describe a world that won't exist. This
layers what a dollar buys, what credit costs, and what the government takes.

Tax scenarios are named by **government structure, not party** — unified control, divided
government, scheduled sunset — and the set is deliberately symmetric, including a
rate-cutting case. A model that only shows rates rising is an argument, not analysis.
Nothing here predicts an election.

The useful output: **a tax-free position doesn't move across any scenario.** That's the
cleanest argument for tax-free accumulation there is, and it doesn't require the client to
agree with you about politics.

`describeSeries()` reports the **worst rolling decade** next to the CAGR — the number a
full-period average hides, and the one that matters if the money is needed inside ten
years. `localOutlook()` warns when insurance compounds faster than rent, which has quietly
rewritten rental economics in coastal markets.

36-year ZIP-level series for appreciation, rent, insurance, and mortgage rates are
**contracts, not data** — they throw if unsourced or shorter than the window presented.

---

## Small Business Lending

### `smallBusinessLending/industryRisk.ts`

25 trades with NAICS, seasonality, collection lag, margin, collateral quality, and seed
multiple.

**Structure is encoded. Loss experience is not.** Seasonality is knowable — a roofer needs
material money in March, not October. Default rates are not knowable without data, so they
must be supplied with a source and an as-of date or scoring throws. Rates older than 18
months throw as stale.

`loadSbaChargeOffRates()` converts the SBA FOIA loan-level extract (~2M loans with NAICS,
approval, status, and charge-off) into those records. **Dollar-weighted, not
count-weighted** — count-weighting flatters a book where the small loans fail and the big
ones hold, which is the usual shape.

The scoring penalizes two things a sector average never catches:
- **Funding outside the season.** Money lent before the season buys revenue. Money lent
  during it usually plugs a hole. A landscaper funded in February and one funded in August
  are different loans.
- **Cadence mismatch.** A 60-day collection cycle cannot service a daily remittance. The
  borrower funds payments out of the advance itself, which is how a performing loan becomes
  a default in month three.

`seedMultiple` decides whether the loan was ever a good idea — revenue per dollar of
working capital in season. Landscaping is 3.2x and can carry expensive money. Full-service
restaurants are 1.2x and can't, which is why they're the worst cohort in the SBA book.

### `smallBusinessLending/loanPricing.ts`

`trueApr()` solves the IRR of the actual payment stream. **A 1.22 factor over six months
of daily remittance is not 44%.** The balance amortizes from day one, average outstanding
is about half, and the real APR lands in the seventies. Four states now make you print
that number before signature.

If you quote factor rates without knowing the APR, you don't know your own book.

`buildDisclosure()` refuses to assemble with a field missing.

**`priceAdvance()` throws on anything secured by a principal dwelling.** No override flag.
See the legal memo for why, and for the lawful instrument that does the same job.

### `smallBusinessLending/prospecting.ts`

Nine distress signals, every one public record or the owner's own published behavior —
UCC filings, tax liens, judgments, lapsed licenses, hiring reversals, review sentiment,
equipment listings, plus the seasonal calendar.

**Intent and credit concern are scored as two separate numbers.** Desperation is
simultaneously the strongest buying signal and the strongest default signal. Blend them
and you get a list of businesses eager to sign and unable to pay — conversion metrics look
great while the book fills with defaults. Stacked UCCs score 9 on intent *and* 8 on
concern, and land in `underwrite-hard`, not `call-first`.

Email and SMS don't share a code path because they don't share a legal regime:
- **Email** — cold B2B is lawful under CAN-SPAM. Postal address and opt-out enforced.
- **SMS** — requires prior express written consent. $500/message, trebled to $1,500,
  uncapped. No B2B exemption for texts to a mobile. `buildSmsCampaign()` throws without a
  matching, unrevoked consent record.

Undisclosed synthetic avatar scripts throw.

---

## The 30-year Time Machine

`time-machine.html` — open it in a browser. S&P 1996–2025, five Pacific Horizon accounts,
and the real COI curve are inline in the file.

- A policy **started 30 years ago at the client's real current age today**. A 70-year-old
  sees the policy issued to the 40-year-old he was.
- **Reshuffle** re-orders the same 30 real years and recomputes.
- **Borrowable cash value on every year.** Always a loan. Never a withdrawal.
- **Liquidity windows ranked by credit still earned after the loan comes out** — not by
  raw balance. Year 30 has the biggest number and the worst answer, and the table says so.
- Year picker, multiplier toggle, print-to-PDF stylesheet.

---

## Running the tests

```bash
npx vitest run server/smallBusinessLending.test.ts   # 43 passing
npx vitest run server/nextBestAction.test.ts         # 38 passing
npx vitest run server/scenarioEngine.test.ts         # 20 passing
npx vitest run server/realEstateMogul.test.ts        # 37 passing
npx vitest run server/timeMachine30.test.ts          # 39 passing
```

Full suite in the repo: 2,351 passing. The 95 failures are pre-existing and environmental
— missing `RESEND_API_KEY` and `HEYGEN_API_KEY`, no server on port 3000, no database. That
was verified by running the suite with this work stashed: identical 95.

---

## What this code refuses to do

Deliberate. If the build chat "fixes" these, it has broken the platform.

1. **No withdrawals.** `DistributionKind` is a single-member type: `'loan'`. Surrender is
   detected and flagged red, never recommended.
2. **No unsourced numbers.** HELOC quotes, industry loss rates, local series, inflation
   assumptions — all throw without a source and a date.
3. **No projection dressed as history.** `IndexHistoryRow` and `ProjectionRow` are
   different types. Above the max illustrated rate, `projectPolicyValues` throws.
4. **No lending against a principal dwelling.** `ConsumerDwellingSecuredError`, no bypass.
5. **No SMS without consent.** `MissingConsentError`, no bypass.
6. **No desperation scored as intent alone.**

---

## Not done yet

- **SBA data not loaded.** `loadSbaChargeOffRates()` is written and tested but
  `data.sba.gov` is blocked from the build container. Run it outside the sandbox. Until
  then `rankIndustries()` returns only the trades you've sourced — by design.
- **Mortgage statement parser.** Real Estate Mogul takes a `Property[]`. Turning 30 PDFs
  into that array isn't written.
- **EPFR Design B and C factors.** All three Pacific Life illustrations ran Design A with
  zero performance factors, so the 2.16x for Design C is a break-even computed by
  bisection, labeled as such everywhere.
- **Engines not deployed.** These live in `russell-capital`. The live site deploys from
  `sam-russell-corpus/russell-capital-systems`. Porting is the next commit.
- **No UI.** These are engines. The green button needs a chart component built on
  `greenButton()`'s return value.
