import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import fs from "node:fs";
import path from "node:path";
import { defineConfig, type Plugin, type ViteDevServer } from "vite";

const PROJECT_ROOT = import.meta.dirname;
const LOG_DIR = path.join(PROJECT_ROOT, ".logs");
const MAX_LOG_SIZE_BYTES = 1 * 1024 * 1024;
const TRIM_TARGET_BYTES = Math.floor(MAX_LOG_SIZE_BYTES * 0.6);

type LogSource = "browserConsole" | "networkRequests" | "sessionReplay";

function ensureLogDir() {
  if (!fs.existsSync(LOG_DIR)) {
    fs.mkdirSync(LOG_DIR, { recursive: true });
  }
}

function trimLogFile(logPath: string, maxSize: number) {
  try {
    if (!fs.existsSync(logPath) || fs.statSync(logPath).size <= maxSize) return;
    const lines = fs.readFileSync(logPath, "utf-8").split("\n");
    const keptLines: string[] = [];
    let keptBytes = 0;
    for (let i = lines.length - 1; i >= 0; i--) {
      const lineBytes = Buffer.byteLength(`${lines[i]}\n`, "utf-8");
      if (keptBytes + lineBytes > TRIM_TARGET_BYTES) break;
      keptLines.unshift(lines[i]);
      keptBytes += lineBytes;
    }
    fs.writeFileSync(logPath, keptLines.join("\n"), "utf-8");
  } catch { /* ignore */ }
}

function writeToLogFile(source: LogSource, entries: unknown[]) {
  if (entries.length === 0) return;
  ensureLogDir();
  const logPath = path.join(LOG_DIR, `${source}.log`);
  const lines = entries.map((entry) => `[${new Date().toISOString()}] ${JSON.stringify(entry)}`);
  fs.appendFileSync(logPath, `${lines.join("\n")}\n`, "utf-8");
  trimLogFile(logPath, MAX_LOG_SIZE_BYTES);
}

function vitePluginDebugCollector(): Plugin {
  return {
    name: "debug-collector",
    configureServer(server: ViteDevServer) {
      server.middlewares.use("/__logs__", (req, res, next) => {
        if (req.method !== "POST") return next();
        let body = "";
        req.on("data", (chunk) => { body += chunk.toString(); });
        req.on("end", () => {
          try {
            const payload = JSON.parse(body);
            if (payload.consoleLogs?.length > 0) writeToLogFile("browserConsole", payload.consoleLogs);
            if (payload.networkRequests?.length > 0) writeToLogFile("networkRequests", payload.networkRequests);
            if (payload.sessionEvents?.length > 0) writeToLogFile("sessionReplay", payload.sessionEvents);
            res.writeHead(200, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: true }));
          } catch (e) {
            res.writeHead(400, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: false, error: String(e) }));
          }
        });
      });
    },
  };
}

function vitePluginShikiLangOptimizer(): Plugin {
  const KEEP_LANGS = new Set([
    'javascript', 'typescript', 'json', 'html', 'css', 'markdown',
    'jsx', 'tsx', 'bash', 'shell', 'sql', 'yaml', 'xml', 'python',
    'plaintext', 'text', 'txt', 'md', 'js', 'ts'
  ]);
  return {
    name: 'shiki-lang-optimizer',
    enforce: 'pre',
    resolveId(source, importer) {
      if (!importer) return null;
      const match = source.match(/^@shikijs\/langs\/(.+)$/);
      if (match) {
        const lang = match[1].toLowerCase();
        if (!KEEP_LANGS.has(lang)) return '\0shiki-lang-stub';
      }
      return null;
    },
    load(id) {
      if (id === '\0shiki-lang-stub') return 'export default [];';
      return null;
    },
  };
}

const plugins = [vitePluginShikiLangOptimizer(), react(), tailwindcss(), vitePluginDebugCollector()];

export default defineConfig({
  plugins,
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets"),
    },
  },
  envDir: path.resolve(import.meta.dirname),
  root: path.resolve(import.meta.dirname, "client"),
  publicDir: path.resolve(import.meta.dirname, "client", "public"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
    chunkSizeWarningLimit: 2000,
    minify: 'esbuild',
    sourcemap: false,
    cssCodeSplit: true,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('recharts') || id.includes('d3-')) return 'recharts-vendor';
          if (id.includes('mermaid')) return 'mermaid-vendor';
          if (id.includes('cytoscape')) return 'cytoscape-vendor';
          if (id.includes('useOrganismNervousSystemDeep')) return 'organism-nervous';
          if (id.includes('useOrganismBrainDeep')) return 'organism-brain';
          if (id.includes('useOrganismHandsDeep')) return 'organism-hands';
          if (id.includes('useOrganismSkeletonDeep')) return 'organism-skeleton';
          if (id.includes('useOrganismEyesDeep')) return 'organism-eyes';
          if (id.includes('useOrganismVoiceDeep')) return 'organism-voice';
          if (id.includes('engine_montecarlo')) return 'engine-mc';
          if (id.includes('engine_tax')) return 'engine-tax';
          if (id.includes('engine_retirement')) return 'engine-ret';
          if (id.includes('engine_insurance_estate')) return 'engine-ins';
          if (id.includes('engine_portfolio')) return 'engine-port';
          if (id.includes('useOrganism') && id.includes('hooks/')) return 'organism-core';
          if (id.includes('node_modules')) {
            if (id.includes('@tanstack') || id.includes('@trpc')) return 'trpc-vendor';
            if (id.includes('lucide')) return 'icons-vendor';
            if (id.includes('radix')) return 'radix-vendor';
            return 'vendor';
          }
          // Portal & calculator pages are all React.lazy() route components.
          // We intentionally do NOT force them into manual chunks: letting
          // Rollup split each dynamic import into its own chunk preserves true
          // lazy-loading (users download only the page they visit) and keeps
          // every chunk small. Manually bucketing them previously collapsed
          // ~150 pages into a single ~5MB chunk, defeating the lazy-loading.
          // Shared vendor/engine/organism code is still grouped above.
        },
      },
    },
  },
  server: {
    host: true,
    allowedHosts: true,
    port: parseInt(process.env.PORT || "5173"),
  },
});
