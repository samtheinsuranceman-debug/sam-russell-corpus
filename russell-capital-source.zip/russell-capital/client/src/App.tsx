import { Suspense, lazy } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
const NotFound = lazy(() => import("@/pages/NotFound"));
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import PortalErrorBoundary from "./components/PortalErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { EntrainmentProvider } from "./contexts/EntrainmentEngine";
import { FinancialDataProvider } from "./context/FinancialDataContext";
import ComplianceGate from "./components/ComplianceGate";
import SubscriptionGuard from "./components/SubscriptionGuard";
import { SkipToContent, FocusRingStyles } from "@/components/AccessibilityHelpers";
import TrialTimer from "./components/TrialTimer";
import { GlobalHooks } from "./components/GlobalHooks";
import { OnboardingTour } from "./components/OnboardingTour";
import { AchievementUnlockOverlay } from "./components/AchievementUnlockOverlay";
import { PetEvolutionOverlay } from "./components/PetEvolutionOverlay";

// Public pages — lazy-loaded to reduce initial bundle
const Landing = lazy(() => import("./pages/Landing"));
const Pricing = lazy(() => import("./pages/Pricing"));
const Privacy = lazy(() => import("./pages/Legal").then(m => ({ default: m.Privacy })));
const Terms = lazy(() => import("./pages/Legal").then(m => ({ default: m.Terms })));
const Support = lazy(() => import("./pages/Legal").then(m => ({ default: m.Support })));
const Login = lazy(() => import("./pages/Login"));
const Register = lazy(() => import("./pages/Register"));
const ForgotPassword = lazy(() => import("./pages/ForgotPassword"));
const ResetPassword = lazy(() => import("./pages/ResetPassword"));
const AcceptInvite = lazy(() => import("./pages/AcceptInvite"));
const TrialLogin = lazy(() => import("./pages/TrialLogin"));
const AdministratorPortal = lazy(() => import("./pages/AdministratorPortal"));
const ExecutiveEntrance = lazy(() => import("./pages/ExecutiveEntrance"));
const ClientPortalView = lazy(() => import("./pages/ClientPortalView"));
const SharedProjection = lazy(() => import("./pages/SharedProjection"));
const SharedSlidesViewer = lazy(() => import("./pages/SharedSlidesViewer"));

// Portal pages — lazy-loaded for fast initial page load
const Onboarding = lazy(() => import("./pages/portal/Onboarding"));
const Dashboard = lazy(() => import("./pages/portal/Dashboard"));
const Clients = lazy(() => import("./pages/portal/Clients"));
const ClientDetail = lazy(() => import("./pages/portal/ClientDetail"));
const Pipeline = lazy(() => import("./pages/portal/Pipeline"));
const StrategyLab = lazy(() => import("./pages/portal/StrategyLab"));
const AiAssist = lazy(() => import("./pages/portal/AiAssist"));
const Team = lazy(() => import("./pages/portal/Team"));
const Billing = lazy(() => import("./pages/portal/Billing"));
const Knowledge = lazy(() => import("./pages/portal/Knowledge"));
const Leaderboard = lazy(() => import("./pages/portal/Leaderboard"));
const EnterpriseAdmin = lazy(() => import("./pages/portal/EnterpriseAdmin"));
const AdminHealthDashboard = lazy(() => import("./pages/portal/AdminHealthDashboard"));
const ScenarioAdjustments = lazy(() => import("./pages/portal/ScenarioAdjustments"));
const AdvisorChat = lazy(() => import("./pages/portal/AdvisorChat"));
const StaleDigest = lazy(() => import("./pages/portal/StaleDigest"));
const Webhooks = lazy(() => import("./pages/portal/Webhooks"));
const SlackIntegration = lazy(() => import("./pages/portal/SlackIntegration"));
const ComplianceExport = lazy(() => import("./pages/portal/ComplianceExport"));
const RebalanceAlerts = lazy(() => import("./pages/portal/RebalanceAlerts"));
const WorkspaceBranding = lazy(() => import("./pages/portal/WorkspaceBranding"));
const Meetings = lazy(() => import("./pages/portal/Meetings"));
const ComplianceAlerts = lazy(() => import("./pages/portal/ComplianceAlerts"));
const HubSpotSync = lazy(() => import("./pages/portal/HubSpotSync"));
const Integrations = lazy(() => import("./pages/portal/Integrations"));
const RothConversionSTR = lazy(() => import("./pages/portal/RothConversionSTR"));
const OnboardingWizard = lazy(() => import("./pages/portal/OnboardingWizard"));
const StrategyCompare = lazy(() => import("./pages/portal/StrategyCompare"));
const CarrierSettings = lazy(() => import("./pages/portal/CarrierSettings"));
const BulkGeneration = lazy(() => import("./pages/portal/BulkGeneration"));
const CarrierQuotes = lazy(() => import("./pages/portal/CarrierQuotes"));
const IndexBacktester = lazy(() => import("./pages/portal/IndexBacktester"));
const TimeMachineAG49 = lazy(() => import("./pages/portal/TimeMachineAG49"));
const TimeMachineMethod = lazy(() => import("./pages/portal/TimeMachineMethod"));
const TimeMachineCalculator = lazy(() => import("./pages/portal/TimeMachineCalculator"));
const IllustrationCompare = lazy(() => import("./pages/portal/IllustrationCompare"));
const PremiumFinancing = lazy(() => import("./pages/portal/PremiumFinancing"));
const PolicyLoans = lazy(() => import("./pages/portal/PolicyLoans"));
const CarrierRatings = lazy(() => import("./pages/portal/CarrierRatings"));
const TaxWaterfall = lazy(() => import("./pages/portal/TaxWaterfall"));
const EstateTax = lazy(() => import("./pages/portal/EstateTax"));
const IncomeTimeline = lazy(() => import("./pages/portal/IncomeTimeline"));
const IULvsRoth = lazy(() => import("./pages/portal/IULvsRoth"));
const CompetitiveAnalysis = lazy(() => import("./pages/portal/CompetitiveAnalysis"));
const QuickQuote = lazy(() => import("./pages/portal/QuickQuote"));
const BatchIllustration = lazy(() => import("./pages/portal/BatchIllustration"));
const MeetingAgenda = lazy(() => import("./pages/portal/MeetingAgenda"));
const OnboardingWizardV2 = lazy(() => import("./pages/portal/OnboardingWizardV2"));
const InflationAnalysis = lazy(() => import("./pages/portal/InflationAnalysis"));
const ClientScorecard = lazy(() => import("./pages/portal/ClientScorecard"));
const DocumentVault = lazy(() => import("./pages/portal/DocumentVault"));
const AuditTimeline = lazy(() => import("./pages/portal/AuditTimeline"));
const ReferralTracker = lazy(() => import("./pages/portal/ReferralTracker"));
const PolicyReview = lazy(() => import("./pages/portal/PolicyReview"));
const AdvancedReporting = lazy(() => import("./pages/portal/AdvancedReporting"));
const MortgageKiller = lazy(() => import("./pages/portal/MortgageKiller"));
const EcologicalDrivers = lazy(() => import("./pages/portal/EcologicalDrivers"));
const ClientComparison = lazy(() => import("./pages/portal/ClientComparison"));
const WebsiteUsage = lazy(() => import("./pages/portal/WebsiteUsage"));
const HouseholdWealth = lazy(() => import("./pages/portal/HouseholdWealth"));
const CryptoCurrencyCorner = lazy(() => import("./pages/portal/CryptoCurrencyCorner"));
const LifetimeGuaranteedIncome = lazy(() => import("./pages/portal/LifetimeGuaranteedIncome"));
const ExistingAnnuities = lazy(() => import("./pages/portal/ExistingAnnuities"));
const GrowthAnnuities = lazy(() => import("./pages/portal/GrowthAnnuities"));
const MYGAFixedRate = lazy(() => import("./pages/portal/MYGAFixedRate"));
const AxonicSP500 = lazy(() => import("./pages/portal/AxonicSP500"));
const AthenePEPlus15 = lazy(() => import("./pages/portal/AthenePEPlus15"));
const AtheneGuaranteedIncome = lazy(() => import("./pages/portal/AtheneGuaranteedIncome"));
const AdvisorIncomeCalculator = lazy(() => import("./pages/portal/AdvisorIncomeCalculator"));
const ClientOnboardingWizard = lazy(() => import("./pages/portal/ClientOnboardingWizard"));
const SavedScenariosHub = lazy(() => import("./pages/portal/SavedScenariosHub"));
const AiStrategyRecommender = lazy(() => import("./pages/portal/AiStrategyRecommender"));
const EmailCampaignManager = lazy(() => import("./pages/portal/EmailCampaignManager"));
const ComplianceAuditCenter = lazy(() => import("./pages/portal/ComplianceAuditCenter"));
const LegalPaymentFolder = lazy(() => import("./pages/portal/LegalPaymentFolder"));
const EducationHub = lazy(() => import("./pages/portal/EducationHub"));
const AffiliateLinkManager = lazy(() => import("./pages/portal/AffiliateLinkManager"));
const HiddenMaterial = lazy(() => import("./pages/portal/HiddenMaterial"));
const IULHistoricalPerformance = lazy(() => import("./pages/portal/IULHistoricalPerformance"));
const IndexStrategyComparison = lazy(() => import("./pages/portal/IndexStrategyComparison"));
const RetirementIncomeProjection = lazy(() => import("./pages/portal/RetirementIncomeProjection"));
const TaxAdvantagedGrowth = lazy(() => import("./pages/portal/TaxAdvantagedGrowth"));
const SocialSecurityOptimizer = lazy(() => import("./pages/portal/SocialSecurityOptimizer"));
const IncomeAnnuityTop10 = lazy(() => import("./pages/portal/IncomeAnnuityTop10"));
const HotIncome = lazy(() => import("./pages/portal/HotIncome"));
const Recommendations = lazy(() => import("./pages/portal/Recommendations"));
const ClientFiles = lazy(() => import("./pages/portal/ClientFiles"));
const RealEstateMogul = lazy(() => import("./pages/portal/RealEstateMogul"));
const FIATop10 = lazy(() => import("./pages/portal/FIATop10"));
const TaxReturnUpload = lazy(() => import("./pages/portal/TaxReturnUpload"));
const AnnuityMemory = lazy(() => import("./pages/portal/AnnuityMemory"));
const AnnuityAccumulationDB = lazy(() => import("./pages/portal/AnnuityAccumulationDB"));
const HouseRecyclingStrategy = lazy(() => import("./pages/portal/HouseRecyclingStrategy"));
const SalesStoryBuilder = lazy(() => import("./pages/portal/SalesStoryBuilder"));
const EstateFlowChart = lazy(() => import("./pages/portal/EstateFlowChart"));
const GoalsBasedPlanning = lazy(() => import("./pages/portal/GoalsBasedPlanning"));
const RiskToleranceScoring = lazy(() => import("./pages/portal/RiskToleranceScoring"));
const MultiScenarioPlayZone = lazy(() => import("./pages/portal/MultiScenarioPlayZone"));
const WithdrawalSequencing = lazy(() => import("./pages/portal/WithdrawalSequencing"));
const BusinessOwnerPlanning = lazy(() => import("./pages/portal/BusinessOwnerPlanning"));
const SeminarGenerator = lazy(() => import("./pages/portal/SeminarGenerator"));
const ComplianceReportGenerator = lazy(() => import("./pages/portal/ComplianceReportGenerator"));
const AdvisorTraining = lazy(() => import("./pages/portal/AdvisorTraining"));
const AgencyTutorial = lazy(() => import("./pages/portal/AgencyTutorial"));
const IndividualAgentTutorial = lazy(() => import("./pages/portal/IndividualAgentTutorial"));
const SupervisorMonitoringAgreement = lazy(() => import("./pages/portal/SupervisorMonitoringAgreement"));
const TeamManagement = lazy(() => import("./pages/portal/TeamManagement"));
const OwnerOversight = lazy(() => import("./pages/portal/OwnerOversight"));
const PredictiveAnalytics = lazy(() => import("./pages/portal/PredictiveAnalytics"));
const CollaborativePlanning = lazy(() => import("./pages/portal/CollaborativePlanning"));
const MarketDataDashboard = lazy(() => import("./pages/portal/MarketDataDashboard"));
const AIMeetingNotes = lazy(() => import("./pages/portal/AIMeetingNotes"));
const ClientPortal = lazy(() => import("./pages/portal/ClientPortal"));
const DocumentTemplates = lazy(() => import("./pages/portal/DocumentTemplates"));
const CommissionCalculator = lazy(() => import("./pages/portal/CommissionCalculator"));
const CarrierComparison = lazy(() => import("./pages/portal/CarrierComparison"));
const ReferralTracking = lazy(() => import("./pages/portal/ReferralTracking"));
const TaxBracketVisualizer = lazy(() => import("./pages/portal/TaxBracketVisualizer"));
const PolicyReviewChecklist = lazy(() => import("./pages/portal/PolicyReviewChecklist"));
const IncomeGapAnalyzer = lazy(() => import("./pages/portal/IncomeGapAnalyzer"));
const MedicareIRMAA = lazy(() => import("./pages/portal/MedicareIRMAA"));
const IbbotsonCharts = lazy(() => import("./pages/portal/IbbotsonCharts"));
const VoicePlanBuilder = lazy(() => import("./pages/portal/VoicePlanBuilder"));
const ClientSnapshotMap = lazy(() => import("./pages/portal/ClientSnapshotMap"));
const TaxOpportunityDetector = lazy(() => import("./pages/portal/TaxOpportunityDetector"));
const WorkflowAutomations = lazy(() => import("./pages/portal/WorkflowAutomations"));
const ScenarioSideBySide = lazy(() => import("./pages/portal/ScenarioSideBySide"));
const ClientHealthDashboard = lazy(() => import("./pages/portal/ClientHealthDashboard"));
const ClientIntakeInterview = lazy(() => import("./pages/portal/ClientIntakeInterview"));
const PortfolioDriftMonitor = lazy(() => import("./pages/portal/PortfolioDriftMonitor"));
const NaturalLanguageQuery = lazy(() => import("./pages/portal/NaturalLanguageQuery"));
const ClientEngagementScore = lazy(() => import("./pages/portal/ClientEngagementScore"));
const PresentationBuilder = lazy(() => import("./pages/portal/PresentationBuilder"));
const ComplianceAuditTrail = lazy(() => import("./pages/portal/ComplianceAuditTrail"));
const LeadGenerator = lazy(() => import("./pages/portal/LeadGenerator"));
const FinancialVitalsScorecard = lazy(() => import("./pages/portal/FinancialVitalsScorecard"));
const EstateDocumentGenerator = lazy(() => import("./pages/portal/EstateDocumentGenerator"));
const RetirementGuardrails = lazy(() => import("./pages/portal/RetirementGuardrails"));
const ClientSelfServicePortal = lazy(() => import("./pages/portal/ClientSelfServicePortal"));
const TaxLossHarvestingScanner = lazy(() => import("./pages/portal/TaxLossHarvestingScanner"));
const BeneficiaryOptimization = lazy(() => import("./pages/portal/BeneficiaryOptimization"));
const FeeTransparencyDashboard = lazy(() => import("./pages/portal/FeeTransparencyDashboard"));
const SuccessionPlanningWizard = lazy(() => import("./pages/portal/SuccessionPlanningWizard"));
const AIPolicyReviewGap = lazy(() => import("./pages/portal/AIPolicyReviewGap"));
const SmartRebalancingAlerts = lazy(() => import("./pages/portal/SmartRebalancingAlerts"));
const ComplianceMonitoringDashboard = lazy(() => import("./pages/portal/ComplianceMonitoringDashboard"));
const MultiGenWealthTransfer = lazy(() => import("./pages/portal/MultiGenWealthTransfer"));
const CharitableGivingOptimizer = lazy(() => import("./pages/portal/CharitableGivingOptimizer"));
const MarketScenarioStressTest = lazy(() => import("./pages/portal/MarketScenarioStressTest"));
const ClientOnboardingAutomation = lazy(() => import("./pages/portal/ClientOnboardingAutomation"));
const CommissionTracker = lazy(() => import("./pages/portal/CommissionTracker"));
const ReverseHeloc = lazy(() => import("./pages/portal/ReverseHeloc"));
const AdvisorySummary = lazy(() => import("./pages/portal/AdvisorySummary"));
const AdvisorDirectory = lazy(() => import("./pages/portal/AdvisorDirectory"));
const AISlideGenerator = lazy(() => import("./pages/portal/AISlideGenerator"));
const MySlides = lazy(() => import("./pages/portal/MySlides"));
const OwnerWarRoom = lazy(() => import("./pages/portal/OwnerWarRoom"));
const BatchSlides = lazy(() => import("./pages/portal/BatchSlides"));

// ── The Experience ──────────────────────────────────────────────
const NerveCenter = lazy(() => import("./pages/portal/NerveCenter"));
const MyWorld = lazy(() => import("./pages/portal/MyWorld"));
const WarRoom = lazy(() => import("./pages/portal/WarRoom"));
const WillWriter = lazy(() => import("./pages/portal/WillWriter"));
const AvatarTwins = lazy(() => import("./pages/portal/AvatarTwins"));
const CouplesMode = lazy(() => import("./pages/portal/CouplesMode"));
const RussellNumber = lazy(() => import("./pages/portal/RussellNumber"));
const DailyDiscovery = lazy(() => import("./pages/portal/DailyDiscovery"));
const RussellWrapped = lazy(() => import("./pages/portal/RussellWrapped"));
const ClientStoryGenerator = lazy(() => import("./pages/portal/ClientStoryGenerator"));
const TimeMachine = lazy(() => import("./pages/portal/TimeMachine"));
const LiveCoPilot = lazy(() => import("./pages/portal/LiveCoPilot"));
const TimeLapse = lazy(() => import("./pages/portal/TimeLapse"));
const MorningRitual = lazy(() => import("./pages/portal/MorningRitual"));
const WarStoryGenerator = lazy(() => import("./pages/portal/WarStoryGenerator"));
const RevenueGuarantee = lazy(() => import("./pages/portal/RevenueGuarantee"));
const DailyBriefing = lazy(() => import("./pages/portal/DailyBriefing"));
const ComparisonDashboard = lazy(() => import("./pages/portal/ComparisonDashboard"));
const VideoProposalGenerator = lazy(() => import("./pages/portal/VideoProposalGenerator"));
const VideoViewer = lazy(() => import("./pages/VideoViewer"));

// ── Tax-Free Wealth Combos ────────────────────────────────────
const TaxFreeWealthCombos = lazy(() => import("./pages/portal/TaxFreeWealthCombos"));
const ComboDetail = lazy(() => import("./pages/portal/ComboDetail"));
const SecretSecrets = lazy(() => import("./pages/portal/SecretSecrets"));
const SecretDetail = lazy(() => import("./pages/portal/SecretDetail"));
const StrategyCompareTool = lazy(() => import("./pages/portal/StrategyCompareTool"));
const ClientIntakeRecommender = lazy(() => import("./pages/portal/ClientIntakeRecommender"));
const DivorceCalculator = lazy(() => import("./pages/portal/DivorceCalculator"));
const TrustsPage = lazy(() => import("./pages/portal/TrustsPage"));
const MortgageKillerV3 = lazy(() => import("./pages/portal/MortgageKillerV3"));
const STRStrategy = lazy(() => import("./pages/portal/STRStrategy"));
const ClientPortfolioDashboard = lazy(() => import("./pages/portal/ClientPortfolioDashboard"));
const PhysiciansEdge = lazy(() => import("./pages/portal/PhysiciansEdge"));
const VideoLibrary = lazy(() => import("./pages/portal/VideoLibrary"));
const PatentShowcase = lazy(() => import("./pages/portal/PatentShowcase"));

// ── Physician-Specific Calculators ──────────────────────────────────────
const PSLFCalculator = lazy(() => import("./pages/portal/PSLFCalculator"));
const IDRComparisonCalc = lazy(() => import("./pages/portal/IDRComparisonCalc"));
const OwnOccDisabilityCalc = lazy(() => import("./pages/portal/OwnOccDisabilityCalc"));
const PhysicianContractCalc = lazy(() => import("./pages/portal/PhysicianContractCalc"));
const ResidencyToAttendingCalc = lazy(() => import("./pages/portal/ResidencyToAttendingCalc"));
// ── Calculator Hub + 100 Financial Calculators + Retirement Advantage ───
const CalculatorHub = lazy(() => import("./pages/portal/CalculatorHub"));
const PhysicianVitalsDashboard = lazy(() => import("./pages/portal/PhysicianVitalsDashboard"));
const PhysicianForum = lazy(() => import("./pages/portal/PhysicianForum"));
const OnboardingQuiz = lazy(() => import("./pages/portal/OnboardingQuiz"));
const PeerBenchmarking = lazy(() => import("./pages/portal/PeerBenchmarking"));
const AnnualFinancialPhysical = lazy(() => import("./pages/portal/AnnualFinancialPhysical"));
const RMDCalculator = lazy(() => import("./pages/portal/RMDCalculator"));
const MarginalTaxRateCalc = lazy(() => import("./pages/portal/MarginalTaxRateCalc"));
const CapitalGainsTaxCalc = lazy(() => import("./pages/portal/CapitalGainsTaxCalc"));
const AMTCalculator = lazy(() => import("./pages/portal/AMTCalculator"));
const SelfEmploymentTaxCalc = lazy(() => import("./pages/portal/SelfEmploymentTaxCalc"));
const TaxEquivalentYieldCalc = lazy(() => import("./pages/portal/TaxEquivalentYieldCalc"));
const W4OptimizerCalc = lazy(() => import("./pages/portal/W4OptimizerCalc"));
const CryptoTaxCalc = lazy(() => import("./pages/portal/CryptoTaxCalc"));
const RSUTaxCalc = lazy(() => import("./pages/portal/RSUTaxCalc"));
const DeductionOptimizerCalc = lazy(() => import("./pages/portal/DeductionOptimizerCalc"));
const FIRECalculator = lazy(() => import("./pages/portal/FIRECalculator"));
const SafeWithdrawalCalc = lazy(() => import("./pages/portal/SafeWithdrawalCalc"));
const PensionVsLumpSumCalc = lazy(() => import("./pages/portal/PensionVsLumpSumCalc"));
const QLACCalculator = lazy(() => import("./pages/portal/QLACCalculator"));
const RetirementHealthcareCalc = lazy(() => import("./pages/portal/RetirementHealthcareCalc"));
const MedicareIRMAACalc = lazy(() => import("./pages/portal/MedicareIRMAACalc"));
const SpousalSSCalc = lazy(() => import("./pages/portal/SpousalSSCalc"));
const DCAvsLumpSumCalc = lazy(() => import("./pages/portal/DCAvsLumpSumCalc"));
const RetirementBudgetCalc = lazy(() => import("./pages/portal/RetirementBudgetCalc"));
const InflationAdjustedCalc = lazy(() => import("./pages/portal/InflationAdjustedCalc"));
const LifeInsuranceNeedsCalc = lazy(() => import("./pages/portal/LifeInsuranceNeedsCalc"));
const DisabilityInsuranceCalc = lazy(() => import("./pages/portal/DisabilityInsuranceCalc"));
const LTCCostCalc = lazy(() => import("./pages/portal/LTCCostCalc"));
const UmbrellaInsuranceCalc = lazy(() => import("./pages/portal/UmbrellaInsuranceCalc"));
const TermVsWholeVsIULCalc = lazy(() => import("./pages/portal/TermVsWholeVsIULCalc"));
const KeyPersonInsuranceCalc = lazy(() => import("./pages/portal/KeyPersonInsuranceCalc"));
const BuySellFundingCalc = lazy(() => import("./pages/portal/BuySellFundingCalc"));
const CRTCalculator = lazy(() => import("./pages/portal/CRTCalculator"));
const GRATCalculator = lazy(() => import("./pages/portal/GRATCalculator"));
const ILITCalculator = lazy(() => import("./pages/portal/ILITCalculator"));
const QPRTCalculator = lazy(() => import("./pages/portal/QPRTCalculator"));
const GSTTCalculator = lazy(() => import("./pages/portal/GSTTCalculator"));
const DAFvsDirectCalc = lazy(() => import("./pages/portal/DAFvsDirectCalc"));
const EstateLiquidityCalc = lazy(() => import("./pages/portal/EstateLiquidityCalc"));
const NetWorthTrackerCalc = lazy(() => import("./pages/portal/NetWorthTrackerCalc"));
const CompoundInterestCalc = lazy(() => import("./pages/portal/CompoundInterestCalc"));
const MillionaireCalc = lazy(() => import("./pages/portal/MillionaireCalc"));
const EmergencyFundVsIULCalc = lazy(() => import("./pages/portal/EmergencyFundVsIULCalc"));
const Education529VsIULCalc = lazy(() => import("./pages/portal/Education529VsIULCalc"));
const DebtPayoffOptimizerCalc = lazy(() => import("./pages/portal/DebtPayoffOptimizerCalc"));
const RentalPropertyROICalc = lazy(() => import("./pages/portal/RentalPropertyROICalc"));
const Exchange1031Calc = lazy(() => import("./pages/portal/Exchange1031Calc"));
const OpportunityZoneCalc = lazy(() => import("./pages/portal/OpportunityZoneCalc"));
const HomeAffordabilityCalc = lazy(() => import("./pages/portal/HomeAffordabilityCalc"));
const RefinanceBreakEvenCalc = lazy(() => import("./pages/portal/RefinanceBreakEvenCalc"));
const CostOfLivingCalc = lazy(() => import("./pages/portal/CostOfLivingCalc"));
const ReverseMortgageCalc = lazy(() => import("./pages/portal/ReverseMortgageCalc"));
const DepreciationTaxShieldCalc = lazy(() => import("./pages/portal/DepreciationTaxShieldCalc"));
const PropertyTaxAppealCalc = lazy(() => import("./pages/portal/PropertyTaxAppealCalc"));
const VacationRentalCalc = lazy(() => import("./pages/portal/VacationRentalCalc"));
const BusinessValuationCalc = lazy(() => import("./pages/portal/BusinessValuationCalc"));
const CashBalancePlanCalc = lazy(() => import("./pages/portal/CashBalancePlanCalc"));
const EntityComparisonCalc = lazy(() => import("./pages/portal/EntityComparisonCalc"));
const QBICalculator = lazy(() => import("./pages/portal/QBICalculator"));
const DeferredCompCalc = lazy(() => import("./pages/portal/DeferredCompCalc"));
const CaptiveInsuranceCalc = lazy(() => import("./pages/portal/CaptiveInsuranceCalc"));
const SuccessionPlanCalc = lazy(() => import("./pages/portal/SuccessionPlanCalc"));
const ESOPCalculator = lazy(() => import("./pages/portal/ESOPCalculator"));
const SeveranceCalc = lazy(() => import("./pages/portal/SeveranceCalc"));
const OverheadExpenseCalc = lazy(() => import("./pages/portal/OverheadExpenseCalc"));
const AssetAllocationCalc = lazy(() => import("./pages/portal/AssetAllocationCalc"));
const PrivateEquityIRRCalc = lazy(() => import("./pages/portal/PrivateEquityIRRCalc"));
const BondLadderCalc = lazy(() => import("./pages/portal/BondLadderCalc"));
const MuniBondLadderCalc = lazy(() => import("./pages/portal/MuniBondLadderCalc"));
const DRIPGrowthCalc = lazy(() => import("./pages/portal/DRIPGrowthCalc"));
const OptionsProfitCalc = lazy(() => import("./pages/portal/OptionsProfitCalc"));
const PortfolioRiskCalc = lazy(() => import("./pages/portal/PortfolioRiskCalc"));
const SectorRotationCalc = lazy(() => import("./pages/portal/SectorRotationCalc"));
const FeeImpactCalc = lazy(() => import("./pages/portal/FeeImpactCalc"));
const TaxLossHarvestCalc = lazy(() => import("./pages/portal/TaxLossHarvestCalc"));
const Budget503020Calc = lazy(() => import("./pages/portal/Budget503020Calc"));
const ZeroBasedBudgetCalc = lazy(() => import("./pages/portal/ZeroBasedBudgetCalc"));
const SpendVsInvestCalc = lazy(() => import("./pages/portal/SpendVsInvestCalc"));
const LeaseVsBuyCalc = lazy(() => import("./pages/portal/LeaseVsBuyCalc"));
const StudentLoanVsInvestCalc = lazy(() => import("./pages/portal/StudentLoanVsInvestCalc"));
const CreditCardPayoffCalc = lazy(() => import("./pages/portal/CreditCardPayoffCalc"));
const SavingsRateCalc = lazy(() => import("./pages/portal/SavingsRateCalc"));
const CostOfWaitingCalc = lazy(() => import("./pages/portal/CostOfWaitingCalc"));
const LifestyleInflationCalc = lazy(() => import("./pages/portal/LifestyleInflationCalc"));
const FinancialFreedomCalc = lazy(() => import("./pages/portal/FinancialFreedomCalc"));
const MegaBackdoorRothCalc = lazy(() => import("./pages/portal/MegaBackdoorRothCalc"));
const BackdoorRothCalc = lazy(() => import("./pages/portal/BackdoorRothCalc"));
const RothVsTraditionalCalc = lazy(() => import("./pages/portal/RothVsTraditionalCalc"));
const NUACalculator = lazy(() => import("./pages/portal/NUACalculator"));
const CharitableStockCalc = lazy(() => import("./pages/portal/CharitableStockCalc"));
const InstallmentSaleCalc = lazy(() => import("./pages/portal/InstallmentSaleCalc"));
const LikeKindExchangeCalc = lazy(() => import("./pages/portal/LikeKindExchangeCalc"));
const TaxGainLossCalc = lazy(() => import("./pages/portal/TaxGainLossCalc"));
const StateTaxArbitrageCalc = lazy(() => import("./pages/portal/StateTaxArbitrageCalc"));
const IncomeShiftingCalc = lazy(() => import("./pages/portal/IncomeShiftingCalc"));
const SpecialNeedsTrustCalc = lazy(() => import("./pages/portal/SpecialNeedsTrustCalc"));
const DivorceSettlementCalc = lazy(() => import("./pages/portal/DivorceSettlementCalc"));
const AlimonyTaxCalc = lazy(() => import("./pages/portal/AlimonyTaxCalc"));
const WindfallCalc = lazy(() => import("./pages/portal/WindfallCalc"));
const SabbaticalPlannerCalc = lazy(() => import("./pages/portal/SabbaticalPlannerCalc"));
const ACASubsidyCalc = lazy(() => import("./pages/portal/ACASubsidyCalc"));
const HSATripleTaxCalc = lazy(() => import("./pages/portal/HSATripleTaxCalc"));
const PensionMaxCalc = lazy(() => import("./pages/portal/PensionMaxCalc"));
const AnnuityComparisonCalc = lazy(() => import("./pages/portal/AnnuityComparisonCalc"));
const FinancialHealthScoreCalc = lazy(() => import("./pages/portal/FinancialHealthScoreCalc"));
const RetirementAdvantage = lazy(() => import("./pages/portal/RetirementAdvantage"));

// ── Sister Invention Patent Pages (SI-001 through SI-027) ──────────────────
const IULComplianceEngine = lazy(() => import("./pages/portal/IULComplianceEngine"));
const MultiCarrierIULOptimizer = lazy(() => import("./pages/portal/MultiCarrierIULOptimizer"));
const PolicyReplacementAnalyzer = lazy(() => import("./pages/portal/PolicyReplacementAnalyzer"));
const PremiumFinancingArbitrage = lazy(() => import("./pages/portal/PremiumFinancingArbitrage"));
const LivingBenefitsProbability = lazy(() => import("./pages/portal/LivingBenefitsProbability"));
const TaxCodeChangeSimulator = lazy(() => import("./pages/portal/TaxCodeChangeSimulator"));
const BehavioralBiasDetector = lazy(() => import("./pages/portal/BehavioralBiasDetector"));
const SocialSecurityBridge = lazy(() => import("./pages/portal/SocialSecurityBridge"));
const StateTaxMigration = lazy(() => import("./pages/portal/StateTaxMigration"));
const CaptiveInsuranceIUL = lazy(() => import("./pages/portal/CaptiveInsuranceIUL"));
const DivorceFinancialImpact = lazy(() => import("./pages/portal/DivorceFinancialImpact"));
const DisabilityGapAnalysis = lazy(() => import("./pages/portal/DisabilityGapAnalysis"));
const FamilyTreeFinancial = lazy(() => import("./pages/portal/FamilyTreeFinancial"));
const GenerationalWealthSim = lazy(() => import("./pages/portal/GenerationalWealthSim"));
const CarrierStrengthMonitor = lazy(() => import("./pages/portal/CarrierStrengthMonitor"));
const SuccessionValuation = lazy(() => import("./pages/portal/SuccessionValuation"));
const CommissionOptimizer = lazy(() => import("./pages/portal/CommissionOptimizer"));
const PeerBenchmarkingIntel = lazy(() => import("./pages/portal/PeerBenchmarkingIntel"));
const CECreditTracker = lazy(() => import("./pages/portal/CECreditTracker"));
const ComplianceDocGenerator = lazy(() => import("./pages/portal/ComplianceDocGenerator"));
const ClientRetentionPredictor = lazy(() => import("./pages/portal/ClientRetentionPredictor"));
const ProspectQualification = lazy(() => import("./pages/portal/ProspectQualification"));
const MultiCurrencyWealth = lazy(() => import("./pages/portal/MultiCurrencyWealth"));
const AnnuityHiddenFee = lazy(() => import("./pages/portal/AnnuityHiddenFee"));
const ClientOnboardingWorkflow = lazy(() => import("./pages/portal/ClientOnboardingWorkflow"));
const RetirementGapInflation = lazy(() => import("./pages/portal/RetirementGapInflation"));
const CRTWealthReplacement = lazy(() => import("./pages/portal/CRTWealthReplacement"));
const InnovationDashboard = lazy(() => import("./pages/portal/InnovationDashboard"));
const UsageAnalyticsDashboard = lazy(() => import("./pages/portal/UsageAnalyticsDashboard"));
const EngineChainingPipeline = lazy(() => import("./pages/portal/EngineChainingPipeline"));
const ClientReportBuilder = lazy(() => import("./pages/portal/ClientReportBuilder"));
const RiskComplianceDashboard = lazy(() => import("./pages/portal/RiskComplianceDashboard"));
const GenerationalWealthSimulator = lazy(() => import("./pages/portal/GenerationalWealthSimulator"));
const ClientRetentionAssistant = lazy(() => import("./pages/portal/ClientRetentionAssistant"));
const AIStrategyLabPro = lazy(() => import("./pages/portal/AIStrategyLabPro"));
const WealthProjectionTheater = lazy(() => import("./pages/portal/WealthProjectionTheater"));
const EngineFusionLab = lazy(() => import("./pages/portal/EngineFusionLab"));
const AIDealCloser = lazy(() => import("./pages/portal/AIDealCloser"));
const PersonaHub = lazy(() => import("./pages/portal/PersonaHub"));
const FinancialDNA = lazy(() => import("./pages/portal/FinancialDNA"));
const WealthRituals = lazy(() => import("./pages/portal/WealthRituals"));
const MasteryNexus = lazy(() => import("./pages/portal/MasteryNexus"));
const HeartfireLegacy = lazy(() => import("./pages/portal/HeartfireLegacy"));
const StrategySynergyHub = lazy(() => import("./pages/portal/StrategySynergyHub"));
const PresentationVault = lazy(() => import("./pages/portal/PresentationVault"));
const FinancialFluencyAcademy = lazy(() => import("./pages/portal/FinancialFluencyAcademy"));
const PracticeWealthSync = lazy(() => import("./pages/portal/PracticeWealthSync"));
const ComplianceCommandCenter = lazy(() => import("./pages/portal/ComplianceCommandCenter"));
const PeerTrustNetwork = lazy(() => import("./pages/portal/PeerTrustNetwork"));
const AutoPilotWorkflow = lazy(() => import("./pages/portal/AutoPilotWorkflow"));
const DimensionalWealthCanvas = lazy(() => import("./pages/portal/DimensionalWealthCanvas"));
const ClientJourneyNavigator = lazy(() => import("./pages/portal/ClientJourneyNavigator"));
const MarketPulseSentinel = lazy(() => import("./pages/portal/MarketPulseSentinel"));
const ExecutiveCommandCenter = lazy(() => import("./pages/portal/ExecutiveCommandCenter"));
const AIWealthConcierge = lazy(() => import("./pages/portal/AIWealthConcierge"));
const ImpactScorecard = lazy(() => import("./pages/portal/ImpactScorecard"));
const LegacyVault = lazy(() => import("./pages/portal/LegacyVault"));
const AIBrainHubPage = lazy(() => import("./pages/AIBrainHubPage"));

// === COMBINATION SUPER-PATENTS ===
const AIBehavioralFinancialPlanning = lazy(() => import("./pages/portal/AIBehavioralFinancialPlanning"));
const UnifiedCrossFeatureIntelligence = lazy(() => import("./pages/portal/UnifiedCrossFeatureIntelligence"));
const CascadingMultiStrategyOptimizer = lazy(() => import("./pages/portal/CascadingMultiStrategyOptimizer"));
const LongitudinalRiskOptimizer = lazy(() => import("./pages/portal/LongitudinalRiskOptimizer"));

// === NEW PATENT FEATURES ===
const UnifiedDataBusDashboard = lazy(() => import("./pages/portal/UnifiedDataBusDashboard"));
const LivingRiskProfile = lazy(() => import("./pages/portal/LivingRiskProfile"));
const OrganismDashboard = lazy(() => import("./pages/portal/OrganismDashboard"));
const CalcInteropMatrix = lazy(() => import("./pages/portal/CalcInteropMatrix"));
const AlertCommandCenter = lazy(() => import("./pages/portal/AlertCommandCenter"));
const DataCompletenessTracker = lazy(() => import("./pages/portal/DataCompletenessTracker"));
const CrossCalcAggregationHub = lazy(() => import("./pages/portal/CrossCalcAggregationHub"));
const SmartRoutingDashboard = lazy(() => import("./pages/portal/SmartRoutingDashboard"));
const MeshHealthMonitor = lazy(() => import("./pages/portal/MeshHealthMonitor"));
const TaxOptimizationCommand = lazy(() => import("./pages/portal/TaxOptimizationCommand"));
const RetirementReadinessCenter = lazy(() => import("./pages/portal/RetirementReadinessCenter"));
const InsuranceCoverageCommand = lazy(() => import("./pages/portal/InsuranceCoverageCommand"));
const EstateWealthTransfer = lazy(() => import("./pages/portal/EstateWealthTransfer"));
const DataFlowVisualizer = lazy(() => import("./pages/portal/DataFlowVisualizer"));
const WealthAccumulationTimeline = lazy(() => import("./pages/portal/WealthAccumulationTimeline"));
const DeepOrganismDashboard = lazy(() => import("./pages/portal/DeepOrganismDashboard"));
const OrganismControlCenter = lazy(() => import("./pages/portal/OrganismControlCenter"));
const FinancialNerveCenter = lazy(() => import("./pages/portal/FinancialNerveCenter"));
const OrganismHealthReport = lazy(() => import("./pages/portal/OrganismHealthReport"));
const ClientFinancialHealthScore = lazy(() => import("./pages/portal/ClientFinancialHealthScore"));
const AdvisorMeetingPrep = lazy(() => import("./pages/portal/AdvisorMeetingPrep"));
const PortfolioStressTest = lazy(() => import("./pages/portal/PortfolioStressTest"));
const TaxStrategyOptimizer = lazy(() => import("./pages/portal/TaxStrategyOptimizer"));
const EstatePlanningSimulator = lazy(() => import("./pages/portal/EstatePlanningSimulator"));
const InsuranceGapAnalyzer = lazy(() => import("./pages/portal/InsuranceGapAnalyzer"));
const RetirementIncomeProjector = lazy(() => import("./pages/portal/RetirementIncomeProjector"));

const RothConversionAnalyzer = lazy(() => import("./pages/portal/RothConversionAnalyzer"));
const CaptiveInsuranceModeler = lazy(() => import("./pages/portal/CaptiveInsuranceModeler"));
const PremiumFinancingCalculator = lazy(() => import("./pages/portal/PremiumFinancingCalculator"));
const Exchange1031Analyzer = lazy(() => import("./pages/portal/Exchange1031Analyzer"));
const CostSegregationEngine = lazy(() => import("./pages/portal/CostSegregationEngine"));
const DynastyTrustPlanner = lazy(() => import("./pages/portal/DynastyTrustPlanner"));
const SLATPlanner = lazy(() => import("./pages/portal/SLATPlanner"));
const IDGTModeler = lazy(() => import("./pages/portal/IDGTModeler"));
const ILITAnalyzer = lazy(() => import("./pages/portal/ILITAnalyzer"));
const AnnuityWaterfallEngine = lazy(() => import("./pages/portal/AnnuityWaterfallEngine"));
const OilGasTaxStrategy = lazy(() => import("./pages/portal/OilGasTaxStrategy"));
const QSBSExclusionCalc = lazy(() => import("./pages/portal/QSBSExclusionCalc"));
const DSTAnalyzer = lazy(() => import("./pages/portal/DSTAnalyzer"));
const NIISurtaxOptimizer = lazy(() => import("./pages/portal/NIISurtaxOptimizer"));
const OpportunityZonePlanner = lazy(() => import("./pages/portal/OpportunityZonePlanner"));
const PPLIModeler = lazy(() => import("./pages/portal/PPLIModeler"));
const DefinedBenefitPlanner = lazy(() => import("./pages/portal/DefinedBenefitPlanner"));
const StudentLoanOptimizer = lazy(() => import("./pages/portal/StudentLoanOptimizer"));
const PhysicianMortgageAnalyzer = lazy(() => import("./pages/portal/PhysicianMortgageAnalyzer"));
const PracticeValuation = lazy(() => import("./pages/portal/PracticeValuation"));
const IncomeProtectionPlanner = lazy(() => import("./pages/portal/IncomeProtectionPlanner"));
const DisabilityGapAnalyzer = lazy(() => import("./pages/portal/DisabilityGapAnalyzer"));
const HSAMaximizer = lazy(() => import("./pages/portal/HSAMaximizer"));
const BackdoorRothGuide = lazy(() => import("./pages/portal/BackdoorRothGuide"));
const MegaBackdoorRoth = lazy(() => import("./pages/portal/MegaBackdoorRoth"));
const NUAStrategy = lazy(() => import("./pages/portal/NUAStrategy"));
const Section199AOptimizer = lazy(() => import("./pages/portal/Section199AOptimizer"));
const CharitableLeadTrust = lazy(() => import("./pages/portal/CharitableLeadTrust"));
const FamilyLimitedPartnership = lazy(() => import("./pages/portal/FamilyLimitedPartnership"));
const MortgageKillerV2 = lazy(() => import("./pages/portal/MortgageKillerV2"));
const ShortTermRentalStrategy = lazy(() => import("./pages/portal/ShortTermRentalStrategy"));
const DeferredCompensation = lazy(() => import("./pages/portal/DeferredCompensation"));
const NavPlaceholder = lazy(() => import("./pages/portal/NavPlaceholder"));
const ExecutiveBonusPlan = lazy(() => import("./pages/portal/ExecutiveBonusPlan"));
const SplitDollarLife = lazy(() => import("./pages/portal/SplitDollarLife"));
const KeyPersonInsurance = lazy(() => import("./pages/portal/KeyPersonInsurance"));
const MYGAWaterfallComparison = lazy(() => import("./pages/portal/MYGAWaterfallComparison"));
const BusinessSuccession = lazy(() => import("./pages/portal/BusinessSuccession"));
const BuySellAgreement = lazy(() => import("./pages/portal/BuySellAgreement"));
const QualifiedPlanMaximizer = lazy(() => import("./pages/portal/QualifiedPlanMaximizer"));
const CrossPurchaseAgreement = lazy(() => import("./pages/portal/CrossPurchaseAgreement"));
const CRTDeepDive = lazy(() => import("./pages/portal/CRTDeepDive"));
const AssetProtection = lazy(() => import("./pages/portal/AssetProtection"));
const WealthTransferScorecard = lazy(() => import("./pages/portal/WealthTransferScorecard"));
const TaxLossHarvesting = lazy(() => import("./pages/portal/TaxLossHarvesting"));
const AlternativeInvestment = lazy(() => import("./pages/portal/AlternativeInvestment"));
const PrivateCredit = lazy(() => import("./pages/portal/PrivateCredit"));
const ConcentratedStock = lazy(() => import("./pages/portal/ConcentratedStock"));
const EmployeeStockOptions = lazy(() => import("./pages/portal/EmployeeStockOptions"));
const RSUTaxPlanning = lazy(() => import("./pages/portal/RSUTaxPlanning"));
const Education529Planner = lazy(() => import("./pages/portal/Education529Planner"));
const CryptoTaxStrategy = lazy(() => import("./pages/portal/CryptoTaxStrategy"));
const InternationalTax = lazy(() => import("./pages/portal/InternationalTax"));
const InstallmentSale = lazy(() => import("./pages/portal/InstallmentSale"));
const PrivatePlacement = lazy(() => import("./pages/portal/PrivatePlacement"));
const SERPAnalyzer = lazy(() => import("./pages/portal/SERPAnalyzer"));
const GrantorTrustStrategy = lazy(() => import("./pages/portal/GrantorTrustStrategy"));
const QualifiedOpportunityFund = lazy(() => import("./pages/portal/QualifiedOpportunityFund"));
const Section1202Planner = lazy(() => import("./pages/portal/Section1202Planner"));
const CRUTDeepDive = lazy(() => import("./pages/portal/CRUTDeepDive"));
const SLATDeepDive = lazy(() => import("./pages/portal/SLATDeepDive"));
const GSTTrustPlanner = lazy(() => import("./pages/portal/GSTTrustPlanner"));
const ILITDeepDive = lazy(() => import("./pages/portal/ILITDeepDive"));
const QPRTPlanner = lazy(() => import("./pages/portal/QPRTPlanner"));
const GRATPlanner = lazy(() => import("./pages/portal/GRATPlanner"));
const BeneficiaryIRAPlanner = lazy(() => import("./pages/portal/BeneficiaryIRAPlanner"));
const StretchIRAStrategy = lazy(() => import("./pages/portal/StretchIRAStrategy"));
const InheritedRothPlanner = lazy(() => import("./pages/portal/InheritedRothPlanner"));
const MedicareIRMAAPlanner = lazy(() => import("./pages/portal/MedicareIRMAAPlanner"));
const LongTermCarePlanner = lazy(() => import("./pages/portal/LongTermCarePlanner"));
const MedicaidPlanning = lazy(() => import("./pages/portal/MedicaidPlanning"));
const DivorceFinancialPlanner = lazy(() => import("./pages/portal/DivorceFinancialPlanner"));
const BusinessEntitySelector = lazy(() => import("./pages/portal/BusinessEntitySelector"));
const PhantomStockPlanner = lazy(() => import("./pages/portal/PhantomStockPlanner"));
const EmployeeRetentionStrategy = lazy(() => import("./pages/portal/EmployeeRetentionStrategy"));
const SuccessionPlanningHub = lazy(() => import("./pages/portal/SuccessionPlanningHub"));
const EquityCompensationHub = lazy(() => import("./pages/portal/EquityCompensationHub"));
const CharitableGivingDashboard = lazy(() => import("./pages/portal/CharitableGivingDashboard"));
const RealEstatePortfolioManager = lazy(() => import("./pages/portal/RealEstatePortfolioManager"));
const PensionMaximization = lazy(() => import("./pages/portal/PensionMaximization"));
const SpousalLifetimeAccess = lazy(() => import("./pages/portal/SpousalLifetimeAccess"));
const WealthTransferTimeline = lazy(() => import("./pages/portal/WealthTransferTimeline"));
const FinancialIndependenceCalc = lazy(() => import("./pages/portal/FinancialIndependenceCalc"));
const PrivateFoundationPlanner = lazy(() => import("./pages/portal/PrivateFoundationPlanner"));
const DAFStrategicPlanner = lazy(() => import("./pages/portal/DAFStrategicPlanner"));
const QPRTAdvancedPlanner = lazy(() => import("./pages/portal/QPRTAdvancedPlanner"));
const IDGTAdvancedModeler = lazy(() => import("./pages/portal/IDGTAdvancedModeler"));
const EstateFreezeComparison = lazy(() => import("./pages/portal/EstateFreezeComparison"));
const TrustComparisonMatrix = lazy(() => import("./pages/portal/TrustComparisonMatrix"));
const WealthAccumulationSimulator = lazy(() => import("./pages/portal/WealthAccumulationSimulator"));
const NetWorthTracker = lazy(() => import("./pages/portal/NetWorthTracker"));
const CashFlowOptimizer = lazy(() => import("./pages/portal/CashFlowOptimizer"));
const DebtPayoffStrategy = lazy(() => import("./pages/portal/DebtPayoffStrategy"));
const EmergencyFundPlanner = lazy(() => import("./pages/portal/EmergencyFundPlanner"));
const CollegeAidOptimizer = lazy(() => import("./pages/portal/CollegeAidOptimizer"));
const SocialSecurityMaximizer = lazy(() => import("./pages/portal/SocialSecurityMaximizer"));
const MedicarePartDPlanner = lazy(() => import("./pages/portal/MedicarePartDPlanner"));
const LongTermCareHybrid = lazy(() => import("./pages/portal/LongTermCareHybrid"));
const AnnuityIncomeBridge = lazy(() => import("./pages/portal/AnnuityIncomeBridge"));
const SequenceOfReturnsRisk = lazy(() => import("./pages/portal/SequenceOfReturnsRisk"));
const WithdrawalRateOptimizer = lazy(() => import("./pages/portal/WithdrawalRateOptimizer"));
const TaxBracketNavigator = lazy(() => import("./pages/portal/TaxBracketNavigator"));
const AMTAnalyzer = lazy(() => import("./pages/portal/AMTAnalyzer"));
const BusinessExitPlanner = lazy(() => import("./pages/portal/BusinessExitPlanner"));
const ESOPAnalyzer = lazy(() => import("./pages/portal/ESOPAnalyzer"));
const CharitableRemainderUniTrust = lazy(() => import("./pages/portal/CharitableRemainderUniTrust"));
const FamilyOfficeSimulator = lazy(() => import("./pages/portal/FamilyOfficeSimulator"));
const IULMaxFundedEngine = lazy(() => import("./pages/portal/IULMaxFundedEngine"));
const WholeLifeDividendEngine = lazy(() => import("./pages/portal/WholeLifeDividendEngine"));
const RealEstateSyndicationAnalyzer = lazy(() => import("./pages/portal/RealEstatesyndicationAnalyzer"));
const TenantInCommonAnalyzer = lazy(() => import("./pages/portal/TenantInCommonAnalyzer"));
const InflationProtectionSuite = lazy(() => import("./pages/portal/InflationProtectionSuite"));
const PhysicianRetirementBlueprint = lazy(() => import("./pages/portal/PhysicianRetirementBlueprint"));
const TaxAlphaScorecard = lazy(() => import("./pages/portal/TaxAlphaScorecard"));
const RetirementReadinessScore = lazy(() => import("./pages/portal/RetirementReadinessScore"));
const MultiGenerationalWealthEngine = lazy(() => import("./pages/portal/MultiGenerationalWealthEngine"));
const RiskToleranceProfiler = lazy(() => import("./pages/portal/RiskToleranceProfiler"));
const FinancialPlanChecklist = lazy(() => import("./pages/portal/FinancialPlanChecklist"));
const ClientPresentationBuilder = lazy(() => import("./pages/portal/ClientPresentationBuilder"));
const FIDOComplianceTracker = lazy(() => import("./pages/portal/FIDOComplianceTracker"));
const AuditDefensePrep = lazy(() => import("./pages/portal/AuditDefensePrep"));
const FBARFATCACompliance = lazy(() => import("./pages/portal/FBARFATCACompliance"));
const OpportunityZoneTracker = lazy(() => import("./pages/portal/OpportunityZoneTracker"));
const CryptoTaxNavigator = lazy(() => import("./pages/portal/CryptoTaxNavigator"));
const AlternativeInvestmentDueDiligence = lazy(() => import("./pages/portal/AlternativeInvestmentDueDiligence"));
const SpecialNeedsPlanner = lazy(() => import("./pages/portal/SpecialNeedsPlanner"));
const ExpatTaxPlanner = lazy(() => import("./pages/portal/ExpatTaxPlanner"));
const ExecutiveCompOptimizer = lazy(() => import("./pages/portal/ExecutiveCompOptimizer"));
const HealthcareCostProjector = lazy(() => import("./pages/portal/HealthcareCostProjector"));
const SuccessionPlanningEngine = lazy(() => import("./pages/portal/SuccessionPlanningEngine"));
const PrivatePlacementLifeInsurance = lazy(() => import("./pages/portal/PrivatePlacementLifeInsurance"));
const InternationalTrustPlanner = lazy(() => import("./pages/portal/InternationalTrustPlanner"));
const CaptiveInsurancePlanner = lazy(() => import("./pages/portal/CaptiveInsurancePlanner"));
const PrivateCreditAnalyzer = lazy(() => import("./pages/portal/PrivateCreditAnalyzer"));
const TaxableEstateCalculator = lazy(() => import("./pages/portal/TaxableEstateCalculator"));
const WealthTransferScoreboard = lazy(() => import("./pages/portal/WealthTransferScoreboard"));
const FamilyLimitedPartnershipPlanner = lazy(() => import("./pages/portal/FamilyLimitedPartnershipPlanner"));
const NetUnrealizedAppreciationPlanner = lazy(() => import("./pages/portal/NetUnrealizedAppreciationPlanner"));
const QualifiedSmallBusinessStock = lazy(() => import("./pages/portal/QualifiedSmallBusinessStock"));
const DefinedBenefitPlanDesigner = lazy(() => import("./pages/portal/DefinedBenefitPlanDesigner"));
const SplitDollarLifeInsurance = lazy(() => import("./pages/portal/SplitDollarLifeInsurance"));
const StructuredNoteAnalyzer = lazy(() => import("./pages/portal/StructuredNoteAnalyzer"));
const Section1031AdvancedExchange = lazy(() => import("./pages/portal/Section1031AdvancedExchange"));
const Section199ADeductionOptimizer = lazy(() => import("./pages/portal/Section199ADeductionOptimizer"));
const CharitableRemainderTrustEngine = lazy(() => import("./pages/portal/CharitableRemainderTrustEngine"));
const PrivateEquityTaxPlanner = lazy(() => import("./pages/portal/PrivateEquityTaxPlanner"));
const EstatePlanningTimeline = lazy(() => import("./pages/portal/EstatePlanningTimeline"));
const TaxEfficientWithdrawalSequencer = lazy(() => import("./pages/portal/TaxEfficientWithdrawalSequencer"));
const InflationAdjustedReturnCalculator = lazy(() => import("./pages/portal/InflationAdjustedReturnCalculator"));
const FamilyGovernanceFramework = lazy(() => import("./pages/portal/FamilyGovernanceFramework"));
const BondLadderConstructor = lazy(() => import("./pages/portal/BondLadderConstructor"));
const DigitalAssetEstatePlanner = lazy(() => import("./pages/portal/DigitalAssetEstatePlanner"));
const SurvivorBenefitPlanner = lazy(() => import("./pages/portal/SurvivorBenefitPlanner"));
const WealthDashboardSummary = lazy(() => import("./pages/portal/WealthDashboardSummary"));
const TrustDecantingPlanner = lazy(() => import("./pages/portal/TrustDecantingPlanner"));
const DirectIndexingOptimizer = lazy(() => import("./pages/portal/DirectIndexingOptimizer"));
const ESOPLeveragedBuyoutPlanner = lazy(() => import("./pages/portal/ESOPLeveragedBuyoutPlanner"));
const PostMortemTaxPlanner = lazy(() => import("./pages/portal/PostMortemTaxPlanner"));
const IncentiveTrustDesigner = lazy(() => import("./pages/portal/IncentiveTrustDesigner"));
const ComprehensiveIRCReferenceIndex = lazy(() => import("./pages/portal/ComprehensiveIRCReferenceIndex"));
const AlternativeMinimumTaxPlanner = lazy(() => import("./pages/portal/AlternativeMinimumTaxPlanner"));
const GraniteStateTrustPlanner = lazy(() => import("./pages/portal/GraniteStateTrustPlanner"));
const PrivatePlacementAnnuity = lazy(() => import("./pages/portal/PrivatePlacementAnnuity"));
const MultiGenerationalRothStrategy = lazy(() => import("./pages/portal/MultiGenerationalRothStrategy"));
const DeferredCompensationAnalyzer = lazy(() => import("./pages/portal/DeferredCompensationAnalyzer"));
const CharitableLeadTrustEngine = lazy(() => import("./pages/portal/CharitableLeadTrustEngine"));
const Section2701ValuationPlanner = lazy(() => import("./pages/portal/Section2701ValuationPlanner"));
const SpousalLifetimeAccessTrust = lazy(() => import("./pages/portal/SpousalLifetimeAccessTrust"));
const Section529AdvancedPlanner = lazy(() => import("./pages/portal/Section529AdvancedPlanner"));
const RetirementIncomeFloorPlanner = lazy(() => import("./pages/portal/RetirementIncomeFloorPlanner"));
const PhilanthropyImpactDashboard = lazy(() => import("./pages/portal/PhilanthropyImpactDashboard"));
const TaxProjectionEngine = lazy(() => import("./pages/portal/TaxProjectionEngine"));
const VariableAnnuityAnalyzer = lazy(() => import("./pages/portal/VariableAnnuityAnalyzer"));
const HealthSavingsAccountMaximizer = lazy(() => import("./pages/portal/HealthSavingsAccountMaximizer"));
const InternationalTaxPlanner = lazy(() => import("./pages/portal/InternationalTaxPlanner"));
const EstateLiquidityPlanner = lazy(() => import("./pages/portal/EstateLiquidityPlanner"));
const RetirementHealthcareCostPlanner = lazy(() => import("./pages/portal/RetirementHealthcareCostPlanner"));
const FiduciaryDutyTracker = lazy(() => import("./pages/portal/FiduciaryDutyTracker"));
const KeyPersonInsurancePlanner = lazy(() => import("./pages/portal/KeyPersonInsurancePlanner"));
const MunicipalBondLadderBuilder = lazy(() => import("./pages/portal/MunicipalBondLadderBuilder"));
const EquityCompensationNavigator = lazy(() => import("./pages/portal/EquityCompensationNavigator"));
const LifeSettlementAnalyzer = lazy(() => import("./pages/portal/LifeSettlementAnalyzer"));
const CharitableLeadTrustPlanner = lazy(() => import("./pages/portal/CharitableLeadTrustPlanner"));
const RetirementPlanDistributionPlanner = lazy(() => import("./pages/portal/RetirementPlanDistributionPlanner"));
const PremiumFinancingEngine = lazy(() => import("./pages/portal/PremiumFinancingEngine"));
const FamilyBankStrategy = lazy(() => import("./pages/portal/FamilyBankStrategy"));
const AlternativeInvestmentDueDiligence2 = lazy(() => import("./pages/portal/AlternativeInvestmentDueDiligence"));
const BusinessValuationEstimator = lazy(() => import("./pages/portal/BusinessValuationEstimator"));
const TaxCreditOptimizer = lazy(() => import("./pages/portal/TaxCreditOptimizer"));
const CrossBorderWealthPlanner = lazy(() => import("./pages/portal/CrossBorderWealthPlanner"));
const DebtRecyclingStrategy = lazy(() => import("./pages/portal/DebtRecyclingStrategy"));
const CashBalancePlanDesigner = lazy(() => import("./pages/portal/CashBalancePlanDesigner"));
const PrivateREITAnalyzer = lazy(() => import("./pages/portal/PrivateREITAnalyzer"));
const TaxDeferredExchangeTimeline = lazy(() => import("./pages/portal/TaxDeferredExchangeTimeline"));
const SocialSecurityBridgeStrategy = lazy(() => import("./pages/portal/SocialSecurityBridgeStrategy"));
const WealthTransferVehicleComparison = lazy(() => import("./pages/portal/WealthTransferVehicleComparison"));
const ShortTermRentalTaxStrategy = lazy(() => import("./pages/portal/ShortTermRentalTaxStrategy"));
const InfinityBankingConcept = lazy(() => import("./pages/portal/InfinityBankingConcept"));
const TaxLossHarvestingEngine = lazy(() => import("./pages/portal/TaxLossHarvestingEngine"));
const DynastyTrustArchitect = lazy(() => import("./pages/portal/DynastyTrustArchitect"));
const RetirementSpendingGuardrails = lazy(() => import("./pages/portal/RetirementSpendingGuardrails"));
const CostSegregationAccelerator = lazy(() => import("./pages/portal/CostSegregationAccelerator"));
const PhysicianFinancialBlueprint = lazy(() => import("./pages/portal/PhysicianFinancialBlueprint"));
const RealEstateStackingStrategy = lazy(() => import("./pages/portal/RealEstateStackingStrategy"));
const ExecutiveRetirementBridge = lazy(() => import("./pages/portal/ExecutiveRetirementBridge"));
const TrustFundingChecklist = lazy(() => import("./pages/portal/TrustFundingChecklist"));
const VolatilityHarvestingEngine = lazy(() => import("./pages/portal/VolatilityHarvestingEngine"));
const SyndicationDealAnalyzer = lazy(() => import("./pages/portal/SyndicationDealAnalyzer"));
const FamilyWealthConstitution = lazy(() => import("./pages/portal/FamilyWealthConstitution"));
const TaxableAccountOptimizer = lazy(() => import("./pages/portal/TaxableAccountOptimizer"));
const DigitalEstatePlanner = lazy(() => import("./pages/portal/DigitalEstatePlanner"));
const PensionMaximizationEngine = lazy(() => import("./pages/portal/PensionMaximizationEngine"));
const AlternativeInvestmentAllocator = lazy(() => import("./pages/portal/AlternativeInvestmentAllocator"));
const ClientReportGenerator = lazy(() => import("./pages/portal/ClientReportGenerator"));
const ComboRecommender = lazy(() => import("./pages/portal/ComboRecommender"));
const FIACollateralStrategy = lazy(() => import("./pages/portal/FIACollateralStrategy"));
const OrganismDeepProvider = lazy(() => import("./pages/portal/OrganismDeepProvider").then(m => ({ default: m.OrganismDeepProvider })));
const PrivateEquitySecondaryMarket = lazy(() => import("./pages/portal/PrivateEquitySecondaryMarket"));
const RealEstateDepreciationRecapture = lazy(() => import("./pages/portal/RealEstateDepreciationRecapture"));
const RetirementIncomeFloorStrategy = lazy(() => import("./pages/portal/RetirementIncomeFloorStrategy"));
const StructuredSettlementPlanner = lazy(() => import("./pages/portal/StructuredSettlementPlanner"));
const WealthErosionTracker = lazy(() => import("./pages/portal/WealthErosionTracker"));
const ToolExplorer = lazy(() => import("./pages/portal/ToolExplorer"));

// --- Consolidation hubs (41) ---
const ResultRevealDemo = lazy(() => import("@/pages/ResultRevealDemo"));
const LabLayer2 = lazy(() => import("@/pages/LabLayer2"));
const BusinessSuccessionHub = lazy(() => import("@/pages/hubs/BusinessSuccessionHub"));
const SlidesPresentationsHub = lazy(() => import("@/pages/hubs/SlidesPresentationsHub"));
const IllustrationQuotingHub = lazy(() => import("@/pages/hubs/IllustrationQuotingHub"));
const SalesStoryBuilderHub = lazy(() => import("@/pages/hubs/SalesStoryBuilderHub"));
const EstateDocumentsHub = lazy(() => import("@/pages/hubs/EstateDocumentsHub"));
const EstateTaxLiquidityHub = lazy(() => import("@/pages/hubs/EstateTaxLiquidityHub"));
const DynastyMultiGenTransferHub = lazy(() => import("@/pages/hubs/DynastyMultiGenTransferHub"));
const AnnuityComparisonReviewHub = lazy(() => import("@/pages/hubs/AnnuityComparisonReviewHub"));
const GuaranteedLifetimeIncomeHub = lazy(() => import("@/pages/hubs/GuaranteedLifetimeIncomeHub"));
const RothStrategyHub = lazy(() => import("@/pages/hubs/RothStrategyHub"));
const LtcPlanningHub = lazy(() => import("@/pages/hubs/LtcPlanningHub"));
const PolicyReviewHub = lazy(() => import("@/pages/hubs/PolicyReviewHub"));
const CaptiveInsuranceHub = lazy(() => import("@/pages/hubs/CaptiveInsuranceHub"));
const PremiumFinancingHub = lazy(() => import("@/pages/hubs/PremiumFinancingHub"));
const MortgageRefiToolsHub = lazy(() => import("@/pages/hubs/MortgageRefiToolsHub"));
const MedicareIrmaaHub = lazy(() => import("@/pages/hubs/MedicareIrmaaHub"));
const TaxLossHarvestingHub = lazy(() => import("@/pages/hubs/TaxLossHarvestingHub"));
const PpliPrivatePlacementHub = lazy(() => import("@/pages/hubs/PpliPrivatePlacementHub"));
const BusinessValuationHub = lazy(() => import("@/pages/hubs/BusinessValuationHub"));
const BuySellFundingHub = lazy(() => import("@/pages/hubs/BuySellFundingHub"));
const DeferredCompHub = lazy(() => import("@/pages/hubs/DeferredCompHub"));
const KeyPersonInsuranceHub = lazy(() => import("@/pages/hubs/KeyPersonInsuranceHub"));
const DisabilityProtectionHub = lazy(() => import("@/pages/hubs/DisabilityProtectionHub"));
const H529EducationHub = lazy(() => import("@/pages/hubs/H529EducationHub"));
const MortgageKillerHub = lazy(() => import("@/pages/hubs/MortgageKillerHub"));
const RetirementIncomeProjectorHub = lazy(() => import("@/pages/hubs/RetirementIncomeProjectorHub"));
const SplitDollarHub = lazy(() => import("@/pages/hubs/SplitDollarHub"));
const SocialSecurityOptimizerHub = lazy(() => import("@/pages/hubs/SocialSecurityOptimizerHub"));
const Section199AQbiHub = lazy(() => import("@/pages/hubs/Section199AQbiHub"));
const IlitPlannerHub = lazy(() => import("@/pages/hubs/IlitPlannerHub"));
const QprtPlannerHub = lazy(() => import("@/pages/hubs/QprtPlannerHub"));
const StudentLoanHub = lazy(() => import("@/pages/hubs/StudentLoanHub"));
const PensionMaximizationHub = lazy(() => import("@/pages/hubs/PensionMaximizationHub"));
const H1031LikeKindExchangeHub = lazy(() => import("@/pages/hubs/H1031LikeKindExchangeHub"));
const CharitableTrustCrtCltHub = lazy(() => import("@/pages/hubs/CharitableTrustCrtCltHub"));
const GratPlannerHub = lazy(() => import("@/pages/hubs/GratPlannerHub"));
const IdgtGrantorTrustHub = lazy(() => import("@/pages/hubs/IdgtGrantorTrustHub"));
const SlatSpousalTrustHub = lazy(() => import("@/pages/hubs/SlatSpousalTrustHub"));
const AmtHub = lazy(() => import("@/pages/hubs/AmtHub"));
const OpportunityZoneHub = lazy(() => import("@/pages/hubs/OpportunityZoneHub"));
const DefinedBenefitCashBalanceHub = lazy(() => import("@/pages/hubs/DefinedBenefitCashBalanceHub"));

/**
 * Sleek loading spinner shown while lazy-loaded pages are being fetched.
 * Keeps the UI feeling responsive during route transitions.
 */
function PageLoader() {
  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <div className="flex flex-col items-center gap-4">
        <div className="relative">
          <div className="w-12 h-12 rounded-full border-4 border-emerald-500/20 border-t-emerald-500 animate-spin" />
        </div>
        <p className="text-sm text-muted-foreground animate-pulse">Loading...</p>
      </div>
    </div>
  );
}

/**
 * SUBSCRIPTION GUARD + COMPLIANCE DISCLAIMER gate to the dashboard.
 * Password gate or subscription required, then compliance disclaimer.
 * Access tiers: Owner (unlimited), Eternal (Welcome@7/18aLiHeap*), Subscriber, Trial (Welcome@1).
 */
function gated(Component: React.ComponentType<any>, returnPath: string, pageName?: string) {
  return function GatedRoute(props: any) {
    return (
      <SubscriptionGuard>
        <ComplianceGate returnTo={returnPath}>
          <PortalErrorBoundary pageName={pageName || returnPath} pagePath={returnPath}>
            <Component {...props} />
          </PortalErrorBoundary>
        </ComplianceGate>
      </SubscriptionGuard>
    );
  };
}

function Router() {
  return (
    <Suspense fallback={<PageLoader />}>
    <Switch>
      {/* === Consolidation hubs: shadow the parent path (parent becomes first tab) === */}
      <Route path="/portal/reveal-demo" component={gated(ResultRevealDemo, "/portal/reveal-demo")} />
      <Route path="/portal/lab" component={gated(LabLayer2, "/portal/lab")} />
      <Route path="/portal/succession-planning" component={gated(BusinessSuccessionHub, "/portal/succession-planning")} />
      <Route path="/portal/seminar-generator" component={gated(SlidesPresentationsHub, "/portal/seminar-generator")} />
      <Route path="/portal/illustration-compare" component={gated(IllustrationQuotingHub, "/portal/illustration-compare")} />
      <Route path="/portal/sales-story" component={gated(SalesStoryBuilderHub, "/portal/sales-story")} />
      <Route path="/portal/estate-flow" component={gated(EstateDocumentsHub, "/portal/estate-flow")} />
      <Route path="/portal/estate-tax" component={gated(EstateTaxLiquidityHub, "/portal/estate-tax")} />
      <Route path="/portal/multi-gen-wealth" component={gated(DynastyMultiGenTransferHub, "/portal/multi-gen-wealth")} />
      <Route path="/portal/existing-annuities" component={gated(AnnuityComparisonReviewHub, "/portal/existing-annuities")} />
      <Route path="/portal/withdrawal-sequencing" component={gated(GuaranteedLifetimeIncomeHub, "/portal/withdrawal-sequencing")} />
      <Route path="/portal/roth-conversion" component={gated(RothStrategyHub, "/portal/roth-conversion")} />
      <Route path="/portal/living-benefits" component={gated(LtcPlanningHub, "/portal/living-benefits")} />
      <Route path="/portal/policy-review-checklist" component={gated(PolicyReviewHub, "/portal/policy-review-checklist")} />
      <Route path="/portal/captive-iul" component={gated(CaptiveInsuranceHub, "/portal/captive-iul")} />
      <Route path="/portal/premium-financing" component={gated(PremiumFinancingHub, "/portal/premium-financing")} />
      <Route path="/portal/reverse-heloc" component={gated(MortgageRefiToolsHub, "/portal/reverse-heloc")} />
      <Route path="/portal/medicare-irmaa" component={gated(MedicareIrmaaHub, "/portal/medicare-irmaa")} />
      <Route path="/portal/tax-loss-harvesting" component={gated(TaxLossHarvestingHub, "/portal/tax-loss-harvesting")} />
      <Route path="/portal/ppli" component={gated(PpliPrivatePlacementHub, "/portal/ppli")} />
      <Route path="/portal/business-valuation" component={gated(BusinessValuationHub, "/portal/business-valuation")} />
      <Route path="/portal/buy-sell-funding" component={gated(BuySellFundingHub, "/portal/buy-sell-funding")} />
      <Route path="/portal/deferred-compensation" component={gated(DeferredCompHub, "/portal/deferred-compensation")} />
      <Route path="/portal/key-person-insurance" component={gated(KeyPersonInsuranceHub, "/portal/key-person-insurance")} />
      <Route path="/portal/overhead-expense" component={gated(DisabilityProtectionHub, "/portal/overhead-expense")} />
      <Route path="/portal/529-vs-iul" component={gated(H529EducationHub, "/portal/529-vs-iul")} />
      <Route path="/portal/mortgage-killer" component={gated(MortgageKillerHub, "/portal/mortgage-killer")} />
      <Route path="/portal/retirement-projection" component={gated(RetirementIncomeProjectorHub, "/portal/retirement-projection")} />
      <Route path="/portal/split-dollar" component={gated(SplitDollarHub, "/portal/split-dollar")} />
      <Route path="/portal/ss-bridge" component={gated(SocialSecurityOptimizerHub, "/portal/ss-bridge")} />
      <Route path="/portal/qbi-calculator" component={gated(Section199AQbiHub, "/portal/qbi-calculator")} />
      <Route path="/portal/ilit-calculator" component={gated(IlitPlannerHub, "/portal/ilit-calculator")} />
      <Route path="/portal/qprt-calculator" component={gated(QprtPlannerHub, "/portal/qprt-calculator")} />
      <Route path="/portal/idr-comparison" component={gated(StudentLoanHub, "/portal/idr-comparison")} />
      <Route path="/portal/pension-vs-lump-sum" component={gated(PensionMaximizationHub, "/portal/pension-vs-lump-sum")} />
      <Route path="/portal/tax-deferred-exchange" component={gated(H1031LikeKindExchangeHub, "/portal/tax-deferred-exchange")} />
      <Route path="/portal/clt-engine" component={gated(CharitableTrustCrtCltHub, "/portal/clt-engine")} />
      <Route path="/portal/grat-calculator" component={gated(GratPlannerHub, "/portal/grat-calculator")} />
      <Route path="/portal/idgt-advanced" component={gated(IdgtGrantorTrustHub, "/portal/idgt-advanced")} />
      <Route path="/portal/slat-deep-dive" component={gated(SlatSpousalTrustHub, "/portal/slat-deep-dive")} />
      <Route path="/portal/amt-calculator" component={gated(AmtHub, "/portal/amt-calculator")} />
      <Route path="/portal/opportunity-zone" component={gated(OpportunityZoneHub, "/portal/opportunity-zone")} />
      <Route path="/portal/cash-balance-plan" component={gated(DefinedBenefitCashBalanceHub, "/portal/cash-balance-plan")} />
      {/* Public routes — NO compliance gate */}
      <Route path="/" component={Landing} />
      <Route path="/pricing" component={Pricing} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/terms" component={Terms} />
      <Route path="/support" component={Support} />
      <Route path="/invite" component={AcceptInvite} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/forgot-password" component={ForgotPassword} />
      <Route path="/reset-password" component={ResetPassword} />
      <Route path="/trial" component={TrialLogin} />
      <Route path="/administrator" component={AdministratorPortal} />
      <Route path="/executive" component={ExecutiveEntrance} />

      {/* Onboarding — accessible without auth or compliance */}
      <Route path="/onboarding" component={Onboarding} />
      <Route path="/portal/onboarding" component={Onboarding} />
      <Route path="/portal/welcome" component={OnboardingWizard} />

      {/* Portal routes — ALL gated with compliance disclaimer */}
      <Route path="/portal" component={gated(Dashboard, "/portal")} />
      <Route path="/portal/tool-explorer" component={gated(ToolExplorer, "/portal/tool-explorer")} />
      <Route path="/portal/dashboard" component={gated(Dashboard, "/portal/dashboard")} />
      <Route path="/portal/advisory-summary" component={gated(AdvisorySummary, "/portal/advisory-summary")} />
      <Route path="/portal/advisor-directory" component={gated(AdvisorDirectory, "/portal/advisor-directory")} />
      <Route path="/portal/clients" component={gated(Clients, "/portal/clients")} />
      <Route path="/portal/clients/:id" component={gated(ClientDetail, "/portal/clients")} />
      <Route path="/portal/pipeline" component={gated(Pipeline, "/portal/pipeline")} />
      <Route path="/portal/strategy" component={gated(StrategyLab, "/portal/strategy")} />

      {/* AI Assist */}
      <Route path="/portal/ai" component={gated(AiAssist, "/portal/ai")} />
      <Route path="/portal/ai-assist" component={gated(AiAssist, "/portal/ai-assist")} />

      <Route path="/portal/team" component={gated(Team, "/portal/team")} />
      <Route path="/portal/billing" component={gated(Billing, "/portal/billing")} />
      <Route path="/portal/knowledge" component={gated(Knowledge, "/portal/knowledge")} />
      <Route path="/portal/leaderboard" component={gated(Leaderboard, "/portal/leaderboard")} />
      <Route path="/portal/scenarios" component={gated(ScenarioAdjustments, "/portal/scenarios")} />
      <Route path="/portal/advisor-chat" component={gated(AdvisorChat, "/portal/advisor-chat")} />
      <Route path="/portal/stale-digest" component={gated(StaleDigest, "/portal/stale-digest")} />
      <Route path="/portal/webhooks" component={gated(Webhooks, "/portal/webhooks")} />
      <Route path="/portal/slack" component={gated(SlackIntegration, "/portal/slack")} />
      <Route path="/portal/compliance" component={gated(ComplianceExport, "/portal/compliance")} />
      <Route path="/portal/legal-payment-folder" component={gated(LegalPaymentFolder, "/portal/legal-payment-folder")} />
      <Route path="/portal/rebalance" component={gated(RebalanceAlerts, "/portal/rebalance")} />
      <Route path="/portal/branding" component={gated(WorkspaceBranding, "/portal/branding")} />
      <Route path="/portal/meetings" component={gated(Meetings, "/portal/meetings")} />
      <Route path="/portal/compliance-alerts" component={gated(ComplianceAlerts, "/portal/compliance-alerts")} />
      <Route path="/portal/hubspot" component={gated(HubSpotSync, "/portal/hubspot")} />
      <Route path="/portal/integrations" component={gated(Integrations, "/portal/integrations")} />
      <Route path="/portal/roth-conversion" component={gated(RothConversionSTR, "/portal/roth-conversion")} />
      <Route path="/portal/strategy-compare" component={gated(StrategyCompareTool, "/portal/strategy-compare")} />
      <Route path="/portal/carrier-settings" component={gated(CarrierSettings, "/portal/carrier-settings")} />
      <Route path="/portal/bulk-generation" component={gated(BulkGeneration, "/portal/bulk-generation")} />
      <Route path="/portal/quotes" component={gated(CarrierQuotes, "/portal/quotes")} />
      <Route path="/portal/index-backtester" component={gated(IndexBacktester, "/portal/index-backtester")} />
      <Route path="/portal/ibbotson-charts" component={gated(IbbotsonCharts, "/portal/ibbotson-charts")} />
      <Route path="/portal/time-machine-ag49" component={gated(TimeMachineAG49, "/portal/time-machine-ag49")} />
      <Route path="/portal/time-machine-method" component={gated(TimeMachineMethod, "/portal/time-machine-method")} />
      <Route path="/portal/time-machine-calculator" component={gated(TimeMachineCalculator, "/portal/time-machine-calculator")} />
      <Route path="/portal/illustration-compare" component={gated(IllustrationCompare, "/portal/illustration-compare")} />
      <Route path="/portal/premium-financing" component={gated(PremiumFinancing, "/portal/premium-financing")} />
      <Route path="/portal/policy-loans" component={gated(PolicyLoans, "/portal/policy-loans")} />
      <Route path="/portal/carrier-ratings" component={gated(CarrierRatings, "/portal/carrier-ratings")} />
      <Route path="/portal/tax-waterfall" component={gated(TaxWaterfall, "/portal/tax-waterfall")} />
      <Route path="/portal/estate-tax" component={gated(EstateTax, "/portal/estate-tax")} />
      <Route path="/portal/income-timeline" component={gated(IncomeTimeline, "/portal/income-timeline")} />
      <Route path="/portal/iul-vs-roth" component={gated(IULvsRoth, "/portal/iul-vs-roth")} />
      <Route path="/portal/competitive" component={gated(CompetitiveAnalysis, "/portal/competitive")} />
      <Route path="/portal/quick-quote" component={gated(QuickQuote, "/portal/quick-quote")} />
      <Route path="/portal/batch-illustration" component={gated(BatchIllustration, "/portal/batch-illustration")} />
      <Route path="/portal/meeting-agenda" component={gated(MeetingAgenda, "/portal/meeting-agenda")} />
      <Route path="/portal/onboarding-v2" component={gated(OnboardingWizardV2, "/portal/onboarding-v2")} />
      <Route path="/portal/inflation" component={gated(InflationAnalysis, "/portal/inflation")} />
      <Route path="/portal/client-scorecard" component={gated(ClientScorecard, "/portal/client-scorecard")} />
      <Route path="/portal/document-vault" component={gated(DocumentVault, "/portal/document-vault")} />
      <Route path="/portal/audit-timeline" component={gated(AuditTimeline, "/portal/audit-timeline")} />
      <Route path="/portal/referral-tracker" component={gated(ReferralTracker, "/portal/referral-tracker")} />
      <Route path="/portal/policy-review" component={gated(PolicyReview, "/portal/policy-review")} />
      <Route path="/portal/advanced-reporting" component={gated(AdvancedReporting, "/portal/advanced-reporting")} />
      <Route path="/portal/mortgage-killer" component={gated(MortgageKiller, "/portal/mortgage-killer")} />
      <Route path="/portal/reverse-heloc" component={gated(ReverseHeloc, "/portal/reverse-heloc")} />
      <Route path="/portal/ecological-drivers" component={gated(EcologicalDrivers, "/portal/ecological-drivers")} />
      <Route path="/portal/client-comparison" component={gated(ClientComparison, "/portal/client-comparison")} />
      <Route path="/portal/website-usage" component={gated(WebsiteUsage, "/portal/website-usage")} />
      <Route path="/portal/household-wealth" component={gated(HouseholdWealth, "/portal/household-wealth")} />
      <Route path="/portal/carrier-rates" component={gated(CarrierRatings, "/portal/carrier-rates")} />
      <Route path="/portal/crypto-corner" component={gated(CryptoCurrencyCorner, "/portal/crypto-corner")} />
      <Route path="/portal/lifetime-income" component={gated(LifetimeGuaranteedIncome, "/portal/lifetime-income")} />
      <Route path="/portal/existing-annuities" component={gated(ExistingAnnuities, "/portal/existing-annuities")} />
      <Route path="/portal/growth-annuities" component={gated(GrowthAnnuities, "/portal/growth-annuities")} />
      <Route path="/portal/myga-fixed-rate" component={gated(MYGAFixedRate, "/portal/myga-fixed-rate")} />
      <Route path="/portal/axonic-sp500" component={gated(AxonicSP500, "/portal/axonic-sp500")} />
      <Route path="/portal/athene-pe-plus15" component={gated(AthenePEPlus15, "/portal/athene-pe-plus15")} />
      <Route path="/portal/athene-guaranteed-income" component={gated(AtheneGuaranteedIncome, "/portal/athene-guaranteed-income")} />
      <Route path="/portal/income-annuity-top10" component={gated(IncomeAnnuityTop10, "/portal/income-annuity-top10")} />
      <Route path="/portal/hot-income" component={gated(HotIncome, "/portal/hot-income")} />
      <Route path="/portal/recommendations" component={gated(Recommendations, "/portal/recommendations")} />
      <Route path="/portal/client-files" component={gated(ClientFiles, "/portal/client-files")} />
      <Route path="/portal/real-estate-mogul" component={gated(RealEstateMogul, "/portal/real-estate-mogul")} />
      <Route path="/portal/fia-top10" component={gated(FIATop10, "/portal/fia-top10")} />
      <Route path="/portal/tax-return-upload" component={gated(TaxReturnUpload, "/portal/tax-return-upload")} />
      <Route path="/portal/advisor-income-calculator" component={gated(AdvisorIncomeCalculator, "/portal/advisor-income-calculator")} />
      <Route path="/portal/social-security" component={gated(SocialSecurityOptimizer, "/portal/social-security")} />
      <Route path="/portal/client-onboarding" component={gated(ClientOnboardingWizard, "/portal/client-onboarding")} />
      <Route path="/portal/saved-scenarios" component={gated(SavedScenariosHub, "/portal/saved-scenarios")} />
      <Route path="/portal/ai-recommender" component={gated(AiStrategyRecommender, "/portal/ai-recommender")} />
      <Route path="/portal/email-campaigns" component={gated(EmailCampaignManager, "/portal/email-campaigns")} />
      <Route path="/portal/compliance-audit" component={gated(ComplianceAuditCenter, "/portal/compliance-audit")} />
      <Route path="/portal/education" component={gated(EducationHub, "/portal/education")} />
      <Route path="/portal/affiliate-links" component={gated(AffiliateLinkManager, "/portal/affiliate-links")} />
      <Route path="/portal/hidden-material" component={gated(HiddenMaterial, "/portal/hidden-material")} />
      <Route path="/portal/annuity-memory" component={gated(AnnuityMemory, "/portal/annuity-memory")} />
      <Route path="/portal/annuity-accumulation-db" component={gated(AnnuityAccumulationDB, "/portal/annuity-accumulation-db")} />
      <Route path="/portal/house-recycling" component={gated(HouseRecyclingStrategy, "/portal/house-recycling")} />

      {/* 20 Transformative Upgrades */}
      <Route path="/portal/sales-story" component={gated(SalesStoryBuilder, "/portal/sales-story")} />
      <Route path="/portal/estate-flow" component={gated(EstateFlowChart, "/portal/estate-flow")} />
      <Route path="/portal/goals-planning" component={gated(GoalsBasedPlanning, "/portal/goals-planning")} />
      <Route path="/portal/risk-tolerance" component={gated(RiskToleranceScoring, "/portal/risk-tolerance")} />
      <Route path="/portal/scenario-play" component={gated(MultiScenarioPlayZone, "/portal/scenario-play")} />
      <Route path="/portal/withdrawal-sequencing" component={gated(WithdrawalSequencing, "/portal/withdrawal-sequencing")} />
      <Route path="/portal/business-owner" component={gated(BusinessOwnerPlanning, "/portal/business-owner")} />
      <Route path="/portal/seminar-generator" component={gated(SeminarGenerator, "/portal/seminar-generator")} />
      <Route path="/portal/compliance-reports" component={gated(ComplianceReportGenerator, "/portal/compliance-reports")} />
      <Route path="/portal/advisor-training" component={gated(AdvisorTraining, "/portal/advisor-training")} />
      <Route path="/portal/agency-tutorial" component={gated(AgencyTutorial, "/portal/agency-tutorial")} />
      <Route path="/portal/agent-tutorial" component={gated(IndividualAgentTutorial, "/portal/agent-tutorial")} />
      <Route path="/portal/monitoring-agreement" component={gated(SupervisorMonitoringAgreement, "/portal/monitoring-agreement")} />
      <Route path="/portal/team-management" component={gated(TeamManagement, "/portal/team-management")} />
      <Route path="/portal/owner-oversight" component={gated(OwnerOversight, "/portal/owner-oversight")} />
      <Route path="/portal/predictive-analytics" component={gated(PredictiveAnalytics, "/portal/predictive-analytics")} />
      <Route path="/portal/collaborative-planning" component={gated(CollaborativePlanning, "/portal/collaborative-planning")} />
      <Route path="/portal/market-data" component={gated(MarketDataDashboard, "/portal/market-data")} />
      <Route path="/portal/ai-meeting-notes" component={gated(AIMeetingNotes, "/portal/ai-meeting-notes")} />
      <Route path="/portal/client-portal-config" component={gated(ClientPortal, "/portal/client-portal-config")} />
      <Route path="/portal/document-templates" component={gated(DocumentTemplates, "/portal/document-templates")} />
      <Route path="/portal/commission-calculator" component={gated(CommissionCalculator, "/portal/commission-calculator")} />
      <Route path="/portal/carrier-comparison" component={gated(CarrierComparison, "/portal/carrier-comparison")} />
      <Route path="/portal/referral-tracking" component={gated(ReferralTracking, "/portal/referral-tracking")} />
      <Route path="/portal/tax-brackets" component={gated(TaxBracketVisualizer, "/portal/tax-brackets")} />
      <Route path="/portal/policy-review-checklist" component={gated(PolicyReviewChecklist, "/portal/policy-review-checklist")} />
      <Route path="/portal/income-gap" component={gated(IncomeGapAnalyzer, "/portal/income-gap")} />
      <Route path="/portal/medicare-irmaa" component={gated(MedicareIRMAA, "/portal/medicare-irmaa")} />

      {/* NAIC Compliant Analysis Pages */}
      <Route path="/portal/iul-historical" component={gated(IULHistoricalPerformance, "/portal/iul-historical")} />
      <Route path="/portal/index-strategies" component={gated(IndexStrategyComparison, "/portal/index-strategies")} />
      <Route path="/portal/retirement-projection" component={gated(RetirementIncomeProjection, "/portal/retirement-projection")} />
      <Route path="/portal/tax-advantaged-growth" component={gated(TaxAdvantagedGrowth, "/portal/tax-advantaged-growth")} />

      {/* Client portal — gate removed */}
      <Route path="/client-portal/:token">{(params: any) => (
        <ClientPortalView {...params} />
      )}</Route>

      {/* Shared projection — public, no gate */}
      <Route path="/shared/:token" component={SharedProjection} />
      <Route path="/shared-slides/:token" component={SharedSlidesViewer} />

      {/* 15 AI Platform-Inspired Features */}
      <Route path="/portal/voice-plan" component={gated(VoicePlanBuilder, "/portal/voice-plan")} />
      <Route path="/portal/client-snapshot" component={gated(ClientSnapshotMap, "/portal/client-snapshot")} />
      <Route path="/portal/tax-opportunities" component={gated(TaxOpportunityDetector, "/portal/tax-opportunities")} />
      <Route path="/portal/workflow-automations" component={gated(WorkflowAutomations, "/portal/workflow-automations")} />
      <Route path="/portal/scenario-side-by-side" component={gated(ScenarioSideBySide, "/portal/scenario-side-by-side")} />
      <Route path="/portal/client-health" component={gated(ClientHealthDashboard, "/portal/client-health")} />
      <Route path="/portal/client-intake" component={gated(ClientIntakeInterview, "/portal/client-intake")} />
      <Route path="/portal/portfolio-drift" component={gated(PortfolioDriftMonitor, "/portal/portfolio-drift")} />
      <Route path="/portal/data-query" component={gated(NaturalLanguageQuery, "/portal/data-query")} />
      <Route path="/portal/engagement-score" component={gated(ClientEngagementScore, "/portal/engagement-score")} />
      <Route path="/portal/presentation-builder" component={gated(PresentationBuilder, "/portal/presentation-builder")} />
      <Route path="/portal/ai-slides" component={gated(AISlideGenerator, "/portal/ai-slides")} />
      <Route path="/portal/my-slides" component={gated(MySlides, "/portal/my-slides")} />
      <Route path="/portal/command-center" component={gated(OwnerWarRoom, "/portal/command-center")} />
      <Route path="/portal/batch-slides" component={gated(BatchSlides, "/portal/batch-slides")} />
      <Route path="/portal/compliance-audit-trail" component={gated(ComplianceAuditTrail, "/portal/compliance-audit-trail")} />
      <Route path="/portal/lead-generator" component={gated(LeadGenerator, "/portal/lead-generator")} />

      {/* 15 Second-Round Features */}
      <Route path="/portal/financial-vitals" component={gated(FinancialVitalsScorecard, "/portal/financial-vitals")} />
      <Route path="/portal/estate-document-gen" component={gated(EstateDocumentGenerator, "/portal/estate-document-gen")} />
      <Route path="/portal/retirement-guardrails" component={gated(RetirementGuardrails, "/portal/retirement-guardrails")} />
      <Route path="/portal/client-self-service" component={gated(ClientSelfServicePortal, "/portal/client-self-service")} />
      <Route path="/portal/tax-loss-harvesting" component={gated(TaxLossHarvestingScanner, "/portal/tax-loss-harvesting")} />
      <Route path="/portal/beneficiary-optimization" component={gated(BeneficiaryOptimization, "/portal/beneficiary-optimization")} />
      <Route path="/portal/fee-transparency" component={gated(FeeTransparencyDashboard, "/portal/fee-transparency")} />
      <Route path="/portal/succession-planning" component={gated(SuccessionPlanningWizard, "/portal/succession-planning")} />
      <Route path="/portal/ai-policy-review" component={gated(AIPolicyReviewGap, "/portal/ai-policy-review")} />
      <Route path="/portal/smart-rebalancing" component={gated(SmartRebalancingAlerts, "/portal/smart-rebalancing")} />
      <Route path="/portal/compliance-monitoring" component={gated(ComplianceMonitoringDashboard, "/portal/compliance-monitoring")} />
      <Route path="/portal/multi-gen-wealth" component={gated(MultiGenWealthTransfer, "/portal/multi-gen-wealth")} />
      <Route path="/portal/charitable-giving" component={gated(CharitableGivingOptimizer, "/portal/charitable-giving")} />
      <Route path="/portal/market-stress-test" component={gated(MarketScenarioStressTest, "/portal/market-stress-test")} />
      <Route path="/portal/client-onboarding-auto" component={gated(ClientOnboardingAutomation, "/portal/client-onboarding-auto")} />
      <Route path="/portal/commission-tracker" component={gated(CommissionTracker, "/portal/commission-tracker")} />

      {/* Enterprise Admin — gated */}
      <Route path="/portal/admin/health" component={gated(AdminHealthDashboard, "/portal/admin/health")} />
      <Route path="/portal/admin" component={gated(EnterpriseAdmin, "/portal/admin")} />
      <Route path="/portal/enterprise" component={gated(EnterpriseAdmin, "/portal/enterprise")} />

      {/* ── The Experience ──────────────────────────────────────── */}
      <Route path="/portal/nerve-center" component={gated(NerveCenter, "/portal/nerve-center")} />
      <Route path="/portal/my-world" component={gated(MyWorld, "/portal/my-world")} />
      <Route path="/portal/war-room" component={gated(WarRoom, "/portal/war-room")} />
      <Route path="/portal/will-writer" component={gated(WillWriter, "/portal/will-writer")} />
      <Route path="/portal/avatar-twins" component={gated(AvatarTwins, "/portal/avatar-twins")} />
      <Route path="/portal/couples" component={gated(CouplesMode, "/portal/couples")} />
      <Route path="/portal/russell-number" component={gated(RussellNumber, "/portal/russell-number")} />
      <Route path="/portal/daily-discovery" component={gated(DailyDiscovery, "/portal/daily-discovery")} />
      <Route path="/portal/wrapped" component={gated(RussellWrapped, "/portal/wrapped")} />
      <Route path="/portal/story-generator" component={gated(ClientStoryGenerator, "/portal/story-generator")} />
      <Route path="/portal/time-machine" component={gated(TimeMachine, "/portal/time-machine")} />
      <Route path="/portal/co-pilot" component={gated(LiveCoPilot, "/portal/co-pilot")} />
      <Route path="/portal/time-lapse" component={gated(TimeLapse, "/portal/time-lapse")} />
      <Route path="/portal/morning-ritual" component={gated(MorningRitual, "/portal/morning-ritual")} />
      <Route path="/portal/war-story-generator" component={gated(WarStoryGenerator, "/portal/war-story-generator")} />
      <Route path="/portal/revenue-guarantee" component={gated(RevenueGuarantee, "/portal/revenue-guarantee")} />
      <Route path="/portal/daily-briefing" component={gated(DailyBriefing, "/portal/daily-briefing")} />
      <Route path="/portal/comparison" component={gated(ComparisonDashboard, "/portal/comparison")} />
      <Route path="/portal/video-proposals" component={gated(VideoProposalGenerator, "/portal/video-proposals")} />
      <Route path="/video/:token" component={VideoViewer} />

      {/* ── Tax-Free Wealth Combos ──────────────────────────── */}
      <Route path="/portal/tax-combos" component={gated(TaxFreeWealthCombos, "/portal/tax-combos")} />
      <Route path="/portal/tax-combos/:id" component={gated(ComboDetail, "/portal/tax-combos")} />
      <Route path="/portal/secret-secrets" component={gated(SecretSecrets, "/portal/secret-secrets")} />
      <Route path="/portal/secret-secrets/:id" component={gated(SecretDetail, "/portal/secret-secrets")} />
      <Route path="/portal/combo-recommender" component={gated(ClientIntakeRecommender, "/portal/combo-recommender")} />
      <Route path="/portal/client-intake-recommender" component={gated(ClientIntakeRecommender, "/portal/client-intake-recommender")} />
      <Route path="/portal/divorce-calculator" component={gated(DivorceCalculator, "/portal/divorce-calculator")} />
      <Route path="/portal/trusts" component={gated(TrustsPage, "/portal/trusts")} />
      <Route path="/portal/mortgage-killer-v3" component={gated(MortgageKillerV3, "/portal/mortgage-killer-v3")} />
      <Route path="/portal/str-strategy" component={gated(STRStrategy, "/portal/str-strategy")} />
      <Route path="/portal/client-portfolio" component={gated(ClientPortfolioDashboard, "/portal/client-portfolio")} />
      <Route path="/portal/physicians-edge" component={gated(PhysiciansEdge, "/portal/physicians-edge")} />
      <Route path="/portal/video-library" component={gated(VideoLibrary, "/portal/video-library")} />
      <Route path="/portal/patent-showcase" component={gated(PatentShowcase, "/portal/patent-showcase")} />

      {/* ── Physician-Specific Calculators ── */}
      <Route path="/portal/pslf-calculator" component={gated(PSLFCalculator, "/portal/pslf-calculator")} />
      <Route path="/portal/idr-comparison" component={gated(IDRComparisonCalc, "/portal/idr-comparison")} />
      <Route path="/portal/own-occ-disability" component={gated(OwnOccDisabilityCalc, "/portal/own-occ-disability")} />
      <Route path="/portal/physician-contract" component={gated(PhysicianContractCalc, "/portal/physician-contract")} />
      <Route path="/portal/residency-to-attending" component={gated(ResidencyToAttendingCalc, "/portal/residency-to-attending")} />

      {/* ── Calculator Hub + 100 Financial Calculators + Retirement Advantage ── */}
      <Route path="/portal/calculator-hub" component={gated(CalculatorHub, "/portal/calculator-hub")} />
      <Route path="/portal/physician-vitals" component={gated(PhysicianVitalsDashboard, "/portal/physician-vitals")} />
      <Route path="/portal/physician-forum" component={gated(PhysicianForum, "/portal/physician-forum")} />
      <Route path="/portal/onboarding-quiz" component={gated(OnboardingQuiz, "/portal/onboarding-quiz")} />
      <Route path="/portal/peer-benchmarking" component={gated(PeerBenchmarking, "/portal/peer-benchmarking")} />
      <Route path="/portal/annual-financial-physical" component={gated(AnnualFinancialPhysical, "/portal/annual-financial-physical")} />
      <Route path="/portal/rmd-calculator" component={gated(RMDCalculator, "/portal/rmd-calculator")} />
      <Route path="/portal/marginal-tax-rate" component={gated(MarginalTaxRateCalc, "/portal/marginal-tax-rate")} />
      <Route path="/portal/capital-gains-tax" component={gated(CapitalGainsTaxCalc, "/portal/capital-gains-tax")} />
      <Route path="/portal/amt-calculator" component={gated(AMTCalculator, "/portal/amt-calculator")} />
      <Route path="/portal/self-employment-tax" component={gated(SelfEmploymentTaxCalc, "/portal/self-employment-tax")} />
      <Route path="/portal/tax-equivalent-yield" component={gated(TaxEquivalentYieldCalc, "/portal/tax-equivalent-yield")} />
      <Route path="/portal/w4-optimizer" component={gated(W4OptimizerCalc, "/portal/w4-optimizer")} />
      <Route path="/portal/crypto-tax" component={gated(CryptoTaxCalc, "/portal/crypto-tax")} />
      <Route path="/portal/rsu-tax" component={gated(RSUTaxCalc, "/portal/rsu-tax")} />
      <Route path="/portal/deduction-optimizer" component={gated(DeductionOptimizerCalc, "/portal/deduction-optimizer")} />
      <Route path="/portal/fire-calculator" component={gated(FIRECalculator, "/portal/fire-calculator")} />
      <Route path="/portal/safe-withdrawal-rate" component={gated(SafeWithdrawalCalc, "/portal/safe-withdrawal-rate")} />
      <Route path="/portal/pension-vs-lump-sum" component={gated(PensionVsLumpSumCalc, "/portal/pension-vs-lump-sum")} />
      <Route path="/portal/qlac-calculator" component={gated(QLACCalculator, "/portal/qlac-calculator")} />
      <Route path="/portal/retirement-healthcare" component={gated(RetirementHealthcareCalc, "/portal/retirement-healthcare")} />
      <Route path="/portal/medicare-irmaa-calc" component={gated(MedicareIRMAACalc, "/portal/medicare-irmaa-calc")} />
      <Route path="/portal/spousal-ss-coordination" component={gated(SpousalSSCalc, "/portal/spousal-ss-coordination")} />
      <Route path="/portal/dca-vs-lump-sum" component={gated(DCAvsLumpSumCalc, "/portal/dca-vs-lump-sum")} />
      <Route path="/portal/retirement-budget" component={gated(RetirementBudgetCalc, "/portal/retirement-budget")} />
      <Route path="/portal/inflation-adjusted-income" component={gated(InflationAdjustedCalc, "/portal/inflation-adjusted-income")} />
      <Route path="/portal/life-insurance-needs" component={gated(LifeInsuranceNeedsCalc, "/portal/life-insurance-needs")} />
      <Route path="/portal/disability-insurance-needs" component={gated(DisabilityInsuranceCalc, "/portal/disability-insurance-needs")} />
      <Route path="/portal/ltc-cost" component={gated(LTCCostCalc, "/portal/ltc-cost")} />
      <Route path="/portal/umbrella-insurance" component={gated(UmbrellaInsuranceCalc, "/portal/umbrella-insurance")} />
      <Route path="/portal/term-vs-whole-vs-iul" component={gated(TermVsWholeVsIULCalc, "/portal/term-vs-whole-vs-iul")} />
      <Route path="/portal/key-person-insurance" component={gated(KeyPersonInsuranceCalc, "/portal/key-person-insurance")} />
      <Route path="/portal/buy-sell-funding" component={gated(BuySellFundingCalc, "/portal/buy-sell-funding")} />
      <Route path="/portal/crt-calculator" component={gated(CRTCalculator, "/portal/crt-calculator")} />
      <Route path="/portal/grat-calculator" component={gated(GRATCalculator, "/portal/grat-calculator")} />
      <Route path="/portal/ilit-calculator" component={gated(ILITCalculator, "/portal/ilit-calculator")} />
      <Route path="/portal/qprt-calculator" component={gated(QPRTCalculator, "/portal/qprt-calculator")} />
      <Route path="/portal/gstt-calculator" component={gated(GSTTCalculator, "/portal/gstt-calculator")} />
      <Route path="/portal/daf-vs-direct-giving" component={gated(DAFvsDirectCalc, "/portal/daf-vs-direct-giving")} />
      <Route path="/portal/estate-liquidity" component={gated(EstateLiquidityCalc, "/portal/estate-liquidity")} />
      <Route path="/portal/net-worth-tracker" component={gated(NetWorthTrackerCalc, "/portal/net-worth-tracker")} />
      <Route path="/portal/compound-interest" component={gated(CompoundInterestCalc, "/portal/compound-interest")} />
      <Route path="/portal/millionaire-calculator" component={gated(MillionaireCalc, "/portal/millionaire-calculator")} />
      <Route path="/portal/emergency-fund-vs-iul" component={gated(EmergencyFundVsIULCalc, "/portal/emergency-fund-vs-iul")} />
      <Route path="/portal/529-vs-iul" component={gated(Education529VsIULCalc, "/portal/529-vs-iul")} />
      <Route path="/portal/debt-payoff-optimizer" component={gated(DebtPayoffOptimizerCalc, "/portal/debt-payoff-optimizer")} />
      <Route path="/portal/rental-property-roi" component={gated(RentalPropertyROICalc, "/portal/rental-property-roi")} />
      <Route path="/portal/1031-exchange" component={gated(Exchange1031Calc, "/portal/1031-exchange")} />
      <Route path="/portal/opportunity-zone" component={gated(OpportunityZoneCalc, "/portal/opportunity-zone")} />
      <Route path="/portal/home-affordability" component={gated(HomeAffordabilityCalc, "/portal/home-affordability")} />
      <Route path="/portal/refinance-break-even" component={gated(RefinanceBreakEvenCalc, "/portal/refinance-break-even")} />
      <Route path="/portal/cost-of-living" component={gated(CostOfLivingCalc, "/portal/cost-of-living")} />
      <Route path="/portal/reverse-mortgage" component={gated(ReverseMortgageCalc, "/portal/reverse-mortgage")} />
      <Route path="/portal/depreciation-tax-shield" component={gated(DepreciationTaxShieldCalc, "/portal/depreciation-tax-shield")} />
      <Route path="/portal/property-tax-appeal" component={gated(PropertyTaxAppealCalc, "/portal/property-tax-appeal")} />
      <Route path="/portal/vacation-rental" component={gated(VacationRentalCalc, "/portal/vacation-rental")} />
      <Route path="/portal/business-valuation" component={gated(BusinessValuationCalc, "/portal/business-valuation")} />
      <Route path="/portal/cash-balance-plan" component={gated(CashBalancePlanCalc, "/portal/cash-balance-plan")} />
      <Route path="/portal/entity-comparison" component={gated(EntityComparisonCalc, "/portal/entity-comparison")} />
      <Route path="/portal/qbi-calculator" component={gated(QBICalculator, "/portal/qbi-calculator")} />
      <Route path="/portal/deferred-compensation" component={gated(DeferredCompCalc, "/portal/deferred-compensation")} />
      <Route path="/portal/captive-insurance" component={gated(CaptiveInsuranceCalc, "/portal/captive-insurance")} />
      <Route path="/portal/succession-plan" component={gated(SuccessionPlanCalc, "/portal/succession-plan")} />
      <Route path="/portal/esop-calculator" component={gated(ESOPCalculator, "/portal/esop-calculator")} />
      <Route path="/portal/severance-calculator" component={gated(SeveranceCalc, "/portal/severance-calculator")} />
      <Route path="/portal/overhead-expense" component={gated(OverheadExpenseCalc, "/portal/overhead-expense")} />
      <Route path="/portal/asset-allocation" component={gated(AssetAllocationCalc, "/portal/asset-allocation")} />
      <Route path="/portal/pe-irr-calculator" component={gated(PrivateEquityIRRCalc, "/portal/pe-irr-calculator")} />
      <Route path="/portal/bond-ladder" component={gated(BondLadderCalc, "/portal/bond-ladder")} />
      <Route path="/portal/muni-bond-ladder" component={gated(MuniBondLadderCalc, "/portal/muni-bond-ladder")} />
      <Route path="/portal/drip-growth" component={gated(DRIPGrowthCalc, "/portal/drip-growth")} />
      <Route path="/portal/options-profit-loss" component={gated(OptionsProfitCalc, "/portal/options-profit-loss")} />
      <Route path="/portal/portfolio-risk-return" component={gated(PortfolioRiskCalc, "/portal/portfolio-risk-return")} />
      <Route path="/portal/sector-rotation" component={gated(SectorRotationCalc, "/portal/sector-rotation")} />
      <Route path="/portal/fee-impact" component={gated(FeeImpactCalc, "/portal/fee-impact")} />
      <Route path="/portal/tax-loss-harvest-calc" component={gated(TaxLossHarvestCalc, "/portal/tax-loss-harvest-calc")} />
      <Route path="/portal/budget-50-30-20" component={gated(Budget503020Calc, "/portal/budget-50-30-20")} />
      <Route path="/portal/zero-based-budget" component={gated(ZeroBasedBudgetCalc, "/portal/zero-based-budget")} />
      <Route path="/portal/spend-vs-invest" component={gated(SpendVsInvestCalc, "/portal/spend-vs-invest")} />
      <Route path="/portal/lease-vs-buy" component={gated(LeaseVsBuyCalc, "/portal/lease-vs-buy")} />
      <Route path="/portal/student-loan-vs-invest" component={gated(StudentLoanVsInvestCalc, "/portal/student-loan-vs-invest")} />
      <Route path="/portal/credit-card-payoff" component={gated(CreditCardPayoffCalc, "/portal/credit-card-payoff")} />
      <Route path="/portal/savings-rate-impact" component={gated(SavingsRateCalc, "/portal/savings-rate-impact")} />
      <Route path="/portal/cost-of-waiting" component={gated(CostOfWaitingCalc, "/portal/cost-of-waiting")} />
      <Route path="/portal/lifestyle-inflation" component={gated(LifestyleInflationCalc, "/portal/lifestyle-inflation")} />
      <Route path="/portal/financial-freedom-number" component={gated(FinancialFreedomCalc, "/portal/financial-freedom-number")} />
      <Route path="/portal/mega-backdoor-roth" component={gated(MegaBackdoorRothCalc, "/portal/mega-backdoor-roth")} />
      <Route path="/portal/backdoor-roth" component={gated(BackdoorRothCalc, "/portal/backdoor-roth")} />
      <Route path="/portal/roth-vs-traditional" component={gated(RothVsTraditionalCalc, "/portal/roth-vs-traditional")} />
      <Route path="/portal/nua-calculator" component={gated(NUACalculator, "/portal/nua-calculator")} />
      <Route path="/portal/charitable-stock-donation" component={gated(CharitableStockCalc, "/portal/charitable-stock-donation")} />
      <Route path="/portal/installment-sale" component={gated(InstallmentSaleCalc, "/portal/installment-sale")} />
      <Route path="/portal/like-kind-exchange" component={gated(LikeKindExchangeCalc, "/portal/like-kind-exchange")} />
      <Route path="/portal/gain-loss-harvesting" component={gated(TaxGainLossCalc, "/portal/gain-loss-harvesting")} />
      <Route path="/portal/state-tax-arbitrage" component={gated(StateTaxArbitrageCalc, "/portal/state-tax-arbitrage")} />
      <Route path="/portal/income-shifting" component={gated(IncomeShiftingCalc, "/portal/income-shifting")} />
      <Route path="/portal/special-needs-trust" component={gated(SpecialNeedsTrustCalc, "/portal/special-needs-trust")} />
      <Route path="/portal/divorce-settlement-enhanced" component={gated(DivorceSettlementCalc, "/portal/divorce-settlement-enhanced")} />
      <Route path="/portal/alimony-tax-impact" component={gated(AlimonyTaxCalc, "/portal/alimony-tax-impact")} />
      <Route path="/portal/windfall-management" component={gated(WindfallCalc, "/portal/windfall-management")} />
      <Route path="/portal/sabbatical-planner" component={gated(SabbaticalPlannerCalc, "/portal/sabbatical-planner")} />
      <Route path="/portal/aca-subsidy" component={gated(ACASubsidyCalc, "/portal/aca-subsidy")} />
      <Route path="/portal/hsa-triple-tax" component={gated(HSATripleTaxCalc, "/portal/hsa-triple-tax")} />
      <Route path="/portal/pension-max" component={gated(PensionMaxCalc, "/portal/pension-max")} />
      <Route path="/portal/annuity-comparison" component={gated(AnnuityComparisonCalc, "/portal/annuity-comparison")} />
      <Route path="/portal/financial-health-score" component={gated(FinancialHealthScoreCalc, "/portal/financial-health-score")} />
      <Route path="/portal/retirement-advantage" component={gated(RetirementAdvantage, "/portal/retirement-advantage")} />

      {/* ── Sister Invention Patent Features (SI-001 through SI-027) ── */}
      <Route path="/portal/iul-compliance-engine" component={gated(IULComplianceEngine, "/portal/iul-compliance-engine")} />
      <Route path="/portal/multi-carrier-iul" component={gated(MultiCarrierIULOptimizer, "/portal/multi-carrier-iul")} />
      <Route path="/portal/policy-replacement" component={gated(PolicyReplacementAnalyzer, "/portal/policy-replacement")} />
      <Route path="/portal/premium-financing-arbitrage" component={gated(PremiumFinancingArbitrage, "/portal/premium-financing-arbitrage")} />
      <Route path="/portal/living-benefits" component={gated(LivingBenefitsProbability, "/portal/living-benefits")} />
      <Route path="/portal/tax-code-simulator" component={gated(TaxCodeChangeSimulator, "/portal/tax-code-simulator")} />
      <Route path="/portal/behavioral-bias" component={gated(BehavioralBiasDetector, "/portal/behavioral-bias")} />
      <Route path="/portal/ss-bridge" component={gated(SocialSecurityBridge, "/portal/ss-bridge")} />
      <Route path="/portal/state-tax-migration" component={gated(StateTaxMigration, "/portal/state-tax-migration")} />
      <Route path="/portal/captive-iul" component={gated(CaptiveInsuranceIUL, "/portal/captive-iul")} />
      <Route path="/portal/divorce-impact" component={gated(DivorceFinancialImpact, "/portal/divorce-impact")} />
      <Route path="/portal/disability-gap" component={gated(DisabilityGapAnalysis, "/portal/disability-gap")} />
      <Route path="/portal/family-tree" component={gated(FamilyTreeFinancial, "/portal/family-tree")} />
      <Route path="/portal/generational-wealth" component={gated(GenerationalWealthSim, "/portal/generational-wealth")} />
      <Route path="/portal/carrier-strength" component={gated(CarrierStrengthMonitor, "/portal/carrier-strength")} />
      <Route path="/portal/succession-valuation" component={gated(SuccessionValuation, "/portal/succession-valuation")} />
      <Route path="/portal/commission-optimizer" component={gated(CommissionOptimizer, "/portal/commission-optimizer")} />
      <Route path="/portal/peer-intel" component={gated(PeerBenchmarkingIntel, "/portal/peer-intel")} />
      <Route path="/portal/ce-credits" component={gated(CECreditTracker, "/portal/ce-credits")} />
      <Route path="/portal/compliance-doc-gen" component={gated(ComplianceDocGenerator, "/portal/compliance-doc-gen")} />
      <Route path="/portal/client-retention" component={gated(ClientRetentionPredictor, "/portal/client-retention")} />
      <Route path="/portal/prospect-qualification" component={gated(ProspectQualification, "/portal/prospect-qualification")} />
      <Route path="/portal/multi-currency" component={gated(MultiCurrencyWealth, "/portal/multi-currency")} />
      <Route path="/portal/annuity-fee-detector" component={gated(AnnuityHiddenFee, "/portal/annuity-fee-detector")} />
      <Route path="/portal/onboarding-workflow" component={gated(ClientOnboardingWorkflow, "/portal/onboarding-workflow")} />
      <Route path="/portal/retirement-gap" component={gated(RetirementGapInflation, "/portal/retirement-gap")} />
      <Route path="/portal/crt-wealth-replacement" component={gated(CRTWealthReplacement, "/portal/crt-wealth-replacement")} />
      <Route path="/portal/innovation-dashboard" component={gated(InnovationDashboard, "/portal/innovation-dashboard")} />
      <Route path="/portal/usage-analytics" component={gated(UsageAnalyticsDashboard, "/portal/usage-analytics")} />
      <Route path="/portal/engine-chaining" component={gated(EngineChainingPipeline, "/portal/engine-chaining")} />
      <Route path="/portal/report-builder" component={gated(ClientReportBuilder, "/portal/report-builder")} />
      <Route path="/portal/risk-compliance" component={gated(RiskComplianceDashboard, "/portal/risk-compliance")} />
      <Route path="/portal/generational-wealth-sim" component={gated(GenerationalWealthSimulator, "/portal/generational-wealth-sim")} />
      <Route path="/portal/client-retention-ai" component={gated(ClientRetentionAssistant, "/portal/client-retention-ai")} />
      <Route path="/portal/ai-strategy-lab" component={gated(AIStrategyLabPro, "/portal/ai-strategy-lab")} />
      <Route path="/portal/projection-theater" component={gated(WealthProjectionTheater, "/portal/projection-theater")} />
      <Route path="/portal/engine-fusion" component={gated(EngineFusionLab, "/portal/engine-fusion")} />
      <Route path="/portal/deal-closer" component={gated(AIDealCloser, "/portal/deal-closer")} />
      <Route path="/portal/persona-hub" component={gated(PersonaHub, "/portal/persona-hub")} />
      <Route path="/portal/financial-dna" component={gated(FinancialDNA, "/portal/financial-dna")} />
      <Route path="/portal/wealth-rituals" component={gated(WealthRituals, "/portal/wealth-rituals")} />
      <Route path="/portal/mastery-nexus" component={gated(MasteryNexus, "/portal/mastery-nexus")} />
      <Route path="/portal/heartfire-legacy" component={gated(HeartfireLegacy, "/portal/heartfire-legacy")} />
      <Route path="/portal/strategy-synergy" component={gated(StrategySynergyHub, "/portal/strategy-synergy")} />
      <Route path="/portal/presentation-vault" component={gated(PresentationVault, "/portal/presentation-vault")} />
      <Route path="/portal/fluency-academy" component={gated(FinancialFluencyAcademy, "/portal/fluency-academy")} />
      <Route path="/portal/practice-sync" component={gated(PracticeWealthSync, "/portal/practice-sync")} />
      <Route path="/portal/compliance-center" component={gated(ComplianceCommandCenter, "/portal/compliance-center")} />
      <Route path="/portal/peer-network" component={gated(PeerTrustNetwork, "/portal/peer-network")} />
      <Route path="/portal/autopilot" component={gated(AutoPilotWorkflow, "/portal/autopilot")} />
      <Route path="/portal/wealth-canvas" component={gated(DimensionalWealthCanvas, "/portal/wealth-canvas")} />
      <Route path="/portal/journey-navigator" component={gated(ClientJourneyNavigator, "/portal/journey-navigator")} />
      <Route path="/portal/market-pulse" component={gated(MarketPulseSentinel, "/portal/market-pulse")} />
      <Route path="/portal/concierge" component={gated(AIWealthConcierge, "/portal/concierge")} />
      <Route path="/portal/impact-scorecard" component={gated(ImpactScorecard, "/portal/impact-scorecard")} />
      <Route path="/portal/legacy-vault" component={gated(LegacyVault, "/portal/legacy-vault")} />
      <Route path="/portal/ai-brain-hub" component={gated(AIBrainHubPage, "/portal/ai-brain-hub")} />

      {/* === COMBINATION SUPER-PATENTS === */}
      <Route path="/portal/behavioral-planning" component={gated(AIBehavioralFinancialPlanning, "/portal/behavioral-planning")} />
      <Route path="/portal/cross-feature-intelligence" component={gated(UnifiedCrossFeatureIntelligence, "/portal/cross-feature-intelligence")} />
      <Route path="/portal/cascading-optimizer" component={gated(CascadingMultiStrategyOptimizer, "/portal/cascading-optimizer")} />
      <Route path="/portal/longitudinal-risk" component={gated(LongitudinalRiskOptimizer, "/portal/longitudinal-risk")} />

      {/* === NEW PATENT FEATURES === */}
      <Route path="/portal/data-bus-dashboard" component={gated(UnifiedDataBusDashboard, "/portal/data-bus-dashboard")} />
      <Route path="/portal/living-risk-profile" component={gated(LivingRiskProfile, "/portal/living-risk-profile")} />
      <Route path="/portal/organism-dashboard" component={gated(OrganismDashboard, "/portal/organism-dashboard")} />
      <Route path="/portal/deep-organism" component={gated(DeepOrganismDashboard, "/portal/deep-organism")} />
      <Route path="/portal/calc-interop-matrix" component={gated(CalcInteropMatrix, "/portal/calc-interop-matrix")} />
      <Route path="/portal/alert-command-center" component={gated(AlertCommandCenter, "/portal/alert-command-center")} />
      <Route path="/portal/data-completeness" component={gated(DataCompletenessTracker, "/portal/data-completeness")} />
      <Route path="/portal/cross-calc-aggregation" component={gated(CrossCalcAggregationHub, "/portal/cross-calc-aggregation")} />
      <Route path="/portal/smart-routing" component={gated(SmartRoutingDashboard, "/portal/smart-routing")} />
      <Route path="/portal/mesh-health" component={gated(MeshHealthMonitor, "/portal/mesh-health")} />
      <Route path="/portal/tax-optimization-command" component={gated(TaxOptimizationCommand, "/portal/tax-optimization-command")} />
      <Route path="/portal/retirement-readiness" component={gated(RetirementReadinessCenter, "/portal/retirement-readiness")} />
      <Route path="/portal/insurance-coverage-command" component={gated(InsuranceCoverageCommand, "/portal/insurance-coverage-command")} />
      <Route path="/portal/estate-wealth-transfer" component={gated(EstateWealthTransfer, "/portal/estate-wealth-transfer")} />
      <Route path="/portal/data-flow-visualizer" component={gated(DataFlowVisualizer, "/portal/data-flow-visualizer")} />
      <Route path="/portal/wealth-timeline" component={gated(WealthAccumulationTimeline, "/portal/wealth-timeline")} />
      <Route path="/portal/organism-control" component={gated(OrganismControlCenter, "/portal/organism-control")} />
      <Route path="/portal/financial-nerve-center" component={gated(FinancialNerveCenter, "/portal/financial-nerve-center")} />
      <Route path="/portal/organism-health" component={gated(OrganismHealthReport, "/portal/organism-health")} />
      <Route path="/portal/meeting-prep" component={gated(AdvisorMeetingPrep, "/portal/meeting-prep")} />
      <Route path="/portal/stress-test" component={gated(PortfolioStressTest, "/portal/stress-test")} />
      <Route path="/portal/tax-optimizer" component={gated(TaxStrategyOptimizer, "/portal/tax-optimizer")} />
      <Route path="/portal/estate-planning-sim" component={gated(EstatePlanningSimulator, "/portal/estate-planning-sim")} />
      <Route path="/portal/insurance-gap" component={gated(InsuranceGapAnalyzer, "/portal/insurance-gap")} />
      <Route path="/portal/retirement-income-proj" component={gated(RetirementIncomeProjector, "/portal/retirement-income-proj")} />
      <Route path="/portal/roth-conversion-analyzer" component={gated(RothConversionAnalyzer, "/portal/roth-conversion-analyzer")} />
      <Route path="/portal/captive-insurance-modeler" component={gated(CaptiveInsuranceModeler, "/portal/captive-insurance-modeler")} />
      <Route path="/portal/premium-financing-calc" component={gated(PremiumFinancingCalculator, "/portal/premium-financing-calc")} />
      <Route path="/portal/1031-exchange-analyzer" component={gated(Exchange1031Analyzer, "/portal/1031-exchange-analyzer")} />
      <Route path="/portal/cost-segregation-engine" component={gated(CostSegregationEngine, "/portal/cost-segregation-engine")} />
      <Route path="/portal/dynasty-trust-planner" component={gated(DynastyTrustPlanner, "/portal/dynasty-trust-planner")} />
      <Route path="/portal/slat-planner" component={gated(SLATPlanner, "/portal/slat-planner")} />
      <Route path="/portal/idgt-modeler" component={gated(IDGTModeler, "/portal/idgt-modeler")} />
      <Route path="/portal/ilit-analyzer" component={gated(ILITAnalyzer, "/portal/ilit-analyzer")} />
      <Route path="/portal/annuity-waterfall" component={gated(AnnuityWaterfallEngine, "/portal/annuity-waterfall")} />
      <Route path="/portal/oil-gas-strategy" component={gated(OilGasTaxStrategy, "/portal/oil-gas-strategy")} />
      <Route path="/portal/qsbs-exclusion" component={gated(QSBSExclusionCalc, "/portal/qsbs-exclusion")} />
      <Route path="/portal/dst-analyzer" component={gated(DSTAnalyzer, "/portal/dst-analyzer")} />
      <Route path="/portal/nii-surtax" component={gated(NIISurtaxOptimizer, "/portal/nii-surtax")} />
      <Route path="/portal/ppli-modeler" component={gated(PPLIModeler, "/portal/ppli-modeler")} />
      <Route path="/portal/defined-benefit" component={gated(DefinedBenefitPlanner, "/portal/defined-benefit")} />
      <Route path="/portal/student-loan-optimizer" component={gated(StudentLoanOptimizer, "/portal/student-loan-optimizer")} />
      <Route path="/portal/physician-mortgage" component={gated(PhysicianMortgageAnalyzer, "/portal/physician-mortgage")} />
      <Route path="/portal/practice-valuation" component={gated(PracticeValuation, "/portal/practice-valuation")} />
      <Route path="/portal/income-protection" component={gated(IncomeProtectionPlanner, "/portal/income-protection")} />
      <Route path="/portal/hsa-maximizer" component={gated(HSAMaximizer, "/portal/hsa-maximizer")} />
      <Route path="/portal/nua-strategy" component={gated(NUAStrategy, "/portal/nua-strategy")} />
      <Route path="/portal/section-199a" component={gated(Section199AOptimizer, "/portal/section-199a")} />
      <Route path="/portal/charitable-lead-trust" component={gated(CharitableLeadTrust, "/portal/charitable-lead-trust")} />
      <Route path="/portal/family-limited-partnership" component={gated(FamilyLimitedPartnership, "/portal/family-limited-partnership")} />
      <Route path="/portal/mortgage-killer-v2" component={gated(MortgageKillerV2, "/portal/mortgage-killer-v2")} />
      <Route path="/portal/short-term-rental" component={gated(ShortTermRentalStrategy, "/portal/short-term-rental")} />
      <Route path="/portal/executive-bonus" component={gated(ExecutiveBonusPlan, "/portal/executive-bonus")} />
      <Route path="/portal/split-dollar-life" component={gated(SplitDollarLife, "/portal/split-dollar-life")} />
      <Route path="/portal/myga-waterfall" component={gated(MYGAWaterfallComparison, "/portal/myga-waterfall")} />
      <Route path="/portal/business-succession" component={gated(BusinessSuccession, "/portal/business-succession")} />
      <Route path="/portal/buy-sell-agreement" component={gated(BuySellAgreement, "/portal/buy-sell-agreement")} />
      <Route path="/portal/qualified-plan-maximizer" component={gated(QualifiedPlanMaximizer, "/portal/qualified-plan-maximizer")} />
      <Route path="/portal/cross-purchase" component={gated(CrossPurchaseAgreement, "/portal/cross-purchase")} />
      <Route path="/portal/crt-deep-dive" component={gated(CRTDeepDive, "/portal/crt-deep-dive")} />
      <Route path="/portal/asset-protection" component={gated(AssetProtection, "/portal/asset-protection")} />
      <Route path="/portal/wealth-transfer-scorecard" component={gated(WealthTransferScorecard, "/portal/wealth-transfer-scorecard")} />
      <Route path="/portal/alternative-investment" component={gated(AlternativeInvestment, "/portal/alternative-investment")} />
      <Route path="/portal/private-credit" component={gated(PrivateCredit, "/portal/private-credit")} />
      <Route path="/portal/concentrated-stock" component={gated(ConcentratedStock, "/portal/concentrated-stock")} />
      <Route path="/portal/employee-stock-options" component={gated(EmployeeStockOptions, "/portal/employee-stock-options")} />
      <Route path="/portal/rsu-tax-planning" component={gated(RSUTaxPlanning, "/portal/rsu-tax-planning")} />
      <Route path="/portal/education-529" component={gated(Education529Planner, "/portal/education-529")} />
      <Route path="/portal/international-tax" component={gated(InternationalTax, "/portal/international-tax")} />
      <Route path="/portal/installment-sale-strategy" component={gated(InstallmentSale, "/portal/installment-sale-strategy")} />
      <Route path="/portal/private-placement" component={gated(PrivatePlacement, "/portal/private-placement")} />
      <Route path="/portal/serp-analyzer" component={gated(SERPAnalyzer, "/portal/serp-analyzer")} />
      <Route path="/portal/grantor-trust" component={gated(GrantorTrustStrategy, "/portal/grantor-trust")} />
      <Route path="/portal/qualified-opportunity-fund" component={gated(QualifiedOpportunityFund, "/portal/qualified-opportunity-fund")} />
      <Route path="/portal/section-1202" component={gated(Section1202Planner, "/portal/section-1202")} />
      <Route path="/portal/crut-deep-dive" component={gated(CRUTDeepDive, "/portal/crut-deep-dive")} />
      <Route path="/portal/slat-deep-dive" component={gated(SLATDeepDive, "/portal/slat-deep-dive")} />
      <Route path="/portal/gst-trust" component={gated(GSTTrustPlanner, "/portal/gst-trust")} />
      <Route path="/portal/ilit-deep-dive" component={gated(ILITDeepDive, "/portal/ilit-deep-dive")} />
      <Route path="/portal/qprt" component={gated(QPRTPlanner, "/portal/qprt")} />
      <Route path="/portal/grat" component={gated(GRATPlanner, "/portal/grat")} />
      <Route path="/portal/beneficiary-ira" component={gated(BeneficiaryIRAPlanner, "/portal/beneficiary-ira")} />
      <Route path="/portal/stretch-ira" component={gated(StretchIRAStrategy, "/portal/stretch-ira")} />
      <Route path="/portal/inherited-roth" component={gated(InheritedRothPlanner, "/portal/inherited-roth")} />
      <Route path="/portal/long-term-care" component={gated(LongTermCarePlanner, "/portal/long-term-care")} />
      <Route path="/portal/medicaid-planning" component={gated(MedicaidPlanning, "/portal/medicaid-planning")} />
      <Route path="/portal/divorce-financial" component={gated(DivorceFinancialPlanner, "/portal/divorce-financial")} />
      <Route path="/portal/business-entity" component={gated(BusinessEntitySelector, "/portal/business-entity")} />
      <Route path="/portal/phantom-stock" component={gated(PhantomStockPlanner, "/portal/phantom-stock")} />
      <Route path="/portal/employee-retention" component={gated(EmployeeRetentionStrategy, "/portal/employee-retention")} />
      <Route path="/portal/equity-compensation" component={gated(EquityCompensationHub, "/portal/equity-compensation")} />
      <Route path="/portal/charitable-giving-dashboard" component={gated(CharitableGivingDashboard, "/portal/charitable-giving-dashboard")} />
      <Route path="/portal/real-estate-portfolio" component={gated(RealEstatePortfolioManager, "/portal/real-estate-portfolio")} />
      <Route path="/portal/pension-maximization" component={gated(PensionMaximization, "/portal/pension-maximization")} />
      <Route path="/portal/spousal-lifetime-access" component={gated(SpousalLifetimeAccess, "/portal/spousal-lifetime-access")} />
      <Route path="/portal/wealth-transfer-timeline" component={gated(WealthTransferTimeline, "/portal/wealth-transfer-timeline")} />
      <Route path="/portal/financial-independence" component={gated(FinancialIndependenceCalc, "/portal/financial-independence")} />
      <Route path="/portal/private-foundation" component={gated(PrivateFoundationPlanner, "/portal/private-foundation")} />
      <Route path="/portal/daf-strategic" component={gated(DAFStrategicPlanner, "/portal/daf-strategic")} />
      <Route path="/portal/qprt-advanced" component={gated(QPRTAdvancedPlanner, "/portal/qprt-advanced")} />
      <Route path="/portal/idgt-advanced" component={gated(IDGTAdvancedModeler, "/portal/idgt-advanced")} />
      <Route path="/portal/estate-freeze-comparison" component={gated(EstateFreezeComparison, "/portal/estate-freeze-comparison")} />
      <Route path="/portal/trust-comparison-matrix" component={gated(TrustComparisonMatrix, "/portal/trust-comparison-matrix")} />
      <Route path="/portal/wealth-accumulation" component={gated(WealthAccumulationSimulator, "/portal/wealth-accumulation")} />
      <Route path="/portal/cash-flow-optimizer" component={gated(CashFlowOptimizer, "/portal/cash-flow-optimizer")} />
      <Route path="/portal/debt-payoff" component={gated(DebtPayoffStrategy, "/portal/debt-payoff")} />
      <Route path="/portal/emergency-fund" component={gated(EmergencyFundPlanner, "/portal/emergency-fund")} />
      <Route path="/portal/college-aid" component={gated(CollegeAidOptimizer, "/portal/college-aid")} />
      <Route path="/portal/social-security-maximizer" component={gated(SocialSecurityMaximizer, "/portal/social-security-maximizer")} />
      <Route path="/portal/medicare-part-d" component={gated(MedicarePartDPlanner, "/portal/medicare-part-d")} />
      <Route path="/portal/long-term-care-hybrid" component={gated(LongTermCareHybrid, "/portal/long-term-care-hybrid")} />
      <Route path="/portal/annuity-income-bridge" component={gated(AnnuityIncomeBridge, "/portal/annuity-income-bridge")} />
      <Route path="/portal/sequence-of-returns" component={gated(SequenceOfReturnsRisk, "/portal/sequence-of-returns")} />
      <Route path="/portal/withdrawal-rate" component={gated(WithdrawalRateOptimizer, "/portal/withdrawal-rate")} />
      <Route path="/portal/tax-bracket-navigator" component={gated(TaxBracketNavigator, "/portal/tax-bracket-navigator")} />
      <Route path="/portal/amt-analyzer" component={gated(AMTAnalyzer, "/portal/amt-analyzer")} />
      <Route path="/portal/business-exit" component={gated(BusinessExitPlanner, "/portal/business-exit")} />
      <Route path="/portal/esop-analyzer" component={gated(ESOPAnalyzer, "/portal/esop-analyzer")} />
      <Route path="/portal/charitable-remainder-unitrust" component={gated(CharitableRemainderUniTrust, "/portal/charitable-remainder-unitrust")} />
      <Route path="/portal/family-office" component={gated(FamilyOfficeSimulator, "/portal/family-office")} />
      <Route path="/portal/iul-max-funded" component={gated(IULMaxFundedEngine, "/portal/iul-max-funded")} />
      <Route path="/portal/whole-life-dividend" component={gated(WholeLifeDividendEngine, "/portal/whole-life-dividend")} />
      <Route path="/portal/real-estate-syndication" component={gated(RealEstateSyndicationAnalyzer, "/portal/real-estate-syndication")} />
      <Route path="/portal/tenant-in-common" component={gated(TenantInCommonAnalyzer, "/portal/tenant-in-common")} />
      <Route path="/portal/inflation-protection" component={gated(InflationProtectionSuite, "/portal/inflation-protection")} />
      <Route path="/portal/physician-retirement" component={gated(PhysicianRetirementBlueprint, "/portal/physician-retirement")} />
      <Route path="/portal/tax-alpha-scorecard" component={gated(TaxAlphaScorecard, "/portal/tax-alpha-scorecard")} />
      <Route path="/portal/multi-generational-wealth" component={gated(MultiGenerationalWealthEngine, "/portal/multi-generational-wealth")} />
      <Route path="/portal/financial-plan-checklist" component={gated(FinancialPlanChecklist, "/portal/financial-plan-checklist")} />
      <Route path="/portal/client-presentation" component={gated(ClientPresentationBuilder, "/portal/client-presentation")} />
      <Route path="/portal/fiduciary-compliance" component={gated(FIDOComplianceTracker, "/portal/fiduciary-compliance")} />
      <Route path="/portal/audit-defense" component={gated(AuditDefensePrep, "/portal/audit-defense")} />
      <Route path="/portal/fbar-fatca" component={gated(FBARFATCACompliance, "/portal/fbar-fatca")} />
      <Route path="/portal/alternative-investments" component={gated(AlternativeInvestmentDueDiligence, "/portal/alternative-investments")} />
      <Route path="/portal/special-needs" component={gated(SpecialNeedsPlanner, "/portal/special-needs")} />
      <Route path="/portal/expat-tax" component={gated(ExpatTaxPlanner, "/portal/expat-tax")} />
      <Route path="/portal/executive-comp" component={gated(ExecutiveCompOptimizer, "/portal/executive-comp")} />
      <Route path="/portal/healthcare-cost" component={gated(HealthcareCostProjector, "/portal/healthcare-cost")} />
      <Route path="/portal/succession-engine" component={gated(SuccessionPlanningEngine, "/portal/succession-engine")} />
      <Route path="/portal/ppli" component={gated(PrivatePlacementLifeInsurance, "/portal/ppli")} />
      <Route path="/portal/international-trust" component={gated(InternationalTrustPlanner, "/portal/international-trust")} />
      <Route path="/portal/taxable-estate" component={gated(TaxableEstateCalculator, "/portal/taxable-estate")} />
      <Route path="/portal/wealth-transfer-scoreboard" component={gated(WealthTransferScoreboard, "/portal/wealth-transfer-scoreboard")} />
      <Route path="/portal/flp-planner" component={gated(FamilyLimitedPartnershipPlanner, "/portal/flp-planner")} />
      <Route path="/portal/nua-planner" component={gated(NetUnrealizedAppreciationPlanner, "/portal/nua-planner")} />
      <Route path="/portal/qsbs" component={gated(QualifiedSmallBusinessStock, "/portal/qsbs")} />
      <Route path="/portal/split-dollar" component={gated(SplitDollarLifeInsurance, "/portal/split-dollar")} />
      <Route path="/portal/structured-notes" component={gated(StructuredNoteAnalyzer, "/portal/structured-notes")} />
      <Route path="/portal/1031-advanced" component={gated(Section1031AdvancedExchange, "/portal/1031-advanced")} />
      <Route path="/portal/199a-optimizer" component={gated(Section199ADeductionOptimizer, "/portal/199a-optimizer")} />
      <Route path="/portal/crt-engine" component={gated(CharitableRemainderTrustEngine, "/portal/crt-engine")} />
      <Route path="/portal/pe-tax" component={gated(PrivateEquityTaxPlanner, "/portal/pe-tax")} />
      <Route path="/portal/estate-timeline" component={gated(EstatePlanningTimeline, "/portal/estate-timeline")} />
      <Route path="/portal/withdrawal-sequencer" component={gated(TaxEfficientWithdrawalSequencer, "/portal/withdrawal-sequencer")} />
      <Route path="/portal/inflation-returns" component={gated(InflationAdjustedReturnCalculator, "/portal/inflation-returns")} />
      <Route path="/portal/family-governance" component={gated(FamilyGovernanceFramework, "/portal/family-governance")} />
      <Route path="/portal/digital-estate" component={gated(DigitalAssetEstatePlanner, "/portal/digital-estate")} />
      <Route path="/portal/survivor-benefits" component={gated(SurvivorBenefitPlanner, "/portal/survivor-benefits")} />
      <Route path="/portal/wealth-dashboard" component={gated(WealthDashboardSummary, "/portal/wealth-dashboard")} />
      <Route path="/portal/trust-decanting" component={gated(TrustDecantingPlanner, "/portal/trust-decanting")} />
      <Route path="/portal/direct-indexing" component={gated(DirectIndexingOptimizer, "/portal/direct-indexing")} />
      <Route path="/portal/esop-buyout" component={gated(ESOPLeveragedBuyoutPlanner, "/portal/esop-buyout")} />
      <Route path="/portal/post-mortem-tax" component={gated(PostMortemTaxPlanner, "/portal/post-mortem-tax")} />
      <Route path="/portal/incentive-trust" component={gated(IncentiveTrustDesigner, "/portal/incentive-trust")} />
      <Route path="/portal/irc-reference" component={gated(ComprehensiveIRCReferenceIndex, "/portal/irc-reference")} />
      <Route path="/portal/amt-planner" component={gated(AlternativeMinimumTaxPlanner, "/portal/amt-planner")} />
      <Route path="/portal/state-trust-planning" component={gated(GraniteStateTrustPlanner, "/portal/state-trust-planning")} />
      <Route path="/portal/ppva" component={gated(PrivatePlacementAnnuity, "/portal/ppva")} />
      <Route path="/portal/multi-gen-roth" component={gated(MultiGenerationalRothStrategy, "/portal/multi-gen-roth")} />
      <Route path="/portal/deferred-comp" component={gated(DeferredCompensationAnalyzer, "/portal/deferred-comp")} />
      <Route path="/portal/clt-engine" component={gated(CharitableLeadTrustEngine, "/portal/clt-engine")} />
      <Route path="/portal/section-2701" component={gated(Section2701ValuationPlanner, "/portal/section-2701")} />
      <Route path="/portal/529-advanced" component={gated(Section529AdvancedPlanner, "/portal/529-advanced")} />
      <Route path="/portal/income-floor" component={gated(RetirementIncomeFloorPlanner, "/portal/income-floor")} />
      <Route path="/portal/philanthropy" component={gated(PhilanthropyImpactDashboard, "/portal/philanthropy")} />
      <Route path="/portal/tax-projection" component={gated(TaxProjectionEngine, "/portal/tax-projection")} />
      <Route path="/portal/variable-annuity" component={gated(VariableAnnuityAnalyzer, "/portal/variable-annuity")} />
      <Route path="/portal/fiduciary-tracker" component={gated(FiduciaryDutyTracker, "/portal/fiduciary-tracker")} />
      <Route path="/portal/life-settlement" component={gated(LifeSettlementAnalyzer, "/portal/life-settlement")} />
      <Route path="/portal/retirement-distributions" component={gated(RetirementPlanDistributionPlanner, "/portal/retirement-distributions")} />
      <Route path="/portal/family-bank" component={gated(FamilyBankStrategy, "/portal/family-bank")} />
      <Route path="/portal/alt-investment-dd" component={gated(AlternativeInvestmentDueDiligence2, "/portal/alt-investment-dd")} />
      <Route path="/portal/tax-credits" component={gated(TaxCreditOptimizer, "/portal/tax-credits")} />
      <Route path="/portal/cross-border-wealth" component={gated(CrossBorderWealthPlanner, "/portal/cross-border-wealth")} />
      <Route path="/portal/debt-recycling" component={gated(DebtRecyclingStrategy, "/portal/debt-recycling")} />
      <Route path="/portal/private-reit" component={gated(PrivateREITAnalyzer, "/portal/private-reit")} />
      <Route path="/portal/tax-deferred-exchange" component={gated(TaxDeferredExchangeTimeline, "/portal/tax-deferred-exchange")} />
      <Route path="/portal/ss-bridge-strategy" component={gated(SocialSecurityBridgeStrategy, "/portal/ss-bridge-strategy")} />
      <Route path="/portal/wealth-transfer-comparison" component={gated(WealthTransferVehicleComparison, "/portal/wealth-transfer-comparison")} />
      <Route path="/portal/str-tax-strategy" component={gated(ShortTermRentalTaxStrategy, "/portal/str-tax-strategy")} />
      <Route path="/portal/infinity-banking" component={gated(InfinityBankingConcept, "/portal/infinity-banking")} />
      <Route path="/portal/dynasty-trust" component={gated(DynastyTrustArchitect, "/portal/dynasty-trust")} />
      <Route path="/portal/spending-guardrails" component={gated(RetirementSpendingGuardrails, "/portal/spending-guardrails")} />
      <Route path="/portal/cost-segregation" component={gated(CostSegregationAccelerator, "/portal/cost-segregation")} />
      <Route path="/portal/nav-placeholder" component={gated(NavPlaceholder, "/portal/nav-placeholder")} />
      <Route path="/portal/physician-blueprint" component={gated(PhysicianFinancialBlueprint, "/portal/physician-blueprint")} />
      <Route path="/portal/re-stacking" component={gated(RealEstateStackingStrategy, "/portal/re-stacking")} />
      <Route path="/portal/executive-bridge" component={gated(ExecutiveRetirementBridge, "/portal/executive-bridge")} />
      <Route path="/portal/trust-funding" component={gated(TrustFundingChecklist, "/portal/trust-funding")} />
      <Route path="/portal/volatility-harvesting" component={gated(VolatilityHarvestingEngine, "/portal/volatility-harvesting")} />
      <Route path="/portal/syndication-deal" component={gated(SyndicationDealAnalyzer, "/portal/syndication-deal")} />
      <Route path="/portal/family-constitution" component={gated(FamilyWealthConstitution, "/portal/family-constitution")} />
      <Route path="/portal/taxable-account" component={gated(TaxableAccountOptimizer, "/portal/taxable-account")} />
      <Route path="/portal/digital-estate-planner" component={gated(DigitalEstatePlanner, "/portal/digital-estate-planner")} />
      <Route path="/portal/pension-max-engine" component={gated(PensionMaximizationEngine, "/portal/pension-max-engine")} />
      <Route path="/portal/alt-allocator" component={gated(AlternativeInvestmentAllocator, "/portal/alt-allocator")} />
      <Route path="/portal/client-report-gen" component={gated(ClientReportGenerator, "/portal/client-report-gen")} />
      <Route path="/portal/combo-recommender-v2" component={gated(ComboRecommender, "/portal/combo-recommender-v2")} />
      <Route path="/portal/fia-collateral" component={gated(FIACollateralStrategy, "/portal/fia-collateral")} />
      <Route path="/portal/organism-deep-provider" component={gated(OrganismDeepProvider, "/portal/organism-deep-provider")} />
      <Route path="/portal/pe-secondary-market" component={gated(PrivateEquitySecondaryMarket, "/portal/pe-secondary-market")} />
      <Route path="/portal/depreciation-recapture" component={gated(RealEstateDepreciationRecapture, "/portal/depreciation-recapture")} />
      <Route path="/portal/income-floor-strategy" component={gated(RetirementIncomeFloorStrategy, "/portal/income-floor-strategy")} />
      <Route path="/portal/structured-settlement" component={gated(StructuredSettlementPlanner, "/portal/structured-settlement")} />
      <Route path="/portal/wealth-erosion" component={gated(WealthErosionTracker, "/portal/wealth-erosion")} />

      {/* Fallback */}
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
    </Suspense>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <FinancialDataProvider>
      <ThemeProvider defaultTheme="dark" switchable>
        <EntrainmentProvider>
          {/* ═══ Universal Coherent Breathing Layer ═══
              Subliminal ambient animation at 6.0 breaths/min (10s cycle).
              Baroreflex resonance entrainment at exact 0.1 Hz for parasympathetic flow state.
              Body-level brightness + viewport scale cover every page — imperceptible to conscious awareness. */}
          <div className="rc-breathe-layer" aria-hidden="true" />
          <div className="rc-breathe-layer-extra" aria-hidden="true" />
          <GlobalHooks />
          <OnboardingTour />
          <AchievementUnlockOverlay />
          <PetEvolutionOverlay />
          <SkipToContent />
          <FocusRingStyles />
          <TooltipProvider>
            <Toaster richColors position="top-right" />
            <Router />
            <TrialTimer />
          </TooltipProvider>
        </EntrainmentProvider>
      </ThemeProvider>
      </FinancialDataProvider>
    </ErrorBoundary>
  );
}

export default App;
