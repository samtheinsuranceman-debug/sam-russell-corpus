// @ts-nocheck

import { useState, useMemo } from "react";
import { ResultReveal } from "@/components/ResultReveal";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Circle, TrendingUp, Shield, CalculatorIcon} from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function BackdoorRothCalc() {
  const autoFill = useCalculatorAutoFill("backdoor-roth");
  const { reportResult } = useCalcResults();
  const [income, setIncome] = useSharedField("annualIncome", 100000);
  const [age, setAge] = useSharedField("currentAge", 40);
  const [iraBalance, setIraBalance] = useSharedField("traditionalIRABalance", 50000);
  const [taxRate, setTaxRate] = useSharedField("currentTaxBracket", 22); // in percentage
  const [growthRate, setGrowthRate] = useSharedField("growthRate", 7); // in percentage
  const [years, setYears] = useSharedField("projectionYears", 20);

  const calculations = useMemo(() => {
    const taxOnConversion = (iraBalance * (taxRate / 100));
    const futureRothValue = iraBalance * Math.pow(1 + (growthRate / 100), years);
    const futureRothAfterTax = futureRothValue * (1 - (taxRate / 100)); // Assuming taxes on withdrawal
    const traditionalFutureValue = iraBalance * Math.pow(1 + (growthRate / 100), years);
    const iulAdvantage = traditionalFutureValue * 0.15; // Simplified: 15% extra growth advantage for IUL
    return {
      taxOnConversion,
      futureRothValue,
      futureRothAfterTax,
      savingsVsTraditional: futureRothValue - futureRothAfterTax,
      iulAdvantage,
    };
  }, [income, age, iraBalance, taxRate, growthRate, years]);
  const projectionData = useMemo(() => {
    const d = [];
    const startVal = typeof portfolioValue !== 'undefined' ? portfolioValue : 1000000;
    let taxAlpha = 0, deferred = startVal, roth = 0, trad = startVal;
    for (let yr = 0; yr <= 50; yr++) {
      const conversionAmt = yr < 20 ? startVal * 0.05 : 0;
      roth = roth * 1.08 + conversionAmt;
      deferred = deferred * 1.07;
      trad = trad * 1.065;
      taxAlpha += (deferred * 0.075 - trad * 0.065) * 0.3;
      d.push({ year: yr, taxAlpha: Math.round(taxAlpha), deferredGrowth: Math.round(deferred), rothConversion: Math.round(roth), traditionalPath: Math.round(trad) });
    }
    return d;
  }, []);


  return (
    <AppShell
      headerTitle="Backdoor Roth IRA Conversion Calculator"
      headerSubtitle="Advanced Tax Strategies"
    >
      <div className="p-6 bg-[#0a0f1a] min-h-screen text-white">
        <AutoFillBanner calcRoute="backdoor-roth" />
        <div className="max-w-4xl mx-auto">
          <Card className="bg-[#0d1526] mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalculatorIcon className="h-6 w-6 text-emerald-400" />
                Input Parameters
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label>Annual Income ($)</Label>
                <div className="flex items-center gap-4">
                  <Input
                    type="number"
                    value={income}
                    onChange={(e) => setIncome(Number(e.target.value))}
                    className="bg-slate-700"
                  />
                  <Slider
                    min={50000}
                    max={500000}
                    step={10000}
                    value={[income]}
                    onValueChange={(value) => setIncome(value[0])}
                  />
                </div>
              </div>
              <div>
                <Label>Age</Label>
                <div className="flex items-center gap-4">
                  <Input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(Number(e.target.value))}
                    className="bg-slate-700"
                  />
                  <Slider
                    min={18}
                    max={65}
                    step={1}
                    value={[age]}
                    onValueChange={(value) => setAge(value[0])}
                  />
                </div>
              </div>
              <div>
                <Label>Traditional IRA Balance ($)</Label>
                <div className="flex items-center gap-4">
                  <Input
                    type="number"
                    value={iraBalance}
                    onChange={(e) => setIraBalance(Number(e.target.value))}
                    className="bg-slate-700"
                  />
                  <Slider
                    min={0}
                    max={200000}
                    step={1000}
                    value={[iraBalance]}
                    onValueChange={(value) => setIraBalance(value[0])}
                  />
                </div>
              </div>
              <div>
                <Label>Marginal Tax Rate (%)</Label>
                <Select onValueChange={(value) => setTaxRate(Number(value))} defaultValue={taxRate.toString()}>
                  <SelectTrigger className="bg-slate-700">
                    <SelectValue placeholder="Select tax rate" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#0d1526]">
                    <SelectItem value="22">22%</SelectItem>
                    <SelectItem value="24">24%</SelectItem>
                    <SelectItem value="32">32%</SelectItem>
                    <SelectItem value="35">35%</SelectItem>
                    <SelectItem value="37">37%</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Growth Rate (%)</Label>
                <div className="flex items-center gap-4">
                  <Input
                    type="number"
                    value={growthRate}
                    onChange={(e) => setGrowthRate(Number(e.target.value))}
                    className="bg-slate-700"
                  />
                  <Slider
                    min={0}
                    max={15}
                    step={0.5}
                    value={[growthRate]}
                    onValueChange={(value) => setGrowthRate(value[0])}
                  />
                </div>
              </div>
              <div>
                <Label>Years Until Retirement</Label>
                <div className="flex items-center gap-4">
                  <Input
                    type="number"
                    value={years}
                    onChange={(e) => setYears(Number(e.target.value))}
                    className="bg-slate-700"
                  />
                  <Slider
                    min={1}
                    max={40}
                    step={1}
                    value={[years]}
                    onValueChange={(value) => setYears(value[0])}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        {/* State Tax Impact */}
        <StateTaxSelector income={income} filingStatus={'single'} className="mb-6" />

          
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "taxAlpha", label: "Tax Alpha Generated", color: "#10b981" }, { key: "deferredGrowth", label: "Tax-Deferred Growth", color: "#06b6d4" }, { key: "rothConversion", label: "Roth Conversion Value", color: "#a855f7" }, { key: "traditionalPath", label: "Traditional Path", color: "#ef4444" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-6 w-6 text-emerald-400" />
                  Tax on Conversion
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">{formatDollars(calculations.taxOnConversion)}</p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-6 w-6 text-emerald-400" />
                  Projected Roth IRA Value
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">{formatDollars(calculations.futureRothValue)}</p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CalculatorIcon className="h-6 w-6 text-emerald-400" />
                  Savings vs Traditional
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResultReveal value={calculations.savingsVsTraditional} prefix="$" label="Savings vs Traditional" />
              </CardContent>
            </Card>
          </div>

          <Card className="bg-[#0d1526] mb-6">
            <CardHeader>
              <CardTitle>IUL Advantage</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Indexed Universal Life (IUL) insurance offers tax-free growth, potentially adding {formatDollars(calculations.iulAdvantage)} in advantages over traditional Roth conversions by providing a hedge against market volatility and tax-free withdrawals.</p>
              <Badge className="mt-2 bg-emerald-400 text-slate-900">Tax-Free Growth Benefit</Badge>
            </CardContent>
          </Card>

          <Button
            onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
            className="bg-emerald-400 text-slate-900 hover:bg-emerald-500"
          >
            Send to AI Advisor
          </Button>
        </div>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("backdoor-roth", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-backdoor-roth");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Backdoor Roth IRA Conversion Calculator"
            calculatorRoute="backdoor-roth"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="backdoor-roth-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/backdoor-roth" />
</div>
    </AppShell>
  );
}