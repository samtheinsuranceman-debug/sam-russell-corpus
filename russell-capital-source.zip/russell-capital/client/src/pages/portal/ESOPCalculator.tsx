// @ts-nocheck
import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Calculator } from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function ESOPCalculator() {
  const autoFill = useCalculatorAutoFill("esop-calculator");
  const { reportResult } = useCalcResults();
  const [salary, setSalary] = useSharedField("annualIncome", 100000);
  const [age, setAge] = useSharedField("currentAge", 40);
  const [esopBalance, setEsopBalance] = useState(50000);
  const [growthRate, setGrowthRate] = useSharedField("growthRate", 7);
  const [yearsToRetirement, setYearsToRetirement] = useSharedField("projectionYears", 20);

  const calculations = useMemo(() => {
    const projectedValue = esopBalance * Math.pow(1 + growthRate / 100, yearsToRetirement);
    const estimatedAnnualGrowth = esopBalance * (growthRate / 100);
    const potentialTaxSavings = (projectedValue * 0.15);  // Simplified assumption of 15% tax rate
    return { projectedValue, estimatedAnnualGrowth, potentialTaxSavings };
  }, [esopBalance, growthRate, yearsToRetirement]);
  const projectionData = useMemo(() => {
    const d = [];
    let opt = 100000, base = 100000, taxSav = 0;
    for (let yr = 0; yr <= 50; yr++) {
      opt *= 1.075;
      base *= 1.05;
      taxSav += (opt - base) * 0.08;
      d.push({ year: yr, optimized: Math.round(opt), baseline: Math.round(base), taxSavings: Math.round(taxSav), netBenefit: Math.round(opt - base + taxSav) });
    }
    return d;
  }, []);


  return (
    <AppShell className="bg-[#0a0f1a] text-white">
      <div className="p-6 max-w-4xl mx-auto">
        <AutoFillBanner calcRoute="esop-calculator" />
        <div className="flex items-center mb-6">
          <Calculator className="mr-2 text-emerald-400" />
          <h1 className="text-2xl font-bold">ESOP Calculator</h1>
        </div>

        {/* Input Section */}
        <div className="space-y-6 mb-8">
          <div>
            <Label>Annual Salary</Label>
            <Input
              type="number"
              value={salary}
              onChange={(e) => setSalary(Number(e.target.value))}
              className="mt-1 bg-[#0d1526] border-[#1e3a5f]"
            />
          </div>
          <div>
            <Label>Current Age</Label>
            <Input
              type="number"
              value={age}
              onChange={(e) => setAge(Number(e.target.value))}
              className="mt-1 bg-[#0d1526] border-[#1e3a5f]"
            />
          </div>
          <div>
            <Label>Current ESOP Balance</Label>
            <Input
              type="number"
              value={esopBalance}
              onChange={(e) => setEsopBalance(Number(e.target.value))}
              className="mt-1 bg-[#0d1526] border-[#1e3a5f]"
            />
          </div>
          <div>
            <Label>Growth Rate (%)</Label>
            <Slider
              min={0}
              max={15}
              step={0.1}
              value={[growthRate]}
              onValueChange={(value) => setGrowthRate(value[0])}
              className="mt-1"
            />
          </div>
          <div>
            <Label>Years to Retirement</Label>
            <Input
              type="number"
              value={yearsToRetirement}
              onChange={(e) => setYearsToRetirement(Number(e.target.value))}
              className="mt-1 bg-[#0d1526] border-[#1e3a5f]"
            />
          </div>
        </div>

        {/* Results Section */}
        {/* State Tax Impact */}
        <StateTaxSelector income={salary} filingStatus={'single'} className="mb-6" />
        
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "optimized", label: "Optimized Strategy", color: "#10b981" }, { key: "baseline", label: "Baseline (No Action)", color: "#ef4444" }, { key: "taxSavings", label: "Cumulative Tax Savings", color: "#06b6d4" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle>Projected ESOP Value</CardTitle>
            </CardHeader>
            <CardContent>{formatDollars(calculations.projectedValue)}</CardContent>
          </Card>
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle>Estimated Annual Growth</CardTitle>
            </CardHeader>
            <CardContent>{formatDollars(calculations.estimatedAnnualGrowth)}</CardContent>
          </Card>
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle>Potential Tax Savings</CardTitle>
            </CardHeader>
            <CardContent>{formatDollars(calculations.potentialTaxSavings)}</CardContent>
          </Card>
        </div>

        {/* IUL Advantage Section */}
        <Card className="bg-[#0d1526] border-[#1e3a5f] mb-8">
          <CardHeader>
            <CardTitle>IUL Advantage</CardTitle>
          </CardHeader>
          <CardContent>
            IUL offers tax-free growth on your investments, providing a significant advantage over ESOP by allowing your funds to grow without annual taxes, potentially increasing your retirement savings by up to 20% compared to taxable ESOP growth.
          </CardContent>
        </Card>

        {/* Send to AI Advisor Button */}
        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-500 hover:bg-emerald-600"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("esop-calculator", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-esop-calculator");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Employee Stock Ownership Plan (ESOP) Calculator"
            calculatorRoute="esop-calculator"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="e-s-o-p-calculator" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/esop-calculator" />
</div>
    </AppShell>
  );
}