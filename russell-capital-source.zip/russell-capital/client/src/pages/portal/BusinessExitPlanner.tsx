// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { LogOut, DollarSign, TrendingUp, Target, Calendar, Percent, ArrowRight, Shield, CheckCircle2, AlertTriangle, Building2, Users } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, AreaChart, Area, ComposedChart, Line, PieChart, Pie, Cell } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

export default function BusinessExitPlanner() {
  const [ebitda, setEbitda] = useState(1000000);
  const [multiple, setMultiple] = useState(5);
  const [dcfRate, setDcfRate] = useState(0.1);
  const [dcfCashFlows, setDcfCashFlows] = useState(500000);
  const [assetValue, setAssetValue] = useState(800000);
  const [comparableSales, setComparableSales] = useState(1200000);
  const [exitStrategy, setExitStrategy] = useState('outright');
  const [esopPercentage, setEsopPercentage] = useState(30);
  const [managementBuyoutAmount, setManagementBuyoutAmount] = useState(900000);
  const [familySuccessionPlan, setFamilySuccessionPlan] = useState('yes');
  const [ipoValuation, setIpoValuation] = useState(2000000);
  const [installmentSaleAmount, setInstallmentSaleAmount] = useState(500000);
  const [qsbsExclusion, setQsbsExclusion] = useState(100000);
  const [idgtSaleAmount, setIdgtSaleAmount] = useState(400000);
  const [crtAmount, setCrtAmount] = useState(300000);
  const [earnOutTarget, setEarnOutTarget] = useState(200000);
  const [earnOutPercentage, setEarnOutPercentage] = useState(20);
  const [goodwillAllocation, setGoodwillAllocation] = useState(50);
  const [initialWealth, setInitialWealth] = useState(1000000);
  const [growthRate, setGrowthRate] = useSharedField("growthRate", 0.05);
  const [sellerTaxRate, setSellerTaxRate] = useState(0.2);
  const [buyerTaxRate, setBuyerTaxRate] = useState(0.15);
  const [irc338Election, setIrc338Election] = useState(false);
  const [section1060Allocation, setSection1060Allocation] = useState(60);
  const [section453Installment, setSection453Installment] = useState(true);
  const [section1202Qsbs, setSection1202Qsbs] = useState(500000);
  const [section1042Esop, setSection1042Esop] = useState(400000);

  const themeStyle = {
    backgroundColor: '#001f3f',
    color: '#ffd700',
    padding: '20px',
    minHeight: '100vh',
    fontFamily: 'Arial, sans-serif',
  };

  const ebitdaValuation = useMemo(() => ebitda * multiple, [ebitda, multiple]);
  const dcfValuation = useMemo(() => dcfCashFlows / (1 + dcfRate), [dcfCashFlows, dcfRate]);
  const assetBasedValuation = useMemo(() => assetValue, [assetValue]);
  const comparableSalesValuation = useMemo(() => comparableSales, [comparableSales]);

  const valuationData = useMemo(() => [
    { name: 'EBITDA Multiple', value: ebitdaValuation },
    { name: 'DCF', value: dcfValuation },
    { name: 'Asset-Based', value: assetBasedValuation },
    { name: 'Comparable Sales', value: comparableSalesValuation },
  ], [ebitdaValuation, dcfValuation, assetBasedValuation, comparableSalesValuation]);

  const exitStrategyData = useMemo(() => [
    { name: 'Outright Sale', value: ebitdaValuation },
    { name: 'ESOP', value: ebitdaValuation * (esopPercentage / 100) },
    { name: 'Management Buyout', value: managementBuyoutAmount },
    { name: 'Family Succession', value: familySuccessionPlan === 'yes' ? ebitdaValuation * 0.8 : 0 },
    { name: 'IPO', value: ipoValuation },
  ], [ebitdaValuation, esopPercentage, managementBuyoutAmount, familySuccessionPlan, ipoValuation]);

  const taxStructureData = useMemo(() => [
    { name: 'Installment Sale', value: installmentSaleAmount },
    { name: 'QSBS Exclusion', value: qsbsExclusion },
    { name: 'IDGT Sale', value: idgtSaleAmount },
    { name: 'CRT', value: crtAmount },
  ], [installmentSaleAmount, qsbsExclusion, idgtSaleAmount, crtAmount]);

  const earnOutProjection = useMemo(() => earnOutTarget * (earnOutPercentage / 100), [earnOutTarget, earnOutPercentage]);

  const optimizedGoodwill = useMemo(() => goodwillAllocation * 0.9, [goodwillAllocation]); // Simplified optimizer

  const wealthProjectionData = useMemo(() => {
    let data = [];
    for (let year = 0; year <= 50; year++) {
      data.push({ year, wealth: initialWealth * Math.pow(1 + growthRate, year) });
    }
    return data;
  }, [initialWealth, growthRate]);

  const taxImpactData = useMemo(() => [
    { name: 'Seller Tax Impact', value: sellerTaxRate * ebitdaValuation },
    { name: 'Buyer Tax Impact', value: buyerTaxRate * ebitdaValuation },
  ], [sellerTaxRate, buyerTaxRate, ebitdaValuation]);

  return (
    <div style={themeStyle}>
      <h1><DollarSign /> Business Exit Planner</h1>
      
      <section>
        <h2><TrendingUp /> Business Valuation Methods</h2>
        <form>
          <label>EBITDA: <input type="number" value={ebitda} onChange={e => setEbitda(Number(e.target.value))} /></label>
          <label>Multiple: <input type="number" value={multiple} onChange={e => setMultiple(Number(e.target.value))} /></label>
          <p>EBITDA Valuation: {ebitdaValuation}</p>
          
          <label>DCF Cash Flows: <input type="number" value={dcfCashFlows} onChange={e => setDcfCashFlows(Number(e.target.value))} /></label>
          <label>DCF Rate: <input type="number" value={dcfRate} onChange={e => setDcfRate(Number(e.target.value))} /></label>
          <p>DCF Valuation: {dcfValuation}</p>
          
          <label>Asset Value: <input type="number" value={assetValue} onChange={e => setAssetValue(Number(e.target.value))} /></label>
          <p>Asset-Based Valuation: {assetBasedValuation}</p>
          
          <label>Comparable Sales: <input type="number" value={comparableSales} onChange={e => setComparableSales(Number(e.target.value))} /></label>
          <p>Comparable Sales Valuation: {comparableSalesValuation}</p>
        </form>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={valuationData}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="value" fill="#ffd700" />
          </BarChart>
        </ResponsiveContainer>
      </section>
      
      <section>
        <h2><ArrowRight /> Exit Strategy Comparison</h2>
        <form>
          <label>Strategy: 
            <select value={exitStrategy} onChange={e => setExitStrategy(e.target.value)}>
              <option value="outright">Outright Sale</option>
              <option value="esop">ESOP</option>
              <option value="management">Management Buyout</option>
              <option value="family">Family Succession</option>
              <option value="ipo">IPO</option>
            </select>
          </label>
          <label>ESOP Percentage: <input type="number" value={esopPercentage} onChange={e => setEsopPercentage(Number(e.target.value))} />%</label>
          <label>Management Buyout Amount: <input type="number" value={managementBuyoutAmount} onChange={e => setManagementBuyoutAmount(Number(e.target.value))} /></label>
          <label>Family Succession Plan: <input type="checkbox" checked={familySuccessionPlan === 'yes'} onChange={e => setFamilySuccessionPlan(e.target.checked ? 'yes' : 'no')} /></label>
          <label>IPO Valuation: <input type="number" value={ipoValuation} onChange={e => setIpoValuation(Number(e.target.value))} /></label>
        </form>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie data={exitStrategyData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} fill="#ffd700" label>
              {exitStrategyData.map((entry, index) => <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#ffd700' : '#001f3f'} />)}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </section>
      
      <section>
        <h2><Shield /> Tax-Efficient Sale Structures</h2>
        <form>
          <label>Installment Sale Amount: <input type="number" value={installmentSaleAmount} onChange={e => setInstallmentSaleAmount(Number(e.target.value))} /></label>
          <label>QSBS Exclusion: <input type="number" value={qsbsExclusion} onChange={e => setQsbsExclusion(Number(e.target.value))} /></label>
          <label>IDGT Sale Amount: <input type="number" value={idgtSaleAmount} onChange={e => setIdgtSaleAmount(Number(e.target.value))} /></label>
          <label>CRT Amount: <input type="number" value={crtAmount} onChange={e => setCrtAmount(Number(e.target.value))} /></label>
        </form>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={taxStructureData}>
            <Area type="monotone" dataKey="value" stroke="#ffd700" fill="#001f3f" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
          </AreaChart>
        </ResponsiveContainer>
      </section>
      
      <section>
        <h2><Target /> Earn-Out Modeling</h2>
        <form>
          <label>Earn-Out Target: <input type="number" value={earnOutTarget} onChange={e => setEarnOutTarget(Number(e.target.value))} /></label>
          <label>Earn-Out Percentage: <input type="number" value={earnOutPercentage} onChange={e => setEarnOutPercentage(Number(e.target.value))} />%</label>
        </form>
        <p>Projected Earn-Out: {earnOutProjection}</p>
        <ResponsiveContainer width="100%" height={300}>
          <ComposedChart data={[{name: 'Earn-Out', value: earnOutProjection}]}>
            <Line type="monotone" dataKey="value" stroke="#ffd700" />
            <Bar dataKey="value" fill="#001f3f" />
          </ComposedChart>
        </ResponsiveContainer>
      </section>
      
      <section>
        <h2><Percent /> Goodwill Allocation Optimizer</h2>
        <form>
          <label>Goodwill Allocation (%): <input type="number" value={goodwillAllocation} onChange={e => setGoodwillAllocation(Number(e.target.value))} />%</label>
        </form>
        <p>Optimized Goodwill: {optimizedGoodwill}</p>
      </section>
      
      <section>
        <h2><Calendar /> 50-Year Post-Exit Wealth Projection</h2>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={wealthProjectionData}>
            <Line type="monotone" dataKey="wealth" stroke="#ffd700" />
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
          </LineChart>
        </ResponsiveContainer>
      </section>
      
      <section>
        <h2><AlertTriangle /> Buyer vs Seller Tax Impact Analysis</h2>
        <form>
          <label>Seller Tax Rate: <input type="number" value={sellerTaxRate} onChange={e => setSellerTaxRate(Number(e.target.value))} /></label>
          <label>Buyer Tax Rate: <input type="number" value={buyerTaxRate} onChange={e => setBuyerTaxRate(Number(e.target.value))} /></label>
        </form>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={taxImpactData}>
            <Bar dataKey="value" fill="#ffd700" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
          </BarChart>
        </ResponsiveContainer>
      </section>
      
      <section>
        <h2><CheckCircle2 /> Compliance Checklist</h2>
        <ul>
          <li><Building2 /> IRC 338(h)(10) Election: <input type="checkbox" checked={irc338Election} onChange={e => setIrc338Election(e.target.checked)} /></li>
          <li><Users /> Section 1060 Allocation: <input type="number" value={section1060Allocation} onChange={e => setSection1060Allocation(Number(e.target.value))} />%</li>
          <li><LogOut /> Section 453 Installment: <input type="checkbox" checked={section453Installment} onChange={e => setSection453Installment(e.target.checked)} /></li>
          <li><Shield /> Section 1202 QSBS: <input type="number" value={section1202Qsbs} onChange={e => setSection1202Qsbs(Number(e.target.value))} /></li>
          <li><Percent /> Section 1042 ESOP Rollover: <input type="number" value={section1042Esop} onChange={e => setSection1042Esop(Number(e.target.value))} /></li>
        </ul>
      </section>
      <PageInsights section="business-exit-planner" />
    </div>
  );
}
