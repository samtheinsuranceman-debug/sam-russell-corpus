// @ts-nocheck
// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Gem, DollarSign, TrendingUp, Shield, CheckCircle2, AlertTriangle, Layers } from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  Legend, 
  RadarChart, 
  Radar, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { PageInsights } from "@/components/PageInsights";

const AlternativeInvestment = () => {
  // State for accredited investor checker
  const [netWorth, setNetWorth] = useState('');
  const [income, setIncome] = useSharedField("annualIncome", '');
  const [isAccredited, setIsAccredited] = useState(null);

  // State for portfolio allocation optimizer
  const [stockAllocation, setStockAllocation] = useState(60);
  const [bondAllocation, setBondAllocation] = useState(40);
  const [altAllocation, setAltAllocation] = useState(0);
  const [optimizedPortfolio, setOptimizedPortfolio] = useState(null);

  // Dummy data for charts
  const assetClasses = [
    { name: 'Private Equity (PE)', icon: <Layers size={24} color="gold" />, description: 'Investments in private companies for long-term growth.' },
    { name: 'Venture Capital (VC)', icon: <TrendingUp size={24} color="gold" />, description: 'Funding startups with high growth potential.' },
    { name: 'Hedge Funds', icon: <Shield size={24} color="gold" />, description: 'Strategies for absolute returns, often with leverage.' },
    { name: 'Real Estate Syndications', icon: <Gem size={24} color="gold" />, description: 'Group investments in property developments.' },
    { name: 'Private Credit', icon: <DollarSign size={24} color="gold" />, description: 'Direct lending to companies outside public markets.' },
    { name: 'Commodities', icon: <AlertTriangle size={24} color="gold" />, description: 'Investments in physical goods like oil, gold, or agriculture.' },
  ];

  const riskReturnData = [
    { subject: 'PE', A: 8, B: 7, fullMark: 10 },
    { subject: 'VC', A: 9, B: 8, fullMark: 10 },
    { subject: 'Hedge Funds', A: 7, B: 6, fullMark: 10 },
    { subject: 'Real Estate', A: 6, B: 5, fullMark: 10 },
    { subject: 'Private Credit', A: 5, B: 4, fullMark: 10 },
    { subject: 'Commodities', A: 4, B: 3, fullMark: 10 },
  ];

  const jCurveData = [
    { time: 'Year 1', return: -10 },
    { time: 'Year 2', return: -5 },
    { time: 'Year 3', return: 0 },
    { time: 'Year 4', return: 5 },
    { time: 'Year 5', return: 10 },
    { time: 'Year 6', return: 15 },
  ];

  const feeData = [
    { name: 'PE', fee: 2.5 },
    { name: 'VC', fee: 2.0 },
    { name: 'Hedge Funds', fee: 1.5 },
    { name: 'Real Estate', fee: 1.0 },
    { name: 'Private Credit', fee: 0.8 },
    { name: 'Commodities', fee: 0.5 },
  ];

  const COLORS = ['#FFD700', '#9370DB', '#8A2BE2', '#4B0082', '#483D8B', '#6A5ACD']; // Gold and purple shades

  const checkAccreditedInvestor = () => {
    const netWorthNum = parseFloat(netWorth);
    const incomeNum = parseFloat(income);
    if ((netWorthNum >= 1000000 && incomeNum >= 200000) || netWorthNum >= 5000000) {
      setIsAccredited(true);
    } else {
      setIsAccredited(false);
    }
  };

  const optimizePortfolio = useMemo(() => {
    const totalReturn60_40 = (stockAllocation * 0.08) + (bondAllocation * 0.04); // Dummy returns
    const totalReturnWithAlt = (stockAllocation * 0.08) + (bondAllocation * 0.04) + (altAllocation * 0.10);
    return {
      '60/40 Return': totalReturn60_40,
      'With Alternatives Return': totalReturnWithAlt,
    };
  }, [stockAllocation, bondAllocation, altAllocation]);

  return (
    <div style={{ backgroundColor: '#2C1A3D', color: '#FFD700', minHeight: '100vh', padding: '20px' }}>
      <h1 style={{ textAlign: 'center', marginBottom: '40px' }}>Alternative Investments</h1>

      {/* Asset Classes Section */}
      <section style={{ marginBottom: '40px' }}>
        <h2>Alternative Asset Classes</h2>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px' }}>
          {assetClasses.map((asset, index) => (
            <div key={index} style={{ backgroundColor: '#3B2A4F', padding: '20px', borderRadius: '10px', width: '300px' }}>
              {asset.icon}
              <h3>{asset.name}</h3>
              <p>{asset.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Accredited Investor Checker */}
      <section style={{ marginBottom: '40px' }}>
        <h2>Accredited Investor Checker</h2>
        <div>
          <input 
            type="number" 
            placeholder="Net Worth" 
            value={netWorth} 
            onChange={(e) => setNetWorth(e.target.value)} 
            style={{ marginRight: '10px', padding: '10px', backgroundColor: '#4B0082', color: '#FFD700' }}
          />
          <input 
            type="number" 
            placeholder="Annual Income" 
            value={income} 
            onChange={(e) => setIncome(e.target.value)} 
            style={{ marginRight: '10px', padding: '10px', backgroundColor: '#4B0082', color: '#FFD700' }}
          />
          <button onClick={checkAccreditedInvestor} style={{ padding: '10px', backgroundColor: '#FFD700', color: '#2C1A3D' }}>
            Check
          </button>
          {isAccredited !== null && (
            <div style={{ marginTop: '10px' }}>
              {isAccredited ? <CheckCircle2 size={24} color="green" /> : <AlertTriangle size={24} color="red" />}
              {isAccredited ? ' You are an accredited investor!' : ' You are not an accredited investor.'}
            </div>
          )}
        </div>
      </section>

      {/* Portfolio Allocation Optimizer */}
      <section style={{ marginBottom: '40px' }}>
        <h2>Portfolio Allocation Optimizer</h2>
        <div>
          <label>Stocks (%): </label>
          <input 
            type="number" 
            value={stockAllocation} 
            onChange={(e) => setStockAllocation(parseInt(e.target.value))} 
            style={{ marginRight: '10px', padding: '10px', backgroundColor: '#4B0082', color: '#FFD700' }}
          />
          <label>Bonds (%): </label>
          <input 
            type="number" 
            value={bondAllocation} 
            onChange={(e) => setBondAllocation(parseInt(e.target.value))} 
            style={{ marginRight: '10px', padding: '10px', backgroundColor: '#4B0082', color: '#FFD700' }}
          />
          <label>Alternatives (%): </label>
          <input 
            type="number" 
            value={altAllocation} 
            onChange={(e) => setAltAllocation(parseInt(e.target.value))} 
            style={{ marginRight: '10px', padding: '10px', backgroundColor: '#4B0082', color: '#FFD700' }}
          />
        </div>
        <div style={{ marginTop: '20px' }}>
          <p>60/40 Portfolio Return: {optimizedPortfolio?.['60/40 Return'].toFixed(2)}%</p>
          <p>With Alternatives Return: {optimizedPortfolio?.['With Alternatives Return'].toFixed(2)}%</p>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={[{name: '60/40', value: optimizedPortfolio?.['60/40 Return']}, {name: 'With Alt', value: optimizedPortfolio?.['With Alternatives Return']}]}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="value" fill="#FFD700" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Risk-Return RadarChart */}
      <section style={{ marginBottom: '40px' }}>
        <h2>Risk-Return Radar Chart</h2>
        <ResponsiveContainer width="100%" height={400}>
          <RadarChart outerRadius={150} data={riskReturnData}>
            <PolarGrid />
            <PolarAngleAxis dataKey="subject" />
            <PolarRadiusAxis angle={30} domain={[0, 10]} />
            <Radar name="Risk-Return" dataKey="A" stroke="#FFD700" fill="#9370DB" fillOpacity={0.6} />
            <Legend />
            <Tooltip />
          </RadarChart>
        </ResponsiveContainer>
      </section>

      {/* J-Curve for PE/VC */}
      <section style={{ marginBottom: '40px' }}>
        <h2>J-Curve for PE/VC</h2>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={jCurveData}>
            <XAxis dataKey="time" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="return" stroke="#FFD700" />
          </LineChart>
        </ResponsiveContainer>
      </section>

      {/* Fee Comparison */}
      <section>
        <h2>Fee Comparison</h2>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={feeData}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={80}
              fill="#8884d8"
              dataKey="fee"
            >
              {feeData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </section>
      <PageInsights section="alternative-investment" />
    </div>
  );
};

export default AlternativeInvestment;
