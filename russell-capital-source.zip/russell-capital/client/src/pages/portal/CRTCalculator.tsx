// @ts-nocheck

import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Calculator, TrendingUp, Shield } from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function CRTCalculator() {
  const autoFill = useCalculatorAutoFill("crt-calculator");
  const { reportResult } = useCalcResults();
  const [age, setAge] = useSharedField("currentAge", 50);
  const [trustValue, setTrustValue] = useState(100000);
  const [payoutRate, setPayoutRate] = useState(5);
  const [assumedReturnRate, setAssumedReturnRate] = useState(4);
  const [years, setYears] = useSharedField("projectionYears", 20);

  const results = useMemo(() => {
    const annualPayout = trustValue * (payoutRate / 100);
    const futureValue = trustValue * Math.pow(1 + (assumedReturnRate / 100), years) - (annualPayout * years);
    const charitableDonation = futureValue > 0 ? futureValue : 0;
    const taxSavings = annualPayout * 0.25;  // Simplified assumption for tax savings rate
    return { annualPayout, charitableDonation, taxSavings };
  }, [trustValue, payoutRate, assumedReturnRate, years]);
  const projectionData = useMemo(() => {
    const d = [];
    let opt = 100000, base = 100000, taxSav = 0;
    for (let yr = 0; yr <= 50; yr++) {
      opt *= 1.075;
      base *= 1.05;
      taxSav += (opt - base) * 0.08;
      d.push({ year: yr, optimized: Math.round(opt), baseline: Math.round(base), taxSavings: Math.round(taxSav), netBenefit: Math.round(opt - base + taxSav) });
    }
    return d;
  }, []);


  return (
    <AppShell>
      <div className="p-6 bg-[#0a0f1a] min-h-screen text-white">
        <AutoFillBanner calcRoute="crt-calculator" />
        <div className="flex items-center mb-6">
          <Calculator className="mr-2" />
          <h1 className="text-2xl font-bold">Charitable Remainder Trust Calculator</h1>
          <Badge className="ml-2 bg-emerald-400 text-slate-900">Estate & Trust Planning</Badge>
        </div>

        {/* Input Section */}
        <Card className="bg-[#0d1526] mb-6">
          <CardHeader className="flex flex-row items-center">
            <Shield className="mr-2" />
            <CardTitle>Inputs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Age Input */}
              <div>
                <Label>Age</Label>
                <div className="flex items-center">
                  <Slider
                    min={18}
                    max={80}
                    step={1}
                    value={[age]}
                    onValueChange={(value) => setAge(value[0])}
                    className="w-full"
                  />
                  <Input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(Number(e.target.value))}
                    className="ml-2 w-20"
                  />
                </div>
              </div>

              {/* Trust Value Input */}
              <div>
                <Label>Trust Value</Label>
                <div className="flex items-center">
                  <Slider
                    min={10000}
                    max={1000000}
                    step={10000}
                    value={[trustValue]}
                    onValueChange={(value) => setTrustValue(value[0])}
                    className="w-full"
                  />
                  <Input
                    type="number"
                    value={trustValue}
                    onChange={(e) => setTrustValue(Number(e.target.value))}
                    className="ml-2 w-32"
                  />
                </div>
              </div>

              {/* Payout Rate Input */}
              <div>
                <Label>Payout Rate (%)</Label>
                <div className="flex items-center">
                  <Slider
                    min={1}
                    max={10}
                    step={0.5}
                    value={[payoutRate]}
                    onValueChange={(value) => setPayoutRate(value[0])}
                    className="w-full"
                  />
                  <Input
                    type="number"
                    value={payoutRate}
                    onChange={(e) => setPayoutRate(Number(e.target.value))}
                    className="ml-2 w-20"
                  />
                </div>
              </div>

              {/* Assumed Return Rate Input */}
              <div>
                <Label>Assumed Return Rate (%)</Label>
                <div className="flex items-center">
                  <Slider
                    min={1}
                    max={10}
                    step={0.5}
                    value={[assumedReturnRate]}
                    onValueChange={(value) => setAssumedReturnRate(value[0])}
                    className="w-full"
                  />
                  <Input
                    type="number"
                    value={assumedReturnRate}
                    onChange={(e) => setAssumedReturnRate(Number(e.target.value))}
                    className="ml-2 w-20"
                  />
                </div>
              </div>

              {/* Years Input */}
              <div>
                <Label>Years</Label>
                <div className="flex items-center">
                  <Slider
                    min={5}
                    max={30}
                    step={1}
                    value={[years]}
                    onValueChange={(value) => setYears(value[0])}
                    className="w-full"
                  />
                  <Input
                    type="number"
                    value={years}
                    onChange={(e) => setYears(Number(e.target.value))}
                    className="ml-2 w-20"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results Section */}
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />
        
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "optimized", label: "Optimized Strategy", color: "#10b981" }, { key: "baseline", label: "Baseline (No Action)", color: "#ef4444" }, { key: "taxSavings", label: "Cumulative Tax Savings", color: "#06b6d4" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="bg-[#0d1526]">
            <CardHeader>
              <CardTitle>Annual Payout</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-emerald-400">{formatDollars(results.annualPayout)}</p>
              <p>Estimated yearly income from CRT</p>
            </CardContent>
          </Card>

          <Card className="bg-[#0d1526]">
            <CardHeader>
              <CardTitle>Charitable Donation</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-emerald-400">{formatDollars(results.charitableDonation)}</p>
              <p>Projected value for charity</p>
            </CardContent>
          </Card>

          <Card className="bg-[#0d1526]">
            <CardHeader>
              <CardTitle>Tax Savings</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-emerald-400">{formatDollars(results.taxSavings)}</p>
              <p>Estimated annual tax benefits</p>
            </CardContent>
          </Card>
        </div>

        {/* IUL Advantage Section */}
        <Card className="bg-[#0d1526] mb-6">
          <CardHeader className="flex flex-row items-center">
            <TrendingUp className="mr-2" />
            <CardTitle>IUL Advantage</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Indexed Universal Life (IUL) offers tax-free growth, which can enhance your CRT by providing a tax-advantaged way to fund the trust, potentially increasing your overall estate value and charitable impact.</p>
            <Badge className="mt-2 bg-emerald-400 text-slate-900">Tax-Free Growth Benefits</Badge>
          </CardContent>
        </Card>

        {/* Send to AI Advisor Button */}
        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-400 hover:bg-emerald-500 text-slate-900"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("crt-calculator", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-crt-calculator");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Charitable Remainder Trust (CRT) Calculator"
            calculatorRoute="crt-calculator"
            inputs={typeof results !== 'undefined' ? results : {}}
            results={typeof results !== 'undefined' ? results : {}}
            projectionData={projectionData}
          />
      <PageInsights section="c-r-t-calculator" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/crt-calculator" />
</div>
    </AppShell>
  );
}