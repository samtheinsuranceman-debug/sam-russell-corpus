// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Briefcase, DollarSign, TrendingUp, Shield, CheckCircle2, AlertTriangle, Calendar, Target, Scale, Zap, Clock, Percent } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, BarChart, Bar, ComposedChart, Line } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

export default function EmployeeStockOptions() {
  const [isoGrantPrice, setIsoGrantPrice] = useState(50);
  const [isoFMV, setIsoFMV] = useState(100);
  const [isoExerciseShares, setIsoExerciseShares] = useState(1000);
  const [taxBracket, setTaxBracket] = useSharedField("currentTaxBracket", 22); // In percent
  const [exerciseYear, setExerciseYear] = useState(5); // Years from grant
  const [amtIncome, setAmtIncome] = useState(200000); // AMT calculator input

  const darkThemeStyle = {
    backgroundColor: '#1a1a2e',
    color: '#e0e0e0',
    padding: '20px',
    minHeight: '100vh',
    fontFamily: 'Arial, sans-serif',
  };

  const accentGreen = '#4CAF50'; // Green accent
  const accentViolet = '#9C27B0'; // Violet accent

  // Memoized AMT calculation for ISOs
  const amtTrapCalculation = useMemo(() => {
    const isoBargainElement = (isoFMV - isoGrantPrice) * isoExerciseShares;
    const amtAdjustment = isoBargainElement * (1 - (taxBracket / 100));
    const effectiveAMT = amtIncome + amtAdjustment;
    return {
      bargainElement: isoBargainElement,
      amtAdjustment,
      effectiveAMT,
    };
  }, [isoGrantPrice, isoFMV, isoExerciseShares, taxBracket, amtIncome]);

  // Sample data for 10yr strategy comparison
  const strategyData = useMemo(() => [
    { year: 0, isoAfterTaxValue: 0, nqsoAfterTaxValue: 0 },
    { year: 1, isoAfterTaxValue: 5000, nqsoAfterTaxValue: 4000 },
    { year: 2, isoAfterTaxValue: 10000, nqsoAfterTaxValue: 8000 },
    { year: 3, isoAfterTaxValue: 15000, nqsoAfterTaxValue: 12000 },
    { year: 4, isoAfterTaxValue: 20000, nqsoAfterTaxValue: 16000 },
    { year: 5, isoAfterTaxValue: 25000, nqsoAfterTaxValue: 20000 },
    { year: 6, isoAfterTaxValue: 30000, nqsoAfterTaxValue: 24000 },
    { year: 7, isoAfterTaxValue: 35000, nqsoAfterTaxValue: 28000 },
    { year: 8, isoAfterTaxValue: 40000, nqsoAfterTaxValue: 32000 },
    { year: 9, isoAfterTaxValue: 45000, nqsoAfterTaxValue: 36000 },
    { year: 10, isoAfterTaxValue: 50000, nqsoAfterTaxValue: 40000 },
  ], []);

  // Sample data for spread vs FMV visualization
  const spreadData = useMemo(() => [
    { fmv: 50, spread: 0 },
    { fmv: 60, spread: 10 },
    { fmv: 70, spread: 20 },
    { fmv: 80, spread: 30 },
    { fmv: 90, spread: 40 },
    { fmv: 100, spread: 50 },
  ], []);

  // Tax bracket impact modeling data
  const taxImpactData = useMemo(() => [
    { bracket: 10, isoValue: 10000, nqsoValue: 9000 },
    { bracket: 22, isoValue: 8000, nqsoValue: 7000 },
    { bracket: 24, isoValue: 6000, nqsoValue: 5000 },
    { bracket: 32, isoValue: 4000, nqsoValue: 3000 },
    { bracket: 35, isoValue: 2000, nqsoValue: 1000 },
    { bracket: 37, isoValue: 0, nqsoValue: -1000 },
  ], []);

  return (
    <div style={darkThemeStyle}>
      <h1 style={{ color: accentGreen }}><Briefcase size={24} /> Employee Stock Options Guide</h1>

      {/* ISO vs NQSO Comparison Table */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: accentViolet }}><Shield size={20} /> ISO vs NQSO Comparison</h2>
        <div className="overflow-x-auto"><table style={{ width: '100%', borderCollapse: 'collapse', border: '1px solid #4CAF50' }}>
          <thead>
            <tr style={{ backgroundColor: '#333', color: '#fff' }}>
              <th style={{ padding: '10px', border: '1px solid #4CAF50' }}>Feature</th>
              <th style={{ padding: '10px', border: '1px solid #4CAF50' }}>ISO (Incentive Stock Options)</th>
              <th style={{ padding: '10px', border: '1px solid #4CAF50' }}>NQSO (Non-Qualified Stock Options)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style={{ padding: '10px', border: '1px solid #4CAF50' }}>Tax Treatment on Exercise</td>
              <td>No regular tax, but potential AMT</td>
              <td>Ordinary income tax on spread</td>
            </tr>
            <tr>
              <td style={{ padding: '10px', border: '1px solid #4CAF50' }}>Holding Period for Long-Term Capital Gains</td>
              <td>1 year after exercise, 2 years after grant</td>
              <td>No special holding period</td>
            </tr>
            <tr>
              <td style={{ padding: '10px', border: '1px solid #4CAF50' }}>AMT Impact</td>
              <td>Possible trap under IRC 422</td>
              <td>None</td>
            </tr>
            <tr>
              <td style={{ padding: '10px', border: '1px solid #4CAF50' }}>Employer Deduction</td>
              <td>No</td>
              <td>Yes, on spread</td>
            </tr>
            <tr>
              <td style={{ padding: '10px', border: '1px solid #4CAF50' }}>Eligibility</td>
              <td>Employees only</td>
              <td>Employees, consultants, etc.</td>
            </tr>
          </tbody>
        </table></div>
      </section>

      {/* AMT Trap Calculator for ISOs */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: accentGreen }}><AlertTriangle size={20} /> AMT Trap Calculator (IRC 422)</h2>
        <div>
          <label>ISO Grant Price: <input type="number" value={isoGrantPrice} onChange={(e) => setIsoGrantPrice(Number(e.target.value))} style={{ backgroundColor: '#333', color: '#e0e0e0', border: '1px solid #9C27B0' }} /></label>
          <label>FMV at Exercise: <input type="number" value={isoFMV} onChange={(e) => setIsoFMV(Number(e.target.value))} style={{ backgroundColor: '#333', color: '#e0e0e0', border: '1px solid #9C27B0' }} /></label>
          <label>Shares Exercised: <input type="number" value={isoExerciseShares} onChange={(e) => setIsoExerciseShares(Number(e.target.value))} style={{ backgroundColor: '#333', color: '#e0e0e0', border: '1px solid #9C27B0' }} /></label>
          <label>AMT Income: <input type="number" value={amtIncome} onChange={(e) => setAmtIncome(Number(e.target.value))} style={{ backgroundColor: '#333', color: '#e0e0e0', border: '1px solid #9C27B0' }} /></label>
          <p>Bargain Element: ${amtTrapCalculation.bargainElement.toFixed(2)}</p>
          <p>AMT Adjustment: ${amtTrapCalculation.amtAdjustment.toFixed(2)}</p>
          <p>Effective AMT: ${amtTrapCalculation.effectiveAMT.toFixed(2)}</p>
        </div>
      </section>

      {/* Optimal Exercise Timing Strategy */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: accentViolet }}><Clock size={20} /> Optimal Exercise Timing Strategy</h2>
        <p>Consider exercising ISOs when the stock price is high but before AMT triggers. Use <TrendingUp size={18} /> to monitor market trends.</p>
        <p>Factors: Tax brackets, company performance, and holding periods. Aim for year {exerciseYear} for maximum after-tax value.</p>
      </section>

      {/* Early Exercise 83(b) Election Analysis */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: accentGreen }}><Zap size={20} /> Early Exercise 83(b) Election Analysis</h2>
        <p>Pros: Locks in lower valuation for taxes. Cons: Risk if stock doesn't appreciate. File within 30 days of exercise.</p>
        <p>Analysis: If FMV is low, elect to avoid future taxes. Use <Scale size={18} /> for risk-reward balance.</p>
      </section>

      {/* Tax Bracket Impact Modeling */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: accentViolet }}><Percent size={20} /> Tax Bracket Impact Modeling</h2>
        <label>Tax Bracket (%): <input type="number" value={taxBracket} onChange={(e) => setTaxBracket(Number(e.target.value))} style={{ backgroundColor: '#333', color: '#e0e0e0', border: '1px solid #9C27B0' }} /></label>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={taxImpactData}>
            <XAxis dataKey="bracket" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="isoValue" fill={accentGreen} />
            <Bar dataKey="nqsoValue" fill={accentViolet} />
          </BarChart>
        </ResponsiveContainer>
      </section>

      {/* Spread vs FMV Visualization */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: accentGreen }}><DollarSign size={20} /> Spread vs FMV Visualization</h2>
        <ResponsiveContainer width="100%" height={300}>
          <ComposedChart data={spreadData}>
            <XAxis dataKey="fmv" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="spread" fill={accentViolet} />
            <Line type="monotone" dataKey="fmv" stroke={accentGreen} />
          </ComposedChart>
        </ResponsiveContainer>
      </section>

      {/* 10yr Exercise Strategy Comparison */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: accentViolet }}><Target size={20} /> 10-Year Exercise Strategy Comparison</h2>
        <ResponsiveContainer width="100%" height={400}>
          <AreaChart data={strategyData}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="isoAfterTaxValue" stroke={accentGreen} fill={accentGreen} />
            <Area type="monotone" dataKey="nqsoAfterTaxValue" stroke={accentViolet} fill={accentViolet} />
          </AreaChart>
        </ResponsiveContainer>
      </section>

      {/* Compliance Information */}
      <section>
        <h2 style={{ color: accentGreen }}><CheckCircle2 size={20} /> Compliance Rules</h2>
        <ul style={{ listStyle: 'none' }}>
          <li><Calendar size={18} /> IRC 422 ISO Rules: Must be granted to employees, exercise price {'>='} FMV at grant, 10-year max term.</li>
          <li><AlertTriangle size={18} /> Section 83(b) Election: Must be filed within 30 days of exercise to include property in income.</li>
          <li><Shield size={18} /> AMT Credit Carryforward: Any AMT paid can be carried forward to offset future regular tax liability.</li>
        </ul>
      </section>
      <PageInsights section="employee-stock-options" />
    </div>
  );
}
