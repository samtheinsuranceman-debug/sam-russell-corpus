// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Clock, DollarSign, TrendingUp, Shield, CheckCircle2, AlertTriangle, Calendar, Target, Percent, ArrowRight, Users, Scale } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, BarChart, Bar, ComposedChart, Line } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

const BeneficiaryIRAPlanner = () => {
  const [accountBalance, setAccountBalance] = useState(1000000); // Initial IRA balance
  const [beneficiaryAge, setBeneficiaryAge] = useState(50); // Beneficiary age
  const [isSpouse, setIsSpouse] = useState(false); // Is beneficiary a spouse?
  const [isMinor, setIsMinor] = useState(false); // Is beneficiary a minor?
  const [isDisabled, setIsDisabled] = useState(false); // Is beneficiary disabled?
  const [isChronicallyIll, setIsChronicallyIll] = useState(false); // Is beneficiary chronically ill?
  const [isNotMoreThan10YearsYounger, setIsNotMoreThan10YearsYounger] = useState(false); // Is beneficiary not more than 10 years younger?
  const [distributionYear, setDistributionYear] = useState(1); // Current distribution year
  const [taxBracket, setTaxBracket] = useSharedField("currentTaxBracket", 22); // Tax bracket percentage

  const sampleDataForChart = useMemo(() => [
    { name: 'Year 1', preSecure: 100000, secureAct: 90000 },
    { name: 'Year 2', preSecure: 95000, secureAct: 85000 },
    { name: 'Year 3', preSecure: 90000, secureAct: 80000 },
    { name: 'Year 4', preSecure: 85000, secureAct: 75000 },
    { name: 'Year 5', preSecure: 80000, secureAct: 70000 },
    { name: 'Year 6', preSecure: 75000, secureAct: 65000 },
    { name: 'Year 7', preSecure: 70000, secureAct: 60000 },
    { name: 'Year 8', preSecure: 65000, secureAct: 55000 },
    { name: 'Year 9', preSecure: 60000, secureAct: 50000 },
    { name: 'Year 10', preSecure: 55000, secureAct: 45000 },
  ], []);

  const optimalStrategy = useMemo(() => {
    let strategy = {};
    if (isSpouse) {
      strategy = { type: 'Stretch IRA', description: 'Spouse can treat as their own IRA for longer distributions.' };
    } else if (isMinor || isDisabled || isChronicallyIll || isNotMoreThan10YearsYounger) {
      strategy = { type: 'Eligible Designated Beneficiary', description: 'Exceptions apply, allowing stretch beyond 10 years.' };
    } else {
      strategy = { type: '10-Year Rule', description: 'Must distribute entire balance by the 10th year.' };
    }
    return strategy;
  }, [isSpouse, isMinor, isDisabled, isChronicallyIll, isNotMoreThan10YearsYounger]);

  const yearByYearSchedule = useMemo(() => {
    let schedule = [];
    for (let year = 1; year <= 10; year++) {
      const distributionAmount = accountBalance / 10; // Simplified calculation
      const taxImpact = distributionAmount * (taxBracket / 100);
      schedule.push({ year, distributionAmount, taxImpact });
    }
    return schedule;
  }, [accountBalance, taxBracket]);

  return (
    <div style={{ backgroundColor: '#121212', color: '#ffffff', padding: '20px', minHeight: '100vh', fontFamily: 'Arial, sans-serif' }}>
      <h1 style={{ color: '#0ff', textAlign: 'center' }}>Beneficiary IRA Distribution Planner under SECURE Act</h1> {/* Cyan accent for title */}
      
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{verticalAlign: 'middle', color: '#0ff'}}>SECURE Act 10-Year Rule vs Pre-SECURE Stretch <TrendingUp size={24} /></h2> {/* Amber accent for headers */}
        <p>The SECURE Act, enacted in 2019, changed IRA distribution rules for beneficiaries. Previously, under the pre-SECURE stretch IRA, beneficiaries could stretch distributions over their lifetime, minimizing taxes. Now, most non-spouse beneficiaries must withdraw the entire account within 10 years of the original owner's death, potentially leading to higher tax burdens.</p>
        <p>Key differences:</p>
        <ul style={{ listStyle: 'none' }}>
          <li><Clock size={18} style={{ color: '#0ff' }} /> Pre-SECURE: Distributions based on life expectancy, allowing for slower withdrawals.</li>
          <li><AlertTriangle size={18} style={{ color: '#ffbf00' }} /> SECURE Act: 10-year rule requires full distribution by year 10, unless exceptions apply.</li>
        </ul>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{verticalAlign: 'middle', color: '#0ff'}}>Eligible Designated Beneficiary Exceptions <Shield size={24} /></h2>
        <p>Under IRC 401(a)(9), certain beneficiaries are exempt from the 10-year rule:</p>
        <ul style={{ listStyle: 'none' }}>
          <li><CheckCircle2 size={18} style={{ color: '#0ff' }} /> Spouse: Can treat the IRA as their own, allowing for stretch distributions.</li>
          <li><Users size={18} style={{ color: '#ffbf00' }} /> Minor Child: Until age 21, then 10-year rule applies.</li>
          <li><Scale size={18} style={{ color: '#0ff' }} /> Disabled or Chronically Ill: Can use life expectancy for distributions.</li>
          <li><ArrowRight size={18} style={{ color: '#ffbf00' }} /> Not More Than 10 Years Younger: Can stretch based on life expectancy.</li>
        </ul>
        <form style={{ marginTop: '20px' }}>
          <label style={{ display: 'block', marginBottom: '10px' }}>
            Is the beneficiary a spouse? <input type="checkbox" checked={isSpouse} onChange={e => setIsSpouse(e.target.checked)} />
          </label>
          <label style={{ display: 'block', marginBottom: '10px' }}>
            Is the beneficiary a minor? <input type="checkbox" checked={isMinor} onChange={e => setIsMinor(e.target.checked)} />
          </label>
          <label style={{ display: 'block', marginBottom: '10px' }}>
            Is the beneficiary disabled? <input type="checkbox" checked={isDisabled} onChange={e => setIsDisabled(e.target.checked)} />
          </label>
          <label style={{ display: 'block', marginBottom: '10px' }}>
            Is the beneficiary chronically ill? <input type="checkbox" checked={isChronicallyIll} onChange={e => setIsChronicallyIll(e.target.checked)} />
          </label>
          <label style={{ display: 'block', marginBottom: '10px' }}>
            Is the beneficiary not more than 10 years younger? <input type="checkbox" checked={isNotMoreThan10YearsYounger} onChange={e => setIsNotMoreThan10YearsYounger(e.target.checked)} />
          </label>
        </form>
        <p style={{ marginTop: '10px', color: '#0ff' }}>Optimal Strategy: {optimalStrategy.type} - {optimalStrategy.description}</p>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{verticalAlign: 'middle', color: '#0ff'}}>Optimal Distribution Strategy Calculator <Target size={24} /></h2>
        <p>This calculator helps determine the best way to distribute IRA funds while managing taxes. Factors include account balance, beneficiary age, and tax bracket.</p>
        <form>
          <label style={{ display: 'block', marginBottom: '10px' }}>
            Account Balance: $<input type="number" value={accountBalance} onChange={e => setAccountBalance(Number(e.target.value))} style={{ backgroundColor: '#333', color: '#fff', borderColor: '#0ff' }} />
          </label>
          <label style={{ display: 'block', marginBottom: '10px' }}>
            Beneficiary Age: <input type="number" value={beneficiaryAge} onChange={e => setBeneficiaryAge(Number(e.target.value))} style={{ backgroundColor: '#333', color: '#fff', borderColor: '#0ff' }} />
          </label>
          <label style={{ display: 'block', marginBottom: '10px' }}>
            Tax Bracket (%): <input type="number" value={taxBracket} onChange={e => setTaxBracket(Number(e.target.value))} style={{ backgroundColor: '#333', color: '#fff', borderColor: '#0ff' }} />
          </label>
          <label style={{ display: 'block', marginBottom: '10px' }}>
            Distribution Year: <input type="number" value={distributionYear} onChange={e => setDistributionYear(Number(e.target.value))} style={{ backgroundColor: '#333', color: '#fff', borderColor: '#0ff' }} />
          </label>
        </form>
        <p style={{ color: '#ffbf00' }}>Recommended: Distribute evenly to stay in lower tax brackets. For year {distributionYear}, estimated distribution: ${yearByYearSchedule[distributionYear - 1]?.distributionAmount.toFixed(2)} with tax impact of ${yearByYearSchedule[distributionYear - 1]?.taxImpact.toFixed(2)}.</p>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{verticalAlign: 'middle', color: '#0ff'}}>Year-by-Year Distribution Schedule with Tax Bracket Management <Calendar size={24} /></h2>
        <p>Plan distributions to minimize taxes by aligning with lower income years. Use the schedule below based on your inputs.</p>
        <div className="overflow-x-auto"><table style={{ width: '100%', borderCollapse: 'collapse', color: '#fff' }}>
          <thead>
            <tr style={{ backgroundColor: '#333' }}>
              <th style={{ padding: '10px', border: '1px solid #0ff' }}>Year</th>
              <th style={{ padding: '10px', border: '1px solid #0ff' }}>Distribution Amount</th>
              <th style={{ padding: '10px', border: '1px solid #0ff' }}>Tax Impact</th>
            </tr>
          </thead>
          <tbody>
            {yearByYearSchedule.map((item, index) => (
              <tr key={index} style={{ backgroundColor: index % 2 === 0 ? '#444' : '#555' }}>
                <td style={{ padding: '10px', border: '1px solid #0ff' }}>{item.year}</td>
                <td style={{ padding: '10px', border: '1px solid #0ff' }}>${item.distributionAmount.toFixed(2)}</td>
                <td style={{ padding: '10px', border: '1px solid #0ff' }}>${item.taxImpact.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table></div>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{verticalAlign: 'middle', color: '#0ff'}}>Roth Conversion Before Inheritance Strategy <Percent size={24} /></h2>
        <p>Consider converting traditional IRA to Roth IRA before inheritance to avoid taxes on distributions. This strategy involves paying taxes upfront but allows tax-free growth for beneficiaries.</p>
        <p>Benefits: <ul style={{listStyle: 'none', color: '#0ff'}}><li><ArrowRight size={18} /> Tax-free withdrawals for beneficiaries.</li><li><DollarSign size={18} /> Potential to reduce overall tax liability under the 10-year rule.</li></ul></p>
        <p>Caution: Ensure you have funds to cover the conversion taxes without dipping into the IRA.</p>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{verticalAlign: 'middle', color: '#0ff'}}>10-Year Distribution Comparison Chart <AreaChart size={24} /></h2>
        <p>This chart compares pre-SECURE stretch vs SECURE Act 10-year rule using sample data.</p>
        <ResponsiveContainer width="100%" height={400}>
          <AreaChart data={sampleDataForChart}>
            <XAxis dataKey="name" stroke="#0ff" />
            <YAxis stroke="#ffbf00" />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="preSecure" stroke="#0ff" fill="#0ff" name="Pre-SECURE" />
            <Area type="monotone" dataKey="secureAct" stroke="#ffbf00" fill="#ffbf00" name="SECURE Act" />
          </AreaChart>
        </ResponsiveContainer>
      </section>

      <section>
        <h2 style={{verticalAlign: 'middle', color: '#0ff'}}>Compliance Information <AlertTriangle size={24} /></h2>
        <p>Ensure compliance with:</p>
        <ul style={{ listStyle: 'none' }}>
          <li><CheckCircle2 size={18} style={{ color: '#0ff' }} /> SECURE Act 2019: Mandates 10-year rule for most beneficiaries.</li>
          <li><Shield size={18} style={{ color: '#ffbf00' }} /> IRC 401(a)(9) RMD Rules: Required minimum distributions must be followed.</li>
          <li><Users size={18} style={{ color: '#0ff' }} /> Section 402(c) Rollover: Allows certain rollovers for eligible beneficiaries.</li>
          <li><Scale size={18} style={{ color: '#ffbf00' }} /> Prop. Reg. 1.401(a)(9)-4: Annual RMD requirements for inherited IRAs.</li>
        </ul>
        <p>Consult a tax professional for personalized advice.</p>
      </section>
      <PageInsights section="beneficiary-i-r-a-planner" />
    </div>
  );
};

export default BeneficiaryIRAPlanner;
