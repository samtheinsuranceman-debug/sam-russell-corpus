// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Heart, DollarSign, TrendingUp, Target, Calendar, Percent, ArrowRight, Shield, CheckCircle2, AlertTriangle, Circle, Gift } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, BarChart, Bar, ComposedChart, Line, PieChart, Pie, Cell } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

const CharitableRemainderUniTrust = () => {
  const [payoutRate, setPayoutRate] = useState(5); // Initial payout rate in percentage
  const [initialAmount, setInitialAmount] = useState(1000000); // Initial trust amount in dollars
  const [years, setYears] = useSharedField("projectionYears", 50); // Projection years
  const [nimcrut, setNimcrut] = useState(false); // Toggle for NIMCRUT vs Standard
  const [assetType, setAssetType] = useState('stock'); // For flip CRUT or appreciated stock
  const [rate7520, setRate7520] = useState(2.0); // 7520 rate in percentage
  const [taxCharacter, setTaxCharacter] = useState('ordinary'); // For 4-tier system

  // Sample data for 50-year projection
  const generateProjectionData = useMemo(() => {
    const data = [];
    let trustValue = initialAmount;
    const annualReturn = 0.05; // Assumed 5% annual return
    for (let year = 0; year <= years; year++) {
      const income = trustValue * (payoutRate / 100);
      trustValue = trustValue * (1 + annualReturn) - income;
      data.push({ year, income: income, trustValue: trustValue > 0 ? trustValue : 0 });
    }
    return data;
  }, [payoutRate, initialAmount, years]);

  // NIMCRUT vs Standard CRUT comparison data
  const comparisonData = [
    { type: 'NIMCRUT', feature: 'Net Income Makeup', value: 'Yes', benefit: 'Allows catching up on payments' },
    { type: 'NIMCRUT', feature: 'Payout Flexibility', value: 'Higher', benefit: 'Based on net income' },
    { type: 'Standard CRUT', feature: 'Net Income Makeup', value: 'No', benefit: 'Fixed payout' },
    { type: 'Standard CRUT', feature: 'Payout Flexibility', value: 'Lower', benefit: 'Fixed unitrust amount' },
  ];

  // 7520 rate impact calculation
  const calculateCharitableDeduction = useMemo(() => {
    const factor = 1 / ((1 + rate7520 / 100) ** (years / 1)); // Simplified annuity factor
    return initialAmount * factor * (payoutRate / 100);
  }, [rate7520, initialAmount, payoutRate, years]);

  // Income tax character distribution (simplified 4-tier)
  const taxTiers = ['Ordinary Income', 'Capital Gains', 'Tax-Exempt', 'Corpus'];
  const tierPercentages = [40, 30, 20, 10]; // Example percentages

  // Pie chart data for tax character
  const pieData = taxTiers.map((tier, index) => ({ name: tier, value: tierPercentages[index] }));

  // Colors for dark theme with purple/gold accents
  const darkThemeStyles = {
    backgroundColor: '#1a1a2e', // Dark purple
    color: '#f0e6f7', // Light purple
    accentColor: '#ffd700', // Gold
  };

  return (
    <div style={{ backgroundColor: darkThemeStyles.backgroundColor, color: darkThemeStyles.color, padding: '20px', minHeight: '100vh' }}>
      <h1 style={{ color: darkThemeStyles.accentColor }}>Charitable Remainder UniTrust (CRUT) Advanced Planning</h1>
      <Heart style={{ color: darkThemeStyles.accentColor }} /> <p>Optimize your CRUT for maximum benefits.</p>

      {/* Payout Rate Optimizer Section */}
      <section style={{ marginBottom: '40px' }}>
        <h2><Percent style={{ color: darkThemeStyles.accentColor }} /> CRUT Payout Rate Optimizer (5% - 50% Range)</h2>
        <p>Adjust the payout rate to optimize income and charitable benefits.</p>
        <input
          type="range"
          min="5"
          max="50"
          value={payoutRate}
          onChange={(e) => setPayoutRate(parseInt(e.target.value))}
          style={{ accentColor: darkThemeStyles.accentColor }}
        />
        <p>Current Payout Rate: {payoutRate}%</p>
        <p>Optimized Annual Income: ${generateProjectionData[1].income.toFixed(2)}</p>
      </section>

      {/* NIMCRUT vs Standard CRUT Comparison */}
      <section style={{ marginBottom: '40px' }}>
        <h2><TrendingUp style={{ color: darkThemeStyles.accentColor }} /> NIMCRUT vs Standard CRUT Comparison</h2>
        <p>Compare features for better decision-making.</p>
        <div className="overflow-x-auto"><table style={{ width: '100%', border: '1px solid #ffd700' }}>
          <thead>
            <tr>
              <th>Type</th>
              <th>Feature</th>
              <th>Value</th>
              <th>Benefit</th>
            </tr>
          </thead>
          <tbody>
            {comparisonData.map((item, index) => (
              <tr key={index} style={{ borderBottom: '1px solid #ffd700' }}>
                <td>{item.type}</td>
                <td>{item.feature}</td>
                <td>{item.value}</td>
                <td>{item.benefit}</td>
              </tr>
            ))}
          </tbody>
        </table></div>
        <button onClick={() => setNimcrut(!nimcrut)} style={{ backgroundColor: darkThemeStyles.accentColor, color: darkThemeStyles.backgroundColor }}>
          Toggle to {nimcrut ? 'Standard' : 'NIMCRUT'}
        </button>
      </section>

      {/* Flip CRUT for Illiquid Assets */}
      <section style={{ marginBottom: '40px' }}>
        <h2><ArrowRight style={{ color: darkThemeStyles.accentColor }} /> Flip CRUT for Illiquid Assets</h2>
        <p>Utilize Flip CRUT to handle illiquid assets effectively.</p>
        <select onChange={(e) => setAssetType(e.target.value)} style={{ backgroundColor: darkThemeStyles.backgroundColor, color: darkThemeStyles.color }}>
          <option value="stock">Appreciated Stock</option>
          <option value="realestate">Real Estate</option>
        </select>
        <p>{assetType === 'stock' ? 'Avoid capital gains with appreciated stock.' : 'Convert illiquid assets over time.'}</p>
      </section>

      {/* CRUT with Appreciated Stock */}
      <section style={{ marginBottom: '40px' }}>
        <h2><DollarSign style={{ color: darkThemeStyles.accentColor }} /> CRUT with Appreciated Stock</h2>
        <p>Avoid capital gains taxes by donating appreciated assets.</p>
        <p>Potential Savings: Up to 20% on gains.</p>
      </section>

      {/* 7520 Rate Impact on Charitable Deduction */}
      <section style={{ marginBottom: '40px' }}>
        <h2><Target style={{ color: darkThemeStyles.accentColor }} /> 7520 Rate Impact on Charitable Deduction</h2>
        <p>Current 7520 Rate: {rate7520}%</p>
        <input
          type="number"
          value={rate7520}
          onChange={(e) => setRate7520(parseFloat(e.target.value))}
          placeholder="Enter 7520 Rate"
          style={{ backgroundColor: darkThemeStyles.backgroundColor, color: darkThemeStyles.color }}
        />
        <p>Estimated Charitable Deduction: ${calculateCharitableDeduction.toFixed(2)}</p>
      </section>

      {/* CRUT Income Tax Character */}
      <section style={{ marginBottom: '40px' }}>
        <h2><Shield style={{ color: darkThemeStyles.accentColor }} /> CRUT Income Tax Character (4-Tier System)</h2>
        <p>The 4-tier system includes: Ordinary, Capital Gains, Tax-Exempt, and Corpus.</p>
        <select onChange={(e) => setTaxCharacter(e.target.value)} style={{ backgroundColor: darkThemeStyles.backgroundColor, color: darkThemeStyles.color }}>
          {taxTiers.map((tier) => (
            <option key={tier} value={tier.toLowerCase()}>{tier}</option>
          ))}
        </select>
        <p>Selected Tier: {taxCharacter}</p>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} fill="#8884d8" label>
              {pieData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#ffd700' : '#ba55d3'} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </section>

      {/* Wealth Replacement with ILIT */}
      <section style={{ marginBottom: '40px' }}>
        <h2><Gift style={{ color: darkThemeStyles.accentColor }} /> Wealth Replacement with ILIT</h2>
        <p>Use Irrevocable Life Insurance Trust (ILIT) to replace wealth for heirs.</p>
        <p>Benefits: Tax-free death benefit and estate tax avoidance.</p>
      </section>

      {/* 50-Year CRUT Income and Remainder Projection */}
      <section style={{ marginBottom: '40px' }}>
        <h2><Calendar style={{ color: darkThemeStyles.accentColor }} /> 50-Year CRUT Income and Remainder Projection</h2>
        <input
          type="number"
          value={years}
          onChange={(e) => setYears(parseInt(e.target.value))}
          placeholder="Years (up to 50)"
          style={{ backgroundColor: darkThemeStyles.backgroundColor, color: darkThemeStyles.color }}
        />
        <ResponsiveContainer width="100%" height={400}>
          <ComposedChart data={generateProjectionData}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="income" fill="#ba55d3" stroke="#ffd700" />
            <Line type="monotone" dataKey="trustValue" stroke="#ffd700" />
            <Bar dataKey="income" fill="#8884d8" />
          </ComposedChart>
        </ResponsiveContainer>
      </section>

      {/* Compliance Section */}
      <section>
        <h2><CheckCircle2 style={{ color: darkThemeStyles.accentColor }} /> Compliance and Rules</h2>
        <ul style={{ listStyle: 'none' }}>
          <li><AlertTriangle style={{ color: '#ff4500' }} /> IRC 664 CRT Rules: Governs Charitable Remainder Trusts.</li>
          <li><AlertTriangle style={{ color: '#ff4500' }} /> Section 7520 Valuation Rate: Used for annuity calculations.</li>
          <li><AlertTriangle style={{ color: '#ff4500' }} /> Section 170 Charitable Deduction: Allows income tax deductions.</li>
          <li><AlertTriangle style={{ color: '#ff4500' }} /> Reg. 1.664-1 through 1.664-4: Detailed regulations for CRTs.</li>
          <li><AlertTriangle style={{ color: '#ff4500' }} /> Section 2055 Estate Tax Deduction: For estate planning benefits.</li>
        </ul>
        <p>Ensure all CRUT setups comply with these IRS rules to avoid penalties.</p>
      </section>

      {/* Additional Charts for Depth */}
      <section>
        <h3><PieIcon style={{ color: darkThemeStyles.accentColor }} /> Additional Projections</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={generateProjectionData.slice(0, 10)}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="income" fill="#ffd700" />
          </BarChart>
        </ResponsiveContainer>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={generateProjectionData}>
            <Area type="monotone" dataKey="trustValue" fill="#ba55d3" stroke="#ffd700" />
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
          </AreaChart>
        </ResponsiveContainer>
      </section>
      <PageInsights section="charitable-remainder-uni-trust" />
    </div>
  );
};

export default CharitableRemainderUniTrust;
