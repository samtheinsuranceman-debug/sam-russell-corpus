// @ts-nocheck

import { useState, useMemo } from "react";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Circle, CalculatorIcon} from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function EntityComparisonCalc() {
  const autoFill = useCalculatorAutoFill("entity-comparison");
  const { reportResult } = useCalcResults();
  const [annualProfit, setAnnualProfit] = useState(100000);
  const [corporateTaxRate, setCorporateTaxRate] = useState(21);
  const [individualTaxRate, setIndividualTaxRate] = useState(24);
  const [dividendTaxRate, setDividendTaxRate] = useState(15);

  const calculations = useMemo(() => {
    const sCorpNet = annualProfit * (1 - individualTaxRate / 100);
    const llcNet = annualProfit * (1 - individualTaxRate / 100);  // Assuming similar pass-through
    const cCorpAfterCorpTax = annualProfit * (1 - corporateTaxRate / 100);
    const cCorpNet = cCorpAfterCorpTax * (1 - dividendTaxRate / 100);
    const iulAdvantageSavings = (sCorpNet - cCorpNet) * 0.1;  // Hypothetical 10% additional savings with IUL

    return {
      sCorpNet,
      llcNet,
      cCorpNet,
      iulAdvantageSavings,
    };
  }, [annualProfit, corporateTaxRate, individualTaxRate, dividendTaxRate]);
  const projectionData = useMemo(() => {
    const d = [];
    let opt = 100000, base = 100000, taxSav = 0;
    for (let yr = 0; yr <= 50; yr++) {
      opt *= 1.075;
      base *= 1.05;
      taxSav += (opt - base) * 0.08;
      d.push({ year: yr, optimized: Math.round(opt), baseline: Math.round(base), taxSavings: Math.round(taxSav), netBenefit: Math.round(opt - base + taxSav) });
    }
    return d;
  }, []);


  return (
    <AppShell
      className="bg-[#0a0f1a] text-white min-h-screen"
      header={
        <div className="flex items-center p-4 bg-[#0d1526]">
          <CalculatorIcon className="mr-2" />
          <h1 className="text-xl font-bold">Entity Comparison Calculator</h1>
        </div>
      }
    >
      <div className="p-6">
        <Card className="bg-[#0d1526] mb-6">
          <CardHeader>
            <CardTitle className="text-emerald-400">Input Parameters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label>Annual Profit</Label>
                <div className="flex items-center space-x-2">
                  <Slider
                    min={50000}
                    max={500000}
                    step={10000}
                    value={[annualProfit]}
                    onValueChange={(value) => setAnnualProfit(value[0])}
                    className="w-full"
                  />
                  <Input
                    type="number"
                    value={annualProfit}
                    onChange={(e) => setAnnualProfit(Number(e.target.value))}
                    className="w-32"
                  />
                </div>
              </div>
              <div>
                <Label>Corporate Tax Rate (%)</Label>
                <div className="flex items-center space-x-2">
                  <Slider
                    min={15}
                    max={35}
                    step={1}
                    value={[corporateTaxRate]}
                    onValueChange={(value) => setCorporateTaxRate(value[0])}
                    className="w-full"
                  />
                  <Input
                    type="number"
                    value={corporateTaxRate}
                    onChange={(e) => setCorporateTaxRate(Number(e.target.value))}
                    className="w-32"
                  />
                </div>
              </div>
              <div>
                <Label>Individual Tax Rate (%)</Label>
                <div className="flex items-center space-x-2">
                  <Slider
                    min={10}
                    max={40}
                    step={1}
                    value={[individualTaxRate]}
                    onValueChange={(value) => setIndividualTaxRate(value[0])}
                    className="w-full"
                  />
                  <Input
                    type="number"
                    value={individualTaxRate}
                    onChange={(e) => setIndividualTaxRate(Number(e.target.value))}
                    className="w-32"
                  />
                </div>
              </div>
              <div>
                <Label>Dividend Tax Rate (%)</Label>
                <div className="flex items-center space-x-2">
                  <Slider
                    min={0}
                    max={25}
                    step={1}
                    value={[dividendTaxRate]}
                    onValueChange={(value) => setDividendTaxRate(value[0])}
                    className="w-full"
                  />
                  <Input
                    type="number"
                    value={dividendTaxRate}
                    onChange={(e) => setDividendTaxRate(Number(e.target.value))}
                    className="w-32"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />

        
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "optimized", label: "Optimized Strategy", color: "#10b981" }, { key: "baseline", label: "Baseline (No Action)", color: "#ef4444" }, { key: "taxSavings", label: "Cumulative Tax Savings", color: "#06b6d4" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card className="bg-[#0d1526]">
            <CardHeader>
              <CardTitle>S-Corp Net After Tax</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-emerald-400">
                {formatDollars(calculations.sCorpNet)}
              </p>
            </CardContent>
          </Card>
          <Card className="bg-[#0d1526]">
            <CardHeader>
              <CardTitle>LLC Net After Tax</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-emerald-400">
                {formatDollars(calculations.llcNet)}
              </p>
            </CardContent>
          </Card>
          <Card className="bg-[#0d1526]">
            <CardHeader>
              <CardTitle>C-Corp Net After Tax</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-emerald-400">
                {formatDollars(calculations.cCorpNet)}
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-[#0d1526] mb-6">
          <CardHeader>
            <CardTitle>IUL Advantage</CardTitle>
          </CardHeader>
          <CardContent>
            <p>
              IUL provides tax-free growth, potentially saving you an additional{" "}
              {formatDollars(calculations.iulAdvantageSavings)} in taxes compared to traditional entities like C-Corp. This advantage allows for greater wealth accumulation through tax-free withdrawals.
            </p>
          </CardContent>
        </Card>

        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-500 hover:bg-emerald-600"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("entity-comparison", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-entity-comparison");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="S-Corp vs LLC vs C-Corp Tax Comparison"
            calculatorRoute="entity-comparison"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="entity-comparison-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/entity-comparison" />
</div>
    </AppShell>
  );
}