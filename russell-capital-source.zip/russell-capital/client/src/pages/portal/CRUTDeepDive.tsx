// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Heart, DollarSign, TrendingUp, Shield, CheckCircle2, AlertTriangle, Calendar, Target, Percent, ArrowRight, Scale, Gift } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, BarChart, Bar, ComposedChart, Line, PieChart, Pie, Cell } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

const CRUTDeepDive = () => {
  const [selectedTrust, setSelectedTrust] = useState('CRUT'); // State for trust comparison toggle
  const [unitrustPercentage, setUnitrustPercentage] = useState(5); // State for unitrust percentage slider (5-50%)
  const [initialAmount, setInitialAmount] = useState(1000000); // State for initial trust amount
  const [rate7520, setRate7520] = useState(2.0); // State for 7520 rate
  const [age, setAge] = useSharedField("currentAge", 65); // State for user age in projections
  const [incomeTaxRate, setIncomeTaxRate] = useState(24); // State for income tax rate in calculator

  // Dummy calculation for charitable deduction based on simplified formula
  const charitableDeduction = useMemo(() => {
    const factor = (unitrustPercentage / 100) * (rate7520 / 100);
    return initialAmount * (1 - factor); // Placeholder: Actual IRS formula is complex
  }, [initialAmount, unitrustPercentage, rate7520]);

  // Dummy data for 20-year income stream projection
  const incomeData = useMemo(() => {
    return Array.from({ length: 20 }, (_, i) => ({
      year: i + 1,
      income: initialAmount * (unitrustPercentage / 100) * (1 + 0.03 * i), // Simulated growth at 3% per year
    }));
  }, [initialAmount, unitrustPercentage]);

  // Dummy data for remainder interest comparison (PieChart)
  const remainderData = [
    { name: 'Charity', value: 60 },
    { name: 'Heirs', value: 40 },
  ];

  // Dummy data for NIMCRUT flip strategy (BarChart)
  const nimcrutData = [
    { year: 1, netIncome: 50000, makeup: 10000 },
    { year: 2, netIncome: 55000, makeup: 8000 },
    { year: 3, netIncome: 60000, makeup: 5000 },
    // ... more data to extend lines
    { year: 4, netIncome: 65000, makeup: 2000 },
    { year: 5, netIncome: 70000, makeup: 0 },
    { year: 6, netIncome: 75000, makeup: 0 },
    { year: 7, netIncome: 80000, makeup: 0 },
    { year: 8, netIncome: 85000, makeup: 0 },
    { year: 9, netIncome: 90000, makeup: 0 },
    { year: 10, netIncome: 95000, makeup: 0 },
  ];

  // Colors for charts with rose/gold accents
  const COLORS = ['#e11d48', '#fbbf24']; // Rose and Gold

  return (
    <div style={{ backgroundColor: '#1a1a2e', color: '#f0f0f0', padding: '40px', fontFamily: 'Arial, sans-serif' }}> {/* Dark theme base */}
      <h1 style={{ color: '#e11d48', textAlign: 'center', marginBottom: '30px' }}> {/* Rose accent for title */}
        Charitable Remainder Unitrust (CRUT) Deep Analysis
      </h1>
      
      {/* Comparison Section with Toggle */}
      <div style={{ marginBottom: '40px', border: '1px solid #fbbf24', padding: '20px', borderRadius: '8px' }}> {/* Gold accent border */}
        <h2 style={{ color: '#fbbf24' }}>CRUT vs CRAT vs NIMCRUT Comparison {/* Gold accent for header */} 
          <Heart size={24} style={{ color: '#e11d48', marginLeft: '10px' }} /> {/* Rose accent icon */}
        </h2>
        <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
          <button 
            onClick={() => setSelectedTrust('CRUT')} 
            style={{ backgroundColor: selectedTrust === 'CRUT' ? '#e11d48' : '#fbbf24', color: '#1a1a2e', padding: '10px' }}
          >
            CRUT
          </button>
          <button 
            onClick={() => setSelectedTrust('CRAT')} 
            style={{ backgroundColor: selectedTrust === 'CRAT' ? '#e11d48' : '#fbbf24', color: '#1a1a2e', padding: '10px' }}
          >
            CRAT
          </button>
          <button 
            onClick={() => setSelectedTrust('NIMCRUT')} 
            style={{ backgroundColor: selectedTrust === 'NIMCRUT' ? '#e11d48' : '#fbbf24', color: '#1a1a2e', padding: '10px' }}
          >
            NIMCRUT
          </button>
        </div>
        {selectedTrust === 'CRUT' && (
          <div>
            <p>CRUT provides a variable income based on a fixed percentage of the trust's annual value. <TrendingUp size={20} style={{color: '#e11d48'}} /> Advantages: Potential growth. <AlertTriangle size={20} /> Disadvantages: Income fluctuates.</p>
          </div>
        )}
        {selectedTrust === 'CRAT' && (
          <div>
            <p>CRAT offers a fixed annuity payment. <DollarSign size={20} style={{color: '#e11d48'}} /> Advantages: Stable income. <Shield size={20} /> Disadvantages: No makeup provisions.</p>
          </div>
        )}
        {selectedTrust === 'NIMCRUT' && (
          <div>
            <p>NIMCRUT allows for net income with makeup provisions. <Gift size={20} style={{color: '#e11d48'}} /> Advantages: Defers income. <Scale size={20} /> Disadvantages: Complex compliance.</p>
          </div>
        )}
      </div>

      {/* Unitrust Percentage Slider */}
      <div style={{ marginBottom: '40px', border: '1px solid #e11d48', padding: '20px', borderRadius: '8px' }}> {/* Rose accent border */}
        <h2 style={{color: '#e11d48', marginLeft: '10px'}}>Unitrust Percentage Slider (5-50%) <Percent size={24} /></h2>
        <input 
          type="range" 
          min="5" 
          max="50" 
          value={unitrustPercentage} 
          onChange={(e) => setUnitrustPercentage(Number(e.target.value))} 
          style={{ width: '100%', accentColor: '#fbbf24' }} // Gold accent for slider
        />
        <p style={{ color: '#e11d48' }}>Selected: {unitrustPercentage}%</p>
      </div>

      {/* 7520 Rate Impact on Charitable Deduction */}
      <div style={{ marginBottom: '40px', border: '1px solid #fbbf24', padding: '20px', borderRadius: '8px' }}>
        <h2 style={{color: '#fbbf24', marginLeft: '10px'}}>7520 Rate Impact <Target size={24} /></h2>
        <p>The 7520 rate affects the present value of the charitable deduction. Current rate: {rate7520}%</p>
        <input 
          type="number" 
          placeholder="7520 Rate (%)" 
          value={rate7520} 
          onChange={(e) => setRate7520(Number(e.target.value))} 
          style={{ backgroundColor: '#2a2a3e', color: '#f0f0f0', padding: '10px' }}
        />
        <p style={{ color: '#fbbf24' }}>Estimated Charitable Deduction: ${charitableDeduction.toFixed(2)}</p>
      </div>

      {/* Income Tax Deduction Calculator */}
      <div style={{ marginBottom: '40px', border: '1px solid #e11d48', padding: '20px', borderRadius: '8px' }}>
        <h2 style={{color: '#e11d48', marginLeft: '10px'}}>Income Tax Deduction Calculator <CheckCircle2 size={24} /></h2>
        <input 
          type="number" 
          placeholder="Initial Amount" 
          value={initialAmount} 
          onChange={(e) => setInitialAmount(Number(e.target.value))} 
          style={{ backgroundColor: '#2a2a3e', color: '#f0f0f0', padding: '10px', marginBottom: '10px' }}
        />
        <input 
          type="number" 
          placeholder="Income Tax Rate (%)" 
          value={incomeTaxRate} 
          onChange={(e) => setIncomeTaxRate(Number(e.target.value))} 
          style={{ backgroundColor: '#2a2a3e', color: '#f0f0f0', padding: '10px', marginBottom: '10px' }}
        />
        <p style={{ color: '#fbbf24' }}>Deduction after tax: ${(charitableDeduction * (1 - incomeTaxRate / 100)).toFixed(2)}</p> {/* Simplified calculation */}
      </div>

      {/* 20-Year Income Stream Projection (AreaChart) */}
      <div style={{ marginBottom: '40px', border: '1px solid #fbbf24', padding: '20px', borderRadius: '8px' }}>
        <h2 style={{color: '#fbbf24', marginLeft: '10px'}}>20-Year Income Stream Projection <Calendar size={24} /></h2>
        <ResponsiveContainer width="100%" height={400}>
          <AreaChart data={incomeData}>
            <Area type="monotone" dataKey="income" stroke="#fbbf24" fill="#e11d48" /> {/* Gold stroke, Rose fill */}
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Remainder Interest to Charity vs Heirs (PieChart) */}
      <div style={{ marginBottom: '40px', border: '1px solid #e11d48', padding: '20px', borderRadius: '8px' }}>
        <h2 style={{color: '#e11d48', marginLeft: '10px'}}>Remainder Interest: Charity vs Heirs <ArrowRight size={24} /></h2>
        <ResponsiveContainer width="100%" height={400}>
          <PieChart>
            <Pie data={remainderData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={150} fill="#fbbf24" label>
              {remainderData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
        <p>Based on projections, 60% to charity and 40% to heirs.</p>
      </div>

      {/* Net Income with Makeup CRUT (NIMCRUT) Flip Strategy (BarChart) */}
      <div style={{ marginBottom: '40px', border: '1px solid #fbbf24', padding: '20px', borderRadius: '8px' }}>
        <h2 style={{color: '#fbbf24', marginLeft: '10px'}}>NIMCRUT Flip Strategy <Gift size={24} /></h2>
        <p>The flip strategy allows for net income with makeup, potentially increasing long-term benefits.</p>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={nimcrutData}>
            <Bar dataKey="netIncome" fill="#e11d48" /> {/* Rose bar */}
            <Bar dataKey="makeup" fill="#fbbf24" /> {/* Gold bar */}
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Compliance Section */}
      <div style={{ marginBottom: '40px', border: '1px solid #e11d48', padding: '20px', borderRadius: '8px' }}>
        <h2 style={{color: '#e11d48', marginLeft: '10px'}}>Compliance Requirements <Shield size={24} /></h2>
        <p><strong>IRC 664:</strong> Governs the taxation of charitable remainder trusts, ensuring proper distribution rules.</p>
        <p><strong>Section 170:</strong> Allows for charitable deductions up to 30% of AGI for CRTs, with carryforward options.</p>
        <p><strong>Section 7520:</strong> Used for valuing annuities, life estates, and remainders; impacts deduction calculations.</p>
        <p><strong>Rev. Rul. 77-374:</strong> Provides guidance on the valuation of charitable interests in trusts.</p>
        <ul>
          <li>Ensure annual valuations and distributions per IRC rules.</li>
          <li>Avoid prohibited transactions to maintain tax-exempt status.</li>
          <li>Consult a tax professional for compliance.</li>
        </ul>
      </div>
      <PageInsights section="c-r-u-t-deep-dive" />
    </div>
  );
};

export default CRUTDeepDive;
