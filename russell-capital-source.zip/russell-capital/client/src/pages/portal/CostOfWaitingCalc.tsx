// @ts-nocheck

import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calculator } from 'lucide-react';
import { toast } from "sonner";
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function CostOfWaitingCalc() {
  const autoFill = useCalculatorAutoFill("cost-of-waiting");
  const { reportResult } = useCalcResults();
  const [age, setAge] = useSharedField("currentAge", 30);
  const [retirementAge, setRetirementAge] = useSharedField("retirementAge", 65);
  const [annualInvestment, setAnnualInvestment] = useState(5000);
  const [annualReturn, setAnnualReturn] = useSharedField("growthRate", 0.07);
  const [inflationRate, setInflationRate] = useState(0.03);
  const [yearsToWait, setYearsToWait] = useState(5);

  const calculations = useMemo(() => {
    const yearsInvestingNow = retirementAge - age;
    const yearsInvestingWaited = yearsInvestingNow - yearsToWait;
    if (yearsInvestingNow <= 0 || yearsInvestingWaited <= 0) {
      return { FV_now: 0, FV_waited: 0, costOfWaiting: 0 };
    }
    const FV_now = annualInvestment * ((Math.pow(1 + annualReturn, yearsInvestingNow) - 1) / annualReturn);
    const FV_waited = annualInvestment * ((Math.pow(1 + annualReturn, yearsInvestingWaited) - 1) / annualReturn);
    const costOfWaiting = FV_now - FV_waited;
    return { FV_now, FV_waited, costOfWaiting };
  }, [age, retirementAge, annualInvestment, annualReturn, yearsToWait]);
  const projectionData = useMemo(() => {
    const d = [];
    const income = typeof annualIncome !== 'undefined' ? annualIncome : 300000;
    const saveRate = 0.20;
    let nw = 0, cumSave = 0, debtElim = 0, emFund = 0;
    for (let yr = 0; yr <= 50; yr++) {
      const annualSave = income * saveRate * Math.pow(1.03, yr);
      cumSave += annualSave;
      debtElim += Math.min(annualSave * 0.3, 25000 * Math.max(0, 1 - yr / 15));
      emFund = Math.min(income * 0.5, emFund + annualSave * 0.1);
      nw = cumSave * 1.06 + debtElim;
      d.push({ year: yr, netWorth: Math.round(nw), cumulativeSavings: Math.round(cumSave), debtReduction: Math.round(debtElim), emergencyFund: Math.round(emFund) });
    }
    return d;
  }, []);


  return (
    <AppShell>
      <main className="bg-[#0a0f1a] min-h-screen p-6 text-white">
        <div className="flex flex-col items-center">
          <Calculator className="mb-4 text-emerald-400" size={48} />
          <h1 className="text-3xl font-bold mb-6">Cost of Waiting to Invest Calculator</h1>
          <p className="text-[#7a95b8] mb-8 text-center max-w-md">
            Calculate the potential cost of delaying your investments and see how IUL can help with tax-free growth.
          </p>
          
          <Card className="bg-[#0d1526] w-full max-w-md mb-8">
            <CardHeader>
              <CardTitle className="text-emerald-400">Input Parameters</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Current Age</Label>
                <Input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="bg-slate-700"
                />
              </div>
              <div>
                <Label>Retirement Age</Label>
                <Input
                  type="number"
                  value={retirementAge}
                  onChange={(e) => setRetirementAge(Number(e.target.value))}
                  className="bg-slate-700"
                />
              </div>
              <div>
                <Label>Annual Investment Amount</Label>
                <Input
                  type="number"
                  value={annualInvestment}
                  onChange={(e) => setAnnualInvestment(Number(e.target.value))}
                  className="bg-slate-700"
                />
              </div>
              <div>
                <Label>Expected Annual Return (%)</Label>
                <Slider
                  min={0}
                  max={0.15}
                  step={0.01}
                  value={[annualReturn]}
                  onValueChange={(value) => setAnnualReturn(value[0])}
                />
                <div className="text-sm text-[#7a95b8] mt-2">{(annualReturn * 100).toFixed(2) + "%"}</div>
              </div>
              <div>
                <Label>Inflation Rate (%)</Label>
                <Slider
                  min={0}
                  max={0.10}
                  step={0.01}
                  value={[inflationRate]}
                  onValueChange={(value) => setInflationRate(value[0])}
                />
                <div className="text-sm text-[#7a95b8] mt-2">{(inflationRate * 100).toFixed(2) + "%"}</div>
              </div>
              <div>
                <Label>Years to Wait</Label>
                <Slider
                  min={0}
                  max={20}
                  step={1}
                  value={[yearsToWait]}
                  onValueChange={(value) => setYearsToWait(value[0])}
                />
                <div className="text-sm text-[#7a95b8] mt-2">{yearsToWait + " years"}</div>
              </div>
            </CardContent>
          </Card>
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />
          
          
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "netWorth", label: "Net Worth", color: "#10b981" }, { key: "cumulativeSavings", label: "Cumulative Savings", color: "#06b6d4" }, { key: "debtReduction", label: "Debt Eliminated", color: "#f59e0b" }, { key: "emergencyFund", label: "Emergency Fund", color: "#a855f7" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 w-full max-w-4xl">
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle>Future Value if Invested Now</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-emerald-400">
                  {formatDollars(calculations.FV_now)}
                </p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle>Future Value if Waited</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-emerald-400">
                  {formatDollars(calculations.FV_waited)}
                </p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle>Cost of Waiting</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-emerald-400">
                  {formatDollars(calculations.costOfWaiting)}
                </p>
              </CardContent>
            </Card>
          </div>
          
          <Card className="bg-[#0d1526] w-full max-w-md mb-8">
            <CardHeader>
              <CardTitle>IUL Advantage</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-[#7a95b8]">
                Indexed Universal Life (IUL) offers tax-free growth on your investments, which can minimize the cost of waiting by providing higher effective returns compared to traditional options.
              </p>
            </CardContent>
          </Card>
          
          <Button
            onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
            className="bg-emerald-500 hover:bg-emerald-600"
          >
            Send to AI Advisor
          </Button>
        

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("cost-of-waiting", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-cost-of-waiting");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Cost of Waiting to Invest Calculator"
            calculatorRoute="cost-of-waiting"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="cost-of-waiting-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/cost-of-waiting" />
</div>
      </main>
    </AppShell>
  );
}