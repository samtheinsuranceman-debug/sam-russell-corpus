// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Layers, DollarSign, TrendingUp, Target, Calendar, Percent, ArrowRight, Shield, CheckCircle2, AlertTriangle, BarChart3, Lock } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, AreaChart, Area, ComposedChart, Line } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

export default function BondLadderConstructor() {
  const [numBonds, setNumBonds] = useState(5); // Number of bonds in ladder
  const [maturitySpacing, setMaturitySpacing] = useState(5); // Years between maturities
  const [initialInvestment, setInitialInvestment] = useState(10000); // Starting amount per bond
  const [yieldCurveType, setYieldCurveType] = useState('normal'); // Yield curve: normal, inverted, flat
  const [creditQuality, setCreditQuality] = useState('AAA'); // Credit quality: AAA, AA, A, BBB
  const [bondType, setBondType] = useState('municipal'); // Bond type: municipal or corporate
  const [taxRate, setTaxRate] = useSharedField("currentTaxBracket", 25); // Tax rate in percentage
  const [callablePrice, setCallablePrice] = useState(105); // Callable bond price
  const [couponRate, setCouponRate] = useState(5); // Coupon rate in percentage
  const [yieldToMaturity, setYieldToMaturity] = useState(4); // Yield to maturity in percentage
  const [projectionYears, setProjectionYears] = useSharedField("projectionYears", 50); // Years for income projection

  // Generate bond ladder data
  const bondLadder = useMemo(() => {
    const ladder = [];
    for (let i = 1; i <= numBonds; i++) {
      ladder.push({
        bondNumber: i,
        maturity: i * maturitySpacing,
        amount: initialInvestment,
        yield: yieldToMaturity + (i * 0.5), // Simulated yield increase
      });
    }
    return ladder;
  }, [numBonds, maturitySpacing, initialInvestment, yieldToMaturity]);

  // Yield curve data based on type
  const yieldCurveData = useMemo(() => {
    const data = [];
    for (let year = 1; year <= 30; year++) {
      let yieldRate;
      if (yieldCurveType === 'normal') {
        yieldRate = 2 + (year * 0.5); // Increasing yield
      } else if (yieldCurveType === 'inverted') {
        yieldRate = 5 - (year * 0.2); // Decreasing yield
      } else {
        yieldRate = 3; // Flat yield
      }
      data.push({ year, yieldRate });
    }
    return data;
  }, [yieldCurveType]);

  // Duration and convexity calculation (simplified formulas)
  const calculateDuration = useMemo(() => {
    return (yieldToMaturity / (1 + (yieldToMaturity / 100))) * (1 / numBonds);
  }, [yieldToMaturity, numBonds]);

  const calculateConvexity = useMemo(() => {
    return (maturitySpacing * (maturitySpacing + 1)) / (2 * (1 + (yieldToMaturity / 100) ** 2));
  }, [maturitySpacing, yieldToMaturity]);

  // After-tax yield comparison
  const afterTaxYield = useMemo(() => {
    const municipalYield = couponRate; // Tax-exempt
    const corporateYield = couponRate * (1 - (taxRate / 100)); // After tax
    return { municipalYield, corporateYield };
  }, [couponRate, taxRate]);

  // Callable bond analysis
  const callableAnalysis = useMemo(() => {
    const callPremium = callablePrice - 100; // Assuming par is 100
    return callPremium > 0 ? 'Callable with premium' : 'Not callable';
  }, [callablePrice]);

  // 50-year income projection
  const incomeProjection = useMemo(() => {
    const projection = [];
    for (let year = 1; year <= projectionYears; year++) {
      const income = bondLadder.reduce((sum, bond) => sum + (bond.amount * (couponRate / 100)), 0);
      projection.push({ year, income });
    }
    return projection;
  }, [bondLadder, couponRate, projectionYears]);

  // Reinvestment risk analysis (simplified)
  const reinvestmentRisk = useMemo(() => {
    const riskLevel = yieldCurveType === 'inverted' ? 'High' : 'Low';
    return riskLevel;
  }, [yieldCurveType]);

  // Compliance checks
  const checkIRC103 = useMemo(() => creditQuality === 'AAA' && bondType === 'municipal', [creditQuality, bondType]);
  const checkSection1276 = useMemo(() => yieldToMaturity > couponRate, [yieldToMaturity, couponRate]);
  const checkSection171 = useMemo(() => initialInvestment > 100, [initialInvestment]); // Simplified
  const checkSection1278 = useMemo(() => maturitySpacing > 10, [maturitySpacing]);
  const checkDeMinimis = useMemo(() => (yieldToMaturity - couponRate) < 0.25, [yieldToMaturity, couponRate]);

  return (
    <div style={{ backgroundColor: '#1a202c', color: '#e2e8f0', minHeight: '100vh', padding: '20px' }}>
      <h1 style={{ color: '#60a5fa' }}>Bond Ladder Constructor</h1>
      
      {/* Bond Ladder Builder Section */}
      <div style={{ marginBottom: '20px' }}>
        <Layers style={{ color: '#60a5fa', marginRight: '10px' }} />
        <h2>Bond Ladder Builder</h2>
        <label>Number of Bonds: <input type="number" value={numBonds} onChange={e => setNumBonds(Number(e.target.value))} style={{ backgroundColor: '#2d3748', color: '#e2e8f0' }} /></label>
        <label>Maturity Spacing (1-30 years): <input type="number" min="1" max="30" value={maturitySpacing} onChange={e => setMaturitySpacing(Number(e.target.value))} style={{ backgroundColor: '#2d3748', color: '#e2e8f0' }} /></label>
        <label>Initial Investment: <input type="number" value={initialInvestment} onChange={e => setInitialInvestment(Number(e.target.value))} style={{ backgroundColor: '#2d3748', color: '#e2e8f0' }} /></label>
        <ul>
          {bondLadder.map((bond, index) => (
            <li key={index}>Bond {bond.bondNumber}: Maturity {bond.maturity} years, Amount ${bond.amount}</li>
          ))}
        </ul>
      </div>

      {/* Yield Curve Visualization */}
      <div style={{ marginBottom: '20px' }}>
        <TrendingUp style={{ color: '#60a5fa', marginRight: '10px' }} />
        <h2>Yield Curve Visualization</h2>
        <select value={yieldCurveType} onChange={e => setYieldCurveType(e.target.value)} style={{ backgroundColor: '#2d3748', color: '#e2e8f0' }}>
          <option value="normal">Normal</option>
          <option value="inverted">Inverted</option>
          <option value="flat">Flat</option>
        </select>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={yieldCurveData}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="yieldRate" stroke="#60a5fa" fill="#3182ce" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Duration and Convexity Calculator */}
      <div style={{ marginBottom: '20px' }}>
        <Target style={{ color: '#60a5fa', marginRight: '10px' }} />
        <h2>Duration and Convexity Calculator</h2>
        <p>Duration: {calculateDuration.toFixed(2)} years</p>
        <p>Convexity: {calculateConvexity.toFixed(2)}</p>
        <label>Yield to Maturity (%): <input type="number" value={yieldToMaturity} onChange={e => setYieldToMaturity(Number(e.target.value))} style={{ backgroundColor: '#2d3748', color: '#e2e8f0' }} /></label>
      </div>

      {/* Credit Quality Allocation */}
      <div style={{ marginBottom: '20px' }}>
        <Shield style={{ color: '#60a5fa', marginRight: '10px' }} />
        <h2>Credit Quality Allocation</h2>
        <select value={creditQuality} onChange={e => setCreditQuality(e.target.value)} style={{ backgroundColor: '#2d3748', color: '#e2e8f0' }}>
          <option value="AAA">AAA</option>
          <option value="AA">AA</option>
          <option value="A">A</option>
          <option value="BBB">BBB</option>
        </select>
        <p>Selected: {creditQuality}</p>
      </div>

      {/* Municipal vs Corporate After-Tax Yield Comparison */}
      <div style={{ marginBottom: '20px' }}>
        <Percent style={{ color: '#60a5fa', marginRight: '10px' }} />
        <h2>Municipal vs Corporate After-Tax Yield</h2>
        <label>Bond Type: <select value={bondType} onChange={e => setBondType(e.target.value)} style={{ backgroundColor: '#2d3748', color: '#e2e8f0' }}><option value="municipal">Municipal</option><option value="corporate">Corporate</option></select></label>
        <label>Tax Rate (%): <input type="number" value={taxRate} onChange={e => setTaxRate(Number(e.target.value))} style={{ backgroundColor: '#2d3748', color: '#e2e8f0' }} /></label>
        <p>Municipal After-Tax Yield: {afterTaxYield.municipalYield}%</p>
        <p>Corporate After-Tax Yield: {afterTaxYield.corporateYield.toFixed(2)}%</p>
        <ResponsiveContainer width="100%" height={300}><BarChart data={[afterTaxYield]}>
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="municipalYield" fill="#60a5fa" />
          <Bar dataKey="corporateYield" fill="#a0aec0" />
        </BarChart></ResponsiveContainer>
      </div>

      {/* Callable Bond Analysis */}
      <div style={{ marginBottom: '20px' }}>
        <ArrowRight style={{ color: '#60a5fa', marginRight: '10px' }} />
        <h2>Callable Bond Analysis</h2>
        <label>Callable Price: <input type="number" value={callablePrice} onChange={e => setCallablePrice(Number(e.target.value))} style={{ backgroundColor: '#2d3748', color: '#e2e8f0' }} /></label>
        <p>Analysis: {callableAnalysis}</p>
      </div>

      {/* 50-Year Income Projection */}
      <div style={{ marginBottom: '20px' }}>
        <Calendar style={{ color: '#60a5fa', marginRight: '10px' }} />
        <h2>50-Year Income Projection</h2>
        <ResponsiveContainer width="100%" height={300}>
          <ComposedChart data={incomeProjection}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="income" fill="#60a5fa" stroke="#3182ce" />
            <Line type="monotone" dataKey="income" stroke="#a0aec0" />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* Reinvestment Risk Analysis */}
      <div style={{ marginBottom: '20px' }}>
        <AlertTriangle style={{ color: '#60a5fa', marginRight: '10px' }} />
        <h2>Reinvestment Risk Analysis</h2>
        <p>Risk Level: {reinvestmentRisk}</p>
      </div>

      {/* Compliance Section */}
      <div>
        <Lock style={{ color: '#60a5fa', marginRight: '10px' }} />
        <h2>Compliance Checks</h2>
        <p>IRC 103 Municipal Exemption: {checkIRC103 ? <CheckCircle2 style={{color: 'red'}} /> : <AlertTriangle />} {checkIRC103 ? 'Compliant' : 'Not Compliant'}</p>
        <p>Section 1276 Market Discount: {checkSection1276 ? <CheckCircle2 style={{color: 'red'}} /> : <AlertTriangle />} {checkSection1276 ? 'Compliant' : 'Not Compliant'}</p>
        <p>Section 171 Bond Premium: {checkSection171 ? <CheckCircle2 style={{color: 'red'}} /> : <AlertTriangle />} {checkSection171 ? 'Compliant' : 'Not Compliant'}</p>
        <p>Section 1278 Market Discount Rules: {checkSection1278 ? <CheckCircle2 style={{color: 'red'}} /> : <AlertTriangle />} {checkSection1278 ? 'Compliant' : 'Not Compliant'}</p>
        <p>De Minimis Rule: {checkDeMinimis ? <CheckCircle2 style={{color: 'red'}} /> : <AlertTriangle />} {checkDeMinimis ? 'Compliant' : 'Not Compliant'}</p>
      </div>

      {/* Additional Charts for Visualization */}
      <div style={{ marginTop: '20px' }}>
        <BarChart3 style={{ color: '#60a5fa', marginRight: '10px' }} />
        <h2>Summary Chart</h2>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={bondLadder}>
            <XAxis dataKey="maturity" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="amount" fill="#60a5fa" />
            <Bar dataKey="yield" fill="#a0aec0" />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <PageInsights section="bond-ladder-constructor" />
    </div>
  );
}
