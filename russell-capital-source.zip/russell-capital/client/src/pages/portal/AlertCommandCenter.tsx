// @ts-nocheck
import React from 'react';
import { useOrganismContext } from "@/contexts/OrganismContext";
import { AlertCircle, AlertTriangle, Info, X } from 'lucide-react';
import { PageInsights } from "@/components/PageInsights";

interface Alert {
  id: string;
  type: string;
  message: string;
  severity: 'critical' | 'warning' | 'info';
  suggestedAction: string;
}

const AlertCommandCenter: React.FC = () => {
  const { alerts, overallRiskScore, isLoading, dismissAlert } = useOrganismContext();

  if (isLoading) {
    return <div className="flex justify-center items-center h-screen bg-[#0a0f1a] text-white">Loading...</div>;
  }

  const totalAlerts = alerts.length;
  const criticalCount = alerts.filter((a: Alert) => a.severity === 'critical').length;

  const groupedAlerts: { [key: string]: Alert[] } = {
    critical: alerts.filter((a: Alert) => a.severity === 'critical'),
    warning: alerts.filter((a: Alert) => a.severity === 'warning'),
    info: alerts.filter((a: Alert) => a.severity === 'info'),
  };

  return (
    <div className="bg-[#0a0f1a] min-h-screen p-4 text-white">
      <header className="mb-4">
        <h1 className="text-2xl font-bold">Alert Command Center</h1>
        <p className="text-lg">Total Alerts: {totalAlerts} | Critical: {criticalCount} | Risk Score: {overallRiskScore}</p>
      </header>
      
      <section>
        {['critical', 'warning', 'info'].map((severity) => (
          groupedAlerts[severity].length > 0 && (
            <div key={severity} className="mb-4">
              <h2 className="text-xl font-semibold capitalize">{severity}</h2>
              <div>
                {groupedAlerts[severity].map((alert: Alert) => (
                  <div key={alert.id} className="flex items-center justify-between p-2 border-b border-[#1e3a5f]">
                    <div className="flex items-center">
                      {alert.severity === 'critical' && <AlertCircle className="mr-2 text-red-500" />}
                      {alert.severity === 'warning' && <AlertTriangle className="mr-2 text-yellow-500" />}
                      {alert.severity === 'info' && <Info className="mr-2 text-blue-500" />}
                      <span>{alert.message}</span>
                    </div>
                    <div className="flex items-center">
                      <span className={`px-2 py-1 rounded mr-2 ${
                        alert.severity === 'critical' ? 'bg-red-500' :
                        alert.severity === 'warning' ? 'bg-yellow-500' :
                        'bg-blue-500'
                      }`}>{alert.severity}</span>
                      <button onClick={() => { /* Handle suggested action */ }} className="mr-2 bg-blue-600 px-2 py-1 rounded">
                        {alert.suggestedAction}
                      </button>
                      <button onClick={() => dismissAlert(alert.id)} className="text-[#7a95b8] hover:text-white">
                        <X />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )
        ))}
      </section>
      
      {totalAlerts === 0 && <p className="text-center text-[#7a95b8]">No alerts to display.</p>}
      <PageInsights section="alert-command-center" />
    </div>
  );
};

export default AlertCommandCenter;
