// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Users, DollarSign, TrendingUp, Target, Calendar, Percent, ArrowRight, Shield, CheckCircle2, AlertTriangle, Building2, Lock } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, AreaChart, Area, ComposedChart, Line } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

export default function ESOPAnalyzer() {
  const [companyValuation, setCompanyValuation] = useState(0);
  const [cashFlow, setCashFlow] = useState(0);
  const [debtCapacity, setDebtCapacity] = useState(0);
  const [sCorpVsCCorp, setSCorpVsCCorp] = useState('S-Corp');
  const [rolloverAmount, setRolloverAmount] = useState(0);
  const [repurchaseYears, setRepurchaseYears] = useState(5);
  const [employeeCount, setEmployeeCount] = useState(50);
  const [leveragedAmount, setLeveragedAmount] = useState(0);
  const [growthRate, setGrowthRate] = useSharedField("growthRate", 0.05);
  const [year, setYear] = useState(1);

  const feasibilityData = useMemo(() => {
    const feasibilityScore = (companyValuation * cashFlow) / (debtCapacity || 1);
    return {
      score: feasibilityScore,
      valuation: companyValuation,
      cashFlow,
      debtCapacity,
    };
  }, [companyValuation, cashFlow, debtCapacity]);

  const sCorpVsCCorpData = useMemo(() => {
    if (sCorpVsCCorp === 'S-Corp') {
      return {
        pros: ['Tax pass-through', 'No double taxation'],
        cons: ['Shareholder limits', 'Complex ESOP rules'],
      };
    } else {
      return {
        pros: ['Unlimited shareholders', 'Easier ESOP setup'],
        cons: ['Double taxation', 'Higher compliance costs'],
      };
    }
  }, [sCorpVsCCorp]);

  const rolloverTaxDeferral = useMemo(() => {
    const deferral = rolloverAmount * 0.15; // Simplified deferral calculation
    return deferral;
  }, [rolloverAmount]);

  const repurchaseProjections = useMemo(() => {
    const projections = Array.from({ length: repurchaseYears }, (_, i) => ({
      year: i + 1,
      obligation: (feasibilityData.valuation / employeeCount) * (1 + growthRate) ** i,
    }));
    return projections;
  }, [feasibilityData.valuation, employeeCount, growthRate, repurchaseYears]);

  const employeeBenefits = useMemo(() => {
    return repurchaseProjections.map((proj, index) => ({
      year: proj.year,
      benefitPerEmployee: proj.obligation / employeeCount,
    }));
  }, [repurchaseProjections, employeeCount]);

  const leveragedESOP = useMemo(() => {
    const structure = leveragedAmount * (1 + growthRate);
    return structure;
  }, [leveragedAmount, growthRate]);

  const esopVs401k = useMemo(() => {
    return {
      esop: 'Ownership and tax benefits',
      '401k': 'Immediate contributions, less ownership',
    };
  }, []);

  const fiftyYearGrowth = useMemo(() => {
    return Array.from({ length: 50 }, (_, i) => ({
      year: i + 1,
      value: companyValuation * (1 + growthRate) ** i,
    }));
  }, [companyValuation, growthRate]);

  const complianceData = {
    irc4975: 'ESOP must be for employees only',
    section1042: 'Rollover for qualified securities',
    section404: 'Deduction limits on contributions',
    section409p: 'Anti-abuse rules for ownership',
    erisa318: 'Adequate consideration for assets',
  };

  return (
    <div style={{ backgroundColor: '#1a1a2e', color: '#ffffff', minHeight: '100vh', padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1 style={{ color: '#00b4d8', textAlign: 'center' }}>ESOP Analyzer</h1>
      
      {/* ESOP Feasibility Calculator Section */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#f9bc60' }}><DollarSign size={24} /> ESOP Feasibility Calculator</h2>
        <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
          <input
            type="number"
            placeholder="Company Valuation"
            onChange={(e) => setCompanyValuation(Number(e.target.value))}
            style={{ padding: '10px', backgroundColor: '#16213e', color: '#fff', border: '1px solid #00b4d8' }}
          />
          <input
            type="number"
            placeholder="Cash Flow"
            onChange={(e) => setCashFlow(Number(e.target.value))}
            style={{ padding: '10px', backgroundColor: '#16213e', color: '#fff', border: '1px solid #00b4d8' }}
          />
          <input
            type="number"
            placeholder="Debt Capacity"
            onChange={(e) => setDebtCapacity(Number(e.target.value))}
            style={{ padding: '10px', backgroundColor: '#16213e', color: '#fff', border: '1px solid #00b4d8' }}
          />
        </div>
        <p>Feasibility Score: {feasibilityData.score.toFixed(2)}</p>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={[feasibilityData]}>
            <XAxis dataKey="valuation" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="cashFlow" fill="#00b4d8" />
            <Bar dataKey="debtCapacity" fill="#f9bc60" />
          </BarChart>
        </ResponsiveContainer>
      </section>

      {/* S-Corp vs C-Corp ESOP Comparison */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#f9bc60' }}><Building2 size={24} /> S-Corp vs C-Corp ESOP</h2>
        <select onChange={(e) => setSCorpVsCCorp(e.target.value)} style={{ padding: '10px', backgroundColor: '#16213e', color: '#fff' }}>
          <option value="S-Corp">S-Corp</option>
          <option value="C-Corp">C-Corp</option>
        </select>
        <ul style={{ color: '#00b4d8' }}>
          {sCorpVsCCorpData.pros.map((pro, index) => <li key={index}>{pro}</li>)}
        </ul>
        <ul style={{ color: '#f9bc60' }}>
          {sCorpVsCCorpData.cons.map((con, index) => <li key={index}>{con}</li>)}
        </ul>
      </section>

      {/* 1042 Rollover Tax Deferral */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#f9bc60' }}><Shield size={24} /> 1042 Rollover Tax Deferral</h2>
        <input
          type="number"
          placeholder="Rollover Amount"
          onChange={(e) => setRolloverAmount(Number(e.target.value))}
          style={{ padding: '10px', backgroundColor: '#16213e', color: '#fff', border: '1px solid #00b4d8' }}
        />
        <p>Deferred Tax: ${rolloverTaxDeferral.toFixed(2)}</p>
        <p>Details: Section 1042 allows deferral on qualified sales to ESOP.</p>
      </section>

      {/* ESOP Repurchase Obligation Projections */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#f9bc60' }}><TrendingUp size={24} /> Repurchase Obligation Projections</h2>
        <input
          type="number"
          placeholder="Years"
          onChange={(e) => setRepurchaseYears(Number(e.target.value))}
          style={{ padding: '10px', backgroundColor: '#16213e', color: '#fff' }}
        />
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={repurchaseProjections}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="obligation" stroke="#00b4d8" />
          </LineChart>
        </ResponsiveContainer>
      </section>

      {/* Employee Benefit Distribution Modeling */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#f9bc60' }}><Users size={24} /> Employee Benefit Distribution</h2>
        <input
          type="number"
          placeholder="Employee Count"
          onChange={(e) => setEmployeeCount(Number(e.target.value))}
          style={{ padding: '10px', backgroundColor: '#16213e', color: '#fff' }}
        />
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={employeeBenefits}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Area type="monotone" dataKey="benefitPerEmployee" stroke="#f9bc60" fill="#00b4d8" />
          </AreaChart>
        </ResponsiveContainer>
      </section>

      {/* Leveraged ESOP Structure */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#f9bc60' }}><Lock size={24} /> Leveraged ESOP Structure</h2>
        <input
          type="number"
          placeholder="Leveraged Amount"
          onChange={(e) => setLeveragedAmount(Number(e.target.value))}
          style={{ padding: '10px', backgroundColor: '#16213e', color: '#fff' }}
        />
        <p>Projected Structure Value: ${leveragedESOP.toFixed(2)}</p>
      </section>

      {/* ESOP vs 401(k) Comparison */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#f9bc60' }}><ArrowRight size={24} /> ESOP vs 401(k)</h2>
        <p>ESOP: {esopVs401k.esop}</p>
        <p>401(k): {esopVs401k['401k']}</p>
      </section>

      {/* 50-Year Company Growth with ESOP */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#f9bc60' }}><Target size={24} /> 50-Year Company Growth</h2>
        <input
          type="number"
          placeholder="Growth Rate (e.g., 0.05 for 5%)"
          onChange={(e) => setGrowthRate(Number(e.target.value))}
          style={{ padding: '10px', backgroundColor: '#16213e', color: '#fff' }}
        />
        <ResponsiveContainer width="100%" height={300}>
          <ComposedChart data={fiftyYearGrowth}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="value" fill="#00b4d8" stroke="#f9bc60" />
            <Line type="monotone" dataKey="value" stroke="#fff" />
          </ComposedChart>
        </ResponsiveContainer>
      </section>

      {/* Compliance Section */}
      <section>
        <h2 style={{ color: '#f9bc60' }}><CheckCircle2 size={24} /> Compliance Overview</h2>
        <p><AlertTriangle size={18} /> IRC 4975(e)(7): {complianceData.irc4975}</p>
        <p><Calendar size={18} /> Section 1042: {complianceData.section1042}</p>
        <p><Percent size={18} /> Section 404(a)(9): {complianceData.section404}</p>
        <p><Shield size={18} /> Section 409(p): {complianceData.section409p}</p>
        <p><Building2 size={18} /> ERISA 3(18): {complianceData.erisa318}</p>
      </section>
      <PageInsights section="e-s-o-p-analyzer" />
    </div>
  );
}
