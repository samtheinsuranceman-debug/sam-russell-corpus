// @ts-nocheck
import React, { useMemo } from 'react';
import { useOrganismContext } from "@/contexts/OrganismContext";
import { CALCULATOR_ATLAS, useRelatedCalculators } from "@/hooks/useOrganismEyes";
import { getRelatedCalcs } from "@/hooks/useOrganismNervousSystem";
import { Check, X } from 'lucide-react';
import { PageInsights } from "@/components/PageInsights";

const CalcInteropMatrix: React.FC = () => {
  const organism = useOrganismContext();

  // Build relationship matrix from CALCULATOR_ATLAS relatedCalcs
  const { calcNames, relMap, totalConnections, orphaned, maxStrength } = useMemo(() => {
    const names = CALCULATOR_ATLAS.map(c => c.name).sort();
    const routeToName: Record<string, string> = {};
    CALCULATOR_ATLAS.forEach(c => { routeToName[c.route] = c.name; });

    const relationships: Array<{ from: string; to: string; strength: number }> = [];
    
    for (const calc of CALCULATOR_ATLAS) {
      for (const relRoute of calc.relatedCalcs) {
        const relName = routeToName[relRoute];
        if (relName) {
          relationships.push({ from: calc.name, to: relName, strength: 0.8 });
        }
      }
    }

    const map: Record<string, Record<string, number>> = {};
    for (const rel of relationships) {
      if (!map[rel.from]) map[rel.from] = {};
      map[rel.from][rel.to] = rel.strength;
    }

    const connectedCalcs = new Set<string>();
    relationships.forEach(r => { connectedCalcs.add(r.from); connectedCalcs.add(r.to); });
    const orphanedCalcs = names.filter(n => !connectedCalcs.has(n));
    const max = relationships.length > 0 ? Math.max(...relationships.map(r => r.strength)) : 0;

    return {
      calcNames: names.slice(0, 20), // Show top 20 for readability
      relMap: map,
      totalConnections: relationships.length,
      orphaned: orphanedCalcs,
      maxStrength: max,
    };
  }, []);

  return (
    <div className="p-6 space-y-6 bg-[#0a0f1a] text-white min-h-screen">
      <h1 className="text-2xl font-bold text-emerald-400">Calculator Interoperability Matrix</h1>
      
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f]">
          <p className="text-sm text-[#7a95b8]">Total Connections</p>
          <p className="text-2xl font-bold text-emerald-400">{totalConnections}</p>
        </div>
        <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f]">
          <p className="text-sm text-[#7a95b8]">Orphaned Calculators</p>
          <p className="text-2xl font-bold text-amber-400">{orphaned.length}</p>
        </div>
        <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f]">
          <p className="text-sm text-[#7a95b8]">Organism Health</p>
          <p className="text-2xl font-bold text-emerald-400">{organism.health.overall}%</p>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full table-auto border-collapse text-xs">
          <thead>
            <tr className="bg-gray-700">
              <th className="border border-[#1e3a5f] p-2 text-left sticky left-0 bg-gray-700 z-10">From \ To</th>
              {calcNames.map(to => (
                <th key={to} className="border border-[#1e3a5f] p-1 text-center whitespace-nowrap" style={{ writingMode: 'vertical-rl', maxHeight: '120px' }}>{to}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {calcNames.map(from => (
              <tr key={from} className="even:bg-[#0d1526]/50">
                <td className="border border-[#1e3a5f] p-2 font-medium text-emerald-300 sticky left-0 bg-[#0a0f1a] z-10 whitespace-nowrap">{from}</td>
                {calcNames.map(to => {
                  const strength = relMap[from]?.[to] || 0;
                  const isConnected = strength > 0;
                  return (
                    <td key={`${from}-${to}`} className="border border-[#1e3a5f] p-1 text-center">
                      {from === to ? (
                        <span className="text-gray-600">—</span>
                      ) : isConnected ? (
                        <Check size={14} className="text-emerald-500 mx-auto" />
                      ) : (
                        <X size={14} className="text-gray-700 mx-auto" />
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {orphaned.length > 0 && (
        <div className="bg-[#0d1526] p-4 rounded-lg border border-amber-500/30">
          <h2 className="text-lg font-semibold text-amber-400 mb-2">Orphaned Calculators ({orphaned.length})</h2>
          <div className="flex flex-wrap gap-2">
            {orphaned.slice(0, 15).map(name => (
              <span key={name} className="px-2 py-1 bg-gray-700 rounded text-xs text-[#94a3b8]">{name}</span>
            ))}
          </div>
        </div>
      )}
      <PageInsights section="calc-interop-matrix" />
    </div>
  );
};

export default CalcInteropMatrix;
