// @ts-nocheck
import { useState, useMemo } from "react";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Calculator, DollarSign, TrendingUp, Shield } from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function CaptiveInsuranceCalc() {
  const autoFill = useCalculatorAutoFill("captive-insurance");
  const { reportResult } = useCalcResults();
  const [businessIncome, setBusinessIncome] = useState(500000);
  const [ownerAge, setOwnerAge] = useState(40);
  const [coverageAmount, setCoverageAmount] = useState(1000000);
  const [premiumRate, setPremiumRate] = useState(5); // Percentage

  const calculations = useMemo(() => {
    const riskFactor = 1 + (ownerAge / 100); // Simplified risk adjustment
    const annualPremium = (coverageAmount * (premiumRate / 100) * riskFactor);
    const totalPremiumOver10Years = annualPremium * 10;
    const iulGrowthAdvantage = totalPremiumOver10Years * 0.07; // Assumed 7% tax-free growth in IUL
    const potentialTaxSavings = iulGrowthAdvantage * 0.25; // Assumed 25% tax rate savings
    return { annualPremium, totalPremiumOver10Years, potentialTaxSavings };
  }, [businessIncome, ownerAge, coverageAmount, premiumRate]);
  const projectionData = useMemo(() => {
    const d = [];
    let opt = 100000, base = 100000, taxSav = 0;
    for (let yr = 0; yr <= 50; yr++) {
      opt *= 1.075;
      base *= 1.05;
      taxSav += (opt - base) * 0.08;
      d.push({ year: yr, optimized: Math.round(opt), baseline: Math.round(base), taxSavings: Math.round(taxSav), netBenefit: Math.round(opt - base + taxSav) });
    }
    return d;
  }, []);


  return (
    <AppShell className="bg-[#0a0f1a] text-white">
      <div className="p-6 max-w-4xl mx-auto">
        <AutoFillBanner calcRoute="captive-insurance" />
        <div className="flex items-center mb-6">
          <Calculator className="mr-2 text-emerald-400" />
          <h1 className="text-2xl font-bold">Captive Insurance Premium Calculator</h1>
          <Badge className="ml-2 bg-emerald-400 text-slate-900">Business Owner Tools</Badge>
        </div>
        
        {/* Input Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div>
            <Label htmlFor="businessIncome">Business Annual Income</Label>
            <div className="flex items-center mt-2">
              <DollarSign className="mr-2 text-emerald-400" />
              <Input
                id="businessIncome"
                type="number"
                value={businessIncome}
                onChange={(e) => setBusinessIncome(Number(e.target.value))}
                className="bg-[#0d1526] border-[#1e3a5f] text-white"
                min={0}
              />
            </div>
            <p className="text-sm text-[#7a95b8] mt-1">Current value: {formatDollars(businessIncome)}</p>
          </div>
          
          <div>
            <Label htmlFor="ownerAge">Owner's Age</Label>
            <Slider
              id="ownerAge"
              min={18}
              max={70}
              step={1}
              value={[ownerAge]}
              onValueChange={(value) => setOwnerAge(value[0])}
              className="mt-2"
            />
            <p className="text-sm text-[#7a95b8] mt-1">Age: {ownerAge} years</p>
          </div>
          
          <div>
            <Label htmlFor="coverageAmount">Desired Coverage Amount</Label>
            <div className="flex items-center mt-2">
              <Shield className="mr-2 text-emerald-400" />
              <Input
                id="coverageAmount"
                type="number"
                value={coverageAmount}
                onChange={(e) => setCoverageAmount(Number(e.target.value))}
                className="bg-[#0d1526] border-[#1e3a5f] text-white"
                min={0}
              />
            </div>
            <p className="text-sm text-[#7a95b8] mt-1">Current value: {formatDollars(coverageAmount)}</p>
          </div>
          
          <div>
            <Label htmlFor="premiumRate">Premium Rate (%)</Label>
            <Slider
              id="premiumRate"
              min={1}
              max={10}
              step={0.1}
              value={[premiumRate]}
              onValueChange={(value) => setPremiumRate(value[0])}
              className="mt-2"
            />
            <p className="text-sm text-[#7a95b8] mt-1">Rate: {premiumRate}%</p>
          </div>
        </div>
        
        {/* Results Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="flex items-center">
                <DollarSign className="mr-2 text-emerald-400" />
                Estimated Annual Premium
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{formatDollars(calculations.annualPremium)}</p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="mr-2 text-emerald-400" />
                Total Premium Over 10 Years
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{formatDollars(calculations.totalPremiumOver10Years)}</p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="mr-2 text-emerald-400" />
                Potential Tax Savings with IUL
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{formatDollars(calculations.potentialTaxSavings)}</p>
            </CardContent>
          </Card>
        </div>
        
        {/* IUL Advantage Section */}
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />
        
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "optimized", label: "Optimized Strategy", color: "#10b981" }, { key: "baseline", label: "Baseline (No Action)", color: "#ef4444" }, { key: "taxSavings", label: "Cumulative Tax Savings", color: "#06b6d4" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="mb-8 p-4 bg-[#0d1526] rounded-lg border border-[#1e3a5f]">
          <h2 className="text-xl font-bold mb-2 flex items-center">
            <TrendingUp className="mr-2 text-emerald-400" />
            IUL Advantage
          </h2>
          <p className="text-[#94a3b8]">
            Indexed Universal Life (IUL) offers tax-free growth on premiums, providing a significant advantage for business owners. By allocating funds into an IUL policy, you can potentially offset captive insurance costs through tax-deferred accumulation and withdrawals, enhancing long-term financial security compared to traditional insurance.
          </p>
          <p className="text-[#7a95b8] mt-2">
            In this calculator, the Potential Tax Savings metric illustrates how IUL's tax-free growth could reduce your overall expenses by approximately 25% on accumulated premiums.
          </p>
        </div>
        
        {/* Send to AI Advisor Button */}
        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-400 text-slate-900 hover:bg-emerald-500"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("captive-insurance", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-captive-insurance");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Captive Insurance Premium Calculator"
            calculatorRoute="captive-insurance"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="captive-insurance-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/captive-insurance" />
</div>
    </AppShell>
  );
}