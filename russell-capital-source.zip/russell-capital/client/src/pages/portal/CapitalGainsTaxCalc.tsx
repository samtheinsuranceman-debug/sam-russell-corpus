// @ts-nocheck

import { useState, useMemo } from "react";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Circle, CalculatorIcon, ShieldIcon, TrendingUpIcon} from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return '$' + (n / 1_000_000).toFixed(1) + 'M';
  if (n >= 1_000) return '$' + (n / 1_000).toFixed(0) + 'K';
  return '$' + n.toFixed(0);
}

export default function CapitalGainsTaxCalc() {
  const autoFill = useCalculatorAutoFill("capital-gains-tax");
  const { reportResult } = useCalcResults();
  const [currentValue, setCurrentValue] = useState(100000);
  const [purchasePrice, setPurchasePrice] = useState(50000);
  const [yearsHeld, setYearsHeld] = useState(2);

  const calculatedResults = useMemo(() => {
    const gain = currentValue - purchasePrice;
    const isLongTerm = yearsHeld > 1;
    const longTermRate = 0.15;  // 15% for long-term
    const shortTermRate = 0.22; // 22% for short-term (assumed ordinary income rate)
    const taxRate = isLongTerm ? longTermRate : shortTermRate;
    const taxOwed = gain > 0 ? gain * taxRate : 0;
    const netProceeds = currentValue - taxOwed;
    const iulAdvantageSavings = taxOwed;  // Tax saved if in IUL

    return {
      gain,
      taxOwed,
      netProceeds,
      iulAdvantageSavings,
      isLongTerm,
    };
  }, [currentValue, purchasePrice, yearsHeld]);
  const projectionData = useMemo(() => {
    const d = [];
    const income = typeof primaryIncome !== 'undefined' ? primaryIncome : 250000;
    const savingsRate = 0.08;
    let withStrat = 0, withoutStrat = 0, cumTax = 0;
    for (let yr = 0; yr <= 50; yr++) {
      const annualSavings = income * savingsRate * (1 + yr * 0.01);
      cumTax += annualSavings;
      withStrat += (income * 0.15) * Math.pow(1.072, yr > 0 ? 1 : 0);
      withoutStrat += (income * 0.15 - annualSavings) * Math.pow(1.055, yr > 0 ? 1 : 0);
      d.push({ year: yr, taxSaved: Math.round(cumTax), withStrategy: Math.round(withStrat), withoutStrategy: Math.round(withoutStrat), netBenefit: Math.round(cumTax * 1.06) });
    }
    return d;
  }, []);


  return (
    <AppShell
      className="bg-[#0a0f1a] text-white min-h-screen"
      header={
        <div className="flex items-center p-4 bg-[#0d1526]">
          <CalculatorIcon className="mr-2 h-6 w-6 text-emerald-400" />
          <h1 className="text-xl font-bold">Capital Gains Tax Calculator</h1>
        </div>
      }
    >
      <div className="p-6 max-w-4xl mx-auto">
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4 text-emerald-400">Input Your Details</h2>
          <div className="space-y-6">
            <div>
              <Label htmlFor="currentValue">Current Value</Label>
              <div className="flex items-center space-x-4 mt-2">
                <Input
                  id="currentValue"
                  type="number"
                  value={currentValue}
                  onChange={(e) => setCurrentValue(Number(e.target.value))}
                  className="bg-[#0d1526] border-[#1e3a5f] text-white"
                  min="0"
                />
                <Slider
                  min={0}
                  max={500000}
                  step={1000}
                  value={[currentValue]}
                  onValueChange={(value) => setCurrentValue(value[0])}
                  className="w-full"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="purchasePrice">Purchase Price (Cost Basis)</Label>
              <div className="flex items-center space-x-4 mt-2">
                <Input
                  id="purchasePrice"
                  type="number"
                  value={purchasePrice}
                  onChange={(e) => setPurchasePrice(Number(e.target.value))}
                  className="bg-[#0d1526] border-[#1e3a5f] text-white"
                  min="0"
                />
                <Slider
                  min={0}
                  max={500000}
                  step={1000}
                  value={[purchasePrice]}
                  onValueChange={(value) => setPurchasePrice(value[0])}
                  className="w-full"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="yearsHeld">Years Held</Label>
              <div className="flex items-center space-x-4 mt-2">
                <Input
                  id="yearsHeld"
                  type="number"
                  value={yearsHeld}
                  onChange={(e) => setYearsHeld(Number(e.target.value))}
                  className="bg-[#0d1526] border-[#1e3a5f] text-white"
                  min="0"
                />
                <Slider
                  min={0}
                  max={10}
                  step={1}
                  value={[yearsHeld]}
                  onValueChange={(value) => setYearsHeld(value[0])}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="mb-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="flex items-center text-emerald-400">
                <TrendingUpIcon className="mr-2 h-5 w-5" />
                Capital Gain
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{formatDollars(calculatedResults.gain)}</p>
              <p className="text-sm text-[#7a95b8]">
                {calculatedResults.isLongTerm ? 'Long-term gain' : 'Short-term gain'}
              </p>
            </CardContent>
          </Card>
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="flex items-center text-emerald-400">
                <CalculatorIcon className="mr-2 h-5 w-5" />
                Estimated Tax Owed
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{formatDollars(calculatedResults.taxOwed)}</p>
              <p className="text-sm text-[#7a95b8]">Based on applicable tax rate</p>
            </CardContent>
          </Card>
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="flex items-center text-emerald-400">
                <TrendingUpIcon className="mr-2 h-5 w-5" />
                Net Proceeds
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{formatDollars(calculatedResults.netProceeds)}</p>
              <p className="text-sm text-[#7a95b8]">After taxes</p>
            </CardContent>
          </Card>
        </div>

        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4 text-emerald-400">IUL Advantage</h2>
          <Card className="bg-[#0d1526] border-[#1e3a5f] p-4">
            <div className="flex items-start">
              <ShieldIcon className="mr-2 h-6 w-6 text-emerald-400" />
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />
              
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "taxSaved", label: "Cumulative Tax Savings", color: "#10b981" }, { key: "withStrategy", label: "With Tax Strategy", color: "#06b6d4" }, { key: "withoutStrategy", label: "Without Strategy", color: "#ef4444" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div>
                <p className="text-sm text-[#94a3b8]">
                  With an Indexed Universal Life (IUL) policy, your gains of{' '}
                  {formatDollars(calculatedResults.gain)} could grow tax-free, potentially saving you{' '}
                  {formatDollars(calculatedResults.iulAdvantageSavings)} in taxes compared to traditional investments.
                </p>
                <p className="mt-2 text-sm text-[#7a95b8]">
                  IUL offers tax-free growth and withdrawals, providing a significant advantage for tax and income optimization.
                </p>
              </div>
            </div>
          </Card>
        </div>

        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-500 hover:bg-emerald-600 text-white"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("capital-gains-tax", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-capital-gains-tax");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Capital Gains Tax Calculator"
            calculatorRoute="capital-gains-tax"
            inputs={typeof calculatedResults !== 'undefined' ? calculatedResults : {}}
            results={typeof calculatedResults !== 'undefined' ? calculatedResults : {}}
            projectionData={projectionData}
          />
      <PageInsights section="capital-gains-tax-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/capital-gains-tax" />
</div>
    </AppShell>
  );
}