// @ts-nocheck

import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Circle, CalculatorIcon, ShieldIcon, TrendingUpIcon} from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function DisabilityInsuranceCalc() {
  const autoFill = useCalculatorAutoFill("disability-insurance-needs");
  const { reportResult } = useCalcResults();
  const [annualIncome, setAnnualIncome] = useSharedField("annualIncome", 50000);
  const [age, setAge] = useSharedField("currentAge", 35);
  const [emergencyFund, setEmergencyFund] = useState(10000);
  const [replacementRatio, setReplacementRatio] = useState(0.6); // 60% as default
  const [coverageYears, setCoverageYears] = useState(20);

  const calculations = useMemo(() => {
    const monthlyIncomeNeeded = (annualIncome * replacementRatio) / 12;
    const yearsToRetirement = 67 - age; // Assuming retirement at 67
    const totalCoverageNeeded = annualIncome * yearsToRetirement - emergencyFund;
    const recommendedMonthlyBenefit = monthlyIncomeNeeded;
    const estimatedPremium = (totalCoverageNeeded * 0.01) / 12; // Simplified premium estimate
    return {
      recommendedMonthlyBenefit,
      totalCoverageNeeded,
      estimatedPremium,
    };
  }, [annualIncome, age, emergencyFund, replacementRatio, coverageYears]);
  const projectionData = useMemo(() => {
    const d = [];
    let opt = 100000, base = 100000, taxSav = 0;
    for (let yr = 0; yr <= 50; yr++) {
      opt *= 1.075;
      base *= 1.05;
      taxSav += (opt - base) * 0.08;
      d.push({ year: yr, optimized: Math.round(opt), baseline: Math.round(base), taxSavings: Math.round(taxSav), netBenefit: Math.round(opt - base + taxSav) });
    }
    return d;
  }, []);


  return (
    <AppShell
      headerTitle="Disability Insurance Needs Calculator"
      headerSubtitle="Insurance & Protection"
    >
      <div className="p-6 bg-[#0a0f1a] min-h-screen text-white">
        <AutoFillBanner calcRoute="disability-insurance-needs" />
        <div className="max-w-4xl mx-auto">
          <Card className="bg-[#0d1526] mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalculatorIcon className="h-6 w-6 text-emerald-400" />
                Input Your Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <Label htmlFor="annualIncome">Annual Income</Label>
                  <div className="flex items-center gap-4 mt-2">
                    <Input
                      id="annualIncome"
                      type="number"
                      value={annualIncome}
                      onChange={(e) => setAnnualIncome(Number(e.target.value))}
                      className="bg-slate-700"
                    />
                    <Slider
                      min={20000}
                      max={200000}
                      step={1000}
                      value={[annualIncome]}
                      onValueChange={(value) => setAnnualIncome(value[0])}
                      className="w-full"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="age">Age</Label>
                  <div className="flex items-center gap-4 mt-2">
                    <Input
                      id="age"
                      type="number"
                      value={age}
                      onChange={(e) => setAge(Number(e.target.value))}
                      className="bg-slate-700"
                    />
                    <Slider
                      min={18}
                      max={65}
                      step={1}
                      value={[age]}
                      onValueChange={(value) => setAge(value[0])}
                      className="w-full"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="emergencyFund">Emergency Fund</Label>
                  <div className="flex items-center gap-4 mt-2">
                    <Input
                      id="emergencyFund"
                      type="number"
                      value={emergencyFund}
                      onChange={(e) => setEmergencyFund(Number(e.target.value))}
                      className="bg-slate-700"
                    />
                    <Slider
                      min={0}
                      max={100000}
                      step={1000}
                      value={[emergencyFund]}
                      onValueChange={(value) => setEmergencyFund(value[0])}
                      className="w-full"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="replacementRatio">Replacement Ratio (e.g., 0.6 for 60%)</Label>
                  <div className="flex items-center gap-4 mt-2">
                    <Input
                      id="replacementRatio"
                      type="number"
                      step="0.1"
                      value={replacementRatio}
                      onChange={(e) => setReplacementRatio(Number(e.target.value))}
                      className="bg-slate-700"
                    />
                    <Slider
                      min={0.5}
                      max={0.8}
                      step={0.05}
                      value={[replacementRatio]}
                      onValueChange={(value) => setReplacementRatio(value[0])}
                      className="w-full"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="coverageYears">Coverage Years</Label>
                  <div className="flex items-center gap-4 mt-2">
                    <Input
                      id="coverageYears"
                      type="number"
                      value={coverageYears}
                      onChange={(e) => setCoverageYears(Number(e.target.value))}
                      className="bg-slate-700"
                    />
                    <Slider
                      min={5}
                      max={30}
                      step={1}
                      value={[coverageYears]}
                      onValueChange={(value) => setCoverageYears(value[0])}
                      className="w-full"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        {/* State Tax Impact */}
        <StateTaxSelector income={annualIncome} filingStatus={'single'} className="mb-6" />

          
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "optimized", label: "Optimized Strategy", color: "#10b981" }, { key: "baseline", label: "Baseline (No Action)", color: "#ef4444" }, { key: "taxSavings", label: "Cumulative Tax Savings", color: "#06b6d4" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShieldIcon className="h-6 w-6 text-emerald-400" />
                  Recommended Monthly Benefit
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">{formatDollars(calculations.recommendedMonthlyBenefit)} / month</p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUpIcon className="h-6 w-6 text-emerald-400" />
                  Total Coverage Needed
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">{formatDollars(calculations.totalCoverageNeeded)}</p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CalculatorIcon className="h-6 w-6 text-emerald-400" />
                  Estimated Annual Premium
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">{formatDollars(calculations.estimatedPremium * 12)} / year</p>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-[#0d1526] mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShieldIcon className="h-6 w-6 text-emerald-400" />
                IUL Advantage
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p>Indexed Universal Life (IUL) offers tax-free growth on your savings, providing an extra layer of protection. While disability insurance covers income loss, IUL can help your emergency funds grow faster than traditional savings, ensuring long-term financial security.</p>
              <Badge className="mt-2 bg-emerald-400 text-slate-900">Tax-Free Growth Benefit</Badge>
            </CardContent>
          </Card>

          <Button
            onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
            className="bg-emerald-400 text-slate-900 hover:bg-emerald-500"
          >
            Send to AI Advisor
          </Button>
        </div>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("disability-insurance-needs", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-disability-insurance-needs");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Disability Insurance Needs Calculator"
            calculatorRoute="disability-insurance-needs"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="disability-insurance-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/disability-insurance-needs" />
</div>
    </AppShell>
  );
}