// @ts-nocheck

import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DollarSign, Users, Calendar, Percent, TrendingUp } from 'lucide-react';
import { toast } from "sonner";
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function BuySellFundingCalc() {
  const autoFill = useCalculatorAutoFill("buy-sell-funding");
  const { reportResult } = useCalcResults();
  const [businessValue, setBusinessValue] = useState(500000);
  const [numOwners, setNumOwners] = useState(2);
  const [avgAge, setAvgAge] = useState(40);
  const [growthRate, setGrowthRate] = useSharedField("growthRate", 5);
  const [premium, setPremium] = useState(10000);

  const calculations = useMemo(() => {
    const deathBenefit = businessValue / numOwners;
    const annualPremium = premium * numOwners;
    const projectedValue = premium * (1 + growthRate / 100) ** 10;
    return { deathBenefit, annualPremium, projectedValue };
  }, [businessValue, numOwners, growthRate, premium]);
  const projectionData = useMemo(() => {
    const d = [];
    let opt = 100000, base = 100000, taxSav = 0;
    for (let yr = 0; yr <= 50; yr++) {
      opt *= 1.075;
      base *= 1.05;
      taxSav += (opt - base) * 0.08;
      d.push({ year: yr, optimized: Math.round(opt), baseline: Math.round(base), taxSavings: Math.round(taxSav), netBenefit: Math.round(opt - base + taxSav) });
    }
    return d;
  }, []);


  return (
    <AppShell
      className="bg-[#0a0f1a] text-white min-h-screen"
      headerTitle="Buy-Sell Agreement Funding Calculator"
      headerSubtitle="Insurance & Protection"
    >
      <div className="p-6 space-y-8">
        <AutoFillBanner calcRoute="buy-sell-funding" />
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-emerald-400">Inputs</h2>
          <div className="space-y-6">
            <div className="flex items-center space-x-4">
              <DollarSign className="h-6 w-6 text-emerald-400" />
              <div className="flex-1">
                <Label>Business Value</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={businessValue}
                    onChange={(e) => setBusinessValue(Number(e.target.value))}
                    className="bg-[#0d1526] border-[#1e3a5f]"
                  />
                  <Slider
                    min={100000}
                    max={5000000}
                    step={10000}
                    value={[businessValue]}
                    onValueChange={(value) => setBusinessValue(value[0])}
                    className="w-full"
                  />
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Users className="h-6 w-6 text-emerald-400" />
              <div className="flex-1">
                <Label>Number of Owners</Label>
                <Input
                  type="number"
                  min={1}
                  max={10}
                  value={numOwners}
                  onChange={(e) => setNumOwners(Number(e.target.value))}
                  className="bg-[#0d1526] border-[#1e3a5f]"
                />
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Calendar className="h-6 w-6 text-emerald-400" />
              <div className="flex-1">
                <Label>Average Age of Owners</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={avgAge}
                    onChange={(e) => setAvgAge(Number(e.target.value))}
                    className="bg-[#0d1526] border-[#1e3a5f]"
                  />
                  <Slider
                    min={30}
                    max={70}
                    step={1}
                    value={[avgAge]}
                    onValueChange={(value) => setAvgAge(value[0])}
                    className="w-full"
                  />
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Percent className="h-6 w-6 text-emerald-400" />
              <div className="flex-1">
                <Label>Growth Rate (%)</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={growthRate}
                    onChange={(e) => setGrowthRate(Number(e.target.value))}
                    className="bg-[#0d1526] border-[#1e3a5f]"
                  />
                  <Slider
                    min={2}
                    max={8}
                    step={0.5}
                    value={[growthRate]}
                    onValueChange={(value) => setGrowthRate(value[0])}
                    className="w-full"
                  />
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <DollarSign className="h-6 w-6 text-emerald-400" />
              <div className="flex-1">
                <Label>Annual Premium per Policy</Label>
                <Input
                  type="number"
                  value={premium}
                  onChange={(e) => setPremium(Number(e.target.value))}
                  className="bg-[#0d1526] border-[#1e3a5f]"
                />
              </div>
            </div>
          </div>
        </section>
        
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-emerald-400">Results</h2>
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />
          
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "optimized", label: "Optimized Strategy", color: "#10b981" }, { key: "baseline", label: "Baseline (No Action)", color: "#ef4444" }, { key: "taxSavings", label: "Cumulative Tax Savings", color: "#06b6d4" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <DollarSign className="h-5 w-5" />
                  <span>Death Benefit Required</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">{formatDollars(calculations.deathBenefit)}</p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <DollarSign className="h-5 w-5" />
                  <span>Annual Premium</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">{formatDollars(calculations.annualPremium)}</p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5" />
                  <span>Projected IUL Value (10 Years)</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">{formatDollars(calculations.projectedValue)}</p>
              </CardContent>
            </Card>
          </div>
        </section>
        
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-emerald-400">IUL Advantage</h2>
          <p className="text-[#94a3b8]">
            Indexed Universal Life (IUL) insurance offers tax-free growth, making it an ideal tool for funding buy-sell agreements. By leveraging IUL, business owners can accumulate cash value that grows based on market indices without taxable events, ensuring efficient funding for buyouts while providing death benefits.
          </p>
        </section>
        
        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-500 hover:bg-emerald-600"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("buy-sell-funding", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-buy-sell-funding");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Buy-Sell Agreement Funding Calculator"
            calculatorRoute="buy-sell-funding"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="buy-sell-funding-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/buy-sell-funding" />
</div>
    </AppShell>
  );
}