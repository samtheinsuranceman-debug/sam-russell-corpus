// @ts-nocheck
/**
 * Client Retention AI Assistant
 * Grok-recommended Feature 3 (Impact 8, Complexity 2)
 * Churn prediction, engagement scoring, and follow-up suggestions
 * using Client Retention + Behavioral Bias engines.
 */
import { useState, useEffect, useMemo } from "react";
import { AppShell } from "@/components/AppShell";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from "recharts";
import { Users, AlertTriangle, TrendingDown, Heart, Zap, UserCheck, DollarSign, Clock, ChevronRight } from 'lucide-react';
import { useReportToHub } from "@/contexts/UnifiedDataBusContext";
import { PageInsights } from "@/components/PageInsights";

// ─── Sample client data ─────────────────────────────────────────────────────
const sampleClients = [
  { clientId: "C001", yearsAsClient: 8, aum: 2500000, meetingsPerYear: 4, emailResponseRate: 0.85, portfolioReturn: 7.2, benchmarkReturn: 6.8, lifeEvents: ["retirement"], lastContactDays: 15, nps: 9 },
  { clientId: "C002", yearsAsClient: 3, aum: 750000, meetingsPerYear: 2, emailResponseRate: 0.45, portfolioReturn: 4.1, benchmarkReturn: 6.8, lifeEvents: ["divorce"], lastContactDays: 90, nps: 5 },
  { clientId: "C003", yearsAsClient: 12, aum: 5000000, meetingsPerYear: 6, emailResponseRate: 0.92, portfolioReturn: 8.5, benchmarkReturn: 6.8, lifeEvents: [], lastContactDays: 7, nps: 10 },
  { clientId: "C004", yearsAsClient: 1, aum: 350000, meetingsPerYear: 1, emailResponseRate: 0.30, portfolioReturn: 2.1, benchmarkReturn: 6.8, lifeEvents: ["job_change", "new_baby"], lastContactDays: 120, nps: 4 },
  { clientId: "C005", yearsAsClient: 5, aum: 1200000, meetingsPerYear: 3, emailResponseRate: 0.60, portfolioReturn: 5.5, benchmarkReturn: 6.8, lifeEvents: ["inheritance"], lastContactDays: 45, nps: 7 },
  { clientId: "C006", yearsAsClient: 2, aum: 500000, meetingsPerYear: 2, emailResponseRate: 0.35, portfolioReturn: 3.2, benchmarkReturn: 6.8, lifeEvents: ["competitor_mention"], lastContactDays: 75, nps: 5 },
  { clientId: "C007", yearsAsClient: 15, aum: 8000000, meetingsPerYear: 4, emailResponseRate: 0.88, portfolioReturn: 7.8, benchmarkReturn: 6.8, lifeEvents: ["grandchild"], lastContactDays: 10, nps: 9 },
  { clientId: "C008", yearsAsClient: 4, aum: 900000, meetingsPerYear: 2, emailResponseRate: 0.50, portfolioReturn: 3.8, benchmarkReturn: 6.8, lifeEvents: ["health_issue"], lastContactDays: 60, nps: 6 },
];

const riskColors: Record<string, string> = {
  critical: "text-red-400",
  high: "text-orange-400",
  moderate: "text-amber-400",
  low: "text-emerald-400",
};
const riskBg: Record<string, string> = {
  critical: "bg-red-500/10 border-red-500/20",
  high: "bg-orange-500/10 border-orange-500/20",
  moderate: "bg-amber-500/10 border-amber-500/20",
  low: "bg-emerald-500/10 border-emerald-500/20",
};
const urgencyColors: Record<string, string> = {
  immediate: "border-red-500/50 text-red-400",
  this_week: "border-orange-500/50 text-orange-400",
  this_month: "border-amber-500/50 text-amber-400",
  quarterly: "border-emerald-500/50 text-emerald-400",
};

const fmt = (n: number) => "$" + n.toLocaleString(undefined, { maximumFractionDigits: 0 });

export default function ClientRetentionAssistant() {
  const _reportToHub = useReportToHub("ai-pro-retention-assistant", "Client Retention AI Assistant", "ai-pro-suite", "/portal/client-retention-assistant");
  useEffect(() => {
    _reportToHub({ visited: true, timestamp: Date.now() });
  }, [_reportToHub]);
  const mutation = trpc.si.clientRetention.useMutation();
  const [analyzed, setAnalyzed] = useState(false);

  const handleAnalyze = () => {
    mutation.mutate({ clients: sampleClients });
    setAnalyzed(true);
  };

  const result = mutation.data;
  const isLoading = mutation.isPending;

  // Sort predictions by churn probability (highest first)
  const sortedPredictions = useMemo(() => {
    if (!result?.predictions) return [];
    return [...result.predictions].sort((a, b) => b.churnProbability - a.churnProbability);
  }, [result]);

  // Chart data
  const riskDistribution = useMemo(() => {
    if (!result?.predictions) return [];
    const counts = { critical: 0, high: 0, moderate: 0, low: 0 };
    result.predictions.forEach(p => { counts[p.riskLevel as keyof typeof counts]++; });
    return [
      { name: "Critical", value: counts.critical, fill: "#ef4444" },
      { name: "High", value: counts.high, fill: "#f97316" },
      { name: "Moderate", value: counts.moderate, fill: "#f59e0b" },
      { name: "Low", value: counts.low, fill: "#10b981" },
    ].filter(d => d.value > 0);
  }, [result]);

  const revenueByClient = useMemo(() => {
    if (!sortedPredictions.length) return [];
    return sortedPredictions.map(p => ({
      name: p.clientName,
      revenue: p.estimatedRevenueAtRisk,
      churn: p.churnProbability,
      fill: p.riskLevel === "critical" ? "#ef4444" : p.riskLevel === "high" ? "#f97316" : p.riskLevel === "moderate" ? "#f59e0b" : "#10b981",
    }));
  }, [sortedPredictions]);

  return (
    <AppShell title="Client Retention" subtitle="AI-powered churn prediction and engagement scoring">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center gap-3">
            <Heart className="h-6 w-6 text-rose-400" />
            <div>
              <h1 className="text-2xl font-bold text-white">Client Retention AI Assistant</h1>
              <p className="text-sm text-[#7a95b8]">Predict churn risk and generate personalized retention strategies</p>
            </div>
          </div>
          <Button onClick={handleAnalyze} disabled={isLoading} className="bg-rose-600 hover:bg-rose-500">
            <Zap className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
            {analyzed ? "Re-Analyze" : "Analyze Portfolio"}
          </Button>
        </div>

        {!analyzed && !isLoading && (
          <Card className="bg-[#0d1526]/50 border-[#1e3a5f]/50">
            <CardContent className="py-12 text-center">
              <Users className="h-16 w-16 text-slate-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-[#94a3b8] mb-2">Client Portfolio Analysis</h3>
              <p className="text-slate-500 mb-4">Analyze {sampleClients.length} clients for churn risk, engagement scoring, and retention strategies</p>
              <Button onClick={handleAnalyze} className="bg-rose-600 hover:bg-rose-500">
                <UserCheck className="h-4 w-4 mr-2" /> Start Analysis
              </Button>
            </CardContent>
          </Card>
        )}

        {isLoading && (
          <div className="flex justify-center py-12">
            <div className="flex flex-col items-center gap-3">
              <div className="w-10 h-10 border-2 border-rose-500/30 border-t-rose-500 rounded-full animate-spin" />
              <p className="text-[#7a95b8] text-sm">Analyzing client behavior patterns...</p>
            </div>
          </div>
        )}

        {result && !isLoading && (
          <>
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="bg-red-500/10 border-red-500/20">
                <CardContent className="pt-5 pb-4">
                  <div className="flex items-center gap-3">
                    <DollarSign className="h-5 w-5 text-red-400" />
                    <div>
                      <p className="text-xs text-[#7a95b8]">Revenue at Risk</p>
                      <p className="text-xl font-bold text-red-400">{fmt(result.totalRevenueAtRisk)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-orange-500/10 border-orange-500/20">
                <CardContent className="pt-5 pb-4">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="h-5 w-5 text-orange-400" />
                    <div>
                      <p className="text-xs text-[#7a95b8]">Critical Clients</p>
                      <p className="text-xl font-bold text-orange-400">{result.criticalCount}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-amber-500/10 border-amber-500/20">
                <CardContent className="pt-5 pb-4">
                  <div className="flex items-center gap-3">
                    <TrendingDown className="h-5 w-5 text-amber-400" />
                    <div>
                      <p className="text-xs text-[#7a95b8]">High Risk</p>
                      <p className="text-xl font-bold text-amber-400">{result.highCount}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-emerald-500/10 border-emerald-500/20">
                <CardContent className="pt-5 pb-4">
                  <div className="flex items-center gap-3">
                    <Heart className="h-5 w-5 text-emerald-400" />
                    <div>
                      <p className="text-xs text-[#7a95b8]">Avg Churn Probability</p>
                      <p className="text-xl font-bold text-emerald-400">{result.avgChurnProbability.toFixed(1)}%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card className="bg-[#0d1526]/50 border-[#1e3a5f]/50">
                <CardHeader><CardTitle className="text-rose-400 text-sm">Revenue at Risk by Client</CardTitle></CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={revenueByClient} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis type="number" stroke="#9CA3AF" tickFormatter={v => `$${(v / 1000).toFixed(0)}K`} />
                      <YAxis dataKey="name" type="category" stroke="#9CA3AF" width={60} tick={{ fontSize: 11 }} />
                      <Tooltip contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #334155", borderRadius: "8px" }}
                        formatter={(v: number) => fmt(v)} />
                      <Bar dataKey="revenue" radius={[0, 4, 4, 0]}>
                        {revenueByClient.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              <Card className="bg-[#0d1526]/50 border-[#1e3a5f]/50">
                <CardHeader><CardTitle className="text-rose-400 text-sm">Risk Distribution</CardTitle></CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie data={riskDistribution} dataKey="value" nameKey="name" cx="50%" cy="50%"
                        outerRadius={90} innerRadius={50} label={({ name, value }) => `${name}: ${value}`}>
                        {riskDistribution.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #334155", borderRadius: "8px" }} />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
      <PageInsights section="client-retention-assistant" />
            </div>

            {/* Client Details */}
            <Tabs defaultValue="clients" className="w-full">
              <TabsList className="bg-[#0d1526] border border-[#1e3a5f]">
                <TabsTrigger value="clients">Client Risk ({sortedPredictions.length})</TabsTrigger>
                <TabsTrigger value="actions">Top Actions</TabsTrigger>
              </TabsList>

              <TabsContent value="clients">
                <div className="space-y-2">
                  {sortedPredictions.map((p, i) => (
                    <Card key={i} className={`${riskBg[p.riskLevel]} border`}>
                      <CardContent className="py-3 px-4">
                        <div className="flex items-center gap-4">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium text-white">{p.clientName}</span>
                              <Badge variant="outline" className={`${urgencyColors[p.urgency]}`}>{p.urgency.replace("_", " ")}</Badge>
                              <Badge variant="outline" className={`${riskColors[p.riskLevel]} border-current/30`}>{p.riskLevel}</Badge>
                            </div>
                            <div className="flex gap-4 text-xs text-[#7a95b8]">
                              <span>Churn: <strong className={riskColors[p.riskLevel]}>{p.churnProbability}%</strong></span>
                              <span>Revenue at Risk: <strong className="text-red-400">{fmt(p.estimatedRevenueAtRisk)}</strong></span>
                            </div>
                          </div>
                          <div className="text-right shrink-0">
                            <p className="text-xs text-slate-500 mb-1">Action</p>
                            <p className="text-sm text-white">{p.recommendedAction}</p>
                          </div>
                          <ChevronRight className="h-4 w-4 text-slate-500 shrink-0" />
                        </div>
                        {p.topRiskFactors.length > 0 && (
                          <div className="mt-2 flex flex-wrap gap-1">
                            {p.topRiskFactors.slice(0, 3).map((f, j) => (
                              <Badge key={j} variant="outline" className="border-[#1e3a5f] text-[#7a95b8] text-xs">{f}</Badge>
                            ))}
                          </div>
                        )}
                        {p.retentionStrategies.length > 0 && (
                          <div className="mt-2 text-xs text-slate-500">
                            Strategies: {p.retentionStrategies.slice(0, 2).join(" | ")}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="actions">
                <Card className="bg-[#0d1526]/50 border-[#1e3a5f]/50">
                  <CardContent className="pt-6">
                    <div className="space-y-3">
                      {result.topRetentionActions.map((action, i) => (
                        <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/20">
                          <div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center shrink-0">
                            <span className="text-xs text-emerald-400 font-bold">{i + 1}</span>
                          </div>
                          <p className="text-sm text-[#94a3b8]">{action}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </>
        )}
      </div>
    </AppShell>
  );
}
