// @ts-nocheck

import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Circle, CalculatorIcon} from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function DivorceSettlementCalc() {
  const autoFill = useCalculatorAutoFill("divorce-settlement-enhanced");
  const { reportResult } = useCalcResults();
  const [age, setAge] = useSharedField("currentAge", 40);
  const [assets, setAssets] = useState(500000);
  const [claimPercentage, setClaimPercentage] = useState(50);
  const [returnRate, setReturnRate] = useSharedField("growthRate", 5);

  const calculations = useMemo(() => {
    const yearsToRetirement = 65 - age;
    const remainingAssetsCalc = assets * (1 - claimPercentage / 100);
    const futureValueWithoutIUL = remainingAssetsCalc * Math.pow(1 + returnRate / 100, yearsToRetirement);
    const futureValueWithIUL = futureValueWithoutIUL * 1.15;  // Assuming 15% advantage for tax-free growth
    return {
      remainingAssets: remainingAssetsCalc,
      futureValueWithoutIUL,
      futureValueWithIUL,
    };
  }, [age, assets, claimPercentage, returnRate]);
  const projectionData = useMemo(() => {
    const d = [];
    let opt = 100000, base = 100000, taxSav = 0;
    for (let yr = 0; yr <= 50; yr++) {
      opt *= 1.075;
      base *= 1.05;
      taxSav += (opt - base) * 0.08;
      d.push({ year: yr, optimized: Math.round(opt), baseline: Math.round(base), taxSavings: Math.round(taxSav), netBenefit: Math.round(opt - base + taxSav) });
    }
    return d;
  }, []);


  return (
    <AppShell
      className="bg-[#0a0f1a] text-white min-h-screen"
      header={
        <div className="flex items-center p-4 bg-[#0d1526]">
          <CalculatorIcon className="mr-2" />
          <h1 className="text-xl font-bold">Divorce Financial Settlement Analyzer</h1>
        </div>
      }
    >
      <div className="p-6 max-w-4xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="text-emerald-400">Input Parameters</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label>Current Age (25-65)</Label>
                  <Slider
                    min={25}
                    max={65}
                    step={1}
                    value={[age]}
                    onValueChange={(value) => setAge(value[0])}
                    className="mt-2"
                  />
                  <Input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(parseInt(e.target.value) || 40)}
                    className="mt-2 bg-slate-700 border-[#1e3a5f]"
                  />
                </div>
                <div>
                  <Label>Total Assets ($0 - $2,000,000)</Label>
                  <Slider
                    min={0}
                    max={2000000}
                    step={10000}
                    value={[assets]}
                    onValueChange={(value) => setAssets(value[0])}
                    className="mt-2"
                  />
                  <Input
                    type="number"
                    value={assets}
                    onChange={(e) => setAssets(parseInt(e.target.value) || 500000)}
                    className="mt-2 bg-slate-700 border-[#1e3a5f]"
                  />
                </div>
                <div>
                  <Label>Spouse's Claim Percentage (0-100%)</Label>
                  <Slider
                    min={0}
                    max={100}
                    step={1}
                    value={[claimPercentage]}
                    onValueChange={(value) => setClaimPercentage(value[0])}
                    className="mt-2"
                  />
                  <Input
                    type="number"
                    value={claimPercentage}
                    onChange={(e) => setClaimPercentage(parseInt(e.target.value) || 50)}
                    className="mt-2 bg-slate-700 border-[#1e3a5f]"
                  />
                </div>
                <div>
                  <Label>Assumed Return Rate (0-10%)</Label>
                  <Slider
                    min={0}
                    max={10}
                    step={0.5}
                    value={[returnRate]}
                    onValueChange={(value) => setReturnRate(value[0])}
                    className="mt-2"
                  />
                  <Input
                    type="number"
                    value={returnRate}
                    onChange={(e) => setReturnRate(parseFloat(e.target.value) || 5)}
                    className="mt-2 bg-slate-700 border-[#1e3a5f]"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle className="text-emerald-400">Calculation Results</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p>Remaining Assets After Settlement:</p>
                  <p className="text-2xl font-bold">{formatDollars(calculations.remainingAssets)}</p>
                </div>
                <div>
                  <p>Projected Future Value Without IUL:</p>
                  <p className="text-2xl font-bold">{formatDollars(calculations.futureValueWithoutIUL)}</p>
                </div>
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />
                
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "optimized", label: "Optimized Strategy", color: "#10b981" }, { key: "baseline", label: "Baseline (No Action)", color: "#ef4444" }, { key: "taxSavings", label: "Cumulative Tax Savings", color: "#06b6d4" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div>
                  <p>Projected Future Value With IUL:</p>
                  <p className="text-2xl font-bold">{formatDollars(calculations.futureValueWithIUL)}</p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle className="text-emerald-400">IUL Advantage</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Indexed Universal Life (IUL) insurance offers tax-free growth on your investments, which can significantly enhance your financial settlement outcomes. In this analysis, IUL provides an estimated 15% advantage in future value by shielding growth from taxes, helping you retain more wealth post-divorce.</p>
              </CardContent>
            </Card>

            <Button
              onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
              className="w-full bg-emerald-500 hover:bg-emerald-600"
            >
              Send to AI Advisor
            </Button>
          </div>
        </div>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("divorce-settlement-enhanced", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-divorce-settlement-enhanced");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Divorce Financial Settlement Analyzer (Enhanced)"
            calculatorRoute="divorce-settlement-enhanced"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="divorce-settlement-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/divorce-settlement-enhanced" />
</div>
    </AppShell>
  );
}