// @ts-nocheck

import { useState, useMemo } from "react";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BookOpen } from 'lucide-react';
import { toast } from "sonner";
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function Education529VsIULCalc() {
  const autoFill = useCalculatorAutoFill("529-vs-iul");
  const { reportResult } = useCalcResults();
  const [parentAge, setParentAge] = useState(30);
  const [childAge, setChildAge] = useState(5);
  const [initialInvestment, setInitialInvestment] = useState(10000);
  const [annualContribution, setAnnualContribution] = useState(2000);
  const [returnRate529, setReturnRate529] = useState(6);
  const [returnRateIUL, setReturnRateIUL] = useState(7);
  const yearsUntilEducation = useMemo(() => 18 - childAge, [childAge]);

  const calculations = useMemo(() => {
    const r529 = returnRate529 / 100;
    const rIUL = returnRateIUL / 100;
    
    const fv529 = initialInvestment * Math.pow(1 + r529, yearsUntilEducation) +
      annualContribution * ((Math.pow(1 + r529, yearsUntilEducation) - 1) / r529);
    
    const fvIUL = initialInvestment * Math.pow(1 + rIUL, yearsUntilEducation) +
      annualContribution * ((Math.pow(1 + rIUL, yearsUntilEducation) - 1) / rIUL);
    
    const taxAdvantage = fvIUL - fv529;  // Simplified difference
    
    return { fv529, fvIUL, taxAdvantage };
  }, [initialInvestment, annualContribution, returnRate529, returnRateIUL, yearsUntilEducation]);
  const projectionData = useMemo(() => {
    const d = [];
    const startWealth = typeof netWorth !== 'undefined' ? netWorth : 200000;
    const annualSave = typeof annualSavings !== 'undefined' ? annualSavings : 50000;
    let wealth = startWealth, invest = startWealth * 0.6, savings = startWealth * 0.1, debtPaid = 0;
    for (let yr = 0; yr <= 50; yr++) {
      invest = invest * 1.08 + annualSave * 0.7;
      savings = Math.min(annualSave * 2, savings * 1.04 + annualSave * 0.1);
      debtPaid += Math.min(annualSave * 0.2, 30000);
      wealth = invest + savings + debtPaid;
      d.push({ year: yr, totalWealth: Math.round(wealth), investments: Math.round(invest), savings: Math.round(savings), debtPayoff: Math.round(debtPaid) });
    }
    return d;
  }, []);


  return (
    <AppShell
      headerTitle="529 vs IUL Education Funding Comparison"
      headerSubtitle="Wealth Building & Savings"
      className="bg-[#0a0f1a] text-white"
    >
      <div className="p-6">
        <AutoFillBanner calcRoute="529-vs-iul" />
        <h2 className="text-2xl font-bold mb-6 text-emerald-400 flex items-center">
          <BookOpen className="mr-2" /> Input Your Details
        </h2>
        
        {/* Input Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div>
            <Label>Parent's Current Age (20-60)</Label>
            <Slider
              min={20}
              max={60}
              step={1}
              value={[parentAge]}
              onValueChange={(value) => setParentAge(value[0])}
              className="mt-2"
            />
            <Input
              type="number"
              value={parentAge}
              onChange={(e) => setParentAge(Number(e.target.value))}
              className="mt-2 bg-[#0d1526] border-[#1e3a5f]"
            />
          </div>
          
          <div>
            <Label>Child's Current Age (0-18)</Label>
            <Slider
              min={0}
              max={18}
              step={1}
              value={[childAge]}
              onValueChange={(value) => setChildAge(value[0])}
              className="mt-2"
            />
            <Input
              type="number"
              value={childAge}
              onChange={(e) => setChildAge(Number(e.target.value))}
              className="mt-2 bg-[#0d1526] border-[#1e3a5f]"
            />
          </div>
          
          <div>
            <Label>Initial Investment ($0 - $100,000)</Label>
            <Input
              type="number"
              value={initialInvestment}
              onChange={(e) => setInitialInvestment(Number(e.target.value))}
              className="mt-2 bg-[#0d1526] border-[#1e3a5f]"
            />
          </div>
          
          <div>
            <Label>Annual Contribution ($0 - $10,000)</Label>
            <Input
              type="number"
              value={annualContribution}
              onChange={(e) => setAnnualContribution(Number(e.target.value))}
              className="mt-2 bg-[#0d1526] border-[#1e3a5f]"
            />
          </div>
          
          <div>
            <Label>Expected Annual Return for 529 (4% - 10%)</Label>
            <Slider
              min={4}
              max={10}
              step={0.5}
              value={[returnRate529]}
              onValueChange={(value) => setReturnRate529(value[0])}
              className="mt-2"
            />
            <Input
              type="number"
              value={returnRate529}
              onChange={(e) => setReturnRate529(Number(e.target.value))}
              className="mt-2 bg-[#0d1526] border-[#1e3a5f]"
            />
          </div>
          
          <div>
            <Label>Expected Annual Return for IUL (5% - 12%)</Label>
            <Slider
              min={5}
              max={12}
              step={0.5}
              value={[returnRateIUL]}
              onValueChange={(value) => setReturnRateIUL(value[0])}
              className="mt-2"
            />
            <Input
              type="number"
              value={returnRateIUL}
              onChange={(e) => setReturnRateIUL(Number(e.target.value))}
              className="mt-2 bg-[#0d1526] border-[#1e3a5f]"
            />
          </div>
        </div>
        
        {/* Results Section */}
        <h2 className="text-2xl font-bold mb-6 text-emerald-400">Results</h2>
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />
        
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "totalWealth", label: "Total Wealth", color: "#10b981" }, { key: "investments", label: "Investment Growth", color: "#06b6d4" }, { key: "savings", label: "Emergency Fund", color: "#f59e0b" }, { key: "debtPayoff", label: "Debt Eliminated", color: "#a855f7" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle>Projected 529 Value</CardTitle>
            </CardHeader>
            <CardContent>
              <p>{formatDollars(calculations.fv529)}</p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle>Projected IUL Value</CardTitle>
            </CardHeader>
            <CardContent>
              <p>{formatDollars(calculations.fvIUL)}</p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle>IUL Tax Advantage</CardTitle>
            </CardHeader>
            <CardContent>
              <p>{formatDollars(calculations.taxAdvantage)}</p>
            </CardContent>
          </Card>
        </div>
        
        {/* IUL Advantage Section */}
        <Card className="bg-[#0d1526] border-[#1e3a5f] mb-8">
          <CardHeader>
            <CardTitle>IUL Advantage</CardTitle>
          </CardHeader>
          <CardContent>
            <p>IUL provides tax-free growth and withdrawals for qualified education expenses, offering more flexibility than 529 plans which are limited to education and may have state taxes.</p>
          </CardContent>
        </Card>
        
        {/* Send to AI Advisor Button */}
        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-500 hover:bg-emerald-600"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("529-vs-iul", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-529-vs-iul");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="529 vs IUL Education Funding Comparison"
            calculatorRoute="529-vs-iul"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="education529-vs-i-u-l-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/529-vs-iul" />
</div>
    </AppShell>
  );
}