// @ts-nocheck

import { useState, useMemo } from "react";
import { ResultReveal } from "@/components/ResultReveal";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calculator } from 'lucide-react';
import { toast } from "sonner";
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function AnnuityComparisonCalc() {
  const autoFill = useCalculatorAutoFill("annuity-comparison");
  const { reportResult } = useCalcResults();
  const [initialAmount, setInitialAmount] = useState(10000);
  const [annualContribution, setAnnualContribution] = useState(5000);
  const [annuityRate, setAnnuityRate] = useState(0.05); // 5%
  const [iulRate, setIulRate] = useState(0.07); // 7%
  const [years, setYears] = useSharedField("projectionYears", 20);

  const calculations = useMemo(() => {
    const calculateFutureValue = (rate: number) => {
      const fvInitial = initialAmount * (1 + rate) ** years;
      const fvContributions = annualContribution * ((1 + rate) ** years - 1) / rate;
      return fvInitial + fvContributions;
    };

    const futureValueAnnuity = calculateFutureValue(annuityRate);
    const futureValueIUL = calculateFutureValue(iulRate);
    const advantage = futureValueIUL - futureValueAnnuity;

    return {
      futureValueAnnuity,
      futureValueIUL,
      advantage,
    };
  }, [initialAmount, annualContribution, annuityRate, iulRate, years]);
  const projectionData = useMemo(() => {
    const d = [];
    let opt = 100000, base = 100000, taxSav = 0;
    for (let yr = 0; yr <= 50; yr++) {
      opt *= 1.075;
      base *= 1.05;
      taxSav += (opt - base) * 0.08;
      d.push({ year: yr, optimized: Math.round(opt), baseline: Math.round(base), taxSavings: Math.round(taxSav), netBenefit: Math.round(opt - base + taxSav) });
    }
    return d;
  }, []);


  return (
    <AppShell
      headerTitle="Annuity Comparison Calculator"
      headerSubtitle="Compare traditional annuities with IUL for tax-free growth advantages"
      icon={<Calculator className="h-6 w-6 text-emerald-400" />}
    >
      <div className="p-6 bg-[#0a0f1a] min-h-screen">
        <Card className="mb-6 bg-[#0d1526] border border-[#1e3a5f]">
          <CardHeader>
            <CardTitle className="text-white">Input Parameters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label className="text-white">Initial Amount</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={initialAmount}
                    onChange={(e) => setInitialAmount(Number(e.target.value))}
                    className="bg-slate-700 text-white"
                  />
                  <Slider
                    min={0}
                    max={100000}
                    step={1000}
                    value={[initialAmount]}
                    onValueChange={(value) => setInitialAmount(value[0])}
                    className="w-full"
                  />
                </div>
              </div>
              <div>
                <Label className="text-white">Annual Contribution</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={annualContribution}
                    onChange={(e) => setAnnualContribution(Number(e.target.value))}
                    className="bg-slate-700 text-white"
                  />
                  <Slider
                    min={0}
                    max={20000}
                    step={500}
                    value={[annualContribution]}
                    onValueChange={(value) => setAnnualContribution(value[0])}
                    className="w-full"
                  />
                </div>
              </div>
              <div>
                <Label className="text-white">Annuity Growth Rate (%)</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={annuityRate * 100}
                    onChange={(e) => setAnnuityRate(Number(e.target.value) / 100)}
                    className="bg-slate-700 text-white"
                  />
                  <Slider
                    min={0}
                    max={10}
                    step={0.1}
                    value={[annuityRate * 100]}
                    onValueChange={(value) => setAnnuityRate(value[0] / 100)}
                    className="w-full"
                  />
                </div>
              </div>
              <div>
                <Label className="text-white">IUL Growth Rate (%)</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={iulRate * 100}
                    onChange={(e) => setIulRate(Number(e.target.value) / 100)}
                    className="bg-slate-700 text-white"
                  />
                  <Slider
                    min={0}
                    max={10}
                    step={0.1}
                    value={[iulRate * 100]}
                    onValueChange={(value) => setIulRate(value[0] / 100)}
                    className="w-full"
                  />
                </div>
              </div>
              <div>
                <Label className="text-white">Investment Years</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={years}
                    onChange={(e) => setYears(Number(e.target.value))}
                    className="bg-slate-700 text-white"
                  />
                  <Slider
                    min={1}
                    max={50}
                    step={1}
                    value={[years]}
                    onValueChange={(value) => setYears(value[0])}
                    className="w-full"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />

        
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "optimized", label: "Optimized Strategy", color: "#10b981" }, { key: "baseline", label: "Baseline (No Action)", color: "#ef4444" }, { key: "taxSavings", label: "Cumulative Tax Savings", color: "#06b6d4" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card className="bg-[#0d1526] border border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="text-white">Future Value of Annuity</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl text-emerald-400">{formatDollars(calculations.futureValueAnnuity)}</p>
            </CardContent>
          </Card>
          <Card className="bg-[#0d1526] border border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="text-white">Future Value of IUL</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl text-emerald-400">{formatDollars(calculations.futureValueIUL)}</p>
            </CardContent>
          </Card>
          <Card className="bg-[#0d1526] border border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="text-white">IUL Advantage</CardTitle>
            </CardHeader>
            <CardContent>
              <ResultReveal value={calculations.advantage} prefix="$" label="IUL Advantage" />
              <p className="text-white mt-2">IUL provides tax-free growth, resulting in higher returns compared to traditional annuities.</p>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-6 bg-[#0d1526] border border-[#1e3a5f]">
          <CardHeader>
            <CardTitle className="text-white">IUL Advantage Explanation</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-white">
              Indexed Universal Life (IUL) offers tax-free growth on your investments, which can lead to a significant advantage over traditional annuities. In this comparison, IUL shows an additional{" "}
              {formatDollars(calculations.advantage)} in potential growth due to its tax benefits and competitive returns.
            </p>
          </CardContent>
        </Card>

        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-500 hover:bg-emerald-600 text-white"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("annuity-comparison", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-annuity-comparison");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Annuity Comparison Calculator"
            calculatorRoute="annuity-comparison"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="annuity-comparison-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/annuity-comparison" />
</div>
    </AppShell>
  );
}