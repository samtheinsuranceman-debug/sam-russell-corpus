// @ts-nocheck
import { useState, useMemo } from "react";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Circle, CalculatorIcon} from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function BondLadderCalc() {
  const autoFill = useCalculatorAutoFill("bond-ladder");
  const { reportResult } = useCalcResults();
  const [initialInvestment, setInitialInvestment] = useState(100000);
  const [numberOfBonds, setNumberOfBonds] = useState(10);
  const [averageDuration, setAverageDuration] = useState(5);
  const [interestRate, setInterestRate] = useState(3);

  const calculations = useMemo(() => {
    const annualIncome = (initialInvestment * (interestRate / 100)) / numberOfBonds;
    const totalPortfolioValue = initialInvestment * (1 + (interestRate / 100) * averageDuration);
    const estimatedDuration = averageDuration * (numberOfBonds / 10);  // Simplified weighted average
    return { annualIncome, totalPortfolioValue, estimatedDuration };
  }, [initialInvestment, numberOfBonds, averageDuration, interestRate]);
  const projectionData = useMemo(() => {
    const d = [];
    const startVal = typeof investmentAmount !== 'undefined' ? investmentAmount : 100000;
    const annualAdd = typeof annualContribution !== 'undefined' ? annualContribution : 20000;
    let agg = startVal, mod = startVal, cons = startVal, infl = startVal;
    for (let yr = 0; yr <= 50; yr++) {
      d.push({ year: yr, aggressive: Math.round(agg), moderate: Math.round(mod), conservative: Math.round(cons), inflation: Math.round(infl) });
      agg = (agg + annualAdd) * 1.085;
      mod = (mod + annualAdd) * 1.065;
      cons = (cons + annualAdd) * 1.045;
      infl = (infl + annualAdd) * 1.03;
    }
    return d;
  }, []);


  return (
    <AppShell>
      <div className="p-6 bg-[#0a0f1a] min-h-screen">
        <AutoFillBanner calcRoute="bond-ladder" />
        <div className="flex flex-col items-center justify-center">
          <div className="w-full max-w-4xl">
            <Card className="bg-[#0d1526] border-[#1e3a5f] mb-6">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <CalculatorIcon className="mr-2 h-6 w-6 text-emerald-400" />
                  Bond Ladder Builder & Duration Calculator
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <Label className="text-white">Initial Investment</Label>
                    <div className="flex items-center space-x-4 mt-2">
                      <Input
                        type="number"
                        value={initialInvestment}
                        onChange={(e) => setInitialInvestment(Number(e.target.value))}
                        className="bg-slate-700 text-white"
                      />
                      <Slider
                        min={10000}
                        max={1000000}
                        step={10000}
                        value={[initialInvestment]}
                        onValueChange={(value) => setInitialInvestment(value[0])}
                        className="w-full"
                      />
                    </div>
                  </div>
                  <div>
                    <Label className="text-white">Number of Bonds</Label>
                    <div className="flex items-center space-x-4 mt-2">
                      <Input
                        type="number"
                        value={numberOfBonds}
                        onChange={(e) => setNumberOfBonds(Number(e.target.value))}
                        className="bg-slate-700 text-white"
                      />
                      <Slider
                        min={1}
                        max={20}
                        step={1}
                        value={[numberOfBonds]}
                        onValueChange={(value) => setNumberOfBonds(value[0])}
                        className="w-full"
                      />
                    </div>
                  </div>
                  <div>
                    <Label className="text-white">Average Duration (Years)</Label>
                    <div className="flex items-center space-x-4 mt-2">
                      <Input
                        type="number"
                        value={averageDuration}
                        onChange={(e) => setAverageDuration(Number(e.target.value))}
                        className="bg-slate-700 text-white"
                      />
                      <Slider
                        min={1}
                        max={30}
                        step={1}
                        value={[averageDuration]}
                        onValueChange={(value) => setAverageDuration(value[0])}
                        className="w-full"
                      />
                    </div>
                  </div>
                  <div>
                    <Label className="text-white">Interest Rate (%)</Label>
                    <div className="flex items-center space-x-4 mt-2">
                      <Input
                        type="number"
                        value={interestRate}
                        onChange={(e) => setInterestRate(Number(e.target.value))}
                        className="bg-slate-700 text-white"
                      />
                      <Slider
                        min={0}
                        max={10}
                        step={0.1}
                        value={[interestRate]}
                        onValueChange={(value) => setInterestRate(value[0])}
                        className="w-full"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />

            
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "aggressive", label: "Aggressive (8.5%)", color: "#10b981" }, { key: "moderate", label: "Moderate (6.5%)", color: "#06b6d4" }, { key: "conservative", label: "Conservative (4.5%)", color: "#f59e0b" }, { key: "inflation", label: "Inflation Erosion", color: "#ef4444" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <Card className="bg-[#0d1526] border-[#1e3a5f]">
                <CardHeader>
                  <CardTitle className="text-emerald-400">Total Portfolio Value</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-white text-2xl font-bold">{formatDollars(calculations.totalPortfolioValue)}</p>
                </CardContent>
              </Card>
              <Card className="bg-[#0d1526] border-[#1e3a5f]">
                <CardHeader>
                  <CardTitle className="text-emerald-400">Estimated Annual Income</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-white text-2xl font-bold">{formatDollars(calculations.annualIncome * numberOfBonds)}</p>
                </CardContent>
              </Card>
              <Card className="bg-[#0d1526] border-[#1e3a5f]">
                <CardHeader>
                  <CardTitle className="text-emerald-400">Average Duration (Years)</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-white text-2xl font-bold">{calculations.estimatedDuration.toFixed(1)}</p>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-[#0d1526] border-[#1e3a5f] mb-6">
              <CardHeader>
                <CardTitle className="text-white">IUL Advantage</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-white">
                  Indexed Universal Life (IUL) insurance offers tax-free growth, providing a potential advantage over traditional bond ladders. While bonds may offer fixed income, IUL can accumulate cash value with market-linked returns, helping to shield your portfolio from taxes and inflation for long-term financial security.
                </p>
              </CardContent>
            </Card>

            <Button
              onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
              className="w-full bg-emerald-500 hover:bg-emerald-600 text-white"
            >
              Send to AI Advisor
            </Button>
          </div>
        </div>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("bond-ladder", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-bond-ladder");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Bond Ladder Builder & Duration Calculator"
            calculatorRoute="bond-ladder"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="bond-ladder-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/bond-ladder" />
</div>
    </AppShell>
  );
}