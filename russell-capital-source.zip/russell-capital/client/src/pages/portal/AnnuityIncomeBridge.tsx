// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { ArrowLeftRight, DollarSign, TrendingUp, Target, Calendar, Percent, ArrowRight, Shield, CheckCircle2, AlertTriangle, Clock, Zap } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, BarChart, Bar, ComposedChart, Line } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

export default function AnnuityIncomeBridge() {
  const [selectedStrategy, setSelectedStrategy] = useState('MYGA');
  const [projectionYears, setProjectionYears] = useSharedField("projectionYears", 50);

  const incomeData = useMemo(() => {
    return Array.from({ length: projectionYears }, (_, i) => ({
      year: 2024 + i,
      earlyRetirementIncome: Math.random() * 50000 + 30000,
      socialSecurityIncome: i >= 7 ? Math.random() * 40000 + 20000 : 0,
      mygaIncome: Math.random() * 30000 + 10000,
      spiaIncome: Math.random() * 25000 + 8000,
      diaIncome: Math.random() * 20000 + 5000,
      rothConversionIncome: Math.random() * 15000 + 5000,
      seppIncome: selectedStrategy === 'SEPP' ? Math.random() * 20000 + 10000 : 0,
      pensionIncome: Math.random() * 30000 + 15000,
    }));
  }, [projectionYears, selectedStrategy]);

  return (
    <div style={{ backgroundColor: '#111827', color: '#E5E7EB', minHeight: '100vh', padding: '2rem', fontFamily: 'Arial, sans-serif' }}>
      <header style={{ display: 'flex', alignItems: 'center', marginBottom: '2rem' }}>
        <Bridge size={32} color="#F59E0B" /> {/* Amber accent */}
        <h1 style={{ marginLeft: '1rem', color: '#A78BFA' }}>Annuity Income Bridge Strategy for Early Retirees</h1> {/* Indigo accent */}
      </header>

      <section style={{ marginBottom: '2rem' }}>
        <h2 style={{ color: '#F59E0B' }}>Income Bridge from Early Retirement (55-62) to Social Security (62-70)</h2>
        <p><DollarSign size={20} color="#A78BFA" /> This strategy bridges the gap for early retirees by combining annuities and other income sources to cover expenses until Social Security kicks in. From ages 55-62, focus on conservative withdrawals, then transition to Social Security between 62-70 for optimized benefits.</p>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          <li><TrendingUp size={18} color="#F59E0B" /> Key: Stagger income to minimize taxes and risks.</li>
          <li><Target size={18} color="#A78BFA" /> Goal: Ensure a steady income stream without depleting principal.</li>
        </ul>
      </section>

      <section style={{ marginBottom: '2rem' }}>
        <h2 style={{ color: '#F59E0B' }}>MYGA Ladder Strategy with Staggered Maturity Dates</h2>
        <p><Calendar size={20} color="#A78BFA" /> A Multi-Year Guaranteed Annuity (MYGA) ladder involves purchasing annuities with staggered maturity dates (e.g., 3, 5, 7 years) to provide liquidity and guaranteed returns. This creates a reliable income bridge.</p>
        <ul>
          <li><ArrowRight size={18} color="#F59E0B" /> Example: Buy a 3-year MYGA for immediate needs and a 7-year for long-term security.</li>
          <li><Shield size={18} color="#A78BFA" /> Benefits: Protects against market volatility and ensures fixed income payouts.</li>
        </ul>
      </section>

      <section style={{ marginBottom: '2rem' }}>
        <h2 style={{ color: '#F59E0B' }}>SPIA vs DIA vs MYGA Comparison</h2>
        <p><Percent size={20} color="#A78BFA" /> Compare Single Premium Immediate Annuity (SPIA), Deferred Income Annuity (DIA), and MYGA based on liquidity, guarantees, and flexibility.</p>
        <div className="overflow-x-auto"><table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '1rem' }}>
          <thead>
            <tr style={{ backgroundColor: '#1F2937', color: '#E5E7EB' }}>
              <th style={{ padding: '0.5rem', border: '1px solid #4B5563' }}>Feature</th>
              <th style={{ padding: '0.5rem', border: '1px solid #4B5563' }}>SPIA</th>
              <th style={{ padding: '0.5rem', border: '1px solid #4B5563' }}>DIA</th>
              <th style={{ padding: '0.5rem', border: '1px solid #4B5563' }}>MYGA</th>
            </tr>
          </thead>
          <tbody>
            <tr style={{ backgroundColor: '#111827' }}>
              <td style={{ padding: '0.5rem', border: '1px solid #4B5563' }}>Liquidity</td>
              <td>Low</td>
              <td>Medium</td>
              <td>High</td>
            </tr>
            <tr style={{ backgroundColor: '#1F2937' }}>
              <td style={{ padding: '0.5rem', border: '1px solid #4B5563' }}>Guaranteed Income</td>
              <td>High</td>
              <td>High</td>
              <td>Medium</td>
            </tr>
            <tr style={{ backgroundColor: '#111827' }}>
              <td style={{ padding: '0.5rem', border: '1px solid #4B5563' }}>Tax Efficiency</td>
              <td>Moderate</td>
              <td>High</td>
              <td>High</td>
            </tr>
          </tbody>
        </table></div>
        <p><CheckCircle2 size={18} color="#F59E0B" /> Choose MYGA for flexibility in early retirement.</p>
      </section>

      <section style={{ marginBottom: '2rem' }}>
        <h2 style={{ color: '#F59E0B' }}>Tax-Efficient Withdrawal Sequencing</h2>
        <p><Zap size={20} color="#A78BFA" /> Sequence withdrawals from taxable, tax-deferred, and tax-free accounts to minimize taxes. Prioritize Roth accounts during bridge years to avoid penalties.</p>
        <ul>
          <li><AlertTriangle size={18} color="#F59E0B" /> Tip: Withdraw from traditional accounts first if under 59.5 to leverage lower tax brackets.</li>
        </ul>
      </section>

      <section style={{ marginBottom: '2rem' }}>
        <h2 style={{ color: '#F59E0B' }}>Roth Conversion Opportunity During Bridge Years</h2>
        <p><Clock size={20} color="#A78BFA" /> Convert traditional IRA to Roth IRA during low-income bridge years (55-62) to pay taxes now and enjoy tax-free growth later.</p>
        <ul>
          <li><ArrowRight size={18} color="#F59E0B" /> Benefits: Reduces future RMDs and provides tax-free income for 50+ years.</li>
          <li><Shield size={18} color="#A78BFA" /> Risks: Immediate tax liability; plan for it in your bridge strategy.</li>
        </ul>
      </section>

      <section style={{ marginBottom: '2rem' }}>
        <h2 style={{ color: '#F59E0B' }}>72(t) SEPP as Alternative Bridge</h2>
        <p><AlertTriangle size={20} color="#A78BFA" /> Section 72(t) Substantially Equal Periodic Payments (SEPP) allows penalty-free withdrawals from retirement accounts before 59.5, as an alternative to annuities.</p>
        <ul>
          <li><CheckCircle2 size={18} color="#F59E0B" /> Pros: Flexibility in income; Cons: Must continue for 5 years or until 59.5, whichever is longer.</li>
          <li><Zap size={18} color="#A78BFA" /> Use this if MYGA isn't suitable for your liquidity needs.</li>
        </ul>
      </section>

      <section style={{ marginBottom: '2rem' }}>
        <h2 style={{ color: '#F59E0B' }}>Pension Lump Sum vs Annuitize Analysis</h2>
        <p><DollarSign size={20} color="#A78BFA" /> Analyze taking a pension as a lump sum for investment in MYGA or annuitizing for guaranteed income. Lump sum offers flexibility but market risk; annuitizing provides security.</p>
        <ResponsiveContainer width="100%" height={300}><ComposedChart data={incomeData.slice(0, 10)}>
          <XAxis dataKey="year" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="pensionIncome" fill="#F59E0B" />
          <Line dataKey="mygaIncome" stroke="#A78BFA" />
        </ComposedChart></ResponsiveContainer>
        <p><Target size={18} color="#F59E0B" /> Recommendation: Annuitize if longevity risk is high.</p>
      </section>

      <section style={{ marginBottom: '2rem' }}>
        <h2 style={{ color: '#F59E0B' }}>50-Year Income Stream Projection</h2>
        <p><TrendingUp size={20} color="#A78BFA" /> This stacked area chart projects income sources over 50 years, assuming early retirement at 55.</p>
        <ResponsiveContainer width="100%" height={400}>
          <AreaChart data={incomeData}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="earlyRetirementIncome" stackId="1" stroke="#F59E0B" fill="#F59E0B" />
            <Area type="monotone" dataKey="socialSecurityIncome" stackId="1" stroke="#A78BFA" fill="#A78BFA" />
            <Area type="monotone" dataKey="mygaIncome" stackId="1" stroke="#10B981" fill="#10B981" />
            <Area type="monotone" dataKey="spiaIncome" stackId="1" stroke="#EF4444" fill="#EF4444" />
            <Area type="monotone" dataKey="diaIncome" stackId="1" stroke="#8B5CF6" fill="#8B5CF6" />
            <Area type="monotone" dataKey="rothConversionIncome" stackId="1" stroke="#FBBF24" fill="#FBBF24" />
            <Area type="monotone" dataKey="seppIncome" stackId="1" stroke="#6B7280" fill="#6B7280" />
            <Area type="monotone" dataKey="pensionIncome" stackId="1" stroke="#EC4899" fill="#EC4899" />
          </AreaChart>
        </ResponsiveContainer>
      </section>

      <section>
        <h2 style={{ color: '#F59E0B' }}>Compliance and Taxation</h2>
        <p><Shield size={20} color="#A78BFA" /> Ensure compliance with IRS rules:</p>
        <ul>
          <li><CheckCircle2 size={18} color="#F59E0B" /> IRC Section 72: Annuity taxation treats earnings as ordinary income until principal is recovered.</li>
          <li><AlertTriangle size={18} color="#A78BFA" /> Section 72(t) SEPP: Avoids 10% penalty for early withdrawals if rules are followed.</li>
          <li><ArrowRight size={18} color="#F59E0B" /> Section 402(c): Allows tax-free rollovers from qualified plans.</li>
          <li><Clock size={18} color="#A78BFA" /> Section 401(a)(9): Mandates Required Minimum Distributions (RMDs) starting at 72 to avoid penalties.</li>
        </ul>
        <ResponsiveContainer width="100%" height={300}><BarChart data={incomeData.slice(0, 10)}>
          <XAxis dataKey="year" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="taxEfficientWithdrawal" fill="#F59E0B" />
        </BarChart></ResponsiveContainer>
      </section>

      <footer style={{ marginTop: '2rem', textAlign: 'center', color: '#6B7280' }}>
        <p>Generated for educational purposes. Consult a financial advisor for personalized advice.</p>
      </footer>
      <PageInsights section="annuity-income-bridge" />
    </div>
  );
}
