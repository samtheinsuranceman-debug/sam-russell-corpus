// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Droplets, DollarSign, TrendingUp, Target, Calendar, Percent, ArrowRight, Shield, CheckCircle2, AlertTriangle, Lock, Users } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, AreaChart, Area, ComposedChart, Line, PieChart, Pie, Cell } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

const EstateLiquidityPlanner = () => {
  const [estateValue, setEstateValue] = useState(5000000); // Initial estate value in dollars
  const [liquidAssets, setLiquidAssets] = useSharedField("liquidAssets", 1000000); // Initial liquid assets
  const [annualGrowthRate, setAnnualGrowthRate] = useState(3); // Percent
  const [insurancePremium, setInsurancePremium] = useState(50000); // Annual premium for ILIT
  const [policyDeathBenefit, setPolicyDeathBenefit] = useState(2000000); // Second-to-die policy benefit
  const [interestRate, setInterestRate] = useState(4); // Percent for IRC 6166
  const [loanAmount, setLoanAmount] = useState(1000000); // Graegin loan amount
  const [projectionYears, setProjectionYears] = useSharedField("projectionYears", 50); // Years for projection

  // Memoized calculations
  const liquidityGap = useMemo(() => estateValue - liquidAssets, [estateValue, liquidAssets]);
  const ilitFundedAmount = useMemo(() => insurancePremium * 10, [insurancePremium]); // Assuming 10 years funding
  const secondToDieValue = useMemo(() => policyDeathBenefit * (1 + (annualGrowthRate / 100)), [policyDeathBenefit, annualGrowthRate]);
  const irc6166Payment = useMemo(() => loanAmount * (interestRate / 100), [loanAmount, interestRate]);
  const graeginLoanInterest = useMemo(() => loanAmount * 0.02, [loanAmount]); // Simplified Graegin interest
  const projectedLiquidity = useMemo(() => {
    let projections = [];
    for (let year = 1; year <= projectionYears; year++) {
      projections.push({
        year,
        value: liquidAssets * Math.pow(1 + (annualGrowthRate / 100), year)
      });
    }
    return projections;
  }, [liquidAssets, annualGrowthRate, projectionYears]);

  const chartData = [
    { name: 'Year 1', liquidity: 1200000, gap: 3800000 },
    { name: 'Year 2', liquidity: 1300000, gap: 3700000 },
    { name: 'Year 3', liquidity: 1400000, gap: 3600000 },
    { name: 'Year 4', liquidity: 1500000, gap: 3500000 },
    { name: 'Year 5', liquidity: 1600000, gap: 3400000 },
  ];

  const pieData = [
    { name: 'Liquid Assets', value: liquidAssets },
    { name: 'Illiquid Assets', value: estateValue - liquidAssets },
  ];

  const COLORS = ['#10B981', '#0B6BCB']; // Emerald and Navy accents

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white p-8 font-sans">
      <header className="flex items-center mb-8">
        <Droplets className="mr-2" size={24} color="#10B981" />
        <h1 className="text-3xl font-bold">Estate Liquidity Planner</h1>
      </header>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4 flex items-center">
          <DollarSign className="mr-2" size={20} color="#10B981" />
          Estate Liquidity Gap Analysis
        </h2>
        <p className="mb-4 text-[#94a3b8]">Analyze the gap between your estate value and liquid assets.</p>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <input
            type="number"
            placeholder="Estate Value"
            value={estateValue}
            onChange={(e) => setEstateValue(Number(e.target.value))}
            className="bg-[#0d1526] p-2 rounded border border-[#1e3a5f]"
          />
          <input
            type="number"
            placeholder="Liquid Assets"
            value={liquidAssets}
            onChange={(e) => setLiquidAssets(Number(e.target.value))}
            className="bg-[#0d1526] p-2 rounded border border-[#1e3a5f]"
          />
        </div>
        <div className="bg-[#0d1526] p-6 rounded shadow">
          <p className="text-xl">Liquidity Gap: ${liquidityGap.toLocaleString()}</p>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <XAxis dataKey="name" stroke="#10B981" />
              <YAxis stroke="#10B981" />
              <Tooltip />
              <Legend />
              <Bar dataKey="liquidity" fill="#10B981" />
              <Bar dataKey="gap" fill="#0B6BCB" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4 flex items-center">
          <Shield className="mr-2" size={20} color="#10B981" />
          ILIT Premium Funding
        </h2>
        <p className="mb-4 text-[#94a3b8]">Plan for funding Irrevocable Life Insurance Trust premiums.</p>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <input
            type="number"
            placeholder="Annual Premium"
            value={insurancePremium}
            onChange={(e) => setInsurancePremium(Number(e.target.value))}
            className="bg-[#0d1526] p-2 rounded border border-[#1e3a5f]"
          />
        </div>
        <div className="bg-[#0d1526] p-6 rounded shadow">
          <p className="text-xl">Total Funded Amount: ${ilitFundedAmount.toLocaleString()}</p>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} fill="#8884d8">
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4 flex items-center">
          <Users className="mr-2" size={20} color="#10B981" />
          Second-to-Die Policy Analysis
        </h2>
        <p className="mb-4 text-[#94a3b8]">Evaluate the benefits of a second-to-die life insurance policy.</p>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <input
            type="number"
            placeholder="Death Benefit"
            value={policyDeathBenefit}
            onChange={(e) => setPolicyDeathBenefit(Number(e.target.value))}
            className="bg-[#0d1526] p-2 rounded border border-[#1e3a5f]"
          />
          <input
            type="number"
            placeholder="Annual Growth Rate (%)"
            value={annualGrowthRate}
            onChange={(e) => setAnnualGrowthRate(Number(e.target.value))}
            className="bg-[#0d1526] p-2 rounded border border-[#1e3a5f]"
          />
        </div>
        <div className="bg-[#0d1526] p-6 rounded shadow">
          <p className="text-xl">Projected Value: ${secondToDieValue.toLocaleString()}</p>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={projectedLiquidity}>
              <XAxis dataKey="year" stroke="#10B981" />
              <YAxis stroke="#10B981" />
              <Tooltip />
              <Area type="monotone" dataKey="value" stroke="#0B6BCB" fill="#10B981" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4 flex items-center">
          <Calendar className="mr-2" size={20} color="#10B981" />
          IRC 6166 Installment Payments
        </h2>
        <p className="mb-4 text-[#94a3b8]">Plan for estate tax payments over installments.</p>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <input
            type="number"
            placeholder="Loan Amount"
            value={loanAmount}
            onChange={(e) => setLoanAmount(Number(e.target.value))}
            className="bg-[#0d1526] p-2 rounded border border-[#1e3a5f]"
          />
          <input
            type="number"
            placeholder="Interest Rate (%)"
            value={interestRate}
            onChange={(e) => setInterestRate(Number(e.target.value))}
            className="bg-[#0d1526] p-2 rounded border border-[#1e3a5f]"
          />
        </div>
        <div className="bg-[#0d1526] p-6 rounded shadow">
          <p className="text-xl">Annual Payment: ${irc6166Payment.toLocaleString()}</p>
          <ResponsiveContainer width="100%" height={300}>
            <ComposedChart data={chartData}>
              <XAxis dataKey="name" stroke="#10B981" />
              <YAxis stroke="#10B981" />
              <Tooltip />
              <Legend />
              <Bar dataKey="liquidity" fill="#10B981" />
              <Line type="monotone" dataKey="gap" stroke="#0B6BCB" />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4 flex items-center">
          <Lock className="mr-2" size={20} color="#10B981" />
          Graegin Loan Strategy
        </h2>
        <p className="mb-4 text-[#94a3b8]">Implement a Graegin loan for tax-efficient liquidity.</p>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <input
            type="number"
            placeholder="Loan Amount"
            value={loanAmount}
            onChange={(e) => setLoanAmount(Number(e.target.value))}
            className="bg-[#0d1526] p-2 rounded border border-[#1e3a5f]"
          />
        </div>
        <div className="bg-[#0d1526] p-6 rounded shadow">
          <p className="text-xl">Annual Interest: ${graeginLoanInterest.toLocaleString()}</p>
          <ul className="list-disc pl-5 text-[#94a3b8]">
            <li>Step 1: Secure low-interest loan</li>
            <li>Step 2: Use for estate needs</li>
            <li>Step 3: Minimize tax impact</li>
          </ul>
        </div>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4 flex items-center">
          <TrendingUp className="mr-2" size={20} color="#10B981" />
          50-Year Estate Liquidity Projection
        </h2>
        <p className="mb-4 text-[#94a3b8]">Long-term projection of estate liquidity.</p>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <input
            type="number"
            placeholder="Annual Growth Rate (%)"
            value={annualGrowthRate}
            onChange={(e) => setAnnualGrowthRate(Number(e.target.value))}
            className="bg-[#0d1526] p-2 rounded border border-[#1e3a5f]"
          />
          <input
            type="number"
            placeholder="Projection Years"
            value={projectionYears}
            onChange={(e) => setProjectionYears(Number(e.target.value))}
            className="bg-[#0d1526] p-2 rounded border border-[#1e3a5f]"
          />
        </div>
        <div className="bg-[#0d1526] p-6 rounded shadow">
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={projectedLiquidity}>
              <XAxis dataKey="year" stroke="#10B981" />
              <YAxis stroke="#10B981" />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="value" stroke="#0B6BCB" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>

      <footer className="text-center text-gray-500 mt-12">
        <p>Icons by Lucide React | Charts by Recharts</p>
      </footer>
      <PageInsights section="estate-liquidity-planner" />
    </div>
  );
};

export default EstateLiquidityPlanner;