// @ts-nocheck

import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Circle, CalculatorIcon} from 'lucide-react';
import { toast } from "sonner";
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function CharitableStockCalc() {
  const autoFill = useCalculatorAutoFill("charitable-stock-donation");
  const { reportResult } = useCalcResults();
  const [stockValue, setStockValue] = useState(100000);
  const [costBasis, setCostBasis] = useState(50000);
  const [donationAmount, setDonationAmount] = useState(50000);
  const [taxRate, setTaxRate] = useSharedField("currentTaxBracket", 22); // Marginal tax rate in percent
  const [capitalGainsRate, setCapitalGainsRate] = useState(15); // Capital gains tax rate in percent

  const results = useMemo(() => {
    const capitalGainsSaved = ((stockValue - costBasis) * (capitalGainsRate / 100));
    const deductionBenefit = (donationAmount * (taxRate / 100));
    const totalTaxSavings = capitalGainsSaved + deductionBenefit;
    const netBenefit = totalTaxSavings - (donationAmount * 0.05); // Assuming 5% transaction cost for simplicity
    return {
      totalTaxSavings,
      netBenefit,
      iulAdvantageGrowth: totalTaxSavings * 1.05, // Hypothetical 5% growth in IUL
    };
  }, [stockValue, costBasis, donationAmount, taxRate, capitalGainsRate]);
  const projectionData = useMemo(() => {
    const d = [];
    const startVal = typeof portfolioValue !== 'undefined' ? portfolioValue : 1000000;
    let taxAlpha = 0, deferred = startVal, roth = 0, trad = startVal;
    for (let yr = 0; yr <= 50; yr++) {
      const conversionAmt = yr < 20 ? startVal * 0.05 : 0;
      roth = roth * 1.08 + conversionAmt;
      deferred = deferred * 1.07;
      trad = trad * 1.065;
      taxAlpha += (deferred * 0.075 - trad * 0.065) * 0.3;
      d.push({ year: yr, taxAlpha: Math.round(taxAlpha), deferredGrowth: Math.round(deferred), rothConversion: Math.round(roth), traditionalPath: Math.round(trad) });
    }
    return d;
  }, []);


  return (
    <AppShell
      headerTitle="Charitable Stock Donation Tax Savings Calculator"
      headerSubtitle="Advanced Tax Strategies"
    >
      <div className="p-6 bg-[#0a0f1a] min-h-screen text-white">
        <AutoFillBanner calcRoute="charitable-stock-donation" />
        <div className="max-w-4xl mx-auto">
          <Card className="mb-6 bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="flex items-center text-emerald-400">
                <CalculatorIcon className="mr-2" /> Input Parameters
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label>Stock Value</Label>
                  <div className="flex items-center space-x-2">
                    <Slider
                      min={10000}
                      max={500000}
                      step={1000}
                      value={[stockValue]}
                      onValueChange={(value) => setStockValue(value[0])}
                    />
                    <Input
                      type="number"
                      value={stockValue}
                      onChange={(e) => setStockValue(Number(e.target.value))}
                      className="w-32 bg-slate-700"
                    />
                  </div>
                </div>
                <div>
                  <Label>Cost Basis</Label>
                  <div className="flex items-center space-x-2">
                    <Slider
                      min={5000}
                      max={250000}
                      step={500}
                      value={[costBasis]}
                      onValueChange={(value) => setCostBasis(value[0])}
                    />
                    <Input
                      type="number"
                      value={costBasis}
                      onChange={(e) => setCostBasis(Number(e.target.value))}
                      className="w-32 bg-slate-700"
                    />
                  </div>
                </div>
                <div>
                  <Label>Donation Amount</Label>
                  <div className="flex items-center space-x-2">
                    <Slider
                      min={10000}
                      max={stockValue}
                      step={1000}
                      value={[donationAmount]}
                      onValueChange={(value) => setDonationAmount(value[0])}
                    />
                    <Input
                      type="number"
                      value={donationAmount}
                      onChange={(e) => setDonationAmount(Number(e.target.value))}
                      className="w-32 bg-slate-700"
                    />
                  </div>
                </div>
                <div>
                  <Label>Marginal Tax Rate (%)</Label>
                  <div className="flex items-center space-x-2">
                    <Slider
                      min={10}
                      max={37}
                      step={1}
                      value={[taxRate]}
                      onValueChange={(value) => setTaxRate(value[0])}
                    />
                    <Input
                      type="number"
                      value={taxRate}
                      onChange={(e) => setTaxRate(Number(e.target.value))}
                      className="w-32 bg-slate-700"
                    />
                  </div>
                </div>
                <div>
                  <Label>Capital Gains Tax Rate (%)</Label>
                  <div className="flex items-center space-x-2">
                    <Slider
                      min={0}
                      max={20}
                      step={1}
                      value={[capitalGainsRate]}
                      onValueChange={(value) => setCapitalGainsRate(value[0])}
                    />
                    <Input
                      type="number"
                      value={capitalGainsRate}
                      onChange={(e) => setCapitalGainsRate(Number(e.target.value))}
                      className="w-32 bg-slate-700"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />

          
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "taxAlpha", label: "Tax Alpha Generated", color: "#10b981" }, { key: "deferredGrowth", label: "Tax-Deferred Growth", color: "#06b6d4" }, { key: "rothConversion", label: "Roth Conversion Value", color: "#a855f7" }, { key: "traditionalPath", label: "Traditional Path", color: "#ef4444" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle>Total Tax Savings</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl text-emerald-400">{formatDollars(results.totalTaxSavings)}</p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle>Net Benefit</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl text-emerald-400">{formatDollars(results.netBenefit)}</p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle>Hypothetical IUL Growth</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl text-emerald-400">{formatDollars(results.iulAdvantageGrowth)}</p>
              </CardContent>
            </Card>
          </div>

          <Card className="mb-6 bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle>IUL Advantage</CardTitle>
            </CardHeader>
            <CardContent>
              <p>By using IUL, you can achieve tax-free growth on your investments, potentially offering greater long-term benefits than traditional charitable donations. For example, the tax savings from this donation could be reinvested in an IUL policy for compounded, tax-free returns.</p>
            </CardContent>
          </Card>

          <Button
            onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
            className="bg-emerald-500 hover:bg-emerald-600"
          >
            Send to AI Advisor
          </Button>
        </div>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("charitable-stock-donation", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-charitable-stock-donation");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Charitable Stock Donation Tax Savings Calculator"
            calculatorRoute="charitable-stock-donation"
            inputs={typeof results !== 'undefined' ? results : {}}
            results={typeof results !== 'undefined' ? results : {}}
            projectionData={projectionData}
          />
      <PageInsights section="charitable-stock-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/charitable-stock-donation" />
</div>
    </AppShell>
  );
}