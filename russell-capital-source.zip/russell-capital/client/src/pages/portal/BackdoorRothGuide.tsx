// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { DollarSign, TrendingUp, Shield, CheckCircle2, AlertTriangle, ArrowRight, Target, Zap, Calendar, Award, Lock, Scale } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

const BackdoorRothGuide: React.FC = () => {
  const [income, setIncome] = useSharedField("annualIncome", 400000); // Default income
  const [age, setAge] = useSharedField("currentAge", 40); // Default age

  // Generate projection data using useMemo for performance
  const projectionData = useMemo(() => {
    const initialContribution = 7000;
    const annualGrowthRate = 0.08;
    const years = 25;
    const data = [];
    let balance = 0;

    for (let year = 1; year <= years; year++) {
      balance += initialContribution; // Add annual contribution
      balance *= (1 + annualGrowthRate); // Apply growth
      data.push({ year, balance });
    }

    return data;
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white font-sans">
      {/* Header Section */}
      <header className="p-8 bg-gradient-to-r from-emerald-800 to-blue-900 text-center">
        <h1 className="text-4xl font-bold mb-4">Backdoor Roth IRA Guide</h1>
        <div className="flex justify-center items-center space-x-4">
          <div>
            <label className="block text-sm text-[#94a3b8]">Annual Income:</label>
            <input
              type="number"
              value={income}
              onChange={(e) => setIncome(Number(e.target.value))}
              className="bg-[#0d1526] border border-[#1e3a5f] rounded p-2 text-white"
              placeholder="$400,000"
            />
          </div>
          <div>
            <label className="block text-sm text-[#94a3b8]">Current Age:</label>
            <input
              type="number"
              value={age}
              onChange={(e) => setAge(Number(e.target.value))}
              className="bg-[#0d1526] border border-[#1e3a5f] rounded p-2 text-white"
              placeholder="40"
            />
          </div>
        </div>
      </header>

      {/* 3-Step Process Section */}
      <section className="p-8">
        <h2 className="text-3xl font-semibold mb-6 text-emerald-400">The 3-Step Backdoor Roth IRA Process</h2>
        <div className="flex flex-col md:flex-row justify-around items-center space-y-4 md:space-y-0 md:space-x-4">
          <div className="bg-[#0d1526] p-6 rounded-lg shadow-lg w-full md:w-1/3">
            <TrendingUp className="text-emerald-500 mb-4" size={32} />
            <h3 className="text-2xl font-bold mb-2">Step 1</h3>
            <p>Contribute $7,000 to Traditional IRA (non-deductible)</p>
          </div>
          <ArrowRight className="text-blue-500" size={48} />
          <div className="bg-[#0d1526] p-6 rounded-lg shadow-lg w-full md:w-1/3">
            <Shield className="text-emerald-500 mb-4" size={32} />
            <h3 className="text-2xl font-bold mb-2">Step 2</h3>
            <p>Convert to Roth IRA (no tax if no gains)</p>
          </div>
          <ArrowRight className="text-blue-500" size={48} />
          <div className="bg-[#0d1526] p-6 rounded-lg shadow-lg w-full md:w-1/3">
            <Target className="text-emerald-500 mb-4" size={32} />
            <h3 className="text-2xl font-bold mb-2">Step 3</h3>
            <p>Invest and grow tax-free forever</p>
          </div>
        </div>
        <div className="mt-6 bg-yellow-900 p-4 rounded-lg flex items-center">
          <AlertTriangle className="text-yellow-500 mr-4" size={24} />
          <p className="text-yellow-300">Warning: Pro-rata rule — Ensure you have $0 in Traditional IRA before conversion.</p>
        </div>
      </section>

      {/* Tax-Free Growth Projection Section */}
      <section className="p-8 bg-[#0d1526]">
        <h2 className="text-3xl font-semibold mb-6 text-blue-400">Tax-Free Growth Projection</h2>
        <p className="mb-4">Assuming $7,000 annual Backdoor Roth contribution at 8% growth:</p>
        <ul className="list-disc pl-6 mb-6 text-[#94a3b8]">
          <li>Year 10: $101K (all tax-free)</li>
          <li>Year 20: $320K (all tax-free)</li>
          <li>Year 25: $493K (all tax-free)</li>
          <li>Tax savings vs taxable: $93K in avoided capital gains</li>
        </ul>
        <ResponsiveContainer width="100%" height={400}>
          <AreaChart data={projectionData}>
            <XAxis dataKey="year" stroke="#fff" />
            <YAxis stroke="#fff" />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="balance" stroke="#10B981" fill="#10B981" fillOpacity={0.3} />
          </AreaChart>
        </ResponsiveContainer>
      </section>

      {/* Pro-Rata Rule Warning Section */}
      <section className="p-8 bg-red-900">
        <h2 className="text-3xl font-semibold mb-6 text-red-400">Pro-Rata Rule Warning</h2>
        <div className="bg-red-800 p-6 rounded-lg shadow-lg flex items-start">
          <AlertTriangle className="text-red-500 mr-4" size={32} />
          <div>
            <p>If you have $100K in Traditional IRA:</p>
            <ul className="list-disc pl-6 mt-2">
              <li>Converting $7K means 93.5% is taxable</li>
              <li>Tax on conversion: $2,425 (at 37%)</li>
              <li>Solution: Roll Traditional IRA into employer 401(k) first</li>
              <li>Then convert with $0 pro-rata impact</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Backdoor Roth vs Other Strategies Section */}
      <section className="p-8">
        <h2 className="text-3xl font-semibold mb-6 text-emerald-400">Backdoor Roth vs Other Strategies</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-700">
                <th className="p-3 border border-[#1e3a5f]">Strategy</th>
                <th className="p-3 border border-[#1e3a5f]">Annual Amount</th>
                <th className="p-3 border border-[#1e3a5f]">Tax Treatment</th>
                <th className="p-3 border border-[#1e3a5f]">Income Limit</th>
                <th className="p-3 border border-[#1e3a5f]">Complexity</th>
              </tr>
            </thead>
            <tbody>
              <tr className="bg-[#0d1526] even:bg-[#0a0f1a]">
                <td className="p-3 border border-[#1e3a5f]">Backdoor Roth</td>
                <td className="p-3 border border-[#1e3a5f]">$7K</td>
                <td className="p-3 border border-[#1e3a5f]">Tax-free growth</td>
                <td className="p-3 border border-[#1e3a5f]">None</td>
                <td className="p-3 border border-[#1e3a5f]">Medium</td>
              </tr>
              <tr className="bg-[#0d1526] even:bg-[#0a0f1a]">
                <td className="p-3 border border-[#1e3a5f]">Direct Roth</td>
                <td className="p-3 border border-[#1e3a5f]">$7K</td>
                <td className="p-3 border border-[#1e3a5f]">Tax-free growth</td>
                <td className="p-3 border border-[#1e3a5f]">$161K single</td>
                <td className="p-3 border border-[#1e3a5f]">Low</td>
              </tr>
              <tr className="bg-[#0d1526] even:bg-[#0a0f1a]">
                <td className="p-3 border border-[#1e3a5f]">Traditional IRA</td>
                <td className="p-3 border border-[#1e3a5f]">$7K</td>
                <td className="p-3 border border-[#1e3a5f]">Tax-deferred</td>
                <td className="p-3 border border-[#1e3a5f]">$83K deduction</td>
                <td className="p-3 border border-[#1e3a5f]">Low</td>
              </tr>
              <tr className="bg-[#0d1526] even:bg-[#0a0f1a]">
                <td className="p-3 border border-[#1e3a5f]">Mega Backdoor</td>
                <td className="p-3 border border-[#1e3a5f]">$46K</td>
                <td className="p-3 border border-[#1e3a5f]">Tax-free growth</td>
                <td className="p-3 border border-[#1e3a5f]">Plan dependent</td>
                <td className="p-3 border border-[#1e3a5f]">High</td>
              </tr>
              <tr className="bg-[#0d1526] even:bg-[#0a0f1a]">
                <td className="p-3 border border-[#1e3a5f]">Taxable Account</td>
                <td className="p-3 border border-[#1e3a5f]">Unlimited</td>
                <td className="p-3 border border-[#1e3a5f]">Taxed annually</td>
                <td className="p-3 border border-[#1e3a5f]">None</td>
                <td className="p-3 border border-[#1e3a5f]">Low</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* Year-by-Year Execution Checklist Section */}
      <section className="p-8 bg-[#0d1526]">
        <h2 className="text-3xl font-semibold mb-6 text-blue-400">Year-by-Year Execution Checklist</h2>
        <ul className="list-decimal pl-6 space-y-2">
          <li>January: Contribute $7K to Traditional IRA</li>
          <li>February: Convert to Roth (wait for settlement)</li>
          <li>April: File Form 8606 with tax return</li>
          <li>Repeat annually for maximum accumulation</li>
        </ul>
      </section>

      {/* IRS Compliance Section */}
      <section className="p-8">
        <h2 className="text-3xl font-semibold mb-6 text-emerald-400">IRS Compliance</h2>
        <div className="space-y-4">
          <p><Lock className="inline mr-2 text-blue-500" size={20} />IRC section 408A: Roth IRA rules</p>
          <p><Scale className="inline mr-2 text-blue-500" size={20} />IRC section 408(d)(2): Pro-rata rule</p>
          <p><Award className="inline mr-2 text-blue-500" size={20} />Form 8606: Nondeductible IRA reporting</p>
          <p><Zap className="inline mr-2 text-blue-500" size={20} />Step transaction doctrine considerations</p>
        </div>
      </section>

      {/* Footer for additional styling and responsiveness */}
      <footer className="p-4 text-center text-gray-500 bg-[#0a0f1a]">
        <p>Always consult a financial advisor. This guide is for educational purposes only.</p>
      </footer>
      <PageInsights section="backdoor-roth-guide" />
    </div>
  );
};

export default BackdoorRothGuide;
