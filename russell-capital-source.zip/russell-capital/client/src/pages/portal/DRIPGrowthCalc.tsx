// @ts-nocheck

import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Circle, CalculatorIcon} from 'lucide-react';
import { toast } from "sonner";
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function DRIPGrowthCalc() {
  const autoFill = useCalculatorAutoFill("drip-growth");
  const { reportResult } = useCalcResults();
  const [initialInvestment, setInitialInvestment] = useState(10000);
  const [dividendYield, setDividendYield] = useState(3);
  const [dividendGrowthRate, setDividendGrowthRate] = useState(2);
  const [years, setYears] = useSharedField("projectionYears", 10);

  const handleInitialInvestmentChange = (value: number[]) => setInitialInvestment(value[0]);
  const handleDividendYieldChange = (value: number[]) => setDividendYield(value[0]);
  const handleDividendGrowthRateChange = (value: number[]) => setDividendGrowthRate(value[0]);
  const handleYearsChange = (value: number[]) => setYears(Math.round(value[0]));

  const calculations = useMemo(() => {
    let value = initialInvestment;
    let year = 0;
    while (year < years) {
      year++;
      const yieldThisYear = dividendYield + (dividendGrowthRate * year);
      value *= (1 + (yieldThisYear / 100));
    }
    const futureValue = value;
    const totalGrowth = ((futureValue - initialInvestment) / initialInvestment) * 100;
    const annualizedReturn = (Math.pow(1 + (totalGrowth / 100), 1 / years) - 1) * 100;
    return { futureValue, totalGrowth, annualizedReturn };
  }, [initialInvestment, dividendYield, dividendGrowthRate, years]);
  const projectionData = useMemo(() => {
    const d = [];
    const startVal = typeof investmentAmount !== 'undefined' ? investmentAmount : 100000;
    const annualAdd = typeof annualContribution !== 'undefined' ? annualContribution : 20000;
    let agg = startVal, mod = startVal, cons = startVal, infl = startVal;
    for (let yr = 0; yr <= 50; yr++) {
      d.push({ year: yr, aggressive: Math.round(agg), moderate: Math.round(mod), conservative: Math.round(cons), inflation: Math.round(infl) });
      agg = (agg + annualAdd) * 1.085;
      mod = (mod + annualAdd) * 1.065;
      cons = (cons + annualAdd) * 1.045;
      infl = (infl + annualAdd) * 1.03;
    }
    return d;
  }, []);


  return (
    <AppShell
      headerTitle="DRIP Growth Calculator"
      headerSubtitle="Investment Analysis"
    >
      <div className="p-6 bg-[#0a0f1a] min-h-screen">
        <AutoFillBanner calcRoute="drip-growth" />
        <div className="max-w-4xl mx-auto">
          <Card className="bg-[#0d1526] border-[#1e3a5f] mb-6">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <CalculatorIcon className="mr-2 text-emerald-400" />
                Input Parameters
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <Label className="text-white">Initial Investment</Label>
                  <div className="mt-2">
                    <Input
                      type="number"
                      value={initialInvestment}
                      onChange={(e) => setInitialInvestment(parseFloat(e.target.value))}
                      className="bg-slate-700 text-white"
                    />
                  </div>
                  <Slider
                    min={1000}
                    max={100000}
                    step={1000}
                    value={[initialInvestment]}
                    onValueChange={handleInitialInvestmentChange}
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label className="text-white">Annual Dividend Yield (%)</Label>
                  <div className="mt-2">
                    <Input
                      type="number"
                      value={dividendYield}
                      onChange={(e) => setDividendYield(parseFloat(e.target.value))}
                      className="bg-slate-700 text-white"
                    />
                  </div>
                  <Slider
                    min={0}
                    max={10}
                    step={0.1}
                    value={[dividendYield]}
                    onValueChange={handleDividendYieldChange}
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label className="text-white">Dividend Growth Rate (%)</Label>
                  <div className="mt-2">
                    <Input
                      type="number"
                      value={dividendGrowthRate}
                      onChange={(e) => setDividendGrowthRate(parseFloat(e.target.value))}
                      className="bg-slate-700 text-white"
                    />
                  </div>
                  <Slider
                    min={0}
                    max={10}
                    step={0.1}
                    value={[dividendGrowthRate]}
                    onValueChange={handleDividendGrowthRateChange}
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label className="text-white">Number of Years</Label>
                  <div className="mt-2">
                    <Input
                      type="number"
                      value={years}
                      onChange={(e) => setYears(parseInt(e.target.value))}
                      className="bg-slate-700 text-white"
                    />
                  </div>
                  <Slider
                    min={1}
                    max={30}
                    step={1}
                    value={[years]}
                    onValueChange={handleYearsChange}
                    className="mt-2"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />

          
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "aggressive", label: "Aggressive (8.5%)", color: "#10b981" }, { key: "moderate", label: "Moderate (6.5%)", color: "#06b6d4" }, { key: "conservative", label: "Conservative (4.5%)", color: "#f59e0b" }, { key: "inflation", label: "Inflation Erosion", color: "#ef4444" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle className="text-emerald-400">Future Value</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-white text-2xl font-bold">
                  {formatDollars(calculations.futureValue)}
                </p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle className="text-emerald-400">Total Growth (%)</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-white text-2xl font-bold">
                  {calculations.totalGrowth.toFixed(2) + "%"}
                </p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle className="text-emerald-400">Annualized Return (%)</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-white text-2xl font-bold">
                  {calculations.annualizedReturn.toFixed(2) + "%"}
                </p>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-[#0d1526] border-[#1e3a5f] mb-6">
            <CardHeader>
              <CardTitle className="text-white">IUL Advantage</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-white">
                IUL offers tax-free growth, potentially increasing your returns by up to{" "}
                {((calculations.annualizedReturn * 1.15) - calculations.annualizedReturn).toFixed(2)}% compared to traditional DRIP investments.
              </p>
            </CardContent>
          </Card>

          <Button
            onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
            className="bg-emerald-500 hover:bg-emerald-600 text-white"
          >
            Send to AI Advisor
          </Button>
        </div>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("drip-growth", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-drip-growth");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Dividend Reinvestment (DRIP) Growth Calculator"
            calculatorRoute="drip-growth"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="d-r-i-p-growth-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/drip-growth" />
</div>
    </AppShell>
  );
}