// @ts-nocheck

import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Calculator, DollarSign, TrendingUp } from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function DeferredCompCalc() {
  const autoFill = useCalculatorAutoFill("deferred-compensation");
  const { reportResult } = useCalcResults();
  const [currentIncome, setCurrentIncome] = useSharedField("annualIncome", 150000);
  const [age, setAge] = useSharedField("currentAge", 40);
  const [retirementAge, setRetirementAge] = useSharedField("retirementAge", 65);
  const [deferralPercentage, setDeferralPercentage] = useState(20);
  const [interestRate, setInterestRate] = useState(5);
  const [iulGrowthRate, setIulGrowthRate] = useState(7);

  const yearsToRetirement = useMemo(() => retirementAge - age, [retirementAge, age]);

  const calculations = useMemo(() => {
    const annualDeferral = (currentIncome * deferralPercentage) / 100;
    const futureValueDeferred = annualDeferral * ((1 + interestRate / 100) ** yearsToRetirement);
    const taxSavings = annualDeferral * 0.25; // Assuming 25% tax bracket for simplicity
    const iulFutureValue = annualDeferral * ((1 + iulGrowthRate / 100) ** yearsToRetirement); // Tax-free growth
    return { futureValueDeferred, taxSavings, iulFutureValue };
  }, [currentIncome, deferralPercentage, interestRate, yearsToRetirement, iulGrowthRate]);
  const projectionData = useMemo(() => {
    const d = [];
    let opt = 100000, base = 100000, taxSav = 0;
    for (let yr = 0; yr <= 50; yr++) {
      opt *= 1.075;
      base *= 1.05;
      taxSav += (opt - base) * 0.08;
      d.push({ year: yr, optimized: Math.round(opt), baseline: Math.round(base), taxSavings: Math.round(taxSav), netBenefit: Math.round(opt - base + taxSav) });
    }
    return d;
  }, []);


  return (
    <AppShell
      headerTitle="Executive Deferred Compensation Calculator"
      headerSubtitle="Business Owner Tools"
    >
      <div className="p-6 space-y-8 bg-[#0a0f1a] text-white">
        <AutoFillBanner calcRoute="deferred-compensation" />
        <section className="space-y-4">
          <h2 className="text-2xl font-bold">Input Parameters</h2>
          <div className="space-y-6">
            <div>
              <Label>Current Annual Income</Label>
              <div className="flex items-center space-x-2">
                <Input
                  type="number"
                  value={currentIncome}
                  onChange={(e) => setCurrentIncome(Number(e.target.value))}
                  className="bg-[#0d1526]"
                />
                <span>{formatDollars(currentIncome)}</span>
              </div>
            </div>
            <div>
              <Label>Current Age</Label>
              <Input
                type="number"
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="bg-[#0d1526]"
              />
            </div>
            <div>
              <Label>Retirement Age</Label>
              <Input
                type="number"
                value={retirementAge}
                onChange={(e) => setRetirementAge(Number(e.target.value))}
                className="bg-[#0d1526]"
              />
            </div>
            <div>
              <Label>Deferral Percentage (%)</Label>
              <Slider
                min={0}
                max={50}
                step={1}
                value={[deferralPercentage]}
                onValueChange={(value) => setDeferralPercentage(value[0])}
                className="mt-2"
              />
              <div>{deferralPercentage}%</div>
            </div>
            <div>
              <Label>Assumed Interest Rate (%)</Label>
              <Slider
                min={0}
                max={10}
                step={0.5}
                value={[interestRate]}
                onValueChange={(value) => setInterestRate(value[0])}
                className="mt-2"
              />
              <div>{interestRate}%</div>
            </div>
            <div>
              <Label>IUL Growth Rate (%)</Label>
              <Slider
                min={0}
                max={10}
                step={0.5}
                value={[iulGrowthRate]}
                onValueChange={(value) => setIulGrowthRate(value[0])}
                className="mt-2"
              />
              <div>{iulGrowthRate}%</div>
            </div>
          </div>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold">Calculation Results</h2>
        {/* State Tax Impact */}
        <StateTaxSelector income={currentIncome} filingStatus={'single'} className="mb-6" />
          
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "optimized", label: "Optimized Strategy", color: "#10b981" }, { key: "baseline", label: "Baseline (No Action)", color: "#ef4444" }, { key: "taxSavings", label: "Cumulative Tax Savings", color: "#06b6d4" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <DollarSign className="mr-2" /> Projected Deferred Value
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{formatDollars(calculations.futureValueDeferred)}</p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="mr-2" /> Estimated Tax Savings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{formatDollars(calculations.taxSavings)}</p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calculator className="mr-2" /> IUL Projected Value
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{formatDollars(calculations.iulFutureValue)}</p>
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold">IUL Advantage</h2>
          <p>IUL provides tax-free growth, which can lead to higher net values compared to traditional deferred compensation. For example, with the inputs above, IUL projects </p>
          <p>a value of {formatDollars(calculations.iulFutureValue)} versus {formatDollars(calculations.futureValueDeferred)} for standard deferral, highlighting potential tax advantages.</p>
        </section>

        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-400 text-slate-900 hover:bg-emerald-500"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("deferred-compensation", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-deferred-compensation");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Executive Deferred Compensation Calculator"
            calculatorRoute="deferred-compensation"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="deferred-comp-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/deferred-compensation" />
</div>
    </AppShell>
  );
}