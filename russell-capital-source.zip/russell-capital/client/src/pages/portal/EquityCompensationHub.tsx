// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Award, DollarSign, TrendingUp, Shield, CheckCircle2, AlertTriangle, Calendar, Target, Percent, ArrowRight, Zap, Scale } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, BarChart, Bar, ComposedChart, Line, PieChart, Pie, Cell } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

const EquityCompensationHub = () => {
  const [isoShares, setIsoShares] = useState(0);
  const [isoExercisePrice, setIsoExercisePrice] = useState(0);
  const [amtIncome, setAmtIncome] = useState(0);
  const [electionAmount, setElectionAmount] = useState(0);
  const [portfolioValue, setPortfolioValue] = useState(100000);
  const [years, setYears] = useSharedField("projectionYears", 10);

  const equityTypes = [
    { type: 'ISO', description: 'Incentive Stock Options - Taxed at capital gains if held >1 year.', pros: 'No tax at exercise if AMT avoided.', cons: 'AMT trap risk.' },
    { type: 'NQSO', description: 'Non-Qualified Stock Options - Ordinary income tax at exercise.', pros: 'No AMT risk.', cons: 'Higher immediate tax.' },
    { type: 'RSU', description: 'Restricted Stock Units - Taxed as ordinary income upon vesting.', pros: 'No purchase required.', cons: 'Full tax on vesting value.' },
    { type: 'RSA', description: 'Restricted Stock Awards - Similar to RSU but taxed at grant if 83(b) elected.', pros: 'Potential for capital gains.', cons: 'Risk if stock value drops.' },
    { type: 'Phantom', description: 'Phantom Stock - Cash or equivalent based on stock performance.', pros: 'No actual shares needed.', cons: 'Not true equity.' },
    { type: 'SAR', description: 'Stock Appreciation Rights - Gain based on stock price increase.', pros: 'Cash settlement option.', cons: 'Taxed as ordinary income.' },
    { type: 'ESPP', description: 'Employee Stock Purchase Plan - Discounted stock purchase.', pros: 'Potential discount up to 15%.', cons: 'Holding period requirements.' },
    { type: 'Profits Interest', description: 'For LLCs - Represents future profits.', pros: 'Tax-free if vested.', cons: 'Complex valuation.' },
  ];

  const amtTrapCalculation = useMemo(() => {
    const bargainElement = isoShares * (100 - isoExercisePrice); // Simplified
    const amtLiability = bargainElement > 0 ? bargainElement * 0.26 : 0; // AMT rate
    return amtLiability > amtIncome ? 'AMT Trap Triggered' : 'No AMT Trap';
  }, [isoShares, isoExercisePrice, amtIncome]);

  const decisionTree = useMemo(() => {
    if (electionAmount > 0 && electionAmount < 100000) {
      return 'Elect 83(b) for potential capital gains treatment.';
    } else if (electionAmount >= 100000) {
      return 'Consider electing 83(b), but watch for high income tax.';
    } else {
      return 'No election needed; wait for vesting.';
    }
  }, [electionAmount]);

  const projectionData = useMemo(() => {
    return Array.from({ length: years }, (_, i) => ({
      year: i + 1,
      value: portfolioValue * Math.pow(1.07, i), // 7% annual growth
    }));
  }, [portfolioValue, years]);

  const riskData = [
    { name: 'Company Stock', value: 70 },
    { name: 'Diversified', value: 30 },
  ];

  const COLORS = ['#10B981', '#F59E0B']; // Emerald and Amber accents

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-gray-100 p-8 font-sans">
      <header className="mb-12">
        <h1 className="text-4xl font-bold flex items-center gap-2">
          <Award className="text-emerald-400" />
          Equity Compensation Hub
        </h1>
        <p className="text-[#7a95b8] mt-2">Comprehensive tools for equity planning and compliance.</p>
      </header>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold flex items-center gap-2 mb-4">
          <DollarSign className="text-amber-400" />
          Master Comparison of Equity Types
        </h2>
        <div className="overflow-x-auto"><table className="w-full border-collapse border border-[#1e3a5f]">
          <thead>
            <tr className="bg-[#0d1526]">
              <th className="p-2 border border-[#1e3a5f]">Type</th>
              <th className="p-2 border border-[#1e3a5f]">Description</th>
              <th className="p-2 border border-[#1e3a5f]">Pros</th>
              <th className="p-2 border border-[#1e3a5f]">Cons</th>
            </tr>
          </thead>
          <tbody>
            {equityTypes.map((eq, index) => (
              <tr key={index} className={index % 2 === 0 ? 'bg-[#0d1526]' : 'bg-gray-700'}>
                <td className="p-2 border border-[#1e3a5f]">{eq.type}</td>
                <td className="p-2 border border-[#1e3a5f]">{eq.description}</td>
                <td className="p-2 border border-[#1e3a5f]">{eq.pros}</td>
                <td className="p-2 border border-[#1e3a5f]">{eq.cons}</td>
              </tr>
            ))}
          </tbody>
        </table></div>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold flex items-center gap-2 mb-4">
          <AlertTriangle className="text-emerald-400" />
          AMT Trap Calculator for ISOs
        </h2>
        <div className="flex gap-4 mb-4">
          <input
            type="number"
            placeholder="ISO Shares"
            onChange={(e) => setIsoShares(Number(e.target.value))}
            className="bg-[#0d1526] p-2 rounded"
          />
          <input
            type="number"
            placeholder="Exercise Price"
            onChange={(e) => setIsoExercisePrice(Number(e.target.value))}
            className="bg-[#0d1526] p-2 rounded"
          />
          <input
            type="number"
            placeholder="AMT Income"
            onChange={(e) => setAmtIncome(Number(e.target.value))}
            className="bg-[#0d1526] p-2 rounded"
          />
        </div>
        <p className="text-emerald-400">Result: {amtTrapCalculation}</p>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold flex items-center gap-2 mb-4">
          <Shield className="text-amber-400" />
          83(b) Election Decision Tree
        </h2>
        <div className="flex gap-4 mb-4">
          <input
            type="number"
            placeholder="Election Amount"
            onChange={(e) => setElectionAmount(Number(e.target.value))}
            className="bg-[#0d1526] p-2 rounded"
          />
        </div>
        <p className="text-[#7a95b8]">{decisionTree}</p>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold flex items-center gap-2 mb-4">
          <TrendingUp className="text-emerald-400" />
          Concentration Risk Dashboard
        </h2>
        <ResponsiveContainer width="100%" height={400}><PieChart>
          <Pie data={riskData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={150} fill="#8884d8" label>
            {riskData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip />
          <Legend />
        </PieChart></ResponsiveContainer>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold flex items-center gap-2 mb-4">
          <Calendar className="text-amber-400" />
          10-Year Equity Portfolio Projection
        </h2>
        <ResponsiveContainer width="100%" height={400}>
          <AreaChart data={projectionData}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="value" stroke="#10B981" fill="#10B981" />
          </AreaChart>
        </ResponsiveContainer>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold flex items-center gap-2 mb-4">
          <Target className="text-emerald-400" />
          Diversification Strategy with 10b5-1 Plan
        </h2>
        <p className="text-[#7a95b8]">Plan your sales under Rule 10b5-1 to avoid insider trading risks.</p>
        <ResponsiveContainer width="100%" height={300}><BarChart data={[{name: 'Year 1', sales: 5000}, {name: 'Year 2', sales: 7000}]}>
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="sales" fill="#F59E0B" />
        </BarChart></ResponsiveContainer>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold flex items-center gap-2 mb-4">
          <CheckCircle2 className="text-amber-400" />
          Compliance Overview
        </h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <h3 className="flex items-center gap-2"><Zap className="text-emerald-400" /> IRC 422 (ISO)</h3>
            <p className="text-[#7a95b8]">Must be granted to employees; $100K limit per year.</p>
          </div>
          <div>
            <h3 className="flex items-center gap-2"><Scale className="text-amber-400" /> Section 83 (RSA/RSU)</h3>
            <p className="text-[#7a95b8]">Taxed on vesting; 83(b) election for immediate taxation.</p>
          </div>
          <div>
            <h3 className="flex items-center gap-2"><Percent className="text-emerald-400" /> Section 409A (NQSO)</h3>
            <p className="text-[#7a95b8]">Options must be valued at fair market value to avoid penalties.</p>
          </div>
          <div>
            <h3 className="flex items-center gap-2"><ArrowRight className="text-amber-400" /> Section 423 (ESPP)</h3>
            <p className="text-[#7a95b8]">Discounted purchases with holding period for favorable tax.</p>
          </div>
          <div>
            <h3 className="flex items-center gap-2"><Target className="text-emerald-400" /> Section 1202 (QSBS)</h3>
            <p className="text-[#7a95b8]">Exclusion of gain on qualified small business stock if held 5 years.</p>
          </div>
          <div>
            <h3 className="flex items-center gap-2"><Shield className="text-amber-400" /> Rule 10b5-1 Plans</h3>
            <p className="text-[#7a95b8]">Pre-scheduled trading to demonstrate non-insider intent.</p>
          </div>
        </div>
      </section>

      <ResponsiveContainer width="100%" height={400}><ComposedChart data={projectionData}>
        <XAxis dataKey="year" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Area type="monotone" dataKey="value" fill="#10B981" />
        <Line type="monotone" dataKey="value" stroke="#F59E0B" />
        <Bar dataKey="value" fill="#8884d8" />
      </ComposedChart></ResponsiveContainer>
      <PageInsights section="equity-compensation-hub" />
    </div>
  );
};

export default EquityCompensationHub;
