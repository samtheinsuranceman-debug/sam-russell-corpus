// @ts-nocheck
/**
 * AutoPilot Workflow Engine
 * Grok-recommended Feature 25 (Impact 8, INTELLIGENT AUTOMATION)
 * AI-driven task automation for onboarding, documents, and follow-ups.
 */
import { useState, useEffect, useCallback } from "react";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Zap, Play, Pause, CheckCircle, Clock, AlertTriangle, Settings, FileText, Users, Mail, Calendar, ArrowRight, Sparkles, Brain, RefreshCw, BarChart3, Shield, ChevronRight, Plus, Eye, Icon} from 'lucide-react';
import { useReportToHub } from "@/contexts/UnifiedDataBusContext";
import { PageInsights } from "@/components/PageInsights";

interface Workflow {
  id: string;
  name: string;
  description: string;
  status: "active" | "paused" | "completed" | "error";
  category: string;
  steps: number;
  completedSteps: number;
  lastRun: string;
  nextRun: string;
  timeSaved: string;
  icon: typeof Zap;
  color: string;
}

interface AutomationTask {
  id: string;
  name: string;
  workflow: string;
  status: "pending" | "running" | "completed" | "failed";
  priority: "high" | "medium" | "low";
  dueDate: string;
  assignedTo: string;
}

const WORKFLOWS: Workflow[] = [
  { id: "w1", name: "New Client Onboarding", description: "Automated 12-step onboarding: KYC, risk assessment, document collection, compliance check, welcome sequence", status: "active", category: "Onboarding", steps: 12, completedSteps: 12, lastRun: "2 hours ago", nextRun: "On trigger", timeSaved: "4.5 hrs/client", icon: Users, color: "emerald" },
  { id: "w2", name: "Annual Policy Review", description: "Automated annual review: carrier strength check, rate comparison, compliance update, client notification", status: "active", category: "Review", steps: 8, completedSteps: 8, lastRun: "1 day ago", nextRun: "Apr 25", timeSaved: "3 hrs/review", icon: FileText, color: "blue" },
  { id: "w3", name: "Compliance Document Generator", description: "Auto-generate suitability forms, disclosure docs, and audit trails for each client interaction", status: "active", category: "Compliance", steps: 6, completedSteps: 6, lastRun: "30 min ago", nextRun: "On trigger", timeSaved: "1.5 hrs/doc", icon: Shield, color: "purple" },
  { id: "w4", name: "Follow-Up Sequence", description: "AI-timed follow-ups based on client engagement, proposal status, and lifecycle stage", status: "active", category: "Communication", steps: 5, completedSteps: 5, lastRun: "4 hours ago", nextRun: "Tomorrow 9 AM", timeSaved: "2 hrs/week", icon: Mail, color: "amber" },
  { id: "w5", name: "Prospect Qualification Pipeline", description: "Auto-score and route prospects through qualification criteria, schedule discovery calls", status: "paused", category: "Sales", steps: 7, completedSteps: 4, lastRun: "3 days ago", nextRun: "Paused", timeSaved: "5 hrs/week", icon: Brain, color: "rose" },
  { id: "w6", name: "Market Alert Digest", description: "Compile daily market alerts relevant to client portfolios, generate personalized summaries", status: "active", category: "Intelligence", steps: 4, completedSteps: 4, lastRun: "6 hours ago", nextRun: "Tomorrow 7 AM", timeSaved: "1 hr/day", icon: BarChart3, color: "red" },
];

const TASKS: AutomationTask[] = [
  { id: "t1", name: "Send onboarding docs to Dr. Martinez", workflow: "New Client Onboarding", status: "completed", priority: "high", dueDate: "Today", assignedTo: "AutoPilot" },
  { id: "t2", name: "Run carrier strength check for Johnson policy", workflow: "Annual Policy Review", status: "running", priority: "high", dueDate: "Today", assignedTo: "AutoPilot" },
  { id: "t3", name: "Generate Q1 compliance report", workflow: "Compliance Document Generator", status: "running", priority: "medium", dueDate: "Apr 23", assignedTo: "AutoPilot" },
  { id: "t4", name: "Follow up with Dr. Chen on IUL proposal", workflow: "Follow-Up Sequence", status: "pending", priority: "high", dueDate: "Apr 23", assignedTo: "AutoPilot" },
  { id: "t5", name: "Qualify 3 new inbound leads", workflow: "Prospect Qualification Pipeline", status: "pending", priority: "medium", dueDate: "Apr 24", assignedTo: "AutoPilot" },
  { id: "t6", name: "Compile market digest for cardiology clients", workflow: "Market Alert Digest", status: "completed", priority: "low", dueDate: "Today", assignedTo: "AutoPilot" },
];

export default function AutoPilotWorkflow() {
  const _reportToHub = useReportToHub("ai-pro-autopilot", "AutoPilot Workflow Engine", "ai-pro-suite", "/portal/autopilot-workflow");
  useEffect(() => {
    _reportToHub({ visited: true, timestamp: Date.now() });
  }, [_reportToHub]);
  const [selectedWorkflow, setSelectedWorkflow] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>("all");

  const activeWorkflows = WORKFLOWS.filter(w => w.status === "active").length;
  const totalTimeSaved = "16.5 hrs/week";
  const tasksCompleted = TASKS.filter(t => t.status === "completed").length;
  const tasksRunning = TASKS.filter(t => t.status === "running").length;

  const filteredTasks = filter === "all" ? TASKS : TASKS.filter(t => t.status === filter);

  return (
    <AppShell title="AutoPilot Workflow Engine" subtitle="AI-driven automation for onboarding, compliance, follow-ups, and more">
      <div className="space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card className="bg-emerald-500/5 border-emerald-500/20">
            <CardContent className="py-3 px-3 text-center">
              <p className="text-2xl font-bold text-emerald-400">{activeWorkflows}</p>
              <p className="text-xs text-slate-500">Active Workflows</p>
            </CardContent>
          </Card>
          <Card className="bg-blue-500/5 border-blue-500/20">
            <CardContent className="py-3 px-3 text-center">
              <p className="text-2xl font-bold text-blue-400">{totalTimeSaved}</p>
              <p className="text-xs text-slate-500">Time Saved</p>
            </CardContent>
          </Card>
          <Card className="bg-amber-500/5 border-amber-500/20">
            <CardContent className="py-3 px-3 text-center">
              <p className="text-2xl font-bold text-amber-400">{tasksCompleted}</p>
              <p className="text-xs text-slate-500">Tasks Completed</p>
            </CardContent>
          </Card>
          <Card className="bg-purple-500/5 border-purple-500/20">
            <CardContent className="py-3 px-3 text-center">
              <p className="text-2xl font-bold text-purple-400">{tasksRunning}</p>
              <p className="text-xs text-slate-500">Running Now</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Workflows */}
          <div className="lg:col-span-2 space-y-4">
            <Card className="bg-[#0d1526]/50 border-[#1e3a5f]/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-emerald-400 flex items-center gap-2">
                  <Zap className="h-4 w-4" /> Automation Workflows
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {WORKFLOWS.map(wf => {
                  const Icon = wf.icon;
                  return (
                    <div key={wf.id} className={`p-3 rounded-lg border cursor-pointer transition-all ${
                      selectedWorkflow === wf.id ? `bg-${wf.color}-500/10 border-${wf.color}-500/30` :
                      "bg-[#0a0f1a]/50 border-[#1e3a5f]/50 hover:border-[#1e3a5f]"
                    }`} onClick={() => setSelectedWorkflow(wf.id === selectedWorkflow ? null : wf.id)}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-lg bg-${wf.color}-500/20 flex items-center justify-center`}>
                            <Icon className={`h-4 w-4 text-${wf.color}-400`} />
                          </div>
                          <div>
                            <p className="text-sm text-white font-medium">{wf.name}</p>
                            <p className="text-xs text-slate-500">{wf.category} · {wf.steps} steps</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={`text-xs ${
                            wf.status === "active" ? "bg-emerald-500/20 text-emerald-400" :
                            wf.status === "paused" ? "bg-amber-500/20 text-amber-400" :
                            wf.status === "completed" ? "bg-blue-500/20 text-blue-400" :
                            "bg-red-500/20 text-red-400"
                          }`}>{wf.status}</Badge>
                          <span className="text-xs text-slate-500">{wf.timeSaved}</span>
                        </div>
                      </div>
                      {selectedWorkflow === wf.id && (
                        <div className="mt-3 pt-3 border-t border-[#1e3a5f]/30 space-y-2">
                          <p className="text-xs text-[#7a95b8]">{wf.description}</p>
                          <div className="flex items-center gap-4 text-xs text-slate-500">
                            <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> Last: {wf.lastRun}</span>
                            <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> Next: {wf.nextRun}</span>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" className="text-xs bg-emerald-600 hover:bg-emerald-500 text-white">
                              <Play className="h-3 w-3 mr-1" /> Run Now
                            </Button>
                            <Button size="sm" variant="outline" className="text-xs border-[#1e3a5f] text-[#7a95b8]">
                              <Settings className="h-3 w-3 mr-1" /> Configure
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </CardContent>
            </Card>
      <PageInsights section="auto-pilot-workflow" />
          </div>

          {/* Task Queue */}
          <div className="space-y-4">
            <Card className="bg-[#0d1526]/50 border-[#1e3a5f]/50">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm text-blue-400 flex items-center gap-2">
                    <Brain className="h-4 w-4" /> Task Queue
                  </CardTitle>
                  <div className="flex gap-1">
                    {["all", "pending", "running", "completed"].map(f => (
                      <Button key={f} size="sm" variant={filter === f ? "default" : "ghost"}
                        onClick={() => setFilter(f)}
                        className={`text-xs capitalize h-6 px-2 ${filter === f ? "bg-blue-600 text-white" : "text-slate-500"}`}>
                        {f}
                      </Button>
                    ))}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                {filteredTasks.map(task => (
                  <div key={task.id} className={`p-2.5 rounded-lg border ${
                    task.status === "completed" ? "bg-emerald-500/5 border-emerald-500/15" :
                    task.status === "running" ? "bg-blue-500/5 border-blue-500/15" :
                    task.status === "failed" ? "bg-red-500/5 border-red-500/15" :
                    "bg-[#0a0f1a]/50 border-[#1e3a5f]/50"
                  }`}>
                    <div className="flex items-center gap-2">
                      {task.status === "completed" ? <CheckCircle className="h-3 w-3 text-emerald-400 shrink-0" /> :
                       task.status === "running" ? <RefreshCw className="h-3 w-3 text-blue-400 animate-spin shrink-0" /> :
                       task.status === "failed" ? <AlertTriangle className="h-3 w-3 text-red-400 shrink-0" /> :
                       <Clock className="h-3 w-3 text-[#7a95b8] shrink-0" />}
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-white truncate">{task.name}</p>
                        <p className="text-xs text-slate-500">{task.workflow} · {task.dueDate}</p>
                      </div>
                      <Badge variant="outline" className={`text-xs shrink-0 ${
                        task.priority === "high" ? "text-red-400 border-red-500/30" :
                        task.priority === "medium" ? "text-amber-400 border-amber-500/30" :
                        "text-[#7a95b8] border-[#1e3a5f]"
                      }`}>{task.priority}</Badge>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Automation Metrics */}
            <Card className="bg-gradient-to-br from-emerald-500/10 via-slate-800 to-blue-500/10 border-emerald-500/20">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-emerald-400 flex items-center gap-2">
                  <Sparkles className="h-4 w-4" /> This Month
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {[
                  { label: "Tasks Automated", value: "247", color: "emerald" },
                  { label: "Hours Saved", value: "66", color: "blue" },
                  { label: "Docs Generated", value: "89", color: "purple" },
                  { label: "Follow-ups Sent", value: "134", color: "amber" },
                ].map(m => (
                  <div key={m.label} className="flex items-center justify-between">
                    <span className="text-xs text-[#7a95b8]">{m.label}</span>
                    <span className={`text-sm font-bold text-${m.color}-400`}>{m.value}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
