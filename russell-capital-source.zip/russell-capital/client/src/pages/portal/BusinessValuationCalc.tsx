// @ts-nocheck

import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Circle, CalculatorIcon} from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function BusinessValuationCalc() {
  const autoFill = useCalculatorAutoFill("business-valuation");
  const { reportResult } = useCalcResults();
  const [annualRevenue, setAnnualRevenue] = useState(500000);
  const [netProfitMargin, setNetProfitMargin] = useState(20);
  const [growthRate, setGrowthRate] = useSharedField("growthRate", 5);
  const [discountRate, setDiscountRate] = useState(8);

  const results = useMemo(() => {
    const netProfit = (annualRevenue * netProfitMargin) / 100;
    const estimatedValue = netProfit * (1 + growthRate / 100) / (discountRate / 100);
    const projectedGrowth = estimatedValue * (growthRate / 100);
    const iulAdvantage = projectedGrowth * 0.30; // Assuming 30% tax-free growth advantage for IUL
    return { estimatedValue, projectedGrowth, iulAdvantage };
  }, [annualRevenue, netProfitMargin, growthRate, discountRate]);
  const projectionData = useMemo(() => {
    const d = [];
    let opt = 100000, base = 100000, taxSav = 0;
    for (let yr = 0; yr <= 50; yr++) {
      opt *= 1.075;
      base *= 1.05;
      taxSav += (opt - base) * 0.08;
      d.push({ year: yr, optimized: Math.round(opt), baseline: Math.round(base), taxSavings: Math.round(taxSav), netBenefit: Math.round(opt - base + taxSav) });
    }
    return d;
  }, []);


  return (
    <AppShell
      headerTitle="Business Valuation Calculator"
      headerSubtitle="Business Owner Tools"
    >
      <div className="p-6 bg-[#0a0f1a] min-h-screen text-white">
        <AutoFillBanner calcRoute="business-valuation" />
        <Card className="mb-6 bg-[#0d1526]">
          <CardHeader>
            <CardTitle className="flex items-center text-emerald-400">
              <CalculatorIcon className="mr-2" /> Input Values
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label>Annual Revenue</Label>
                <div className="flex items-center space-x-2">
                  <Slider
                    min={100000}
                    max={5000000}
                    step={10000}
                    value={[annualRevenue]}
                    onValueChange={(value) => setAnnualRevenue(value[0])}
                  />
                  <Input
                    type="number"
                    value={annualRevenue}
                    onChange={(e) => setAnnualRevenue(Number(e.target.value))}
                    className="w-32 bg-slate-700"
                  />
                </div>
              </div>
              <div>
                <Label>Net Profit Margin (%)</Label>
                <div className="flex items-center space-x-2">
                  <Slider
                    min={5}
                    max={50}
                    step={1}
                    value={[netProfitMargin]}
                    onValueChange={(value) => setNetProfitMargin(value[0])}
                  />
                  <Input
                    type="number"
                    value={netProfitMargin}
                    onChange={(e) => setNetProfitMargin(Number(e.target.value))}
                    className="w-32 bg-slate-700"
                  />
                </div>
              </div>
              <div>
                <Label>Growth Rate (%)</Label>
                <div className="flex items-center space-x-2">
                  <Slider
                    min={0}
                    max={20}
                    step={1}
                    value={[growthRate]}
                    onValueChange={(value) => setGrowthRate(value[0])}
                  />
                  <Input
                    type="number"
                    value={growthRate}
                    onChange={(e) => setGrowthRate(Number(e.target.value))}
                    className="w-32 bg-slate-700"
                  />
                </div>
              </div>
              <div>
                <Label>Discount Rate (%)</Label>
                <div className="flex items-center space-x-2">
                  <Slider
                    min={5}
                    max={15}
                    step={1}
                    value={[discountRate]}
                    onValueChange={(value) => setDiscountRate(value[0])}
                  />
                  <Input
                    type="number"
                    value={discountRate}
                    onChange={(e) => setDiscountRate(Number(e.target.value))}
                    className="w-32 bg-slate-700"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />

        
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "optimized", label: "Optimized Strategy", color: "#10b981" }, { key: "baseline", label: "Baseline (No Action)", color: "#ef4444" }, { key: "taxSavings", label: "Cumulative Tax Savings", color: "#06b6d4" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card className="bg-[#0d1526]">
            <CardHeader>
              <CardTitle>Estimated Business Value</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl text-emerald-400">
                {formatDollars(results.estimatedValue)}
              </p>
            </CardContent>
          </Card>
          <Card className="bg-[#0d1526]">
            <CardHeader>
              <CardTitle>Projected Annual Growth</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl text-emerald-400">
                {formatDollars(results.projectedGrowth)}
              </p>
            </CardContent>
          </Card>
          <Card className="bg-[#0d1526]">
            <CardHeader>
              <CardTitle>Potential Tax-Free Savings with IUL</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl text-emerald-400">
                {formatDollars(results.iulAdvantage)}
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-6 bg-[#0d1526]">
          <CardHeader>
            <CardTitle className="text-emerald-400">IUL Advantage</CardTitle>
          </CardHeader>
          <CardContent>
            <p>
              Indexed Universal Life (IUL) insurance offers tax-free growth on your investments, providing a significant advantage for business owners. By allocating a portion of your business value into an IUL, you could potentially shield 
              + (results.iulAdvantage / results.estimatedValue * 100).toFixed(2) + "% of your projected growth from taxes, enhancing your overall financial strategy.
            </p>
          </CardContent>
        </Card>

        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-500 hover:bg-emerald-600"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("business-valuation", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-business-valuation");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Business Valuation Calculator"
            calculatorRoute="business-valuation"
            inputs={typeof results !== 'undefined' ? results : {}}
            results={typeof results !== 'undefined' ? results : {}}
            projectionData={projectionData}
          />
      <PageInsights section="business-valuation-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/business-valuation" />
</div>
    </AppShell>
  );
}