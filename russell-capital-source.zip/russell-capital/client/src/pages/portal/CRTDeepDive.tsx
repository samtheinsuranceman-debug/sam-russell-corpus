// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Heart, DollarSign, TrendingUp, Shield, CheckCircle2, ArrowRight, Target, Calendar, Award, Scale, Percent, Gift } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, BarChart, Bar, ComposedChart, Line } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

const CRTDeepDive = () => {
  const [trustAmount, setTrustAmount] = useState(1000000); // Initial trust amount in dollars
  const [annuityRate, setAnnuityRate] = useState(5); // CRAT annuity rate in %
  const [unitrustRate, setUnitrustRate] = useState(5); // CRUT unitrust rate in %
  const [irs7520Rate, setIrs7520Rate] = useState(2.6); // IRS Section 7520 rate in %
  const [years, setYears] = useSharedField("projectionYears", 20); // Simulation years

  // Sample data for payout simulation
  const generatePayoutData = useMemo(() => {
    const data = [];
    for (let year = 1; year <= years; year++) {
      const cratPayout = (trustAmount * (annuityRate / 100)) / year; // Simplified CRAT payout
      const crutPayout = (trustAmount * (unitrustRate / 100)) * (1 + 0.03) ** year; // Simulated growth for CRUT
      data.push({ year, cratPayout, crutPayout });
    }
    return data;
  }, [trustAmount, annuityRate, unitrustRate, years]);

  // Income tax deduction calculation
  const calculateDeduction = useMemo(() => {
    const factor = 1 / (1 + irs7520Rate / 100) ** years; // Present value factor
    const cratDeduction = trustAmount * factor * (annuityRate / 100); // Simplified
    const crutDeduction = trustAmount * factor * (unitrustRate / 100);
    return { cratDeduction, crutDeduction };
  }, [trustAmount, irs7520Rate, years, annuityRate, unitrustRate]);

  // Remainder interest calculation
  const remainderInterest = useMemo(() => {
    const factor = 1 / (1 + irs7520Rate / 100) ** years;
    return trustAmount * factor * 0.1; // Assuming 10% to charity, simplified
  }, [trustAmount, irs7520Rate, years]);

  // Sample data for deduction waterfall
  const deductionWaterfallData = [
    { category: 'Initial Contribution', amount: trustAmount },
    { category: 'Deductible Portion', amount: calculateDeduction.cratDeduction },
    { category: 'Adjusted Basis', amount: trustAmount * 0.2 }, // Example
    { category: 'Net Deduction', amount: calculateDeduction.cratDeduction * 0.8 },
  ];

  return (
    <div style={{ backgroundColor: '#1a1a1a', color: '#f5f5f5', padding: '40px', fontFamily: 'Arial, sans-serif', minHeight: '100vh' }}>
      <h1 style={{ color: '#facc15', textAlign: 'center' }}>Deep Dive into Charitable Remainder Trusts (CRTs)</h1>
      <p style={{ color: '#e11d48' }}>Explore the intricacies of CRAT vs CRUT, tax benefits, and simulations for financial planning.</p>

      {/* CRAT vs CRUT Comparison Section */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#facc15' }}><Heart size={24} /> CRAT vs CRUT: A Comprehensive Comparison</h2>
        <p><DollarSign size={18} /> <strong>CRAT (Charitable Remainder Annuity Trust):</strong> Provides a fixed annuity payment based on the initial trust value. Ideal for steady income.</p>
        <p><TrendingUp size={18} /> <strong>CRUT (Charitable Remainder Unitrust):</strong> Pays a percentage of the trust's annual value, allowing for growth and variable payouts.</p>
        <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: '20px' }}>
          <div>
            <h3 style={{ color: '#e11d48' }}>CRAT: Fixed Annuity</h3>
            <p><ArrowRight size={16} /> Annual Rate: {annuityRate}%</p>
            <input
              type="number"
              value={annuityRate}
              onChange={(e) => setAnnuityRate(e.target.value)}
              style={{ backgroundColor: '#333', color: '#f5f5f5', border: '1px solid #facc15' }}
            />
          </div>
          <div>
            <h3 style={{ color: '#e11d48' }}>CRUT: Unitrust Percentage</h3>
            <p><Percent size={16} /> Annual Rate: {unitrustRate}%</p>
            <input
              type="number"
              value={unitrustRate}
              onChange={(e) => setUnitrustRate(e.target.value)}
              style={{ backgroundColor: '#333', color: '#f5f5f5', border: '1px solid #facc15' }}
            />
          </div>
        </div>
        <p><Shield size={18} /> Key Difference: CRAT offers predictability, while CRUT benefits from asset appreciation.</p>
      </section>

      {/* Income Tax Deduction Calculator */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#facc15' }}><CheckCircle2 size={24} /> Income Tax Deduction Modeling</h2>
        <p><Target size={18} /> Using IRS Section 7520 rate: {irs7520Rate}%</p>
        <input
          type="number"
          value={irs7520Rate}
          onChange={(e) => setIrs7520Rate(e.target.value)}
          style={{ backgroundColor: '#333', color: '#f5f5f5', border: '1px solid #facc15' }}
        />
        <p><Award size={18} /> CRAT Deduction: ${calculateDeduction.cratDeduction.toFixed(2)}</p>
        <p><Scale size={18} /> CRUT Deduction: ${calculateDeduction.crutDeduction.toFixed(2)}</p>
        <p><Gift size={18} /> Section 170 limits apply; deductions capped at 30% of AGI for appreciated assets.</p>
      </section>

      {/* Payout Simulation */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#facc15' }}><Calendar size={24} /> Unitrust Payout Simulation Over 20 Years</h2>
        <p><TrendingUp size={18} /> Simulate payouts for CRAT and CRUT using an AreaChart.</p>
        <ResponsiveContainer width="100%" height={400}>
          <AreaChart data={generatePayoutData}>
            <XAxis dataKey="year" stroke="#facc15" />
            <YAxis stroke="#e11d48" />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="cratPayout" stroke="#facc15" fill="#facc15" fillOpacity={0.3} />
            <Area type="monotone" dataKey="crutPayout" stroke="#e11d48" fill="#e11d48" fillOpacity={0.3} />
          </AreaChart>
        </ResponsiveContainer>
        <input
          type="number"
          value={years}
          onChange={(e) => setYears(e.target.value)}
          style={{ backgroundColor: '#333', color: '#f5f5f5', border: '1px solid #facc15' }}
        />
      </section>

      {/* Remainder Interest Projection */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#facc15' }}><Gift size={24} /> Remainder Interest to Charity Projection</h2>
        <p><DollarSign size={18} /> Projected remainder: ${remainderInterest.toFixed(2)}</p>
        <p><Percent size={18} /> Calculated using IRS 7520 rate and trust duration.</p>
        <p><ArrowRight size={18} /> This represents the charitable portion after payouts.</p>
      </section>

      {/* Capital Gains Bypass Strategy */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#facc15' }}><Shield size={24} /> Capital Gains Bypass Strategy</h2>
        <p><TrendingUp size={18} /> Sell appreciated assets inside the CRT to bypass capital gains tax, as the trust is tax-exempt under IRC Section 664.</p>
        <p><CheckCircle2 size={18} /> Example: Transfer stocks with $500,000 gain; sell within CRT without immediate tax liability.</p>
      </section>

      {/* NIMCRUT Flip Provision Explanation */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#facc15' }}><ArrowRight size={24} /> NIMCRUT Flip Provision</h2>
        <p><Target size={18} /> A Net Income Makeup Charitable Remainder Unitrust (NIMCRUT) allows for a flip from income-based payouts to standard unitrust payouts after a triggering event.</p>
        <p><Calendar size={18} /> This provides flexibility for beneficiaries during low-income periods.</p>
      </section>

      {/* Income Tax Deduction Waterfall */}
      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#facc15' }}><Scale size={24} /> Income Tax Deduction Waterfall</h2>
        <p><Percent size={18} /> Visual breakdown using a BarChart.</p>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={deductionWaterfallData}>
            <XAxis dataKey="category" stroke="#facc15" />
            <YAxis stroke="#e11d48" />
            <Tooltip />
            <Legend />
            <Bar dataKey="amount" fill="#facc15" />
          </BarChart>
        </ResponsiveContainer>
      </section>

      {/* IRS Compliance Section */}
      <section>
        <h2 style={{ color: '#facc15' }}><CheckCircle2 size={24} /> IRS Compliance and Regulations</h2>
        <p><Shield size={18} /> <strong>IRC Section 664:</strong> Governs CRTs, ensuring they meet the requirements for tax-exempt status.</p>
        <p><Award size={18} /> <strong>Section 170 Deduction Limits:</strong> Deductions for charitable contributions are limited to 30% of AGI for long-term capital gain property.</p>
        <p><Percent size={18} /> <strong>Section 7520 Rate:</strong> Used for valuing annuities, as set to {irs7520Rate}% in this example.</p>
        <p><Gift size={18} /> Compliance ensures the trust qualifies, providing tax benefits while supporting charity.</p>
      </section>

      {/* Additional Details for Length */}
      <div style={{ marginTop: '40px' }}>
        <h3 style={{ color: '#e11d48' }}>Why Choose CRTs?</h3>
        <p>CRTs offer a blend of income, tax savings, and philanthropy. With CRAT, you get fixed payments, making it suitable for retirees. CRUT, on the other hand, grows with investments, ideal for long-term planning.</p>
        <p>Consider the capital gains bypass: by placing appreciated assets into a CRT, you can sell them without triggering taxes, reinvesting the full amount for greater growth.</p>
        <p>The NIMCRUT flip is particularly useful in volatile markets, allowing adjustments based on income streams.</p>
        <p>For deduction modeling, always consult a tax professional to navigate the waterfall of adjustments under Section 170.</p>
        <p>Projections like the 20-year simulation help visualize how your trust performs over time, factoring in rates like 7520.</p>
        <p>In summary, CRTs are a powerful tool in estate planning, blending personal financial security with charitable giving.</p>
      </div>
      <PageInsights section="c-r-t-deep-dive" />
    </div>
  );
};

export default CRTDeepDive;
