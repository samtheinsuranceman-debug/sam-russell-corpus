// @ts-nocheck
/**
 * Client Journey Navigator
 * Grok-recommended Feature 27 (Impact 8, CLIENT LIFECYCLE MANAGEMENT)
 * Full client lifecycle management with milestone tracking and engagement prediction.
 */
import { useState, useEffect } from "react";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Map, Users, Target, CheckCircle, Clock, ArrowRight, Star, TrendingUp, Heart, Mail, Phone, Calendar, AlertTriangle, Sparkles, Brain, ChevronRight, Eye, Zap, BarChart3, Shield, Icon} from 'lucide-react';
import { useReportToHub } from "@/contexts/UnifiedDataBusContext";
import { PageInsights } from "@/components/PageInsights";

interface ClientProfile {
  id: string;
  name: string;
  specialty: string;
  stage: "prospect" | "onboarding" | "active" | "growth" | "retention" | "advocate";
  engagementScore: number;
  nextMilestone: string;
  nextAction: string;
  lastContact: string;
  lifetimeValue: string;
  riskFlag: boolean;
  avatar: string;
}

interface JourneyStage {
  id: string;
  name: string;
  description: string;
  clients: number;
  avgDuration: string;
  conversionRate: number;
  color: string;
  icon: typeof Map;
}

const STAGES: JourneyStage[] = [
  { id: "prospect", name: "Prospect", description: "Initial discovery and qualification", clients: 12, avgDuration: "14 days", conversionRate: 68, color: "slate", icon: Target },
  { id: "onboarding", name: "Onboarding", description: "KYC, risk assessment, initial planning", clients: 8, avgDuration: "21 days", conversionRate: 92, color: "blue", icon: Users },
  { id: "active", name: "Active", description: "Policy implementation and monitoring", clients: 45, avgDuration: "Ongoing", conversionRate: 95, color: "emerald", icon: CheckCircle },
  { id: "growth", name: "Growth", description: "Portfolio expansion and optimization", clients: 23, avgDuration: "Ongoing", conversionRate: 88, color: "purple", icon: TrendingUp },
  { id: "retention", name: "Retention", description: "Annual reviews and re-engagement", clients: 15, avgDuration: "30 days", conversionRate: 85, color: "amber", icon: Heart },
  { id: "advocate", name: "Advocate", description: "Referral generation and testimonials", clients: 18, avgDuration: "Ongoing", conversionRate: 100, color: "rose", icon: Star },
];

const CLIENTS: ClientProfile[] = [
  { id: "c1", name: "Dr. Sarah Chen", specialty: "Cardiology", stage: "growth", engagementScore: 92, nextMilestone: "Annual Review", nextAction: "Schedule Q2 review call", lastContact: "2 days ago", lifetimeValue: "$45K", riskFlag: false, avatar: "SC" },
  { id: "c2", name: "Dr. James Martinez", specialty: "Orthopedics", stage: "onboarding", engagementScore: 78, nextMilestone: "Policy Delivery", nextAction: "Send final illustrations", lastContact: "1 day ago", lifetimeValue: "$12K", riskFlag: false, avatar: "JM" },
  { id: "c3", name: "Dr. Emily Thompson", specialty: "Dermatology", stage: "retention", engagementScore: 45, nextMilestone: "Re-engagement", nextAction: "Send personalized market update", lastContact: "45 days ago", lifetimeValue: "$38K", riskFlag: true, avatar: "ET" },
  { id: "c4", name: "Dr. Michael Park", specialty: "Anesthesiology", stage: "active", engagementScore: 88, nextMilestone: "Premium Financing Review", nextAction: "Compare new carrier rates", lastContact: "5 days ago", lifetimeValue: "$52K", riskFlag: false, avatar: "MP" },
  { id: "c5", name: "Dr. Lisa Wong", specialty: "Radiology", stage: "prospect", engagementScore: 65, nextMilestone: "Discovery Call", nextAction: "Send intro materials", lastContact: "3 days ago", lifetimeValue: "$0", riskFlag: false, avatar: "LW" },
  { id: "c6", name: "Dr. Robert Kim", specialty: "Surgery", stage: "advocate", engagementScore: 96, nextMilestone: "Referral Follow-up", nextAction: "Thank for 2 referrals this month", lastContact: "1 week ago", lifetimeValue: "$67K", riskFlag: false, avatar: "RK" },
];

export default function ClientJourneyNavigator() {
  const _reportToHub = useReportToHub("ai-pro-client-journey", "Client Journey Navigator", "ai-pro-suite", "/portal/client-journey");
  useEffect(() => {
    _reportToHub({ visited: true, timestamp: Date.now() });
  }, [_reportToHub]);
  const [selectedStage, setSelectedStage] = useState<string | null>(null);
  const [selectedClient, setSelectedClient] = useState<ClientProfile | null>(null);

  const totalClients = STAGES.reduce((s, st) => s + st.clients, 0);
  const atRiskClients = CLIENTS.filter(c => c.riskFlag).length;
  const avgEngagement = Math.round(CLIENTS.reduce((s, c) => s + c.engagementScore, 0) / CLIENTS.length);

  const filteredClients = selectedStage ? CLIENTS.filter(c => c.stage === selectedStage) : CLIENTS;

  return (
    <AppShell title="Client Journey Navigator" subtitle="Manage the full client lifecycle with AI-driven milestone tracking and engagement prediction">
      <div className="space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card className="bg-emerald-500/5 border-emerald-500/20">
            <CardContent className="py-3 px-3 text-center">
              <p className="text-2xl font-bold text-emerald-400">{totalClients}</p>
              <p className="text-xs text-slate-500">Total Clients</p>
            </CardContent>
          </Card>
          <Card className="bg-blue-500/5 border-blue-500/20">
            <CardContent className="py-3 px-3 text-center">
              <p className="text-2xl font-bold text-blue-400">{avgEngagement}%</p>
              <p className="text-xs text-slate-500">Avg Engagement</p>
            </CardContent>
          </Card>
          <Card className="bg-amber-500/5 border-amber-500/20">
            <CardContent className="py-3 px-3 text-center">
              <p className="text-2xl font-bold text-amber-400">{atRiskClients}</p>
              <p className="text-xs text-slate-500">At Risk</p>
            </CardContent>
          </Card>
          <Card className="bg-purple-500/5 border-purple-500/20">
            <CardContent className="py-3 px-3 text-center">
              <p className="text-2xl font-bold text-purple-400">18</p>
              <p className="text-xs text-slate-500">Advocates</p>
            </CardContent>
          </Card>
        </div>

        {/* Journey Pipeline */}
        <Card className="bg-[#0d1526]/50 border-[#1e3a5f]/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-emerald-400 flex items-center gap-2">
              <Map className="h-4 w-4" /> Client Journey Pipeline
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-1 overflow-x-auto pb-2">
              {STAGES.map((stage, i) => {
                const Icon = stage.icon;
                const isSelected = selectedStage === stage.id;
                return (
                  <div key={stage.id} className="flex items-center">
                    <button onClick={() => setSelectedStage(isSelected ? null : stage.id)}
                      className={`flex flex-col items-center p-3 rounded-lg border min-w-[120px] transition-all ${
                        isSelected ? `bg-${stage.color}-500/15 border-${stage.color}-500/40` :
                        "bg-[#0a0f1a]/50 border-[#1e3a5f]/50 hover:border-[#1e3a5f]"
                      }`}>
                      <div className={`w-8 h-8 rounded-full bg-${stage.color}-500/20 flex items-center justify-center mb-1`}>
                        <Icon className={`h-4 w-4 text-${stage.color}-400`} />
                      </div>
                      <span className="text-xs text-white font-medium">{stage.name}</span>
                      <span className={`text-lg font-bold text-${stage.color}-400`}>{stage.clients}</span>
                      <span className="text-xs text-slate-500">{stage.avgDuration}</span>
                      <div className="w-full mt-1">
                        <Progress value={stage.conversionRate} className="h-1 bg-slate-700" />
                      </div>
                      <span className="text-xs text-slate-500 mt-0.5">{stage.conversionRate}% conv.</span>
                    </button>
                    {i < STAGES.length - 1 && <ArrowRight className="h-4 w-4 text-slate-600 mx-1 shrink-0" />}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Client List */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2">
            <Card className="bg-[#0d1526]/50 border-[#1e3a5f]/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-blue-400 flex items-center gap-2">
                  <Users className="h-4 w-4" /> {selectedStage ? `${STAGES.find(s => s.id === selectedStage)?.name} Clients` : "All Clients"}
                  <Badge variant="outline" className="text-xs text-[#7a95b8] border-[#1e3a5f]">{filteredClients.length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {filteredClients.map(client => (
                  <div key={client.id} className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    selectedClient?.id === client.id ? "bg-blue-500/10 border-blue-500/30" :
                    client.riskFlag ? "bg-red-500/5 border-red-500/20" :
                    "bg-[#0a0f1a]/50 border-[#1e3a5f]/50 hover:border-[#1e3a5f]"
                  }`} onClick={() => setSelectedClient(client)}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center text-xs font-bold text-blue-400">
                          {client.avatar}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="text-sm text-white font-medium">{client.name}</p>
                            {client.riskFlag && <AlertTriangle className="h-3 w-3 text-red-400" />}
                          </div>
                          <p className="text-xs text-slate-500">{client.specialty} · {client.stage}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 text-right">
                        <div>
                          <p className={`text-sm font-bold ${client.engagementScore >= 80 ? "text-emerald-400" : client.engagementScore >= 60 ? "text-amber-400" : "text-red-400"}`}>
                            {client.engagementScore}%
                          </p>
                          <p className="text-xs text-slate-500">Engagement</p>
                        </div>
                        <ChevronRight className="h-4 w-4 text-slate-500" />
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
      <PageInsights section="client-journey-navigator" />
          </div>

          {/* Client Detail / Actions */}
          <Card className="bg-[#0d1526]/50 border-[#1e3a5f]/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-purple-400 flex items-center gap-2">
                <Brain className="h-4 w-4" /> {selectedClient ? "Client Actions" : "Quick Actions"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {selectedClient ? (
                <>
                  <div className="text-center p-3 bg-[#0a0f1a]/50 rounded-lg border border-[#1e3a5f]/30">
                    <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center text-lg font-bold text-blue-400 mx-auto mb-2">
                      {selectedClient.avatar}
                    </div>
                    <p className="text-sm text-white font-semibold">{selectedClient.name}</p>
                    <p className="text-xs text-slate-500">{selectedClient.specialty}</p>
                    <p className="text-xs text-emerald-400 mt-1">LTV: {selectedClient.lifetimeValue}</p>
                  </div>
                  <div className="space-y-2">
                    <div className="p-2 rounded-lg bg-emerald-500/5 border border-emerald-500/15">
                      <p className="text-xs text-emerald-400 font-medium">Next Milestone</p>
                      <p className="text-xs text-[#94a3b8]">{selectedClient.nextMilestone}</p>
                    </div>
                    <div className="p-2 rounded-lg bg-blue-500/5 border border-blue-500/15">
                      <p className="text-xs text-blue-400 font-medium">Recommended Action</p>
                      <p className="text-xs text-[#94a3b8]">{selectedClient.nextAction}</p>
                    </div>
                    <div className="p-2 rounded-lg bg-[#0a0f1a]/50 border border-[#1e3a5f]/30">
                      <p className="text-xs text-slate-500">Last Contact: {selectedClient.lastContact}</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Button size="sm" className="text-xs bg-emerald-600 hover:bg-emerald-500 text-white">
                      <Mail className="h-3 w-3 mr-1" /> Email
                    </Button>
                    <Button size="sm" className="text-xs bg-blue-600 hover:bg-blue-500 text-white">
                      <Phone className="h-3 w-3 mr-1" /> Call
                    </Button>
                    <Button size="sm" variant="outline" className="text-xs border-[#1e3a5f] text-[#7a95b8] col-span-2">
                      <Calendar className="h-3 w-3 mr-1" /> Schedule Meeting
                    </Button>
                  </div>
                </>
              ) : (
                <div className="space-y-2">
                  {[
                    { label: "Review at-risk clients", icon: AlertTriangle, color: "red" },
                    { label: "Send batch follow-ups", icon: Mail, color: "blue" },
                    { label: "Schedule annual reviews", icon: Calendar, color: "purple" },
                    { label: "Generate engagement report", icon: BarChart3, color: "emerald" },
                  ].map(action => {
                    const Icon = action.icon;
                    return (
                      <Button key={action.label} size="sm" variant="outline"
                        className={`w-full justify-start text-xs border-[#1e3a5f] text-[#7a95b8] hover:text-${action.color}-400`}>
                        <Icon className={`h-3 w-3 mr-2 text-${action.color}-400`} /> {action.label}
                      </Button>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}
