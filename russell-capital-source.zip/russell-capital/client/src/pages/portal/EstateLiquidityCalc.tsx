// @ts-nocheck

import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Circle, CalculatorIcon, ShieldIcon, TrendingUpIcon} from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function EstateLiquidityCalc() {
  const autoFill = useCalculatorAutoFill("estate-liquidity");
  const { reportResult } = useCalcResults();
  const [currentAge, setCurrentAge] = useSharedField("currentAge", 40);
  const [lifeExpectancy, setLifeExpectancy] = useState(85);
  const [currentEstateValue, setCurrentEstateValue] = useState(500000);
  const [annualGrowthRate, setAnnualGrowthRate] = useState(5);
  const [inflationRate, setInflationRate] = useState(3);
  const [taxRate, setTaxRate] = useSharedField("currentTaxBracket", 40);

  const calculations = useMemo(() => {
    const yearsToDeath = lifeExpectancy - currentAge;
    const futureEstateValue = currentEstateValue * Math.pow(1 + (annualGrowthRate / 100), yearsToDeath);
    const inflatedEstateValue = futureEstateValue * Math.pow(1 + (inflationRate / 100), yearsToDeath);
    const estateTaxes = (inflatedEstateValue * (taxRate / 100));
    const liquidityNeeded = estateTaxes * 1.1;  // Add 10% buffer
    return {
      futureEstateValue,
      estateTaxes,
      liquidityNeeded,
    };
  }, [currentAge, lifeExpectancy, currentEstateValue, annualGrowthRate, inflationRate, taxRate]);

  const iulAdvantage = (
    <div className="p-4 bg-[#0d1526] rounded-lg shadow-md">
      <h3 className="text-xl font-bold text-white mb-2">IUL Advantage</h3>
      <p className="text-[#94a3b8]">
        Indexed Universal Life (IUL) insurance provides tax-free growth and a death benefit, helping to cover estate liquidity needs without eroding your estate. It offers protection against market volatility and can be a key tool in estate planning.
      </p>
      <Badge variant="secondary" className="mt-2 bg-emerald-400 text-black">
        Tax-Free Growth
      </Badge>
    </div>
  );
  const projectionData = useMemo(() => {
    const d = [];
    let opt = 100000, base = 100000, taxSav = 0;
    for (let yr = 0; yr <= 50; yr++) {
      opt *= 1.075;
      base *= 1.05;
      taxSav += (opt - base) * 0.08;
      d.push({ year: yr, optimized: Math.round(opt), baseline: Math.round(base), taxSavings: Math.round(taxSav), netBenefit: Math.round(opt - base + taxSav) });
    }
    return d;
  }, []);


  return (
    <AppShell
      headerTitle="Estate Liquidity Needs Calculator"
      headerSubtitle="Category: Estate & Trust Planning"
    >
      <div className="p-6 bg-[#0a0f1a] min-h-screen">
        <AutoFillBanner calcRoute="estate-liquidity" />
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-4">Input Your Details</h2>
          <div className="space-y-4">
            <div>
              <Label htmlFor="age" className="text-white">Current Age</Label>
              <div className="flex items-center space-x-2">
                <Input
                  id="age"
                  type="number"
                  value={currentAge}
                  onChange={(e) => setCurrentAge(Number(e.target.value))}
                  className="bg-[#0d1526] text-white"
                  min={18}
                  max={100}
                />
                <Slider
                  min={18}
                  max={100}
                  step={1}
                  value={[currentAge]}
                  onValueChange={(value) => setCurrentAge(value[0])}
                  className="w-full"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="lifeExpectancy" className="text-white">Life Expectancy</Label>
              <div className="flex items-center space-x-2">
                <Input
                  id="lifeExpectancy"
                  type="number"
                  value={lifeExpectancy}
                  onChange={(e) => setLifeExpectancy(Number(e.target.value))}
                  className="bg-[#0d1526] text-white"
                  min={50}
                  max={120}
                />
                <Slider
                  min={50}
                  max={120}
                  step={1}
                  value={[lifeExpectancy]}
                  onValueChange={(value) => setLifeExpectancy(value[0])}
                  className="w-full"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="estateValue" className="text-white">Current Estate Value</Label>
              <Input
                id="estateValue"
                type="number"
                value={currentEstateValue}
                onChange={(e) => setCurrentEstateValue(Number(e.target.value))}
                className="bg-[#0d1526] text-white"
              />
            </div>
            <div>
              <Label htmlFor="growthRate" className="text-white">Annual Growth Rate (%)</Label>
              <div className="flex items-center space-x-2">
                <Input
                  id="growthRate"
                  type="number"
                  value={annualGrowthRate}
                  onChange={(e) => setAnnualGrowthRate(Number(e.target.value))}
                  className="bg-[#0d1526] text-white"
                  min={0}
                  max={20}
                />
                <Slider
                  min={0}
                  max={20}
                  step={0.5}
                  value={[annualGrowthRate]}
                  onValueChange={(value) => setAnnualGrowthRate(value[0])}
                  className="w-full"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="inflationRate" className="text-white">Inflation Rate (%)</Label>
              <div className="flex items-center space-x-2">
                <Input
                  id="inflationRate"
                  type="number"
                  value={inflationRate}
                  onChange={(e) => setInflationRate(Number(e.target.value))}
                  className="bg-[#0d1526] text-white"
                  min={0}
                  max={10}
                />
                <Slider
                  min={0}
                  max={10}
                  step={0.5}
                  value={[inflationRate]}
                  onValueChange={(value) => setInflationRate(value[0])}
                  className="w-full"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="taxRate" className="text-white">Estate Tax Rate (%)</Label>
              <div className="flex items-center space-x-2">
                <Input
                  id="taxRate"
                  type="number"
                  value={taxRate}
                  onChange={(e) => setTaxRate(Number(e.target.value))}
                  className="bg-[#0d1526] text-white"
                  min={0}
                  max={100}
                />
                <Slider
                  min={0}
                  max={100}
                  step={1}
                  value={[taxRate]}
                  onValueChange={(value) => setTaxRate(value[0])}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        </div>
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />

        
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "optimized", label: "Optimized Strategy", color: "#10b981" }, { key: "baseline", label: "Baseline (No Action)", color: "#ef4444" }, { key: "taxSavings", label: "Cumulative Tax Savings", color: "#06b6d4" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <CalculatorIcon className="mr-2" /> Future Estate Value
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl text-emerald-400">{formatDollars(calculations.futureEstateValue)}</p>
            </CardContent>
          </Card>
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <TrendingUpIcon className="mr-2" /> Estimated Estate Taxes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl text-emerald-400">{formatDollars(calculations.estateTaxes)}</p>
            </CardContent>
          </Card>
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <ShieldIcon className="mr-2" /> Liquidity Needed
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl text-emerald-400">{formatDollars(calculations.liquidityNeeded)}</p>
            </CardContent>
          </Card>
        </div>

        {iulAdvantage}

        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="mt-4 bg-emerald-400 text-black hover:bg-emerald-500"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("estate-liquidity", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-estate-liquidity");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Estate Liquidity Needs Calculator"
            calculatorRoute="estate-liquidity"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="estate-liquidity-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/estate-liquidity" />
</div>
    </AppShell>
  );
}