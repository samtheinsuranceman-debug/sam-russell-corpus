// @ts-nocheck

import { useState, useMemo } from "react";
import { useLocation } from "wouter";
import { useCalcResults } from "@/components/CalculatorIntegration";
import { CALCULATOR_ATLAS } from "@/hooks/useOrganismEyes";
import { PageInsights } from "@/components/PageInsights";

export default function DataFlowVisualizer() {
  const [location, navigate] = useLocation();
  const { results: calcResults } = useCalcResults();
  const calculators = CALCULATOR_ATLAS;

  // Build edges from relatedCalcs in the atlas
  const edges = useMemo(() => {
    const result: Array<{ from: string; to: string }> = [];
    for (const calc of calculators) {
      for (const rel of calc.relatedCalcs) {
        if (calculators.some(c => c.route === rel)) {
          result.push({ from: calc.route, to: rel });
        }
      }
    }
    return result;
  }, [calculators]);

  // Show first 30 calculators for readability
  const visibleCalcs = calculators.slice(0, 30);

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-amber-300 p-6">
      <h1 className="text-3xl font-bold mb-2 text-amber-400">Data Flow Visualizer</h1>
      <p className="text-sm text-[#7a95b8] mb-6">{calculators.length} calculators &middot; {edges.length} data connections</p>
      
      <div className="relative" style={{ minHeight: '80vh' }}>
        <svg className="absolute top-0 left-0 w-full h-full pointer-events-none" style={{ zIndex: 1 }}>
          {edges.slice(0, 100).map((edge, i) => {
            const fromIndex = visibleCalcs.findIndex(c => c.route === edge.from);
            const toIndex = visibleCalcs.findIndex(c => c.route === edge.to);
            if (fromIndex === -1 || toIndex === -1) return null;
            const cols = 3;
            const cellW = 320;
            const cellH = 100;
            const fromX = (fromIndex % cols) * cellW + cellW / 2;
            const fromY = Math.floor(fromIndex / cols) * cellH + cellH / 2;
            const toX = (toIndex % cols) * cellW + cellW / 2;
            const toY = Math.floor(toIndex / cols) * cellH + cellH / 2;
            const isActive = calcResults[edge.from] && calcResults[edge.to];
            return (
              <line
                key={`edge-${i}`}
                x1={fromX}
                y1={fromY}
                x2={toX}
                y2={toY}
                stroke={isActive ? "#10b981" : "#d97706"}
                strokeWidth="1.5"
                strokeOpacity="0.4"
              />
            );
          })}
        </svg>
        <div className="grid grid-cols-3 gap-3 relative" style={{ zIndex: 2 }}>
          {visibleCalcs.map((calc) => {
            const hasResults = !!calcResults[calc.route];
            return (
              <div
                key={calc.route}
                onClick={() => navigate(`/portal/${calc.route}`)}
                className={`bg-[#0d1526] p-3 rounded cursor-pointer transition hover:bg-[#162a4a] ${
                  hasResults ? "border-2 border-emerald-500" : "border border-amber-500/40"
                }`}
              >
                <h2 className="text-amber-400 font-medium text-sm">{calc.name}</h2>
                <p className="text-xs text-gray-500">{calc.category} &middot; {calc.relatedCalcs.length} connections</p>
              </div>
            );
          })}
        </div>
      </div>
      <PageInsights section="data-flow-visualizer" />
    </div>
  );
}
