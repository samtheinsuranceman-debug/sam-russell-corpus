// @ts-nocheck
import React from 'react';
import { useOrganismContext } from '@/contexts/OrganismContext';
import { AlertCircle, CheckCircle } from 'lucide-react';
import { PageInsights } from "@/components/PageInsights";

interface OrganismContextType {
  organism: {
    clientData?: {
      Personal: { [key: string]: boolean };
      Financial: { [key: string]: boolean };
      Insurance: { [key: string]: boolean };
      Estate: { [key: string]: boolean };
      Tax: { [key: string]: boolean };
      Retirement: { [key: string]: boolean };
    };
  } | null;
}

const categories: string[] = ['Personal', 'Financial', 'Insurance', 'Estate', 'Tax', 'Retirement'];

const DataCompletenessTracker: React.FC = () => {
  const { organism } = useOrganismContext() as OrganismContextType;

  if (!organism || !organism.clientData) {
    return (
      <div className="bg-[#0a1628] min-h-screen flex items-center justify-center text-white p-4">
        Loading...
      </div>
    );
  }

  const clientData = organism.clientData;
  const missingFieldsArray: { category: string; field: string }[] = [];
  let totalFields = 0;
  let completeFields = 0;

  categories.forEach(category => {
    if (clientData[category]) {
      Object.entries(clientData[category]).forEach(([field, isComplete]) => {
        totalFields++;
        if (!isComplete) {
          missingFieldsArray.push({ category, field });
        } else {
          completeFields++;
        }
      });
    }
  });

  const overallPercentage = totalFields > 0 ? (completeFields / totalFields) * 100 : 0;
  const quickFill = missingFieldsArray.slice(0, 5);
  const missingFields: { [key: string]: string[] } = {};

  missingFieldsArray.forEach(({ category, field }) => {
    if (!missingFields[category]) missingFields[category] = [];
    missingFields[category].push(field);
  });

  const radius = 40;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference * (1 - overallPercentage / 100);

  return (
    <div className="bg-[#0a1628] min-h-screen p-4 text-white flex flex-col items-center">
      <h1 className="text-2xl font-bold mb-6">Data Completeness</h1>
      
      <div className="mb-8 flex flex-col items-center">
        <h2 className="text-xl mb-2">Overall Completeness</h2>
        <svg width="100" height="100" className="mb-2">
          <circle
            r={radius}
            cx="50"
            cy="50"
            stroke="gray"
            strokeWidth="10"
            fill="none"
            strokeDasharray={circumference}
            strokeDashoffset={circumference}
          />
          <circle
            r={radius}
            cx="50"
            cy="50"
            stroke="blue"
            strokeWidth="10"
            fill="none"
            strokeDasharray={circumference}
            strokeDashoffset={dashOffset}
          />
        </svg>
        <p className="text-lg">{overallPercentage.toFixed(2)}%</p>
      </div>
      
      <h2 className="text-xl mb-4 w-full max-w-md">Missing Fields by Category</h2>
      <div className="w-full max-w-md">
        {categories.map(category => (
          missingFields[category] && missingFields[category].length > 0 && (
            <div key={category} className="mb-6">
              <h3 className="text-lg font-semibold mb-2">{category}</h3>
              <ul className="list-disc pl-5">
                {missingFields[category].map(field => (
                  <li key={field} className="flex items-center mb-1">
                    <AlertCircle className="mr-2" size={16} />
                    <a href={`/edit-${category.toLowerCase()}`} className="text-blue-400 hover:underline">
                      {field}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          )
        ))}
        {missingFieldsArray.length === 0 && (
          <p className="text-center">No missing fields! <CheckCircle className="inline" size={20} /></p>
        )}
      </div>
      
      <h2 className="text-xl mb-4 mt-6 w-full max-w-md">Quick Fill</h2>
      <div className="w-full max-w-md">
        <ul className="list-disc pl-5">
          {quickFill.map(({ category, field }, index) => (
            <li key={index} className="flex items-center mb-1">
              <AlertCircle className="mr-2" size={16} />
              <a href={`/edit-${category.toLowerCase()}`} className="text-blue-400 hover:underline">
                {field} ({category})
              </a>
            </li>
          ))}
          {quickFill.length === 0 && <p className="text-center">All set for quick fill!</p>}
        </ul>
      </div>
      <PageInsights section="data-completeness-tracker" />
    </div>
  );
};

export default DataCompletenessTracker;
