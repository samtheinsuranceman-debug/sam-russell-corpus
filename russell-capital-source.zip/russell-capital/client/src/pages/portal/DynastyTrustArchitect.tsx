// @ts-nocheck
import React, { useState } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Activity, Briefcase, Calculator, CheckCircle2, ChevronDown, ChevronUp, Coins, DollarSign, Layers, LineChartIcon, PieChartIcon, Shield, TrendingUp, Users, Wallet } from 'lucide-react';
import { toast } from 'sonner';
import { PageInsights } from '@/components/PageInsights';

const DynastyTrustArchitect: React.FC = () => {
  const [activeTab, setActiveTab] = useState('design');
  const [stateSelection, setStateSelection] = useState('South Dakota');
  const [gstAllocation, setGstAllocation] = useState(13610000);
  const [projectionYears, setProjectionYears] = useSharedField("projectionYears", 50);
  const [initialFunding, setInitialFunding] = useState(5000000);
  const [annualGift, setAnnualGift] = useState(18000);
  const [growthRate, setGrowthRate] = useSharedField("growthRate", 5);

  // Sample data for 50-year wealth projection
  const projectionData = Array.from({ length: projectionYears }, (_, i) => {
    const year = 2024 + i;
    const value = initialFunding * Math.pow(1 + growthRate / 100, i) + annualGift * i;
    return { year, value };
  });

  // Sample distribution data for bar chart
  const distributionData = [
    { generation: 'Gen 1', amount: 2000000 },
    { generation: 'Gen 2', amount: 3500000 },
    { generation: 'Gen 3', amount: 5000000 },
    { generation: 'Gen 4', amount: 6500000 },
  ];

  const handleGenerateOutcome = () => {
    if (gstAllocation > 13610000) {
      toast.warning('GST allocation exceeds 2024 exemption limit of $13.61M per person (IRC §2631).');
    } else {
      toast.success('Trust outcome generated successfully based on current parameters.');
    }
  };

  const stateOptions = ['South Dakota', 'Nevada', 'Alaska', 'Delaware'];

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-2 mb-6">
          <Shield className="w-8 h-8 text-emerald-400" />
          <h1 className="text-3xl font-bold">Dynasty Trust Architect</h1>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-4 border-b border-[#1e3a5f] mb-6">
          {['design', 'projections', 'distributions'].map((tab) => (
            <button
              key={tab}
              className={`pb-3 px-4 capitalize ${activeTab === tab ? 'text-emerald-400 border-b-2 border-emerald-400' : 'text-[#7a95b8]'}`}
              onClick={() => setActiveTab(tab)}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Design Tab */}
        {activeTab === 'design' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f]">
                <div className="flex items-center gap-2 mb-3">
                  <Layers className="w-5 h-5 text-emerald-400" />
                  <h2 className="text-xl font-semibold">State Selection Matrix</h2>
                </div>
                <p className="text-[#7a95b8] mb-3">Select a state with no rule against perpetuities for perpetual trust design.</p>
                <select
                  className="w-full bg-[#0a0f1a] border border-[#1e3a5f] rounded-md p-2 text-white"
                  value={stateSelection}
                  onChange={(e) => setStateSelection(e.target.value)}
                >
                  {stateOptions.map((state) => (
                    <option key={state} value={state}>{state}</option>
                  ))}
                </select>
              </div>

              <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f]">
                <div className="flex items-center gap-2 mb-3">
                  <DollarSign className="w-5 h-5 text-emerald-400" />
                  <h2 className="text-xl font-semibold">GST Exemption Allocation</h2>
                </div>
                <p className="text-[#7a95b8] mb-3">2024 Limit: $13.61M per person (IRC §2631)</p>
                <input
                  type="number"
                  className="w-full bg-[#0a0f1a] border border-[#1e3a5f] rounded-md p-2 text-white"
                  value={gstAllocation}
                  onChange={(e) => setGstAllocation(Number(e.target.value))}
                />
              </div>
            </div>

            <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f]">
              <div className="flex items-center gap-2 mb-3">
                <Briefcase className="w-5 h-5 text-emerald-400" />
                <h2 className="text-xl font-semibold">Trust Provisions</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-[#7a95b8]">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Trust Protector Provisions</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Decanting Powers</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Directed Trust Structures</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Projections Tab */}
        {activeTab === 'projections' && (
          <div className="space-y-6">
            <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f]">
              <div className="flex items-center gap-2 mb-3">
                <LineChartIcon className="w-5 h-5 text-emerald-400" />
                <h2 className="text-xl font-semibold">Wealth Projection (50+ Years)</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div>
                  <label className="text-[#7a95b8] block mb-1">Initial Funding ($)</label>
                  <input
                    type="number"
                    className="w-full bg-[#0a0f1a] border border-[#1e3a5f] rounded-md p-2 text-white"
                    value={initialFunding}
                    onChange={(e) => setInitialFunding(Number(e.target.value))}
                  />
                </div>
                <div>
                  <label className="text-[#7a95b8] block mb-1">Annual Gift ($)</label>
                  <input
                    type="number"
                    className="w-full bg-[#0a0f1a] border border-[#1e3a5f] rounded-md p-2 text-white"
                    value={annualGift}
                    onChange={(e) => setAnnualGift(Number(e.target.value))}
                  />
                </div>
                <div>
                  <label className="text-[#7a95b8] block mb-1">Growth Rate (%)</label>
                  <input
                    type="number"
                    className="w-full bg-[#0a0f1a] border border-[#1e3a5f] rounded-md p-2 text-white"
                    value={growthRate}
                    onChange={(e) => setGrowthRate(Number(e.target.value))}
                  />
                </div>
              </div>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={projectionData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                    <XAxis dataKey="year" stroke="#7a95b8" />
                    <YAxis stroke="#7a95b8" tickFormatter={(value) => `$${value.toLocaleString()}`} />
                    <Tooltip formatter={(value) => `$${value.toLocaleString()}`} contentStyle={{ backgroundColor: '#0d1526', border: '1px solid #1e3a5f' }} />
                    <Area type="monotone" dataKey="value" stroke="#34d399" fill="#34d39933" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* Distributions Tab */}
        {activeTab === 'distributions' && (
          <div className="space-y-6">
            <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f]">
              <div className="flex items-center gap-2 mb-3">
                <PieChartIcon className="w-5 h-5 text-emerald-400" />
                <h2 className="text-xl font-semibold">Generational Distribution</h2>
              </div>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={distributionData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                    <XAxis dataKey="generation" stroke="#7a95b8" />
                    <YAxis stroke="#7a95b8" tickFormatter={(value) => `$${value.toLocaleString()}`} />
                    <Tooltip formatter={(value) => `$${value.toLocaleString()}`} contentStyle={{ backgroundColor: '#0d1526', border: '1px solid #1e3a5f' }} />
                    <Bar dataKey="amount" fill="#34d399" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* Generate Outcome Section */}
        <div className="mt-6 bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f] flex justify-between items-center">
          <div>
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              Generate Trust Outcome
            </h2>
            <p className="text-[#7a95b8] mt-1">Simulate wealth transfer based on current parameters.</p>
          </div>
          <button
            className="bg-emerald-500 hover:bg-emerald-400 text-white px-4 py-2 rounded-md flex items-center gap-2"
            onClick={handleGenerateOutcome}
          >
            <Calculator className="w-4 h-4" />
            Generate
          </button>
        </div>

        <PageInsights section="DynastyTrustArchitect" />
      </div>
    </div>
  );
};

export default DynastyTrustArchitect;