// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { CreditCard, DollarSign, TrendingDown, Target, Calendar, Percent, ArrowRight, Shield, CheckCircle2, AlertTriangle, Zap, Clock } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, AreaChart, Area, ComposedChart, Line } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

export default function DebtPayoffStrategy() {
  const [debts, setDebts] = useState([
    { type: 'Student Loans', amount: 200000, interest: 6.8, minPayment: 1200 },
    { type: 'Mortgage', amount: 500000, interest: 3.5, minPayment: 2500 },
    { type: 'Auto Loan', amount: 30000, interest: 4.5, minPayment: 500 },
    { type: 'Credit Cards', amount: 15000, interest: 18, minPayment: 400 },
    { type: 'Practice Loans', amount: 100000, interest: 7, minPayment: 800 },
    { type: 'HELOC', amount: 50000, interest: 7, minPayment: 300 },
  ]);

  const [extraPayment, setExtraPayment] = useState(500);
  const [selectedStrategy, setSelectedStrategy] = useState('avalanche');
  const [income, setIncome] = useSharedField("annualIncome", 300000);
  const [monthlyExpenses, setMonthlyExpenses] = useState(10000);
  const [helocAmount, setHelocAmount] = useState(50000);
  const [investmentReturn, setInvestmentReturn] = useState(15);
  const [studentLoanType, setStudentLoanType] = useState('PSLF');
  const [years, setYears] = useSharedField("projectionYears", 50);

  const darkThemeStyle = {
    backgroundColor: '#1a1a2e',
    color: '#ffffff',
    padding: '20px',
    minHeight: '100vh',
  };

  const accentRed = { color: '#ff4d4d' };
  const accentGreen = { color: '#4dff4d' };

  const calculateTotalDebt = useMemo(() => debts.reduce((sum, debt) => sum + debt.amount, 0), [debts]);

  const calculateDTI = useMemo(() => {
    const totalDebtPayment = debts.reduce((sum, debt) => sum + debt.minPayment, 0);
    return ((totalDebtPayment / (income / 12)) * 100).toFixed(2);
  }, [debts, income]);

  const avalancheStrategy = useMemo(() => {
    const sortedDebts = [...debts].sort((a, b) => b.interest - a.interest);
    return sortedDebts.map(debt => ({
      ...debt,
      payoffTime: calculatePayoffTime(debt.amount, debt.interest, debt.minPayment + extraPayment),
    }));
  }, [debts, extraPayment]);

  const snowballStrategy = useMemo(() => {
    const sortedDebts = [...debts].sort((a, b) => a.amount - b.amount);
    return sortedDebts.map(debt => ({
      ...debt,
      payoffTime: calculatePayoffTime(debt.amount, debt.interest, debt.minPayment + extraPayment),
    }));
  }, [debts, extraPayment]);

  const hybridStrategy = useMemo(() => {
    const highInterest = [...debts].filter(debt => debt.interest > 7).sort((a, b) => b.interest - a.interest);
    const lowBalance = [...debts].filter(debt => debt.interest <= 7).sort((a, b) => a.amount - b.amount);
    return [...highInterest, ...lowBalance].map(debt => ({
      ...debt,
      payoffTime: calculatePayoffTime(debt.amount, debt.interest, debt.minPayment + extraPayment),
    }));
  }, [debts, extraPayment]);

  const refinanceStrategy = useMemo(() => {
    return debts.map(debt => ({
      ...debt,
      interest: debt.interest * 0.9, // Assume 10% reduction
      payoffTime: calculatePayoffTime(debt.amount, debt.interest * 0.9, debt.minPayment + extraPayment),
    }));
  }, [debts, extraPayment]);

  const calculateInterestSavings = useMemo(() => {
    const originalInterest = debts.reduce((sum, debt) => sum + (debt.amount * (debt.interest / 100)), 0);
    const newInterest = avalancheStrategy.reduce((sum, debt) => sum + (debt.amount * (debt.interest / 100)), 0);
    return originalInterest - newInterest;
  }, [debts, avalancheStrategy]);

  const helocArbitrageReturn = useMemo(() => {
    const borrowed = helocAmount;
    const interestPaid = borrowed * (7 / 100);
    const investmentGain = borrowed * (investmentReturn / 100);
    return investmentGain - interestPaid;
  }, [helocAmount, investmentReturn]);

  const studentLoanForgivenessAnalysis = useMemo(() => {
    if (studentLoanType === 'PSLF') return 'Public Service Loan Forgiveness: Potential forgiveness after 10 years of payments.';
    if (studentLoanType === 'IDR') return 'Income-Driven Repayment: Adjusts payments based on income, forgiveness after 20-25 years.';
    if (studentLoanType === 'SAVE') return 'SAVE Plan: Similar to IDR with potential for faster forgiveness.';
    return 'No analysis selected.';
  }, [studentLoanType]);

  const wealthComparisonData = useMemo(() => {
    const aggressive = Array.from({ length: years }, (_, i) => ({
      year: i,
      wealth: calculateWealth(i, true),
    }));
    const leverage = Array.from({ length: years }, (_, i) => ({
      year: i,
      wealth: calculateWealth(i, false),
    }));
    return { aggressive, leverage };
  }, [years]);

  const calculatePayoffTime = (amount, interest, payment) => {
    let balance = amount;
    let months = 0;
    while (balance > 0) {
      const interestCharge = balance * (interest / 100 / 12);
      balance += interestCharge - payment;
      if (balance < 0) balance = 0;
      months++;
    }
    return months / 12;
  };

  const calculateWealth = (year, aggressive) => {
    if (aggressive) return (income * year) - calculateTotalDebt;
    return (income * year) + (helocAmount * (investmentReturn / 100 * year));
  };

  const optimizedMonthlyPayment = useMemo(() => {
    const totalMinPayments = debts.reduce((sum, debt) => sum + debt.minPayment, 0);
    return totalMinPayments + extraPayment;
  }, [debts, extraPayment]);

  return (
    <div style={darkThemeStyle}>
      <h1 style={accentGreen}><DollarSign /> Advanced Debt Payoff Strategy for Physicians and HNW Individuals</h1>
      
      {/* Debt Inventory Section */}
      <section>
        <h2 style={accentRed}><CreditCard /> Debt Inventory</h2>
        <ul>
          {debts.map((debt, index) => (
            <li key={index}>
              {debt.type}: ${debt.amount} at {debt.interest}% interest, Min Payment: ${debt.minPayment}
            </li>
          ))}
        </ul>
        <input
          type="number"
          placeholder="Extra Payment"
          onChange={e => setExtraPayment(Number(e.target.value))}
          style={{ backgroundColor: '#2a2a3e', color: '#fff' }}
        />
      </section>
      
      {/* Payoff Strategies Comparison */}
      <section>
        <h2 style={accentGreen}><Target /> Payoff Strategies Comparison</h2>
        <select onChange={e => setSelectedStrategy(e.target.value)}>
          <option value="avalanche">Avalanche</option>
          <option value="snowball">Snowball</option>
          <option value="hybrid">Hybrid</option>
          <option value="refinance">Refinance</option>
        </select>
        {selectedStrategy === 'avalanche' && <p>Avalanche Strategy Data: {JSON.stringify(avalancheStrategy)}</p>}
        {/* Add more detailed rendering */}
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={avalancheStrategy}>
            <XAxis dataKey="type" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="amount" fill="#ff4d4d" />
            <Bar dataKey="payoffTime" fill="#4dff4d" />
          </BarChart>
        </ResponsiveContainer>
      </section>
      
      {/* Interest Savings Calculator */}
      <section>
        <h2 style={accentRed}><TrendingDown /> Interest Savings Calculator</h2>
        <p>Savings: ${calculateInterestSavings.toFixed(2)}</p>
      </section>
      
      {/* Debt-to-Income Ratio Optimizer */}
      <section>
        <h2 style={accentGreen}><Percent /> Debt-to-Income Ratio Optimizer</h2>
        <input type="number" placeholder="Annual Income" onChange={e => setIncome(Number(e.target.value))} />
        <p>DTI: {calculateDTI}%</p>
        {calculateDTI > 43 && <p style={accentRed}><AlertTriangle /> High DTI! Optimize payments.</p>}
      </section>
      
      {/* HELOC Arbitrage Strategy */}
      <section>
        <h2 style={accentRed}><Zap /> HELOC Arbitrage Strategy</h2>
        <input type="number" placeholder="HELOC Amount" onChange={e => setHelocAmount(Number(e.target.value))} />
        <input type="number" placeholder="Investment Return %" onChange={e => setInvestmentReturn(Number(e.target.value))} />
        <p>Potential Return: ${helocArbitrageReturn.toFixed(2)}</p>
      </section>
      
      {/* Student Loan Forgiveness Analysis */}
      <section>
        <h2 style={accentGreen}><Shield /> Student Loan Forgiveness Analysis</h2>
        <select onChange={e => setStudentLoanType(e.target.value)}>
          <option value="PSLF">PSLF</option>
          <option value="IDR">IDR</option>
          <option value="SAVE">SAVE</option>
        </select>
        <p>{studentLoanForgivenessAnalysis}</p>
      </section>
      
      {/* 50-Year Wealth Comparison */}
      <section>
        <h2 style={accentRed}><Clock /> 50-Year Wealth Comparison</h2>
        <input type="number" placeholder="Years" onChange={e => setYears(Number(e.target.value))} />
        <ResponsiveContainer width="100%" height={400}>
          <ComposedChart data={wealthComparisonData.aggressive}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="wealth" fill="#ff4d4d" stroke="#4dff4d" />
            <Line type="monotone" dataKey="wealth" stroke="#ffffff" />
          </ComposedChart>
        </ResponsiveContainer>
      </section>
      
      {/* Monthly Payment Optimizer */}
      <section>
        <h2 style={accentGreen}><Calendar /> Monthly Payment Optimizer</h2>
        <p>Optimized Payment: ${optimizedMonthlyPayment}</p>
      </section>
      
      {/* Compliance Section */}
      <section>
        <h2 style={accentRed}><CheckCircle2 /> Compliance and Tax Deductions</h2>
        <p><ArrowRight /> IRC 163: Mortgage interest deduction up to $750,000.</p>
        <p><ArrowRight /> IRC 221: Student loan interest deduction up to $2,500.</p>
        <p><ArrowRight /> IRC 108: Cancellation of debt income exclusion for qualified loans.</p>
      </section>
      <PageInsights section="debt-payoff-strategy" />
    </div>
  );
}
