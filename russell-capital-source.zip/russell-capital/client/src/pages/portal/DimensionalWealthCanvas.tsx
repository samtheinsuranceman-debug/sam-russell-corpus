// @ts-nocheck
/**
 * Dimensional Wealth Canvas
 * Grok-recommended Feature 26 (Impact 8, ADVANCED DATA VISUALIZATION)
 * 3D-style portfolio mapping and multi-dimensional financial visualizations.
 */
import { useState, useEffect, useMemo } from "react";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Layers, Eye, Sparkles, BarChart3, PieChart, TrendingUp, Shield, Target, Brain, Zap, ChevronRight, Maximize2, RotateCcw, ZoomIn, ZoomOut, Grid3X3, Icon} from 'lucide-react';
import { useReportToHub } from "@/contexts/UnifiedDataBusContext";
import { PageInsights } from "@/components/PageInsights";

interface PortfolioDimension {
  name: string;
  value: number;
  maxValue: number;
  color: string;
  description: string;
}

interface AssetNode {
  id: string;
  name: string;
  category: string;
  value: number;
  risk: number;
  growth: number;
  taxEfficiency: number;
  color: string;
  size: number;
}

interface ScenarioResult {
  name: string;
  year5: number;
  year10: number;
  year20: number;
  year30: number;
  color: string;
}

const DIMENSIONS: PortfolioDimension[] = [
  { name: "Growth Potential", value: 78, maxValue: 100, color: "emerald", description: "Expected long-term appreciation across all assets" },
  { name: "Tax Efficiency", value: 85, maxValue: 100, color: "blue", description: "Percentage of wealth in tax-advantaged structures" },
  { name: "Risk Mitigation", value: 72, maxValue: 100, color: "purple", description: "Downside protection through insurance and diversification" },
  { name: "Liquidity Access", value: 65, maxValue: 100, color: "amber", description: "Ability to access funds within 30 days" },
  { name: "Legacy Transfer", value: 90, maxValue: 100, color: "rose", description: "Estate planning efficiency and wealth transfer readiness" },
  { name: "Income Generation", value: 68, maxValue: 100, color: "red", description: "Current and projected passive income streams" },
];

const ASSET_NODES: AssetNode[] = [
  { id: "a1", name: "IUL Policy (Pacific Life)", category: "Insurance", value: 1800000, risk: 15, growth: 6.5, taxEfficiency: 95, color: "emerald", size: 28 },
  { id: "a2", name: "401(k) + Match", category: "Retirement", value: 850000, risk: 45, growth: 8.2, taxEfficiency: 80, color: "blue", size: 20 },
  { id: "a3", name: "Taxable Brokerage", category: "Investment", value: 620000, risk: 55, growth: 9.1, taxEfficiency: 35, color: "amber", size: 16 },
  { id: "a4", name: "Real Estate (Rental)", category: "Real Estate", value: 450000, risk: 30, growth: 5.5, taxEfficiency: 70, color: "purple", size: 14 },
  { id: "a5", name: "CRT Trust", category: "Estate", value: 380000, risk: 20, growth: 4.8, taxEfficiency: 100, color: "rose", size: 12 },
  { id: "a6", name: "Practice Equity", category: "Business", value: 2200000, risk: 40, growth: 3.5, taxEfficiency: 50, color: "red", size: 30 },
  { id: "a7", name: "Emergency Fund", category: "Cash", value: 150000, risk: 5, growth: 4.5, taxEfficiency: 20, color: "slate", size: 8 },
];

const SCENARIOS: ScenarioResult[] = [
  { name: "Current Path", year5: 7200000, year10: 10800000, year20: 18500000, year30: 28000000, color: "slate" },
  { name: "Optimized (IUL Focus)", year5: 7800000, year10: 12200000, year20: 22000000, year30: 35000000, color: "emerald" },
  { name: "Aggressive Growth", year5: 8100000, year10: 13500000, year20: 25000000, year30: 40000000, color: "blue" },
  { name: "Conservative Shield", year5: 7000000, year10: 10200000, year20: 16000000, year30: 23000000, color: "amber" },
];

export default function DimensionalWealthCanvas() {
  const _reportToHub = useReportToHub("ai-pro-dimensional-canvas", "Dimensional Wealth Canvas", "ai-pro-suite", "/portal/dimensional-wealth-canvas");
  useEffect(() => {
    _reportToHub({ visited: true, timestamp: Date.now() });
  }, [_reportToHub]);
  const [activeView, setActiveView] = useState<"radar" | "bubble" | "timeline">("radar");
  const [selectedAsset, setSelectedAsset] = useState<AssetNode | null>(null);
  const [zoom, setZoom] = useState(1);

  const totalWealth = ASSET_NODES.reduce((s, a) => s + a.value, 0);
  const avgRisk = Math.round(ASSET_NODES.reduce((s, a) => s + a.risk * a.value, 0) / totalWealth);
  const avgGrowth = (ASSET_NODES.reduce((s, a) => s + a.growth * a.value, 0) / totalWealth).toFixed(1);
  const avgTax = Math.round(ASSET_NODES.reduce((s, a) => s + a.taxEfficiency * a.value, 0) / totalWealth);

  const fmtM = (n: number) => `$${(n / 1_000_000).toFixed(1)}M`;
  const fmtK = (n: number) => n >= 1_000_000 ? `$${(n / 1_000_000).toFixed(1)}M` : `$${(n / 1000).toFixed(0)}K`;

  return (
    <AppShell title="Dimensional Wealth Canvas" subtitle="Multi-dimensional portfolio visualization with 3D mapping and scenario analysis">
      <div className="space-y-6">
        {/* Overview */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <Card className="bg-emerald-500/5 border-emerald-500/20">
            <CardContent className="py-3 px-3 text-center">
              <p className="text-lg font-bold text-emerald-400">{fmtM(totalWealth)}</p>
              <p className="text-xs text-slate-500">Total Wealth</p>
            </CardContent>
          </Card>
          <Card className="bg-blue-500/5 border-blue-500/20">
            <CardContent className="py-3 px-3 text-center">
              <p className="text-lg font-bold text-blue-400">{avgGrowth}%</p>
              <p className="text-xs text-slate-500">Wtd. Growth</p>
            </CardContent>
          </Card>
          <Card className="bg-purple-500/5 border-purple-500/20">
            <CardContent className="py-3 px-3 text-center">
              <p className="text-lg font-bold text-purple-400">{avgRisk}%</p>
              <p className="text-xs text-slate-500">Wtd. Risk</p>
            </CardContent>
          </Card>
          <Card className="bg-amber-500/5 border-amber-500/20">
            <CardContent className="py-3 px-3 text-center">
              <p className="text-lg font-bold text-amber-400">{avgTax}%</p>
              <p className="text-xs text-slate-500">Tax Efficiency</p>
            </CardContent>
          </Card>
          <Card className="bg-rose-500/5 border-rose-500/20">
            <CardContent className="py-3 px-3 text-center">
              <p className="text-lg font-bold text-rose-400">{ASSET_NODES.length}</p>
              <p className="text-xs text-slate-500">Asset Classes</p>
            </CardContent>
          </Card>
        </div>

        {/* View Toggle */}
        <div className="flex items-center gap-2">
          {[
            { key: "radar" as const, label: "Dimension Radar", icon: Target },
            { key: "bubble" as const, label: "Asset Constellation", icon: Grid3X3 },
            { key: "timeline" as const, label: "Scenario Timeline", icon: TrendingUp },
          ].map(v => {
            const Icon = v.icon;
            return (
              <Button key={v.key} size="sm" variant={activeView === v.key ? "default" : "outline"}
                onClick={() => setActiveView(v.key)}
                className={`text-xs ${activeView === v.key ? "bg-emerald-600 text-white" : "border-[#1e3a5f] text-[#7a95b8]"}`}>
                <Icon className="h-3 w-3 mr-1" /> {v.label}
              </Button>
            );
          })}
        </div>

        {/* Radar View */}
        {activeView === "radar" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card className="bg-[#0d1526]/50 border-[#1e3a5f]/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-emerald-400 flex items-center gap-2">
                  <Target className="h-4 w-4" /> Portfolio Dimensions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative w-full aspect-square max-w-md mx-auto">
                  {/* Radar background rings */}
                  {[25, 50, 75, 100].map(ring => (
                    <div key={ring} className="absolute inset-0 flex items-center justify-center" style={{ padding: `${(100 - ring) / 2}%` }}>
                      <div className="w-full h-full rounded-full border border-[#1e3a5f]/30" />
                    </div>
                  ))}
                  {/* Dimension points */}
                  {DIMENSIONS.map((dim, i) => {
                    const angle = (i * 360) / DIMENSIONS.length - 90;
                    const rad = (angle * Math.PI) / 180;
                    const radius = (dim.value / dim.maxValue) * 42;
                    const x = 50 + radius * Math.cos(rad);
                    const y = 50 + radius * Math.sin(rad);
                    const labelX = 50 + 48 * Math.cos(rad);
                    const labelY = 50 + 48 * Math.sin(rad);
                    return (
                      <div key={dim.name}>
                        <div className={`absolute w-3 h-3 rounded-full bg-${dim.color}-400 shadow-lg shadow-${dim.color}-400/30`}
                          style={{ left: `${x}%`, top: `${y}%`, transform: "translate(-50%, -50%)" }} />
                        <div className="absolute text-xs text-[#7a95b8] whitespace-nowrap"
                          style={{ left: `${labelX}%`, top: `${labelY}%`, transform: "translate(-50%, -50%)" }}>
                          {dim.name}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526]/50 border-[#1e3a5f]/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-blue-400 flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" /> Dimension Scores
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {DIMENSIONS.map(dim => (
                  <div key={dim.name}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-[#7a95b8]">{dim.name}</span>
                      <span className={`text-sm font-bold text-${dim.color}-400`}>{dim.value}%</span>
                    </div>
                    <Progress value={dim.value} className="h-2 bg-slate-700" />
                    <p className="text-xs text-slate-500 mt-0.5">{dim.description}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        )}

        {/* Bubble View */}
        {activeView === "bubble" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2">
              <Card className="bg-[#0d1526]/50 border-[#1e3a5f]/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-purple-400 flex items-center gap-2">
                    <Grid3X3 className="h-4 w-4" /> Asset Constellation
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="relative w-full h-80 bg-[#0a0f1a]/50 rounded-lg border border-[#1e3a5f]/30 overflow-hidden">
                    <div className="absolute bottom-2 left-2 text-xs text-slate-600">Risk →</div>
                    <div className="absolute top-2 left-2 text-xs text-slate-600 -rotate-90 origin-top-left translate-y-12">Growth →</div>
                    {ASSET_NODES.map(node => {
                      const x = (node.risk / 60) * 80 + 10;
                      const y = 90 - (node.growth / 10) * 80;
                      return (
                        <div key={node.id}
                          className={`absolute rounded-full bg-${node.color}-500/30 border-2 border-${node.color}-400/50 cursor-pointer hover:scale-110 transition-transform flex items-center justify-center`}
                          style={{
                            left: `${x}%`, top: `${y}%`,
                            width: `${node.size * zoom}px`, height: `${node.size * zoom}px`,
                            transform: "translate(-50%, -50%)"
                          }}
                          onClick={() => setSelectedAsset(node)}>
                          <span className="text-xs text-white font-mono" style={{ fontSize: `${Math.max(8, node.size * zoom * 0.3)}px` }}>
                            {fmtK(node.value)}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex items-center justify-center gap-2 mt-2">
                    <Button size="sm" variant="ghost" onClick={() => setZoom(z => Math.max(0.5, z - 0.2))} className="h-6 w-6 p-0 text-[#7a95b8]">
                      <ZoomOut className="h-3 w-3" />
                    </Button>
                    <span className="text-xs text-slate-500">{Math.round(zoom * 100)}%</span>
                    <Button size="sm" variant="ghost" onClick={() => setZoom(z => Math.min(2, z + 0.2))} className="h-6 w-6 p-0 text-[#7a95b8]">
                      <ZoomIn className="h-3 w-3" />
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => setZoom(1)} className="h-6 w-6 p-0 text-[#7a95b8]">
                      <RotateCcw className="h-3 w-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
            <Card className="bg-[#0d1526]/50 border-[#1e3a5f]/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-amber-400 flex items-center gap-2">
                  <Eye className="h-4 w-4" /> {selectedAsset ? "Asset Detail" : "Asset Legend"}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {selectedAsset ? (
                  <div className="space-y-3">
                    <h3 className="text-sm font-semibold text-white">{selectedAsset.name}</h3>
                    <Badge variant="outline" className="text-xs text-[#7a95b8] border-[#1e3a5f]">{selectedAsset.category}</Badge>
                    {[
                      { label: "Value", value: fmtK(selectedAsset.value), color: "emerald" },
                      { label: "Risk Score", value: `${selectedAsset.risk}%`, color: "red" },
                      { label: "Growth Rate", value: `${selectedAsset.growth}%`, color: "blue" },
                      { label: "Tax Efficiency", value: `${selectedAsset.taxEfficiency}%`, color: "purple" },
                    ].map(m => (
                      <div key={m.label} className="flex items-center justify-between">
                        <span className="text-xs text-[#7a95b8]">{m.label}</span>
                        <span className={`text-sm font-bold text-${m.color}-400`}>{m.value}</span>
                      </div>
                    ))}
                    <Button size="sm" variant="outline" onClick={() => setSelectedAsset(null)} className="w-full text-xs border-[#1e3a5f] text-[#7a95b8]">
                      Back to Legend
                    </Button>
                  </div>
                ) : (
                  ASSET_NODES.map(node => (
                    <div key={node.id} className="flex items-center gap-2 cursor-pointer hover:bg-[#162a4a]/30 p-1 rounded"
                      onClick={() => setSelectedAsset(node)}>
                      <div className={`w-3 h-3 rounded-full bg-${node.color}-400`} />
                      <span className="text-xs text-[#7a95b8] flex-1">{node.name}</span>
                      <span className="text-xs text-white font-mono">{fmtK(node.value)}</span>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* Timeline View */}
        {activeView === "timeline" && (
          <Card className="bg-[#0d1526]/50 border-[#1e3a5f]/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-blue-400 flex items-center gap-2">
                <TrendingUp className="h-4 w-4" /> Scenario Projections
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-5 gap-2 text-xs text-slate-500 border-b border-[#1e3a5f]/50 pb-2">
                  <span>Scenario</span>
                  <span className="text-center">Year 5</span>
                  <span className="text-center">Year 10</span>
                  <span className="text-center">Year 20</span>
                  <span className="text-center">Year 30</span>
                </div>
                {SCENARIOS.map(sc => {
                  const maxVal = Math.max(...SCENARIOS.map(s => s.year30));
                  return (
                    <div key={sc.name} className="space-y-2">
                      <div className="grid grid-cols-5 gap-2 items-center">
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full bg-${sc.color}-400`} />
                          <span className="text-xs text-white">{sc.name}</span>
                        </div>
                        {[sc.year5, sc.year10, sc.year20, sc.year30].map((val, i) => (
                          <span key={i} className={`text-xs text-center font-mono text-${sc.color}-400`}>{fmtM(val)}</span>
                        ))}
                      </div>
                      <div className="h-3 bg-[#0a0f1a]/50 rounded-full overflow-hidden">
                        <div className={`h-full bg-${sc.color}-500/40 rounded-full transition-all duration-1000`}
                          style={{ width: `${(sc.year30 / maxVal) * 100}%` }} />
                      </div>
      <PageInsights section="dimensional-wealth-canvas" />
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </AppShell>
  );
}
