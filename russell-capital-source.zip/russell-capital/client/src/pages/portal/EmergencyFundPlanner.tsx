// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { ShieldAlert, DollarSign, TrendingUp, Target, Calendar, Percent, ArrowRight, Shield, CheckCircle2, AlertTriangle, Umbrella, Lock } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, AreaChart, Area, PieChart, Pie, Cell } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

const EmergencyFundPlanner = () => {
  const [profession, setProfession] = useState('');
  const [monthlyExpenses, setMonthlyExpenses] = useState(0);
  const [emergencyFundGoal, setEmergencyFundGoal] = useState(0);
  const [investmentOption, setInvestmentOption] = useState('cash');
  const [disabilityCoverage, setDisabilityCoverage] = useState(0);
  const [businessInterruptionFund, setBusinessInterruptionFund] = useState(0);
  const [iulCashValue, setIulCashValue] = useState(0);
  const [timeHorizon, setTimeHorizon] = useSharedField("projectionYears", 50); // Years for opportunity cost

  const professions = {
    physician: { specialties: ['Cardiology', 'Surgery', 'Pediatrics'], multiplier: 6 },
    attorney: { specialties: ['Corporate', 'Litigation', 'Family'], multiplier: 4 },
    executive: { specialties: ['CEO', 'CFO', 'Manager'], multiplier: 5 },
  };

  const calculateEmergencyFund = useMemo(() => {
    if (!profession || !monthlyExpenses) return 0;
    const multiplier = professions[profession]?.multiplier || 3;
    return monthlyExpenses * multiplier * 30; // Monthly to annual, then multiply
  }, [profession, monthlyExpenses]);

  const tiers = [
    { months: 3, description: 'Basic Coverage', color: '#FF8C00' }, // Orange accent
    { months: 6, description: 'Standard Coverage', color: '#1E90FF' }, // Blue accent
    { months: 12, description: 'Extended Coverage', color: '#FFD700' },
  ];

  const opportunityCostOptions = {
    cash: { returnRate: 0.01, liquidity: 'High' },
    myga: { returnRate: 0.03, liquidity: 'Medium' },
    tbills: { returnRate: 0.02, liquidity: 'High' },
    moneyMarket: { returnRate: 0.015, liquidity: 'High' },
  };

  const calculateOpportunityCost = useMemo(() => {
    const initialAmount = emergencyFundGoal;
    const years = timeHorizon;
    const option = opportunityCostOptions[investmentOption];
    const futureValue = initialAmount * Math.pow(1 + option.returnRate, years);
    return { initial: initialAmount, future: futureValue, rate: option.returnRate };
  }, [emergencyFundGoal, investmentOption, timeHorizon]);

  const ladderStrategy = [
    { tier: 1, description: 'Immediate Liquidity (Cash)', percentage: 40 },
    { tier: 2, description: 'Short-term (T-Bills)', percentage: 30 },
    { tier: 3, description: 'Medium-term (MYGA)', percentage: 20 },
    { tier: 4, description: 'Long-term (Bonds)', percentage: 10 },
  ];

  const disabilityGapAnalysis = useMemo(() => {
    const gap = monthlyExpenses * 12 - disabilityCoverage;
    return gap > 0 ? gap : 0;
  }, [monthlyExpenses, disabilityCoverage]);

  const practiceInterruptionFundNeeded = useMemo(() => {
    return businessInterruptionFund > 0 ? businessInterruptionFund * 1.5 : 0; // Example multiplier
  }, [businessInterruptionFund]);

  const iulAsBackstop = useMemo(() => {
    return iulCashValue * 0.8; // 80% accessible as backstop
  }, [iulCashValue]);

  const complianceNotes = {
    irc7702: 'IUL must comply with IRC 7702 for tax advantages.',
    annuity72: 'Annuity distributions under IRC 72 rules.',
  };

  const barChartData = [
    { name: 'Cash', value: opportunityCostOptions.cash.returnRate * 100 },
    { name: 'MYGA', value: opportunityCostOptions.myga.returnRate * 100 },
    { name: 'T-Bills', value: opportunityCostOptions.tbills.returnRate * 100 },
    { name: 'Money Market', value: opportunityCostOptions.moneyMarket.returnRate * 100 },
  ];

  const areaChartData = Array.from({ length: 50 }, (_, i) => ({
    year: i + 1,
    cash: emergencyFundGoal * Math.pow(1 + opportunityCostOptions.cash.returnRate, i),
    myga: emergencyFundGoal * Math.pow(1 + opportunityCostOptions.myga.returnRate, i),
  }));

  const pieChartData = ladderStrategy.map((tier, index) => ({
    name: tier.description,
    value: tier.percentage,
  }));

  const COLORS = ['#FF4500', '#1E90FF', '#32CD32', '#FFD700']; // Orange, Blue accents

  return (
    <div style={{ backgroundColor: '#121212', color: '#E0E0E0', minHeight: '100vh', padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1 style={{ color: '#FF8C00', display: 'flex', alignItems: 'center' }}>
        <ShieldAlert size={32} color="#FF8C00" /> Emergency Fund Planner for High-Income Professionals
      </h1>

      <section style={{ marginBottom: '20px' }}>
        <h2 style={{ color: '#1E90FF' }}>User Input</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <label>
            Profession: 
            <select onChange={(e) => setProfession(e.target.value)} style={{ backgroundColor: '#333', color: '#E0E0E0', borderColor: '#FF8C00' }}>
              <option value="">Select</option>
              <option value="physician">Physician</option>
              <option value="attorney">Attorney</option>
              <option value="executive">Executive</option>
            </select>
          </label>
          <label>
            Monthly Expenses: 
            <input type="number" onChange={(e) => setMonthlyExpenses(Number(e.target.value))} style={{ backgroundColor: '#333', color: '#E0E0E0', borderColor: '#1E90FF' }} />
          </label>
          <label>
            Emergency Fund Goal: 
            <input type="number" onChange={(e) => setEmergencyFundGoal(Number(e.target.value))} style={{ backgroundColor: '#333', color: '#E0E0E0', borderColor: '#FF8C00' }} />
          </label>
          <label>
            Investment Option: 
            <select onChange={(e) => setInvestmentOption(e.target.value)} style={{ backgroundColor: '#333', color: '#E0E0E0', borderColor: '#1E90FF' }}>
              <option value="cash">Cash</option>
              <option value="myga">MYGA</option>
              <option value="tbills">T-Bills</option>
              <option value="moneyMarket">Money Market</option>
            </select>
          </label>
          <label>
            Disability Coverage Annual: 
            <input type="number" onChange={(e) => setDisabilityCoverage(Number(e.target.value))} style={{ backgroundColor: '#333', color: '#E0E0E0', borderColor: '#FF8C00' }} />
          </label>
          <label>
            Business Interruption Fund: 
            <input type="number" onChange={(e) => setBusinessInterruptionFund(Number(e.target.value))} style={{ backgroundColor: '#333', color: '#E0E0E0', borderColor: '#1E90FF' }} />
          </label>
          <label>
            IUL Cash Value: 
            <input type="number" onChange={(e) => setIulCashValue(Number(e.target.value))} style={{ backgroundColor: '#333', color: '#E0E0E0', borderColor: '#FF8C00' }} />
          </label>
          <label>
            Time Horizon (Years): 
            <input type="number" onChange={(e) => setTimeHorizon(Number(e.target.value))} style={{ backgroundColor: '#333', color: '#E0E0E0', borderColor: '#1E90FF' }} />
          </label>
        </div>
      </section>

      <section style={{ marginBottom: '20px' }}>
        <h2 style={{ color: '#FF8C00' }}>Emergency Fund Calculator by Profession</h2>
        <p>Recommended Fund: ${calculateEmergencyFund.toFixed(2)}</p>
        {profession && (
          <ul>
            {professions[profession].specialties.map((spec) => (
              <li key={spec} style={{ color: '#1E90FF' }}>{spec} - Multiplier: {professions[profession].multiplier}</li>
            ))}
          </ul>
        )}
      </section>

      <section style={{ marginBottom: '20px' }}>
        <h2 style={{ color: '#1E90FF' }}>3-6-12 Month Expense Coverage Tiers</h2>
        <ul>
          {tiers.map((tier) => (
            <li key={tier.months} style={{ color: tier.color }}>
              <Target size={20} color={tier.color} /> {tier.months} Months: {tier.description} - Goal: ${ (monthlyExpenses * tier.months).toFixed(2) }
            </li>
          ))}
        </ul>
      </section>

      <section style={{ marginBottom: '20px' }}>
        <h2 style={{ color: '#FF8C00' }}>Opportunity Cost Analysis</h2>
        <p>Selected: {investmentOption} - Future Value after {timeHorizon} years: ${calculateOpportunityCost.future.toFixed(2)}</p>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={barChartData}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="value" fill="#1E90FF" />
          </BarChart>
        </ResponsiveContainer>
      </section>

      <section style={{ marginBottom: '20px' }}>
        <h2 style={{ color: '#1E90FF' }}>Emergency Fund Ladder Strategy</h2>
        <ul>
          {ladderStrategy.map((tier) => (
            <li key={tier.tier} style={{ color: '#FF8C00' }}>
              <ArrowRight size={20} color="#FF8C00" /> Tier {tier.tier}: {tier.description} - {tier.percentage}%
            </li>
          ))}
        </ul>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie data={pieChartData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} fill="#8884d8" label>
              {pieChartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </section>

      <section style={{ marginBottom: '20px' }}>
        <h2 style={{ color: '#FF8C00' }}>Disability Income Gap Analysis</h2>
        <p>Gap: ${disabilityGapAnalysis.toFixed(2)}</p>
        <CheckCircle2 size={24} color={disabilityGapAnalysis > 0 ? '#FF0000' : '#00FF00'} />
      </section>

      <section style={{ marginBottom: '20px' }}>
        <h2 style={{ color: '#1E90FF' }}>Practice Interruption Fund for Business Owners</h2>
        <p>Recommended Fund: ${practiceInterruptionFundNeeded.toFixed(2)}</p>
        <Umbrella size={24} color="#FF8C00" />
      </section>

      <section style={{ marginBottom: '20px' }}>
        <h2 style={{ color: '#FF8C00' }}>IUL Cash Value as Emergency Backstop</h2>
        <p>Accessible Amount: ${iulAsBackstop.toFixed(2)}</p>
        <Shield size={24} color="#1E90FF" />
      </section>

      <section style={{ marginBottom: '20px' }}>
        <h2 style={{ color: '#1E90FF' }}>50-Year Opportunity Cost Comparison</h2>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={areaChartData}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="cash" stroke="#FF8C00" fill="#FF4500" />
            <Area type="monotone" dataKey="myga" stroke="#1E90FF" fill="#4682B4" />
          </AreaChart>
        </ResponsiveContainer>
      </section>

      <section style={{ marginBottom: '20px' }}>
        <h2 style={{ color: '#FF8C00' }}>Compliance Notes</h2>
        <p><AlertTriangle size={20} color="#FFD700" /> IRC 7702: {complianceNotes.irc7702}</p>
        <p><Lock size={20} color="#1E90FF" /> Annuity 72: {complianceNotes.annuity72}</p>
      </section>

      <footer style={{ color: '#888', textAlign: 'center' }}>
        <TrendingUp size={24} color="#FF8C00" /> Optimize your emergency fund today!
      </footer>
      <PageInsights section="emergency-fund-planner" />
    </div>
  );
};

export default EmergencyFundPlanner;
