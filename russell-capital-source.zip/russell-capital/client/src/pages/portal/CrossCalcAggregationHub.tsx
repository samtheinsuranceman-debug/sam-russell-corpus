// @ts-nocheck
import React from 'react';
import { useOrganismContext } from '@/contexts/OrganismContext';
import { DollarSign, TrendingUp, Shield, Home, Calculator, Percent } from 'lucide-react';
import { PageInsights } from "@/components/PageInsights";

interface AggregatedResults {
  netWorth: number;
  taxSavings: number;
  retirementIncome: number;
  insuranceCoverage: number;
  estateValue: number;
  calcsUsed: number;
  breakdown: Array<{ category: string; value: number }>;
}

const CrossCalcAggregationHub: React.FC = () => {
  const { aggregatedResults, isLoading } = useOrganismContext() as { aggregatedResults: AggregatedResults; isLoading: boolean };

  if (isLoading) {
    return (
      <div className="bg-[#0a0f1a] min-h-screen flex items-center justify-center text-white">
        Loading...
      </div>
    );
  }

  if (!aggregatedResults) {
    return (
      <div className="bg-[#0a0f1a] min-h-screen flex items-center justify-center text-white">
        No data available
      </div>
    );
  }

  const { netWorth, taxSavings, retirementIncome, insuranceCoverage, estateValue, calcsUsed, breakdown } = aggregatedResults;
  const maxBreakdownValue = breakdown.reduce((max, item) => (item.value > max ? item.value : max), 0);

  return (
    <div className="bg-[#0a0f1a] min-h-screen p-4 text-gray-200">
      <h1 className="text-2xl font-bold mb-6">Aggregated Calculator Results</h1>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        <div className="bg-[#0d1526] p-4 rounded shadow flex flex-col items-center">
          <DollarSign className="mb-2" size={24} />
          <h2 className="text-xl">Net Worth</h2>
          <p>${netWorth.toFixed(2)}</p>
        </div>
        <div className="bg-[#0d1526] p-4 rounded shadow flex flex-col items-center">
          <Percent className="mb-2" size={24} />
          <h2 className="text-xl">Tax Savings</h2>
          <p>${taxSavings.toFixed(2)}</p>
        </div>
        <div className="bg-[#0d1526] p-4 rounded shadow flex flex-col items-center">
          <TrendingUp className="mb-2" size={24} />
          <h2 className="text-xl">Retirement Income</h2>
          <p>${retirementIncome.toFixed(2)}</p>
        </div>
        <div className="bg-[#0d1526] p-4 rounded shadow flex flex-col items-center">
          <Shield className="mb-2" size={24} />
          <h2 className="text-xl">Insurance Coverage</h2>
          <p>${insuranceCoverage.toFixed(2)}</p>
        </div>
        <div className="bg-[#0d1526] p-4 rounded shadow flex flex-col items-center">
          <Home className="mb-2" size={24} />
          <h2 className="text-xl">Estate Value</h2>
          <p>${estateValue.toFixed(2)}</p>
        </div>
        <div className="bg-[#0d1526] p-4 rounded shadow flex flex-col items-center">
          <Calculator className="mb-2" size={24} />
          <h2 className="text-xl">Calcs Used</h2>
          <p>{calcsUsed}</p>
        </div>
      </div>
      
      <div className="mt-8">
        <h2 className="text-xl font-bold mb-4">Breakdown by Category</h2>
        <div className="flex flex-wrap gap-4">
          {breakdown.map((item) => (
            <div key={item.category} className="w-full sm:w-1/2 md:w-1/3 p-2">
              <div className="flex justify-between items-center mb-1">
                <span>{item.category}</span>
                <span>{item.value.toFixed(2)}</span>
              </div>
              <div className="bg-gray-700 h-6 rounded" style={{ width: `${(item.value / maxBreakdownValue) * 100}%` }}></div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="mt-8">
        <h2 className="text-xl font-bold mb-4">What-If Scenario</h2>
        <p className="text-[#7a95b8]">
          Adding more calculator results could increase metrics like Net Worth and Tax Savings. For example, including a new investment calc might add $10,000 to Net Worth.
        </p>
      </div>
      <PageInsights section="cross-calc-aggregation-hub" />
    </div>
  );
};

export default CrossCalcAggregationHub;
