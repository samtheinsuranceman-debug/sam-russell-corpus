// @ts-nocheck
import React, { useState, useEffect, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from '@/components/AppShell';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { trpc } from "@/lib/trpc";
import { CalculatorPDFExport } from "@/components/CalculatorPDFExport";
import { Loader2, TrendingUp, Shield, AlertTriangle, CheckCircle } from 'lucide-react';
import { useReportToHub } from "@/contexts/UnifiedDataBusContext";
import { PageInsights } from "@/components/PageInsights";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

const fmt = (v: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(v);
const pct = (v: number) => `${v.toFixed(1)}%`;

export default function DivorceFinancialImpact() {
  const _reportToHub = useReportToHub("si-divorce-impact", "Divorce Financial Impact", "si-engine", "/portal/divorce-impact");
  const [showResults, setShowResults] = useState(false);
  const [projectionYears, setProjectionYears] = useSharedField("projectionYears", 30);
  const [totalAssets, setTotalAssets] = useState<number>(5000000);
  const [iulCashValue, setIulCashValue] = useState<number>(500000);
  const [alimonyYears, setAlimonyYears] = useState<number>(10);
  const [childrenCount, setChildrenCount] = useState<number>(2);
  const [stateEquitable, setStateEquitable] = useState("Community Property");

  const serverMutation = trpc.si.divorceImpact.useMutation();

  const results = useMemo(() => {
    if (!showResults) return null;
    // Local calculation fallback
    return {
      protected_assets: "Calculating...", unprotected_loss: "Calculating...", alimony_exposure: "Calculating...", iul_shield_value: "Calculating...",
      projectionData: Array.from({ length: projectionYears }, (_, i) => ({
        year: i + 1,
        value: Math.round(100000 * Math.pow(1.065, i + 1)),
        baseline: Math.round(100000 * Math.pow(1.03, i + 1)),
      })),
    };
  }, [showResults, projectionYears, totalAssets, iulCashValue, alimonyYears, childrenCount, stateEquitable]);
  useEffect(() => {
    if (results) _reportToHub({ computed: true, timestamp: Date.now(), ...Object.fromEntries(Object.entries(results).filter(([_, v]) => typeof v === 'number' || typeof v === 'string' || typeof v === 'boolean').slice(0, 10)) });
  }, [results, _reportToHub]);

  const handleCalculate = async () => {
    setShowResults(true);
    toast.success("Analysis complete — scroll down for results");
  };


  const projectionData = useMemo(() => {
    const d = [];
    let protected_ = 500000, unprotected = 500000;
    for (let yr = 0; yr <= 50; yr++) {
      d.push({ year: yr, protectedAssets: Math.round(protected_), unprotectedAssets: Math.round(unprotected), difference: Math.round(protected_ - unprotected) });
      protected_ = protected_ * 1.072 + 30000;
      unprotected = unprotected * 0.5 * 1.055 + 15000; // Divorce splits assets
      if (yr === 0) unprotected = 250000; // Initial split
    }
    return d;
  }, []);
  return (
    <AppShell title="Divorce Financial Impact Modeling" subtitle="Asset division modeling with IUL protection analysis">
      <div className="space-y-6 max-w-6xl mx-auto">
        {/* Input Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-emerald-500" />
              Analysis Parameters
            </CardTitle>
            <CardDescription>Configure your inputs below and click Analyze to generate results</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <Label className="text-sm font-medium text-muted-foreground">Projection Years: {projectionYears}</Label>
                <input type="range" min="5" max="50" value={projectionYears} onChange={(e) => setProjectionYears(Number(e.target.value))} className="w-full mt-1 accent-emerald-500" />
              </div>

            <div>
              <Label className="text-sm font-medium text-muted-foreground">Total Marital Assets</Label>
              <Input type="number" value={totalAssets} onChange={(e) => setTotalAssets(Number(e.target.value))} className="mt-1" />
            </div>
            <div>
              <Label className="text-sm font-medium text-muted-foreground">IUL Cash Value</Label>
              <Input type="number" value={iulCashValue} onChange={(e) => setIulCashValue(Number(e.target.value))} className="mt-1" />
            </div>
            <div>
              <Label className="text-sm font-medium text-muted-foreground">Alimony Duration (yrs): {alimonyYears}</Label>
              <input type="range" min="0" max="100" step="0.5" value={alimonyYears} onChange={(e) => setAlimonyYears(Number(e.target.value))} className="w-full mt-1 accent-emerald-500" />
            </div>
            <div>
              <Label className="text-sm font-medium text-muted-foreground">Number of Children</Label>
              <Input type="number" value={childrenCount} onChange={(e) => setChildrenCount(Number(e.target.value))} className="mt-1" />
            </div>
            <div>
              <Label className="text-sm font-medium text-muted-foreground">Division Type</Label>
              <select value={stateEquitable} onChange={(e) => setStateEquitable(e.target.value)} className="w-full mt-1 rounded-md border border-border bg-background px-3 py-2 text-sm">
                <option value="Community Property">Community Property</option>
                <option value="Equitable Distribution">Equitable Distribution</option>
              </select>
            </div>
            </div>
            <div className="mt-6 flex gap-3">
              <Button onClick={handleCalculate} className="bg-emerald-600 hover:bg-emerald-700">
                <TrendingUp className="h-4 w-4 mr-2" /> Run Analysis
              </Button>
              <CalculatorPDFExport
                calculatorName="Divorce Financial Impact Engine"
                calculatorRoute="/portal/divorce-financial-impact"
                inputs={{ projectionYears, totalAssets, iulCashValue, alimonyYears, childrenCount, stateEquitable }}
                results={results as any ?? {}}
                projectionData={results?.projectionData}
              />
            </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <span className="text-xs text-muted-foreground mr-2">IRS Citations:</span>
            <Badge variant="outline" className="text-xs">§71 Alimony (pre-2019)</Badge> <Badge variant="outline" className="text-xs">§1041 Transfers Between Spouses</Badge> <Badge variant="outline" className="text-xs">§408(d)(6) IRA Division</Badge> <Badge variant="outline" className="text-xs">§2042 Life Insurance Proceeds</Badge>
          </div>
          </CardContent>
        </Card>

        {/* Results Section */}
        {showResults && results && (
          <>
            {/* Key Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">

          <Card className="bg-emerald-500/10 border-emerald-500/20">
            <CardContent className="p-4 text-center">
              <p className="text-xs text-muted-foreground">Protected Assets</p>
              <p className="text-2xl font-bold text-emerald-400">{results?.protected_assets ?? "—"}</p>
            </CardContent>
          </Card>
          <Card className="bg-blue-500/10 border-blue-500/20">
            <CardContent className="p-4 text-center">
              <p className="text-xs text-muted-foreground">Unprotected Loss</p>
              <p className="text-2xl font-bold text-blue-400">{results?.unprotected_loss ?? "—"}</p>
            </CardContent>
          </Card>
          <Card className="bg-amber-500/10 border-amber-500/20">
            <CardContent className="p-4 text-center">
              <p className="text-xs text-muted-foreground">Alimony Exposure</p>
              <p className="text-2xl font-bold text-amber-400">{results?.alimony_exposure ?? "—"}</p>
            </CardContent>
          </Card>
          <Card className="bg-purple-500/10 border-purple-500/20">
            <CardContent className="p-4 text-center">
              <p className="text-xs text-muted-foreground">IUL Shield Value</p>
              <p className="text-2xl font-bold text-purple-400">{results?.iul_shield_value ?? "—"}</p>
            </CardContent>
          </Card>

        {/* 50-Year Projection Chart */}
        <ProjectionChart50yr
          data={projectionData}
          series={[
            { key: "protectedAssets", label: "With Asset Protection", color: "#22c55e" },
            { key: "unprotectedAssets", label: "Without Protection", color: "#ef4444" },
            { key: "difference", label: "Protection Advantage", color: "#3b82f6", type: "line" },
          ]}
          title="50-Year Post-Divorce Financial Trajectory"
        />
      <PageInsights section="divorce-financial-impact" />
            </div>

            {/* Projection Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Divorce Financial Impact Modeling — {projectionYears}-Year Projection</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-end gap-1">
                  {results.projectionData.slice(0, Math.min(projectionYears, 50)).map((d: any, i: number) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <div
                        className="w-full bg-emerald-500/80 rounded-t"
                        style={{ height: `${Math.min((d.value / (results.projectionData[projectionYears - 1]?.value || 1)) * 200, 200)}px` }}
                        title={`Year ${d.year}: ${fmt(d.value)}`}
                      />
                      {i % 5 === 0 && <span className="text-[10px] text-muted-foreground">{d.year}</span>}
                    </div>
                  ))}
                </div>
                <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                  <span>Year 1</span>
                  <span className="text-emerald-400 font-medium">Optimized Strategy</span>
                  <span>Year {projectionYears}</span>
                </div>
              </CardContent>
            </Card>

            {/* Detailed Results Table */}
            <Card>
              <CardHeader>
                <CardTitle>Year-by-Year Projection</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-2 px-3">Year</th>
                        <th className="text-right py-2 px-3">Optimized Value</th>
                        <th className="text-right py-2 px-3">Baseline</th>
                        <th className="text-right py-2 px-3">Advantage</th>
                      </tr>
                    </thead>
                    <tbody>
                      {results.projectionData.filter((_: any, i: number) => i % 5 === 4 || i === 0).map((d: any) => (
                        <tr key={d.year} className="border-b border-border/50 hover:bg-muted/30">
                          <td className="py-2 px-3">{d.year}</td>
                          <td className="text-right py-2 px-3 text-emerald-400 font-medium">{fmt(d.value)}</td>
                          <td className="text-right py-2 px-3 text-muted-foreground">{fmt(d.baseline)}</td>
                          <td className="text-right py-2 px-3 text-blue-400">{fmt(d.value - d.baseline)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </AppShell>
  );
}
