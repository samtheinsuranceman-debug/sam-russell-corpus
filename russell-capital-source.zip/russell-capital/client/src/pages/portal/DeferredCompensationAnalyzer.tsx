// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Clock, DollarSign, TrendingUp, Target, Calendar, Percent, ArrowRight, Shield, CheckCircle2, AlertTriangle, Briefcase, Lock } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, AreaChart, Area, ComposedChart, Line } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

const DeferredCompensationAnalyzer = () => {
  const [selectedPlan, setSelectedPlan] = useState('SERP'); // Options: SERP, phantom stock, rabbi trust
  const [deferralAmount, setDeferralAmount] = useState(100000); // Annual deferral in USD
  const [interestRate, setInterestRate] = useState(5); // Annual interest rate in %
  const [years, setYears] = useSharedField("projectionYears", 50); // Projection years
  const [ficaTiming, setFicaTiming] = useState('deferred'); // FICA timing: deferred or immediate
  const [employerCreditRisk, setEmployerCreditRisk] = useState(10); // Risk level 1-100

  const data = useMemo(() => {
    const projections = [];
    let balance = 0;
    for (let year = 1; year <= years; year++) {
      balance += deferralAmount * (1 + interestRate / 100);
      projections.push({ year, balance, riskAdjusted: balance * (1 - employerCreditRisk / 100) });
    }
    return projections;
  }, [deferralAmount, interestRate, years, employerCreditRisk]);

  const chartData = useMemo(() => [
    { name: 'Year 1', wealth: data[0]?.balance || 0, riskAdjusted: data[0]?.riskAdjusted || 0 },
    { name: 'Year 10', wealth: data[9]?.balance || 0, riskAdjusted: data[9]?.riskAdjusted || 0 },
    { name: 'Year 20', wealth: data[19]?.balance || 0, riskAdjusted: data[19]?.riskAdjusted || 0 },
    { name: 'Year 30', wealth: data[29]?.balance || 0, riskAdjusted: data[29]?.riskAdjusted || 0 },
    { name: 'Year 40', wealth: data[39]?.balance || 0, riskAdjusted: data[39]?.riskAdjusted || 0 },
    { name: 'Year 50', wealth: data[49]?.balance || 0, riskAdjusted: data[49]?.riskAdjusted || 0 },
  ], [data]);

  return (
    <div style={{ backgroundColor: '#0a192f', color: '#ffffff', minHeight: '100vh', padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
        <h1 style={{ color: '#fbbf24' }}>NQDC Planning & 409A Compliance Tool</h1>
        <Briefcase size={32} color="#fbbf24" />
      </header>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#fbbf24' }}>Select NQDC Plan Type</h2>
        <div style={{ display: 'flex', gap: '10px', marginBottom: '10px' }}>
          <button onClick={() => setSelectedPlan('SERP')} style={{ backgroundColor: selectedPlan === 'SERP' ? '#fbbf24' : '#1a365d', color: '#ffffff', padding: '10px', border: 'none', borderRadius: '5px' }}>
            <Shield size={20} /> SERP
          </button>
          <button onClick={() => setSelectedPlan('phantom stock')} style={{ backgroundColor: selectedPlan === 'phantom stock' ? '#fbbf24' : '#1a365d', color: '#ffffff', padding: '10px', border: 'none', borderRadius: '5px' }}>
            <TrendingUp size={20} /> Phantom Stock
          </button>
          <button onClick={() => setSelectedPlan('rabbi trust')} style={{ backgroundColor: selectedPlan === 'rabbi trust' ? '#fbbf24' : '#1a365d', color: '#ffffff', padding: '10px', border: 'none', borderRadius: '5px' }}>
            <Lock size={20} /> Rabbi Trust
          </button>
        </div>
        <p style={{ color: '#a0aec0' }}>SERP provides supplemental retirement benefits. Phantom Stock mimics equity. Rabbi Trust secures funds but is subject to employer credit risk.</p>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#fbbf24' }}>409A Compliance Check</h2>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <CheckCircle2 size={24} color={selectedPlan === 'SERP' ? '#fbbf24' : '#ffffff'} />
          <p style={{ color: '#a0aec0' }}>Ensure plan complies with IRC Section 409A. Deferrals must be elected before services are performed. <AlertTriangle size={20} color="#fbbf24" /> Non-compliance risks immediate taxation and penalties.</p>
        </div>
        <button style={{ backgroundColor: '#1a365d', color: '#fbbf24', padding: '10px', border: 'none', borderRadius: '5px', marginTop: '10px' }}>
          <ArrowRight size={16} /> Run 409A Audit
        </button>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#fbbf24' }}>FICA Timing Analysis</h2>
        <div style={{ display: 'flex', gap: '10px', marginBottom: '10px' }}>
          <button onClick={() => setFicaTiming('deferred')} style={{ backgroundColor: ficaTiming === 'deferred' ? '#fbbf24' : '#1a365d', color: '#ffffff', padding: '10px', border: 'none', borderRadius: '5px' }}>
            <Calendar size={20} /> Deferred
          </button>
          <button onClick={() => setFicaTiming('immediate')} style={{ backgroundColor: ficaTiming === 'immediate' ? '#fbbf24' : '#1a365d', color: '#ffffff', padding: '10px', border: 'none', borderRadius: '5px' }}>
            <Clock size={20} /> Immediate
          </button>
        </div>
        <p style={{ color: '#a0aec0' }}>Deferred FICA means taxes are paid upon distribution. Immediate FICA applies at deferral, reducing net wealth growth.</p>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#fbbf24' }}>50-Year Wealth Comparison</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '20px' }}>
          <label style={{backgroundColor: '#1a365d', color: '#ffffff', border: '1px solid #fbbf24', padding: '5px'}}>Annual Deferral Amount: <DollarSign size={16} color="#fbbf24" /> <input type="number" value={deferralAmount} onChange={(e) => setDeferralAmount(Number(e.target.value))} /></label>
          <label style={{backgroundColor: '#1a365d', color: '#ffffff', border: '1px solid #fbbf24', padding: '5px'}}>Interest Rate (%): <Percent size={16} color="#fbbf24" /> <input type="number" value={interestRate} onChange={(e) => setInterestRate(Number(e.target.value))} /></label>
          <label style={{backgroundColor: '#1a365d', color: '#ffffff', border: '1px solid #fbbf24', padding: '5px'}}>Years: <Target size={16} color="#fbbf24" /> <input type="number" value={years} onChange={(e) => setYears(Number(e.target.value))} max="50" /></label>
          <label style={{backgroundColor: '#1a365d', color: '#ffffff', border: '1px solid #fbbf24', padding: '5px'}}>Employer Credit Risk (%): <AlertTriangle size={16} color="#fbbf24" /> <input type="number" value={employerCreditRisk} onChange={(e) => setEmployerCreditRisk(Number(e.target.value))} /></label>
        </div>
        <ResponsiveContainer width="100%" height={400}>
          <ComposedChart data={chartData}>
            <XAxis dataKey="name" stroke="#fbbf24" />
            <YAxis stroke="#fbbf24" />
            <Tooltip />
            <Legend />
            <Bar dataKey="wealth" fill="#fbbf24" name="Projected Wealth" />
            <Line type="monotone" dataKey="riskAdjusted" stroke="#ffffff" name="Risk-Adjusted Wealth" />
          </ComposedChart>
        </ResponsiveContainer>
        <p style={{ color: '#a0aec0', marginTop: '10px' }}>This chart compares raw projected wealth vs. risk-adjusted wealth over 50 years, accounting for employer credit risk.</p>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#fbbf24' }}>Employer Credit Risk Assessment</h2>
        <p style={{ color: '#a0aec0' }}>Risk level: {employerCreditRisk}%. Higher risk means potential loss of deferred compensation. Use a <Shield size={20} color="#fbbf24" /> rabbi trust to mitigate.</p>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={data}>
            <XAxis dataKey="year" stroke="#fbbf24" />
            <YAxis stroke="#fbbf24" />
            <Tooltip />
            <Area type="monotone" dataKey="riskAdjusted" fill="#fbbf24" stroke="#fbbf24" fillOpacity={0.3} />
          </AreaChart>
        </ResponsiveContainer>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#fbbf24' }}>Detailed Projections Table</h2>
        <div className="overflow-x-auto"><table style={{ width: '100%', borderCollapse: 'collapse', color: '#a0aec0' }}>
          <thead>
            <tr style={{ backgroundColor: '#1a365d' }}>
              <th style={{ padding: '10px', border: '1px solid #fbbf24' }}>Year</th>
              <th style={{ padding: '10px', border: '1px solid #fbbf24' }}>Projected Balance</th>
              <th style={{ padding: '10px', border: '1px solid #fbbf24' }}>Risk-Adjusted Balance</th>
            </tr>
          </thead>
          <tbody>
            {data.slice(0, 10).map((item, index) => (
              <tr key={index} style={{ backgroundColor: index % 2 === 0 ? '#0a192f' : '#1a365d' }}>
                <td style={{ padding: '10px', border: '1px solid #fbbf24', textAlign: 'center' }}>{item.year}</td>
                <td style={{ padding: '10px', border: '1px solid #fbbf24', textAlign: 'center' }}>${item.balance.toFixed(2)}</td>
                <td style={{ padding: '10px', border: '1px solid #fbbf24', textAlign: 'center' }}>${item.riskAdjusted.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table></div>
      </section>

      <section>
        <h2 style={{ color: '#fbbf24' }}>Additional Insights</h2>
        <ul style={{ color: '#a0aec0', listStyle: 'none', padding: 0 }}>
          <li><Clock size={16} color="#fbbf24" /> FICA Timing: {ficaTiming === 'deferred' ? 'Taxes deferred, maximizing growth.' : 'Taxes immediate, reducing upfront wealth.'}</li>
          <li><TrendingUp size={16} color="#fbbf24" /> Plan Type: {selectedPlan} selected for analysis.</li>
          <li><AlertTriangle size={16} color="#fbbf24" /> 409A: Always ensure compliance to avoid penalties.</li>
          <li><Target size={16} color="#fbbf24" /> Long-term Goal: Achieve wealth growth over 50 years while managing risks.</li>
        </ul>
      </section>
      <PageInsights section="deferred-compensation-analyzer" />
    </div>
  );
};

export default DeferredCompensationAnalyzer;
