// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Building2, DollarSign, TrendingUp, Shield, CheckCircle2, Calendar, Target, Users, Calculator, ArrowRight, Award, Clock } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, AreaChart, Area, ComposedChart, Line } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

const DefinedBenefitPlanner: React.FC = () => {
  const [age, setAge] = useSharedField("currentAge", 50); // State for user's age, default 50
  const [income, setIncome] = useSharedField("annualIncome", 500000); // State for user's income, default $500,000

  // Memoized function to calculate wealth accumulation data based on age
  const chartData = useMemo(() => {
    const annualContribution = age === 50 ? 280000 : 200000; // Example: Adjust based on age
    const growthRate = 0.06; // 6% growth rate
    const years = 15; // Projection for 15 years
    const data = [];
    let balance = 0;

    for (let year = 1; year <= years; year++) {
      balance += annualContribution;
      balance *= (1 + growthRate);
      data.push({ year, balance: Math.round(balance) });
    }

    return data; // Returns array like [{year:1, balance:280000}, ...]
  }, [age]);

  // Helper function to format currency for display
  const formatCurrency = (amount: number) => {
    return '$' + amount.toLocaleString(); // e.g., $280,000
  };

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white p-8 font-sans">
      {/* Header Section */}
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold text-amber-400 flex items-center justify-center">
          <Calculator className="mr-2" size={32} /> Defined Benefit Plan Calculator
        </h1>
        <p className="text-[#94a3b8] mt-2">Model your Defined Benefit Plan to shelter $200K-$350K+ annually in tax-deductible contributions.</p>
        <div className="mt-6 flex justify-center items-center space-x-4">
          <label className="flex items-center">
            <Clock className="mr-2" size={20} color="blue" />
            Age:
            <input
              type="number"
              value={age}
              onChange={(e) => setAge(Number(e.target.value))}
              className="ml-2 bg-[#0d1526] border border-blue-500 p-2 rounded w-24 text-center"
              min={30}
              max={70}
            />
          </label>
          <label className="flex items-center">
            <DollarSign className="mr-2" size={20} color="amber-400" />
            Income:
            <input
              type="number"
              value={income}
              onChange={(e) => setIncome(Number(e.target.value))}
              className="ml-2 bg-[#0d1526] border border-amber-500 p-2 rounded w-40 text-center"
              min={0}
            />
          </label>
        </div>
      </header>

      {/* Maximum Contribution Analysis Section */}
      <section className="mb-12">
        <h2 className="text-2xl font-semibold text-blue-400 mb-4 flex items-center">
          <TrendingUp className="mr-2" size={24} /> Maximum Contribution Analysis by Age
        </h2>
        <p className="text-[#94a3b8] mb-4">See how age affects your maximum contributions and tax savings (assuming 37% tax bracket).</p>
        <div className="overflow-x-auto"><table className="w-full border-collapse text-left">
          <thead className="bg-[#0d1526]">
            <tr>
              <th className="p-4 border-b border-[#1e3a5f]">Age</th>
              <th className="p-4 border-b border-[#1e3a5f]">Max Annual Benefit</th>
              <th className="p-4 border-b border-[#1e3a5f]">Max Contribution</th>
              <th className="p-4 border-b border-[#1e3a5f]">Tax Savings (37%)</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b border-[#1e3a5f]">
              <td className="p-4">40</td>
              <td className="p-4">$275K</td>
              <td className="p-4">$150K</td>
              <td className="p-4">$55.5K</td>
            </tr>
            <tr className="border-b border-[#1e3a5f]">
              <td className="p-4">45</td>
              <td className="p-4">$275K</td>
              <td className="p-4">$200K</td>
              <td className="p-4">$74K</td>
            </tr>
            <tr className="border-b border-[#1e3a5f]">
              <td className="p-4">50</td>
              <td className="p-4">$275K</td>
              <td className="p-4">$280K</td>
              <td className="p-4">$103.6K</td>
            </tr>
            <tr className="border-b border-[#1e3a5f]">
              <td className="p-4">55</td>
              <td className="p-4">$275K</td>
              <td className="p-4">$350K</td>
              <td className="p-4">$129.5K</td>
            </tr>
            <tr className="border-b border-[#1e3a5f]">
              <td className="p-4">60</td>
              <td className="p-4">$275K</td>
              <td className="p-4">$400K+</td>
              <td className="p-4">$148K+</td>
            </tr>
          </tbody>
        </table></div>
        <p className="text-[#7a95b8] mt-4">Note: Older ages allow higher contributions due to shorter funding periods.</p>
      </section>

      {/* Wealth Accumulation Section */}
      <section className="mb-12">
        <h2 className="text-2xl font-semibold text-amber-400 mb-4 flex items-center">
          <Target className="mr-2" size={24} /> Wealth Accumulation Projection
        </h2>
        <p className="text-[#94a3b8] mb-4">Projected balance over 15 years to retirement (based on age {age}, 6% growth rate).</p>
        <ResponsiveContainer width="100%" height={400}>
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#8884d8" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <XAxis dataKey="year" stroke="gray" />
            <YAxis stroke="gray" />
            <Tooltip formatter={(value) => formatCurrency(value as number)} />
            <Legend />
            <Area type="monotone" dataKey="balance" stroke="#8884d8" fillOpacity={1} fill="url(#colorBalance)" />
          </AreaChart>
        </ResponsiveContainer>
        <div className="mt-4 text-[#94a3b8]">
          <p>Year 5 Balance: {formatCurrency(chartData[4]?.balance || 1670000)}</p>
          <p>Year 10 Balance: {formatCurrency(chartData[9]?.balance || 3910000)}</p>
          <p>Year 15 Balance: {formatCurrency(chartData[14]?.balance || 6870000)}</p>
          <p>Total Tax Saved Over 15 Years: $1.55M</p>
        </div>
      </section>

      {/* DB Plan + 401(k) Combo Section */}
      <section className="mb-12">
        <h2 className="text-2xl font-semibold text-blue-400 mb-4 flex items-center">
          <Shield className="mr-2" size={24} /> DB Plan + 401(k) Combo
        </h2>
        <p className="text-[#94a3b8] mb-4">Maximize your tax shelter with a combination plan.</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-[#0d1526] p-6 rounded shadow">
            <h3 className="text-xl font-medium">Contributions</h3>
            <p><ArrowRight className="inline mr-2" size={16} /> DB Plan: {formatCurrency(280000)}</p>
            <p><ArrowRight className="inline mr-2" size={16} /> 401(k): $23.5K + $7.5K catch-up</p>
            <p className="font-bold mt-2">Total Annual Shelter: {formatCurrency(311000)}</p>
          </div>
          <div className="bg-[#0d1526] p-6 rounded shadow">
            <h3 className="text-xl font-medium">Tax Benefits</h3>
            <p>Total Tax Savings: {formatCurrency(115000)}/yr</p>
          </div>
        </div>
      </section>

      {/* Plan Design Options Section */}
      <section className="mb-12">
        <h2 className="text-2xl font-semibold text-amber-400 mb-4 flex items-center">
          <Building2 className="mr-2" size={24} /> Plan Design Options
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-[#0d1526] p-6 rounded shadow">
            <h3 className="text-xl font-medium flex items-center"><Award className="mr-2" size={20} /> Traditional DB</h3>
            <p>Fixed benefit formula</p>
            <p>Actuarial funding</p>
            <p>Best for: older owners, high income</p>
          </div>
          <div className="bg-[#0d1526] p-6 rounded shadow">
            <h3 className="text-xl font-medium flex items-center"><Users className="mr-2" size={20} /> Cash Balance Plan</h3>
            <p>Hypothetical account balance</p>
            <p>Pay credit + interest credit</p>
            <p>Best for: firms with employees</p>
          </div>
          <div className="bg-[#0d1526] p-6 rounded shadow">
            <h3 className="text-xl font-medium flex items-center"><CheckCircle2 className="mr-2" size={20} /> Combo DB + 401(k)</h3>
            <p>Maximum shelter</p>
            <p>Flexible contributions</p>
            <p>Best for: maximizing deductions</p>
          </div>
        </div>
      </section>

      {/* Employee Cost Analysis Section */}
      <section className="mb-12">
        <h2 className="text-2xl font-semibold text-blue-400 mb-4 flex items-center">
          <DollarSign className="mr-2" size={24} /> Employee Cost Analysis
        </h2>
        <p className="text-[#94a3b8] mb-4">Understand the net benefits after employee costs.</p>
        <div className="bg-[#0d1526] p-6 rounded shadow">
          <p>Owner Contribution: {formatCurrency(280000)}</p>
          <p>Required Employee Contributions: ~$15K-$25K</p>
          <p>Net Tax Benefit: {formatCurrency(280000)} deduction - $20K employee cost = {formatCurrency(260000)} net</p>
          <p className="font-bold">Still Saves: {formatCurrency(96000)} in taxes</p>
        </div>
      </section>

      {/* IRS Compliance Section */}
      <section>
        <h2 className="text-2xl font-semibold text-amber-400 mb-4 flex items-center">
          <Calendar className="mr-2" size={24} /> IRS Compliance
        </h2>
        <ul className="list-disc pl-6 text-[#94a3b8]">
          <li>IRC Section 415(b): Maximum annual benefit ($275K for 2024)</li>
          <li>IRC Section 404: Deduction limits</li>
          <li>IRC Section 412: Minimum funding standards</li>
          <li>ERISA coverage and nondiscrimination testing</li>
          <li>Form 5500: Annual reporting</li>
        </ul>
      </section>
      <PageInsights section="defined-benefit-planner" />
    </div>
  );
};

export default DefinedBenefitPlanner;
