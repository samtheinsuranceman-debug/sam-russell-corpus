// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Key, DollarSign, TrendingUp, Target, Calendar, Percent, ArrowRight, Shield, CheckCircle2, AlertTriangle, Lock, Globe } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

export default function DigitalAssetEstatePlanner() {
  const [cryptoAssets, setCryptoAssets] = useState([
    { id: 1, name: 'Bitcoin', quantity: 5, value: 50000 },
    { id: 2, name: 'Ethereum', quantity: 10, value: 3000 },
  ]);
  const [nftAssets, setNftAssets] = useState([
    { id: 1, name: 'CryptoPunk #1234', value: 100000 },
    { id: 2, name: 'Bored Ape #5678', value: 50000 },
  ]);
  const [domainAssets, setDomainAssets] = useState([
    { id: 1, name: 'example.com', value: 1000 },
    { id: 2, name: 'cryptoestate.io', value: 500 },
  ]);
  const [socialMediaAssets, setSocialMediaAssets] = useState([
    { id: 1, platform: 'Twitter', handle: '@user1', value: 2000 },
    { id: 2, platform: 'Instagram', handle: '@user2', value: 1500 },
  ]);
  const [digitalFilesAssets, setDigitalFilesAssets] = useState([
    { id: 1, name: 'ImportantDocument.pdf', value: 100 },
    { id: 2, name: 'PhotoCollection.zip', value: 50 },
  ]);
  const [projectionYears, setProjectionYears] = useSharedField("projectionYears", 50);
  const [growthRate, setGrowthRate] = useSharedField("growthRate", 5); // Percent

  const projectedGrowthData = useMemo(() => {
    const data = [];
    let currentValue = 100000; // Starting value
    for (let year = 1; year <= projectionYears; year++) {
      currentValue *= (1 + growthRate / 100);
      data.push({ year, value: currentValue });
    }
    return data;
  }, [projectionYears, growthRate]);

  const addCryptoAsset = (newAsset) => {
    setCryptoAssets([...cryptoAssets, newAsset]);
  };

  const addNftAsset = (newAsset) => {
    setNftAssets([...nftAssets, newAsset]);
  };

  // Similar functions for other assets...

  return (
    <div style={{ backgroundColor: '#1a1a2e', color: '#e0e0e0', minHeight: '100vh', padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <header style={{ textAlign: 'center', marginBottom: '40px' }}>
        <h1 style={{ color: '#00b4d8' }}>Digital Asset Estate Planner</h1>
        <p style={{ color: '#a18cd1' }}>Plan your cryptocurrency inheritance and digital legacy securely.</p>
      </header>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#00b4d8', display: 'flex', alignItems: 'center' }}>
          <Key size={24} color="#a18cd1" style={{ marginRight: '10px' }} />
          Digital Asset Inventory
        </h2>
        <p>Track your crypto, NFTs, domain names, social media, and digital files.</p>

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px' }}>
          <div style={{ flex: 1, minWidth: '300px', backgroundColor: '#2c2c3e', padding: '20px', borderRadius: '8px' }}>
            <h3 style={{ color: '#a18cd1' }}>Crypto Assets</h3>
            <ul>
              {cryptoAssets.map(asset => (
                <li key={asset.id}>{asset.name}: {asset.quantity} units, Value: ${asset.value}</li>
              ))}
            </ul>
            <button
              onClick={() => addCryptoAsset({ id: cryptoAssets.length + 1, name: 'New Crypto', quantity: 1, value: 1000 })}
              style={{ backgroundColor: '#00b4d8', color: '#1a1a2e', border: 'none', padding: '10px', borderRadius: '5px', cursor: 'pointer' }}
            >
              Add Crypto Asset
            </button>
          </div>

          <div style={{ flex: 1, minWidth: '300px', backgroundColor: '#2c2c3e', padding: '20px', borderRadius: '8px' }}>
            <h3 style={{ color: '#a18cd1' }}>NFT Assets</h3>
            <ul>
              {nftAssets.map(asset => (
                <li key={asset.id}>{asset.name}: Value: ${asset.value}</li>
              ))}
            </ul>
            <button
              onClick={() => addNftAsset({ id: nftAssets.length + 1, name: 'New NFT', value: 5000 })}
              style={{ backgroundColor: '#00b4d8', color: '#1a1a2e', border: 'none', padding: '10px', borderRadius: '5px', cursor: 'pointer' }}
            >
              Add NFT Asset
            </button>
          </div>

          <div style={{ flex: 1, minWidth: '300px', backgroundColor: '#2c2c3e', padding: '20px', borderRadius: '8px' }}>
            <h3 style={{ color: '#a18cd1' }}>Domain Names</h3>
            <ul>
              {domainAssets.map(asset => (
                <li key={asset.id}>{asset.name}: Value: ${asset.value}</li>
              ))}
            </ul>
          </div>

          <div style={{ flex: 1, minWidth: '300px', backgroundColor: '#2c2c3e', padding: '20px', borderRadius: '8px' }}>
            <h3 style={{ color: '#a18cd1' }}>Social Media</h3>
            <ul>
              {socialMediaAssets.map(asset => (
                <li key={asset.id}>{asset.platform} - {asset.handle}: Value: ${asset.value}</li>
              ))}
            </ul>
          </div>

          <div style={{ flex: 1, minWidth: '300px', backgroundColor: '#2c2c3e', padding: '20px', borderRadius: '8px' }}>
            <h3 style={{ color: '#a18cd1' }}>Digital Files</h3>
            <ul>
              {digitalFilesAssets.map(asset => (
                <li key={asset.id}>{asset.name}: Value: ${asset.value}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#00b4d8', display: 'flex', alignItems: 'center' }}>
          <Lock size={24} color="#a18cd1" style={{ marginRight: '10px' }} />
          Private Key Custody Solutions
        </h2>
        <p>Secure your private keys with advanced custody options for inheritance.</p>
        <ul style={{ listStyle: 'none' }}>
          <li style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
            <Shield size={20} color="#00b4d8" style={{ marginRight: '10px' }} /> Multi-factor authentication
          </li>
          <li style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
            <Key size={20} color="#00b4d8" style={{ marginRight: '10px' }} /> Encrypted storage vaults
          </li>
        </ul>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#00b4d8', display: 'flex', alignItems: 'center' }}>
          <Shield size={24} color="#a18cd1" style={{ marginRight: '10px' }} />
          Multi-Sig Wallet Estate Planning
        </h2>
        <p>Set up multi-signature wallets for secure asset transfer upon succession.</p>
        <div style={{ backgroundColor: '#2c2c3e', padding: '20px', borderRadius: '8px' }}>
          <p>Requires at least 2 out of 3 signatures for access.</p>
        </div>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#00b4d8', display: 'flex', alignItems: 'center' }}>
          <Lock size={24} color="#a18cd1" style={{ marginRight: '10px' }} />
          Hardware Wallet Succession
        </h2>
        <p>Plan for hardware wallet inheritance with recovery phrases.</p>
        <ul style={{ listStyle: 'none' }}>
          <li style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
            <ArrowRight size={20} color="#00b4d8" style={{ marginRight: '10px' }} /> Designate heirs
          </li>
          <li style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
            <Calendar size={20} color="#00b4d8" style={{ marginRight: '10px' }} /> Time-based access
          </li>
        </ul>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#00b4d8', display: 'flex', alignItems: 'center' }}>
          <Globe size={24} color="#a18cd1" style={{ marginRight: '10px' }} />
          Digital Asset Trust Structures
        </h2>
        <p>Create trusts for digital assets to ensure proper distribution.</p>
        <p>Benefits: Tax efficiency and asset protection.</p>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#00b4d8', display: 'flex', alignItems: 'center' }}>
          <Target size={24} color="#a18cd1" style={{ marginRight: '10px' }} />
          Fiduciary Access to Digital Assets
        </h2>
        <p>Grant fiduciaries access as per legal standards.</p>
        <ul style={{ listStyle: 'none' }}>
          <li style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
            <CheckCircle2 size={20} color="#00b4d8" style={{ marginRight: '10px' }} /> Revised Uniform Fiduciary Access to Digital Assets Act
          </li>
          <li style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
            <AlertTriangle size={20} color="#00b4d8" style={{ marginRight: '10px' }} /> IRC 1014 step-up basis for crypto
          </li>
        </ul>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#00b4d8', display: 'flex', alignItems: 'center' }}>
          <TrendingUp size={24} color="#a18cd1" style={{ marginRight: '10px' }} />
          50-Year Digital Asset Growth Projection
        </h2>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
          <label>Years: </label>
          <input
            type="number"
            value={projectionYears}
            onChange={(e) => setProjectionYears(Number(e.target.value))}
            style={{ marginLeft: '10px', backgroundColor: '#2c2c3e', color: '#e0e0e0', border: '1px solid #00b4d8' }}
          />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
          <label>Growth Rate (%): </label>
          <input
            type="number"
            value={growthRate}
            onChange={(e) => setGrowthRate(Number(e.target.value))}
            style={{ marginLeft: '10px', backgroundColor: '#2c2c3e', color: '#e0e0e0', border: '1px solid #00b4d8' }}
          />
        </div>
        <ResponsiveContainer width="100%" height={400}>
          <AreaChart data={projectedGrowthData}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="value" stroke="#a18cd1" fill="#00b4d8" />
          </AreaChart>
        </ResponsiveContainer>
      </section>

      <section>
        <h2 style={{ color: '#00b4d8', display: 'flex', alignItems: 'center' }}>
          <Percent size={24} color="#a18cd1" style={{ marginRight: '10px' }} />
          Compliance Information
        </h2>
        <ul style={{ listStyle: 'none' }}>
          <li style={{ marginBottom: '10px' }}>Revised Uniform Fiduciary Access to Digital Assets Act</li>
          <li style={{ marginBottom: '10px' }}>IRC 1014 step-up basis for crypto</li>
          <li style={{ marginBottom: '10px' }}>Section 2031 digital asset valuation</li>
          <li style={{ marginBottom: '10px' }}>State digital asset laws</li>
          <li style={{ marginBottom: '10px' }}>IRS Notice 2014-21</li>
        </ul>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie data={[{name: 'Compliance', value: 50}, {name: 'Risk', value: 50}]} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} fill="#8884d8">
              <Cell fill="#00b4d8" />
              <Cell fill="#a18cd1" />
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </section>
      <PageInsights section="digital-asset-estate-planner" />
    </div>
  );
}
