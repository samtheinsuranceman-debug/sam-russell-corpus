// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Layers, DollarSign, TrendingUp, Shield, CheckCircle2, AlertTriangle, Calendar, Target, Percent, ArrowRight, Scale, Lock } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, ComposedChart, Line, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

const techniques = [
  { name: 'GRAT', fullName: 'Grantor Retained Annuity Trust', description: 'A trust where the grantor retains an annuity interest, freezing the asset value for estate tax purposes.', compliance: 'IRC 2702', icon: <Layers className="inline mr-2 text-cyan-400" /> },
  { name: 'IDGT', fullName: 'Intentionally Defective Grantor Trust', description: 'A trust treated as a grantor trust for income tax but not estate tax, allowing asset growth outside the estate.', compliance: 'Sections 671-679', icon: <DollarSign className="inline mr-2 text-violet-400" /> },
  { name: 'FLP', fullName: 'Family Limited Partnership', description: 'A partnership structure to discount asset values for gift and estate taxes while maintaining control.', compliance: 'Section 2704', icon: <TrendingUp className="inline mr-2 text-cyan-400" /> },
  { name: 'SLAT', fullName: 'Spousal Lifetime Access Trust', description: 'A trust for spouses that provides access to assets while removing them from the estate.', compliance: 'Section 2511', icon: <Shield className="inline mr-2 text-violet-400" /> },
  { name: 'QPRT', fullName: 'Qualified Personal Residence Trust', description: 'A trust that freezes the value of a personal residence for estate tax purposes.', compliance: 'Section 2702(a)(3)', icon: <CheckCircle2 className="inline mr-2 text-cyan-400" /> },
  { name: 'CRT', fullName: 'Charitable Remainder Trust', description: 'A trust that provides income to beneficiaries and a remainder to charity, reducing estate taxes.', compliance: 'Section 664', icon: <AlertTriangle className="inline mr-2 text-violet-400" /> },
  { name: 'CLT', fullName: 'Charitable Lead Trust', description: 'A trust that pays income to charity first, then to beneficiaries, freezing estate value.', compliance: 'Section 170', icon: <Calendar className="inline mr-2 text-cyan-400" /> },
  { name: 'Dynasty Trust', fullName: 'Dynasty Trust', description: 'A perpetual trust that passes wealth through generations without estate taxes.', compliance: 'Section 2601', icon: <Target className="inline mr-2 text-violet-400" /> },
];

const radarChartData = [
  { technique: 'GRAT', taxSavings: 8, complexity: 7, cost: 6, flexibility: 5, assetProtection: 4, control: 9 },
  { technique: 'IDGT', taxSavings: 9, complexity: 8, cost: 7, flexibility: 7, assetProtection: 8, control: 6 },
  { technique: 'FLP', taxSavings: 7, complexity: 6, cost: 5, flexibility: 6, assetProtection: 9, control: 8 },
  { technique: 'SLAT', taxSavings: 6, complexity: 5, cost: 4, flexibility: 8, assetProtection: 7, control: 7 },
  { technique: 'QPRT', taxSavings: 5, complexity: 4, cost: 3, flexibility: 4, assetProtection: 5, control: 5 },
  { technique: 'CRT', taxSavings: 8, complexity: 6, cost: 5, flexibility: 3, assetProtection: 6, control: 4 },
  { technique: 'CLT', taxSavings: 7, complexity: 5, cost: 4, flexibility: 5, assetProtection: 4, control: 3 },
  { technique: 'Dynasty Trust', taxSavings: 9, complexity: 7, cost: 6, flexibility: 9, assetProtection: 9, control: 8 },
];

const taxSavingsData = [
  { year: 0, GRAT: 0, IDGT: 0, FLP: 0, SLAT: 0, QPRT: 0, CRT: 0, CLT: 0, Dynasty: 0 },
  { year: 5, GRAT: 500000, IDGT: 600000, FLP: 400000, SLAT: 300000, QPRT: 200000, CRT: 450000, CLT: 350000, Dynasty: 700000 },
  { year: 10, GRAT: 1000000, IDGT: 1200000, FLP: 800000, SLAT: 600000, QPRT: 400000, CRT: 900000, CLT: 700000, Dynasty: 1400000 },
  { year: 15, GRAT: 1500000, IDGT: 1800000, FLP: 1200000, SLAT: 900000, QPRT: 600000, CRT: 1350000, CLT: 1050000, Dynasty: 2100000 },
  { year: 20, GRAT: 2000000, IDGT: 2400000, FLP: 1600000, SLAT: 1200000, QPRT: 800000, CRT: 1800000, CLT: 1400000, Dynasty: 2800000 },
  { year: 25, GRAT: 2500000, IDGT: 3000000, FLP: 2000000, SLAT: 1500000, QPRT: 1000000, CRT: 2250000, CLT: 1750000, Dynasty: 3500000 },
  { year: 30, GRAT: 3000000, IDGT: 3600000, FLP: 2400000, SLAT: 1800000, QPRT: 1200000, CRT: 2700000, CLT: 2100000, Dynasty: 4200000 },
];

export default function EstateFreezeComparison() {
  const [clientAge, setClientAge] = useSharedField("currentAge", '');
  const [clientAssets, setClientAssets] = useState('');
  const [optimalTechnique, setOptimalTechnique] = useState('');

  const selectOptimalTechnique = useMemo(() => {
    if (clientAge && clientAssets) {
      const age = parseInt(clientAge);
      const assets = parseInt(clientAssets);
      if (age < 50 && assets > 5000000) return 'Dynasty Trust';
      if (age < 60 && assets > 2000000) return 'IDGT';
      if (age < 70) return 'GRAT';
      return 'FLP';
    }
    return '';
  }, [clientAge, clientAssets]);

  const handleSubmit = (e) => {
    e.preventDefault();
    setOptimalTechnique(selectOptimalTechnique);
  };

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white p-8">
      <h1 className="text-4xl font-bold mb-8 text-cyan-400">Estate Freeze Techniques Comparison</h1>
      
      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4 text-violet-400">Side-by-Side Comparison</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {techniques.map((tech) => (
            <div key={tech.name} className="bg-[#0d1526] p-6 rounded-lg shadow-lg border border-cyan-500">
              {tech.icon}
              <h3 className="text-xl font-bold">{tech.fullName}</h3>
              <p className="text-[#94a3b8]">{tech.description}</p>
              <p className="mt-2 text-sm text-violet-300">Compliance: {tech.compliance}</p>
            </div>
          ))}
        </div>
      </section>
      
      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4 text-cyan-400">Radar Chart: Scoring on 6 Dimensions</h2>
        <p className="text-[#94a3b8] mb-4">Scores out of 10 for Tax Savings, Complexity, Cost, Flexibility, Asset Protection, and Control.</p>
        <RadarChart outerRadius={90} width={730} height={500} data={radarChartData}>
          <PolarGrid />
          <PolarAngleAxis dataKey="technique" />
          <PolarRadiusAxis angle={30} domain={[0, 10]} />
          <Radar name="Tax Savings" dataKey="taxSavings" stroke="#00BFFF" fill="#00BFFF" fillOpacity={0.6} />
          <Radar name="Complexity" dataKey="complexity" stroke="#8A2BE2" fill="#8A2BE2" fillOpacity={0.6} />
          <Radar name="Cost" dataKey="cost" stroke="#00CED1" fill="#00CED1" fillOpacity={0.6} />
          <Radar name="Flexibility" dataKey="flexibility" stroke="#9370DB" fill="#9370DB" fillOpacity={0.6} />
          <Radar name="Asset Protection" dataKey="assetProtection" stroke="#00FA9A" fill="#00FA9A" fillOpacity={0.6} />
          <Radar name="Control" dataKey="control" stroke="#FF69B4" fill="#FF69B4" fillOpacity={0.6} />
          <Legend />
          <Tooltip />
        </RadarChart>
      </section>
      
      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4 text-violet-400">Optimal Technique Selector</h2>
        <p className="text-[#94a3b8] mb-4">Based on your age and assets, select the best technique.</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-cyan-300">Age:</label>
            <input type="number" value={clientAge} onChange={(e) => setClientAge(e.target.value)} className="bg-gray-700 p-2 rounded w-full text-white" />
          </div>
          <div>
            <label className="block text-cyan-300">Assets (in USD):</label>
            <input type="number" value={clientAssets} onChange={(e) => setClientAssets(e.target.value)} className="bg-gray-700 p-2 rounded w-full text-white" />
          </div>
          <button type="submit" className="bg-violet-500 px-4 py-2 rounded">Select Optimal Technique</button>
        </form>
        {optimalTechnique && <p className="mt-4 text-xl text-green-400">Recommended: {optimalTechnique}</p>}
      </section>
      
      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4 text-cyan-400">30-Year Estate Tax Savings Comparison</h2>
        <p className="text-[#94a3b8] mb-4">Projected savings over 30 years for each technique.</p>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={taxSavingsData}>
            <XAxis dataKey="year" stroke="white" />
            <YAxis stroke="white" />
            <Tooltip />
            <Legend />
            <Bar dataKey="GRAT" fill="#00BFFF" />
            <Bar dataKey="IDGT" fill="#8A2BE2" />
            <Bar dataKey="FLP" fill="#00CED1" />
            <Bar dataKey="SLAT" fill="#9370DB" />
            <Bar dataKey="QPRT" fill="#00FA9A" />
            <Bar dataKey="CRT" fill="#FF69B4" />
            <Bar dataKey="CLT" fill="#FFD700" />
            <Bar dataKey="Dynasty" fill="#FF4500" />
          </BarChart>
        </ResponsiveContainer>
      </section>
      
      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4 text-violet-400">Technique Combination Strategies</h2>
        <p className="text-[#94a3b8]">Combining techniques can enhance benefits. For example:</p>
        <ul className="list-disc pl-5 text-gray-200">
          <li>GRAT + Dynasty Trust: Freeze assets with GRAT and ensure perpetual transfer with Dynasty Trust for maximum tax savings and asset protection.</li>
          <li>IDGT + FLP: Use IDGT for income tax advantages and FLP for valuation discounts, improving flexibility and control.</li>
          <li>SLAT + CRT: Provide spousal access via SLAT and charitable benefits via CRT to balance estate reduction with philanthropy.</li>
          <li>QPRT + CLT: Freeze residence value with QPRT and lead with charity via CLT for overall estate minimization.</li>
          <li>General Strategy: Always consult with a tax advisor to ensure combinations comply with IRC rules and optimize for your profile.</li>
        </ul>
      </section>
      
      <section>
        <h2 className="text-2xl font-semibold mb-4 text-cyan-400">Compliance References</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-[#0d1526] p-4 rounded">
            <p><Percent className="inline mr-2" /> GRAT: IRC 2702</p>
            <p><ArrowRight className="inline mr-2" /> IDGT: Sections 671-679</p>
            <p><Scale className="inline mr-2" /> FLP: Section 2704</p>
          </div>
          <div className="bg-[#0d1526] p-4 rounded">
            <p><Lock className="inline mr-2" /> SLAT: Section 2511</p>
            <p><CheckCircle2 className="inline mr-2" /> QPRT: Section 2702(a)(3)</p>
            <p><AlertTriangle className="inline mr-2" /> CRT: Section 664</p>
          </div>
          <div className="bg-[#0d1526] p-4 rounded">
            <p><Calendar className="inline mr-2" /> CLT: Section 170</p>
            <p><Target className="inline mr-2" /> Dynasty Trust: Section 2601</p>
          </div>
        </div>
        <p className="mt-4 text-[#94a3b8]">Ensure all strategies comply with current IRS regulations to avoid penalties.</p>
      </section>
      <PageInsights section="estate-freeze-comparison" />
    </div>
  );
}
