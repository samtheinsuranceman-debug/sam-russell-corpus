// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Heart, DollarSign, TrendingUp, Target, Calendar, Percent, ArrowRight, Shield, CheckCircle2, AlertTriangle, Gift, Users } from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, 
  BarChart, Bar, ComposedChart, Line, PieChart, Pie, Cell 
} from 'recharts';
import { PageInsights } from "@/components/PageInsights";

const CharitableLeadTrustEngine = () => {
  const [trustType, setTrustType] = useState('CLAT'); // CLAT or CLUT
  const [grantorType, setGrantorType] = useState('grantor'); // grantor or non-grantor
  const [initialAmount, setInitialAmount] = useState(1000000); // Initial trust amount
  const [durationYears, setDurationYears] = useState(20); // Trust duration in years
  const [payoutRate, setPayoutRate] = useState(5); // Annual payout rate in %
  const [zeroedOut, setZeroedOut] = useState(false); // Zeroed-out CLT toggle
  const [sharkFin, setSharkFin] = useState(false); // Shark-fin CLAT toggle
  const [rate7520, setRate7520] = useState(2.5); // 7520 rate in %
  const [projectionYears, setProjectionYears] = useSharedField("projectionYears", 50); // Years for wealth projection

  const data = useMemo(() => {
    const generateProjection = () => {
      let projections = [];
      let currentValue = initialAmount;
      for (let year = 0; year <= projectionYears; year++) {
        const growthRate = 5; // Assumed annual growth rate
        const payout = (trustType === 'CLAT' ? (initialAmount * (payoutRate / 100)) : (currentValue * (payoutRate / 100)));
        currentValue = currentValue * (1 + (growthRate / 100)) - payout;
        projections.push({ year, value: currentValue });
      }
      return projections;
    };
    return generateProjection();
  }, [trustType, initialAmount, payoutRate, projectionYears]);

  const chartData = [
    { name: 'Year 1', CLAT: 500000, CLUT: 450000 },
    { name: 'Year 2', CLAT: 550000, CLUT: 500000 },
    { name: 'Year 3', CLAT: 600000, CLUT: 550000 },
    { name: 'Year 4', CLAT: 650000, CLUT: 600000 },
    { name: 'Year 5', CLAT: 700000, CLUT: 650000 },
  ];

  const pieData = [
    { name: 'Charitable Portion', value: 60 },
    { name: 'Family Portion', value: 40 },
  ];

  const COLORS = ['#10B981', '#8B5CF6']; // Emerald and Purple accents

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white p-8 font-sans">
      <header className="flex items-center mb-8">
        <Heart className="mr-2" size={24} color="#10B981" />
        <h1 className="text-3xl font-bold">Charitable Lead Trust Engine</h1>
      </header>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-4 flex items-center">
          <DollarSign className="mr-2" size={20} color="#8B5CF6" />
          Trust Type: CLAT vs CLUT
        </h2>
        <p className="mb-4">CLAT (Charitable Lead Annuity Trust) provides fixed annual payments to charity. CLUT (Charitable Lead Unitrust) provides payments based on a percentage of the trust's annual value.</p>
        <div className="flex space-x-4">
          <button 
            onClick={() => setTrustType('CLAT')} 
            className={`p-2 rounded ${trustType === 'CLAT' ? 'bg-emerald-500' : 'bg-gray-700'}`}
          >
            Select CLAT
          </button>
          <button 
            onClick={() => setTrustType('CLUT')} 
            className={`p-2 rounded ${trustType === 'CLUT' ? 'bg-emerald-500' : 'bg-gray-700'}`}
          >
            Select CLUT
          </button>
        </div>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="CLAT" fill="#10B981" />
            <Bar dataKey="CLUT" fill="#8B5CF6" />
          </BarChart>
        </ResponsiveContainer>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-4 flex items-center">
          <Shield className="mr-2" size={20} color="#8B5CF6" />
          Grantor vs Non-Grantor
        </h2>
        <p className="mb-4">Grantor trusts are taxed to the grantor, providing tax benefits. Non-grantor trusts are taxed to the trust or beneficiaries.</p>
        <div className="flex space-x-4">
          <button 
            onClick={() => setGrantorType('grantor')} 
            className={`p-2 rounded ${grantorType === 'grantor' ? 'bg-emerald-500' : 'bg-gray-700'}`}
          >
            Grantor
          </button>
          <button 
            onClick={() => setGrantorType('non-grantor')} 
            className={`p-2 rounded ${grantorType === 'non-grantor' ? 'bg-emerald-500' : 'bg-gray-700'}`}
          >
            Non-Grantor
          </button>
        </div>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-4 flex items-center">
          <CheckCircle2 className="mr-2" size={20} color="#10B981" />
          Zeroed-Out CLT
        </h2>
        <p className="mb-4">A zeroed-out CLT sets the present value of charitable interests equal to the asset value, minimizing gift tax.</p>
        <label className="flex items-center">
          <input 
            type="checkbox" 
            checked={zeroedOut} 
            onChange={() => setZeroedOut(!zeroedOut)} 
            className="mr-2"
          />
          Enable Zeroed-Out
        </label>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-4 flex items-center">
          <AlertTriangle className="mr-2" size={20} color="#8B5CF6" />
          Shark-Fin CLAT
        </h2>
        <p className="mb-4">Shark-fin CLAT features increasing payments over time for strategic wealth transfer.</p>
        <label className="flex items-center">
          <input 
            type="checkbox" 
            checked={sharkFin} 
            onChange={() => setSharkFin(!sharkFin)} 
            className="mr-2"
          />
          Enable Shark-Fin
        </label>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-4 flex items-center">
          <Percent className="mr-2" size={20} color="#10B981" />
          7520 Rate Impact
        </h2>
        <p className="mb-4">The 7520 rate affects the valuation of annuities. Current rate: {rate7520}%</p>
        <input 
          type="number" 
          value={rate7520} 
          onChange={(e) => setRate7520(parseFloat(e.target.value))} 
          className="p-2 rounded bg-gray-700 text-white"
          placeholder="Enter 7520 rate"
        />
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-4 flex items-center">
          <TrendingUp className="mr-2" size={20} color="#8B5CF6" />
          50-Year Family Wealth Projection
        </h2>
        <p className="mb-4">Projection based on inputs for {projectionYears} years.</p>
        <ResponsiveContainer width="100%" height={400}>
          <ComposedChart data={data}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="value" fill="#10B981" stroke="#8B5CF6" />
            <Line type="monotone" dataKey="value" stroke="#8B5CF6" />
            <Bar dataKey="value" fill="#10B981" />
          </ComposedChart>
        </ResponsiveContainer>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-4 flex items-center">
          <Gift className="mr-2" size={20} color="#10B981" />
          Wealth Distribution Pie Chart
        </h2>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={pieData}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
            >
              {pieData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-4 flex items-center">
          <Users className="mr-2" size={20} color="#8B5CF6" />
          Input Parameters
        </h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label>Initial Amount</label>
            <input 
              type="number" 
              value={initialAmount} 
              onChange={(e) => setInitialAmount(parseFloat(e.target.value))} 
              className="p-2 rounded bg-gray-700 w-full"
            />
          </div>
          <div>
            <label>Duration (Years)</label>
            <input 
              type="number" 
              value={durationYears} 
              onChange={(e) => setDurationYears(parseInt(e.target.value))} 
              className="p-2 rounded bg-gray-700 w-full"
            />
          </div>
          <div>
            <label>Payout Rate (%)</label>
            <input 
              type="number" 
              value={payoutRate} 
              onChange={(e) => setPayoutRate(parseFloat(e.target.value))} 
              className="p-2 rounded bg-gray-700 w-full"
            />
          </div>
          <div>
            <label>Projection Years</label>
            <input 
              type="number" 
              value={projectionYears} 
              onChange={(e) => setProjectionYears(parseInt(e.target.value))} 
              className="p-2 rounded bg-gray-700 w-full"
            />
          </div>
        </div>
      </section>

      <footer className="mt-8 flex items-center justify-center">
        <ArrowRight size={24} color="#10B981" />
        <p>Explore more with Charitable Lead Trusts for optimized wealth and charity strategies.</p>
      </footer>
      <PageInsights section="charitable-lead-trust-engine" />
    </div>
  );
};

export default CharitableLeadTrustEngine;
