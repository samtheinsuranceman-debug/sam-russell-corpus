// @ts-nocheck
import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Calculator } from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function CryptoTaxCalc() {
  const autoFill = useCalculatorAutoFill("crypto-tax");
  const { reportResult } = useCalcResults();
  const [purchasePrice, setPurchasePrice] = useState(50000);
  const [currentPrice, setCurrentPrice] = useState(60000);
  const [amount, setAmount] = useState(1);
  const [holdingPeriod, setHoldingPeriod] = useState(1);
  const [annualIncome, setAnnualIncome] = useSharedField("annualIncome", 50000);

  const calculations = useMemo(() => {
    const gainPerUnit = currentPrice - purchasePrice;
    const totalGain = gainPerUnit * amount;

    let taxRate = 0;
    if (holdingPeriod > 1) {  // Long-term
      if (annualIncome < 40000) taxRate = 0;
      else if (annualIncome < 441725) taxRate = 0.15;
      else taxRate = 0.20;
    } else {  // Short-term
      if (annualIncome < 11000) taxRate = 0.10;
      else if (annualIncome < 44725) taxRate = 0.12;
      else if (annualIncome < 95375) taxRate = 0.22;
      else taxRate = 0.24;
    }

    const taxOwed = totalGain > 0 ? totalGain * taxRate : 0;
    const netProfit = totalGain - taxOwed;
    const effectiveTaxRate = totalGain > 0 ? (taxOwed / totalGain) * 100 : 0;

    return { totalGain, taxOwed, netProfit, effectiveTaxRate };
  }, [purchasePrice, currentPrice, amount, holdingPeriod, annualIncome]);
  const projectionData = useMemo(() => {
    const d = [];
    const income = typeof primaryIncome !== 'undefined' ? primaryIncome : 250000;
    const savingsRate = 0.08;
    let withStrat = 0, withoutStrat = 0, cumTax = 0;
    for (let yr = 0; yr <= 50; yr++) {
      const annualSavings = income * savingsRate * (1 + yr * 0.01);
      cumTax += annualSavings;
      withStrat += (income * 0.15) * Math.pow(1.072, yr > 0 ? 1 : 0);
      withoutStrat += (income * 0.15 - annualSavings) * Math.pow(1.055, yr > 0 ? 1 : 0);
      d.push({ year: yr, taxSaved: Math.round(cumTax), withStrategy: Math.round(withStrat), withoutStrategy: Math.round(withoutStrat), netBenefit: Math.round(cumTax * 1.06) });
    }
    return d;
  }, []);


  return (
    <AppShell className="bg-[#0a0f1a] text-white">
      <div className="p-6">
        <AutoFillBanner calcRoute="crypto-tax" />
        <Card className="bg-[#0d1526] mb-6">
          <CardHeader>
            <CardTitle className="flex items-center text-emerald-400">
              <Calculator className="mr-2" /> Crypto Capital Gains Tax Calculator
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Purchase Price per Bitcoin</Label>
                <Input
                  type="number"
                  value={purchasePrice}
                  onChange={(e) => setPurchasePrice(Number(e.target.value))}
                  className="mt-1 bg-slate-700"
                />
              </div>
              <div>
                <Label>Current Price per Bitcoin</Label>
                <Input
                  type="number"
                  value={currentPrice}
                  onChange={(e) => setCurrentPrice(Number(e.target.value))}
                  className="mt-1 bg-slate-700"
                />
              </div>
              <div>
                <Label>Number of Bitcoins</Label>
                <Input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  className="mt-1 bg-slate-700"
                />
              </div>
              <div>
                <Label>Holding Period (years)</Label>
                <Slider
                  min={0}
                  max={5}
                  step={1}
                  value={[holdingPeriod]}
                  onValueChange={(value) => setHoldingPeriod(value[0])}
                  className="mt-1"
                />
                <p className="mt-1 text-sm">Current: {holdingPeriod} years</p>
              </div>
              <div>
                <Label>Annual Income</Label>
                <Slider
                  min={0}
                  max={200000}
                  step={10000}
                  value={[annualIncome]}
                  onValueChange={(value) => setAnnualIncome(value[0])}
                  className="mt-1"
                />
                <p className="mt-1 text-sm">Current: {formatDollars(annualIncome)}</p>
              </div>
              <div>
                <Label>Tax Filing Status</Label>
                <Select onValueChange={(value) => console.log(value)}> {/* Simplified, no state change for now */}
                  <SelectTrigger className="mt-1 bg-slate-700">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="single">Single</SelectItem>
                    <SelectItem value="married">Married Filing Jointly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
        {/* State Tax Impact */}
        <StateTaxSelector income={annualIncome} filingStatus={'single'} className="mb-6" />

        
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "taxSaved", label: "Cumulative Tax Savings", color: "#10b981" }, { key: "withStrategy", label: "With Tax Strategy", color: "#06b6d4" }, { key: "withoutStrategy", label: "Without Strategy", color: "#ef4444" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="bg-[#0d1526]">
            <CardHeader>
              <CardTitle>Capital Gains Tax Owed</CardTitle>
            </CardHeader>
            <CardContent>{formatDollars(calculations.taxOwed)}</CardContent>
          </Card>
          <Card className="bg-[#0d1526]">
            <CardHeader>
              <CardTitle>Net Profit After Tax</CardTitle>
            </CardHeader>
            <CardContent>{formatDollars(calculations.netProfit)}</CardContent>
          </Card>
          <Card className="bg-[#0d1526]">
            <CardHeader>
              <CardTitle>Effective Tax Rate</CardTitle>
            </CardHeader>
            <CardContent>{calculations.effectiveTaxRate.toFixed(2) + "%"}</CardContent>
          </Card>
        </div>

        <Card className="bg-[#0d1526] mb-6">
          <CardHeader>
            <CardTitle>IUL Advantage</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Indexed Universal Life (IUL) insurance offers tax-free growth on your investments, unlike crypto gains which are subject to capital gains tax. By switching to IUL, you could save </p>
            <p>{formatDollars(calculations.taxOwed)} in taxes and enjoy protected, tax-optimized growth for your financial future.</p>
          </CardContent>
        </Card>

        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-500 hover:bg-emerald-600"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("crypto-tax", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-crypto-tax");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Crypto / Bitcoin Capital Gains Tax Calculator"
            calculatorRoute="crypto-tax"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="crypto-tax-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/crypto-tax" />
</div>
    </AppShell>
  );
}