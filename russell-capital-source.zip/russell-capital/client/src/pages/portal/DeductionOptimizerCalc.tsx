// @ts-nocheck

import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Calculator } from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function DeductionOptimizerCalc() {
  const autoFill = useCalculatorAutoFill("deduction-optimizer");
  const { reportResult } = useCalcResults();
  const [annualIncome, setAnnualIncome] = useSharedField("annualIncome", 50000);
  const [age, setAge] = useSharedField("currentAge", 30);
  const [deductions, setDeductions] = useState(10000);
  const [taxRate, setTaxRate] = useSharedField("currentTaxBracket", 0.22);
  const [iulPremium, setIulPremium] = useState(5000);

  const calculations = useMemo(() => {
    const taxableIncome = annualIncome - deductions;
    const taxOwed = taxableIncome > 0 ? taxableIncome * taxRate : 0;
    const iulGrowthRate = 0.06; // Assumed 6% annual growth
    const yearsToRetirement = 65 - age; // Assuming retirement at 65
    const projectedIulValue = iulPremium * yearsToRetirement * (1 + iulGrowthRate); // Simplified projection
    const estimatedTaxSavings = taxOwed * 0.15; // Hypothetical savings from optimization
    const netBenefit = projectedIulValue - taxOwed; // Net benefit calculation

    return {
      estimatedTaxSavings,
      projectedIulValue,
      netBenefit,
    };
  }, [annualIncome, age, deductions, taxRate, iulPremium]);
  const projectionData = useMemo(() => {
    const d = [];
    const income = typeof primaryIncome !== 'undefined' ? primaryIncome : 250000;
    const savingsRate = 0.08;
    let withStrat = 0, withoutStrat = 0, cumTax = 0;
    for (let yr = 0; yr <= 50; yr++) {
      const annualSavings = income * savingsRate * (1 + yr * 0.01);
      cumTax += annualSavings;
      withStrat += (income * 0.15) * Math.pow(1.072, yr > 0 ? 1 : 0);
      withoutStrat += (income * 0.15 - annualSavings) * Math.pow(1.055, yr > 0 ? 1 : 0);
      d.push({ year: yr, taxSaved: Math.round(cumTax), withStrategy: Math.round(withStrat), withoutStrategy: Math.round(withoutStrat), netBenefit: Math.round(cumTax * 1.06) });
    }
    return d;
  }, []);


  return (
    <AppShell>
      <div className="bg-[#0a0f1a] min-h-screen p-6 text-white">
        <AutoFillBanner calcRoute="deduction-optimizer" />
        <div className="flex flex-col items-center justify-center">
          <h1 className="text-3xl font-bold mb-6 text-emerald-400 flex items-center">
            <Calculator className="mr-2" /> Deduction Optimizer Calculator
          </h1>
          
          {/* Input Section */}
          <div className="w-full max-w-md bg-[#0d1526] p-6 rounded-lg shadow-lg mb-8">
            <h2 className="text-2xl font-semibold mb-4 text-emerald-400">Inputs</h2>
            <div className="space-y-4">
              <div>
                <Label>Annual Income</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={annualIncome}
                    onChange={(e) => setAnnualIncome(Number(e.target.value))}
                    className="bg-slate-700"
                  />
                  <Slider
                    min={0}
                    max={200000}
                    step={1000}
                    value={[annualIncome]}
                    onValueChange={(value) => setAnnualIncome(value[0])}
                    className="w-full"
                  />
                </div>
              </div>
              <div>
                <Label>Age</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(Number(e.target.value))}
                    className="bg-slate-700"
                  />
                  <Slider
                    min={18}
                    max={65}
                    step={1}
                    value={[age]}
                    onValueChange={(value) => setAge(value[0])}
                    className="w-full"
                  />
                </div>
              </div>
              <div>
                <Label>Deductions</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={deductions}
                    onChange={(e) => setDeductions(Number(e.target.value))}
                    className="bg-slate-700"
                  />
                  <Slider
                    min={0}
                    max={50000}
                    step={500}
                    value={[deductions]}
                    onValueChange={(value) => setDeductions(value[0])}
                    className="w-full"
                  />
                </div>
              </div>
              <div>
                <Label>Tax Rate (e.g., 0.22 for 22%)</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={taxRate}
                    onChange={(e) => setTaxRate(Number(e.target.value))}
                    className="bg-slate-700"
                  />
                  <Slider
                    min={0}
                    max={0.4}
                    step={0.01}
                    value={[taxRate]}
                    onValueChange={(value) => setTaxRate(value[0])}
                    className="w-full"
                  />
                </div>
              </div>
              <div>
                <Label>IUL Annual Premium</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={iulPremium}
                    onChange={(e) => setIulPremium(Number(e.target.value))}
                    className="bg-slate-700"
                  />
                  <Slider
                    min={0}
                    max={20000}
                    step={500}
                    value={[iulPremium]}
                    onValueChange={(value) => setIulPremium(value[0])}
                    className="w-full"
                  />
                </div>
              </div>
            </div>
          </div>
          
          {/* Results Section */}
        {/* State Tax Impact */}
        <StateTaxSelector income={annualIncome} filingStatus={'single'} className="mb-6" />
          
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "taxSaved", label: "Cumulative Tax Savings", color: "#10b981" }, { key: "withStrategy", label: "With Tax Strategy", color: "#06b6d4" }, { key: "withoutStrategy", label: "Without Strategy", color: "#ef4444" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle>Estimated Tax Savings</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-emerald-400">
                  {formatDollars(calculations.estimatedTaxSavings)}
                </p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle>Projected IUL Value</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-emerald-400">
                  {formatDollars(calculations.projectedIulValue)}
                </p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle>Net Benefit</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-emerald-400">
                  {formatDollars(calculations.netBenefit)}
                </p>
              </CardContent>
            </Card>
          </div>
          
          {/* IUL Advantage Section */}
          <Card className="bg-[#0d1526] p-6 w-full max-w-md mb-8">
            <CardHeader>
              <CardTitle className="text-emerald-400">IUL Advantage</CardTitle>
            </CardHeader>
            <CardContent>
              <p>IUL provides tax-free growth, allowing your investments to compound without tax impact. This optimizer shows how directing premiums to IUL can enhance your tax and income strategy compared to taxable accounts.</p>
              <Badge className="mt-2 bg-emerald-400 text-slate-900">Tax-Free Growth Benefit</Badge>
            </CardContent>
          </Card>
          
          {/* Send to AI Advisor Button */}
          <Button
            onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
            className="bg-emerald-400 text-slate-900 hover:bg-emerald-500"
          >
            Send to AI Advisor
          </Button>
        </div>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("deduction-optimizer", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-deduction-optimizer");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Tax Deduction Optimizer"
            calculatorRoute="deduction-optimizer"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="deduction-optimizer-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/deduction-optimizer" />
</div>
    </AppShell>
  );
}