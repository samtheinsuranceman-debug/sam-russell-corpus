// @ts-nocheck

import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Circle, CalculatorIcon} from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function DepreciationTaxShieldCalc() {
  const autoFill = useCalculatorAutoFill("depreciation-tax-shield");
  const { reportResult } = useCalcResults();
  const [purchasePrice, setPurchasePrice] = useState(500000);
  const [landValuePercentage, setLandValuePercentage] = useState(20);
  const [usefulLife, setUsefulLife] = useState(27.5);
  const [taxRate, setTaxRate] = useSharedField("currentTaxBracket", 22);

  const calculations = useMemo(() => {
    const depreciableBasis = purchasePrice * (1 - landValuePercentage / 100);
    const annualDepreciation = depreciableBasis / usefulLife;
    const annualTaxShield = annualDepreciation * (taxRate / 100);
    const totalTaxSavings = annualTaxShield * usefulLife;
    return {
      annualDepreciation,
      annualTaxShield,
      totalTaxSavings,
    };
  }, [purchasePrice, landValuePercentage, usefulLife, taxRate]);
  const projectionData = useMemo(() => {
    const d = [];
    let opt = 100000, base = 100000, taxSav = 0;
    for (let yr = 0; yr <= 50; yr++) {
      opt *= 1.075;
      base *= 1.05;
      taxSav += (opt - base) * 0.08;
      d.push({ year: yr, optimized: Math.round(opt), baseline: Math.round(base), taxSavings: Math.round(taxSav), netBenefit: Math.round(opt - base + taxSav) });
    }
    return d;
  }, []);


  return (
    <AppShell
      headerTitle="Real Estate Depreciation & Tax Shield Calculator"
      headerSubtitle="Category: Real Estate & Property"
    >
      <div className="p-6 bg-[#0a0f1a] min-h-screen text-white">
        <AutoFillBanner calcRoute="depreciation-tax-shield" />
        <h1 className="text-2xl font-bold mb-6 text-emerald-400">
          Calculate Your Depreciation and Tax Benefits
        </h1>
        
        {/* Input Section */}
        <Card className="bg-[#0d1526] mb-6">
          <CardHeader>
            <CardTitle className="flex items-center text-emerald-400">
              <CalculatorIcon className="mr-2" /> Input Values
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label>Property Purchase Price</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={purchasePrice}
                    onChange={(e) => setPurchasePrice(Number(e.target.value))}
                    className="bg-slate-700"
                  />
                  <Slider
                    min={100000}
                    max={2000000}
                    step={10000}
                    value={[purchasePrice]}
                    onValueChange={(value) => setPurchasePrice(value[0])}
                  />
                </div>
              </div>
              
              <div>
                <Label>Land Value Percentage (%)</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={landValuePercentage}
                    onChange={(e) => setLandValuePercentage(Number(e.target.value))}
                    className="bg-slate-700"
                    min={0}
                    max={100}
                  />
                  <Slider
                    min={0}
                    max={100}
                    step={1}
                    value={[landValuePercentage]}
                    onValueChange={(value) => setLandValuePercentage(value[0])}
                  />
                </div>
              </div>
              
              <div>
                <Label>Useful Life of Property (Years)</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={usefulLife}
                    onChange={(e) => setUsefulLife(Number(e.target.value))}
                    className="bg-slate-700"
                    min={10}
                    max={40}
                    step={0.5}
                  />
                  <Slider
                    min={10}
                    max={40}
                    step={0.5}
                    value={[usefulLife]}
                    onValueChange={(value) => setUsefulLife(value[0])}
                  />
                </div>
              </div>
              
              <div>
                <Label>Marginal Tax Rate (%)</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={taxRate}
                    onChange={(e) => setTaxRate(Number(e.target.value))}
                    className="bg-slate-700"
                    min={0}
                    max={50}
                  />
                  <Slider
                    min={0}
                    max={50}
                    step={1}
                    value={[taxRate]}
                    onValueChange={(value) => setTaxRate(value[0])}
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Results Section */}
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />
        
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "optimized", label: "Optimized Strategy", color: "#10b981" }, { key: "baseline", label: "Baseline (No Action)", color: "#ef4444" }, { key: "taxSavings", label: "Cumulative Tax Savings", color: "#06b6d4" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card className="bg-[#0d1526]">
            <CardHeader>
              <CardTitle>Annual Depreciation</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-emerald-400">
                {formatDollars(calculations.annualDepreciation)}
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#0d1526]">
            <CardHeader>
              <CardTitle>Annual Tax Shield</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-emerald-400">
                {formatDollars(calculations.annualTaxShield)}
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#0d1526]">
            <CardHeader>
              <CardTitle>Total Tax Savings</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-emerald-400">
                {formatDollars(calculations.totalTaxSavings)}
              </p>
            </CardContent>
          </Card>
        </div>
        
        {/* IUL Advantage Section */}
        <Card className="bg-[#0d1526] mb-6">
          <CardHeader>
            <CardTitle className="text-emerald-400">IUL Advantage</CardTitle>
          </CardHeader>
          <CardContent>
            <p>
              While real estate depreciation provides a tax shield by reducing
              taxable income, Indexed Universal Life (IUL) offers tax-free
              growth and withdrawals. This can complement your real estate
              investments by providing additional tax-advantaged income
              streams, enhancing your overall financial strategy.
            </p>
          </CardContent>
        </Card>
        
        {/* Send to AI Advisor Button */}
        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-500 hover:bg-emerald-600"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("depreciation-tax-shield", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-depreciation-tax-shield");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Real Estate Depreciation & Tax Shield Calculator"
            calculatorRoute="depreciation-tax-shield"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="depreciation-tax-shield-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/depreciation-tax-shield" />
</div>
    </AppShell>
  );
}