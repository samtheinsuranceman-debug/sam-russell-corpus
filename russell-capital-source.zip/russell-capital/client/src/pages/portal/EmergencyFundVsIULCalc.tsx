// @ts-nocheck

import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calculator, DollarSign } from 'lucide-react';
import { toast } from "sonner";
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function EmergencyFundVsIULCalc() {
  const autoFill = useCalculatorAutoFill("emergency-fund-vs-iul");
  const { reportResult } = useCalcResults();
  const [annualIncome, setAnnualIncome] = useSharedField("annualIncome", 50000);
  const [age, setAge] = useSharedField("currentAge", 30);
  const [emergencyFundBalance, setEmergencyFundBalance] = useState(10000);
  const [iulAnnualContribution, setIulAnnualContribution] = useState(5000);
  const [emergencyFundRate, setEmergencyFundRate] = useState(0.01); // e.g., 1%
  const [iulGrowthRate, setIulGrowthRate] = useState(0.06); // e.g., 6%
  const [yearsToProject, setYearsToProject] = useSharedField("projectionYears", 5);

  const calculations = useMemo(() => {
    const emergencyFundFutureValue = emergencyFundBalance * Math.pow(1 + emergencyFundRate, yearsToProject);
    const iulFutureValue = iulAnnualContribution * ((Math.pow(1 + iulGrowthRate, yearsToProject) - 1) / iulGrowthRate);
    const advantageAmount = iulFutureValue - emergencyFundFutureValue;
    return { emergencyFundFutureValue, iulFutureValue, advantageAmount };
  }, [emergencyFundBalance, iulAnnualContribution, emergencyFundRate, iulGrowthRate, yearsToProject]);
  const projectionData = useMemo(() => {
    const d = [];
    const startWealth = typeof netWorth !== 'undefined' ? netWorth : 200000;
    const annualSave = typeof annualSavings !== 'undefined' ? annualSavings : 50000;
    let wealth = startWealth, invest = startWealth * 0.6, savings = startWealth * 0.1, debtPaid = 0;
    for (let yr = 0; yr <= 50; yr++) {
      invest = invest * 1.08 + annualSave * 0.7;
      savings = Math.min(annualSave * 2, savings * 1.04 + annualSave * 0.1);
      debtPaid += Math.min(annualSave * 0.2, 30000);
      wealth = invest + savings + debtPaid;
      d.push({ year: yr, totalWealth: Math.round(wealth), investments: Math.round(invest), savings: Math.round(savings), debtPayoff: Math.round(debtPaid) });
    }
    return d;
  }, []);


  return (
    <AppShell
      headerTitle="Emergency Fund vs IUL Cash Value Calculator"
      headerSubtitle="Wealth Building & Savings"
    >
      <div className="p-6 bg-[#0a0f1a] min-h-screen text-white">
        <AutoFillBanner calcRoute="emergency-fund-vs-iul" />
        <div className="max-w-4xl mx-auto">
          <Card className="bg-[#0d1526] mb-6">
            <CardHeader>
              <CardTitle className="flex items-center text-emerald-400">
                <Calculator className="mr-2" /> Input Your Financial Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label>Annual Income</Label>
                  <div className="flex items-center space-x-2">
                    <Input
                      type="number"
                      value={annualIncome}
                      onChange={(e) => setAnnualIncome(Number(e.target.value))}
                      className="bg-slate-700"
                    />
                    <span>{formatDollars(annualIncome)}</span>
                  </div>
                </div>
                <div>
                  <Label>Current Age</Label>
                  <Input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(Number(e.target.value))}
                    className="bg-slate-700"
                  />
                </div>
                <div>
                  <Label>Current Emergency Fund Balance</Label>
                  <div className="flex items-center space-x-2">
                    <Slider
                      min={0}
                      max={50000}
                      step={1000}
                      value={[emergencyFundBalance]}
                      onValueChange={(value) => setEmergencyFundBalance(value[0])}
                    />
                    <Input
                      type="number"
                      value={emergencyFundBalance}
                      onChange={(e) => setEmergencyFundBalance(Number(e.target.value))}
                      className="bg-slate-700 w-32"
                    />
                  </div>
                </div>
                <div>
                  <Label>Annual IUL Contribution</Label>
                  <div className="flex items-center space-x-2">
                    <Slider
                      min={0}
                      max={20000}
                      step={500}
                      value={[iulAnnualContribution]}
                      onValueChange={(value) => setIulAnnualContribution(value[0])}
                    />
                    <Input
                      type="number"
                      value={iulAnnualContribution}
                      onChange={(e) => setIulAnnualContribution(Number(e.target.value))}
                      className="bg-slate-700 w-32"
                    />
                  </div>
                </div>
                <div>
                  <Label>Emergency Fund Interest Rate (%)</Label>
                  <div className="flex items-center space-x-2">
                    <Slider
                      min={0}
                      max={0.05}
                      step={0.001}
                      value={[emergencyFundRate]}
                      onValueChange={(value) => setEmergencyFundRate(value[0])}
                    />
                    <Input
                      type="number"
                      value={emergencyFundRate * 100}
                      onChange={(e) => setEmergencyFundRate(Number(e.target.value) / 100)}
                      className="bg-slate-700 w-32"
                    />
                  </div>
                </div>
                <div>
                  <Label>IUL Growth Rate (%)</Label>
                  <div className="flex items-center space-x-2">
                    <Slider
                      min={0}
                      max={0.10}
                      step={0.001}
                      value={[iulGrowthRate]}
                      onValueChange={(value) => setIulGrowthRate(value[0])}
                    />
                    <Input
                      type="number"
                      value={iulGrowthRate * 100}
                      onChange={(e) => setIulGrowthRate(Number(e.target.value) / 100)}
                      className="bg-slate-700 w-32"
                    />
                  </div>
                </div>
                <div>
                  <Label>Years to Project</Label>
                  <div className="flex items-center space-x-2">
                    <Slider
                      min={1}
                      max={30}
                      step={1}
                      value={[yearsToProject]}
                      onValueChange={(value) => setYearsToProject(value[0])}
                    />
                    <Input
                      type="number"
                      value={yearsToProject}
                      onChange={(e) => setYearsToProject(Number(e.target.value))}
                      className="bg-slate-700 w-32"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        {/* State Tax Impact */}
        <StateTaxSelector income={annualIncome} filingStatus={'single'} className="mb-6" />

          
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "totalWealth", label: "Total Wealth", color: "#10b981" }, { key: "investments", label: "Investment Growth", color: "#06b6d4" }, { key: "savings", label: "Emergency Fund", color: "#f59e0b" }, { key: "debtPayoff", label: "Debt Eliminated", color: "#a855f7" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="text-emerald-400">Projected Emergency Fund</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl">{formatDollars(calculations.emergencyFundFutureValue)}</p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="text-emerald-400">Projected IUL Cash Value</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl">{formatDollars(calculations.iulFutureValue)}</p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="text-emerald-400">IUL Advantage Amount</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl">{formatDollars(calculations.advantageAmount)}</p>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-[#0d1526] mb-6">
            <CardHeader>
              <CardTitle className="flex items-center text-emerald-400">
                <DollarSign className="mr-2" /> IUL Advantage
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p>Indexed Universal Life (IUL) offers tax-free growth, which can significantly outperform a traditional emergency fund. For your inputs, IUL provides an additional benefit of up to {formatDollars(calculations.advantageAmount)} over the projection period, helping you build wealth more efficiently.</p>
            </CardContent>
          </Card>

          <Button
            onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            Send to AI Advisor
          </Button>
        </div>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("emergency-fund-vs-iul", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-emergency-fund-vs-iul");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Emergency Fund vs IUL Cash Value Calculator"
            calculatorRoute="emergency-fund-vs-iul"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="emergency-fund-vs-i-u-l-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/emergency-fund-vs-iul" />
</div>
    </AppShell>
  );
}