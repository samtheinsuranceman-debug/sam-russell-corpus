// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Heart, DollarSign, TrendingUp, Shield, CheckCircle2, ArrowRight, Target, Users, Calendar, Award, Gift, Scale } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, BarChart, Bar, ComposedChart, Line } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

export default function CharitableLeadTrust() {
  // State for user inputs
  const [principalAmount, setPrincipalAmount] = useState(1000000); // Initial principal in USD
  const [annualPayoutRate, setAnnualPayoutRate] = useState(5); // Annual payout rate to charity in %
  const [interestRate, setInterestRate] = useState(2.5); // 7520 rate in %
  const [years, setYears] = useSharedField("projectionYears", 20); // Projection years

  // Memoized calculation for gift tax savings
  const giftTaxSavings = useMemo(() => {
    // Simplified calculation based on IRC 2522: Deductible amount is the present value of the charitable interest
    const charitableInterest = principalAmount * (annualPayoutRate / 100) * years;
    const presentValueFactor = 1 / (1 + (interestRate / 100)) ** years; // Discounted using 7520 rate
    return charitableInterest * presentValueFactor; // Returns estimated deductible amount
  }, [principalAmount, annualPayoutRate, interestRate, years]);

  // Memoized data for 20-year growth projection chart
  const projectionData = useMemo(() => {
    const data = [];
    for (let i = 0; i <= years; i++) {
      const growthFactor = (1 + (interestRate / 100)) ** i;
      data.push({
        year: i,
        projectedValue: principalAmount * growthFactor * (1 - (annualPayoutRate / 100) * i), // Adjusted for payouts
        charitablePayout: principalAmount * (annualPayoutRate / 100) * i,
      });
    }
    return data;
  }, [principalAmount, annualPayoutRate, interestRate, years]);

  // Memoized data for 7520 rate impact analysis (using a simple bar chart dataset)
  const rateImpactData = useMemo(() => [
    { rate: 1.0, savings: giftTaxSavings * 0.8 },
    { rate: 2.5, savings: giftTaxSavings },
    { rate: 4.0, savings: giftTaxSavings * 1.2 },
    { rate: 5.5, savings: giftTaxSavings * 1.5 },
  ], [giftTaxSavings]);

  return (
    <div style={{ backgroundColor: '#1a1a1a', color: '#ffffff', fontFamily: 'Arial, sans-serif', padding: '40px', minHeight: '100vh' }}>
      <header style={{ display: 'flex', alignItems: 'center', marginBottom: '40px' }}>
        <Heart color="#e11d48" size={32} /> {/* Rose accent */}
        <h1 style={{ marginLeft: '10px', fontSize: '28px', color: '#10b981' }}>Charitable Lead Trust (CLT) Modeling</h1> {/* Emerald accent */}
      </header>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ fontSize: '24px', display: 'flex', alignItems: 'center' }}>
          <Gift color="#e11d48" size={24} /> CLT Structure Flow
        </h2>
        <p>
          A Charitable Lead Trust (CLT) is a trust that provides an income stream to a charity for a specified period, after which the remaining assets pass to non-charitable beneficiaries (e.g., heirs). The flow is as follows:
        </p>
        <ul style={{ listStyle: 'none', paddingLeft: 0 }}>
          <li style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
            <ArrowRight color="#10b981" size={18} /> <strong>Step 1:</strong> Donor transfers assets into the CLT.
          </li>
          <li style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
            <ArrowRight color="#10b981" size={18} /> <strong>Step 2:</strong> Trust pays annual income to charity based on the annuity or unitrust rate.
          </li>
          <li style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
            <ArrowRight color="#10b981" size={18} /> <strong>Step 3:</strong> After the term (e.g., 20 years), remainder goes to heirs.
          </li>
          <li style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
            <ArrowRight color="#10b981" size={18} /> <strong>Step 4:</strong> Donor may receive gift tax savings under IRC 2522.
          </li>
        </ul>
        <p style={{ color: '#a1a1aa' }}>This structure allows for immediate tax deductions while eventually passing wealth to family.</p>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ fontSize: '24px', display: 'flex', alignItems: 'center' }}>
          <DollarSign color="#e11d48" size={24} /> Gift Tax Savings Calculation
        </h2>
        <p>
          Use the inputs below to calculate estimated gift tax savings. Based on IRC 2522, the deductible amount is the present value of the charitable lead interest.
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '20px' }}>
          <input
            type="number"
            placeholder="Principal Amount (USD)"
            value={principalAmount}
            onChange={(e) => setPrincipalAmount(Number(e.target.value))}
            style={{ padding: '10px', backgroundColor: '#3f3f3f', color: '#ffffff', border: '1px solid #10b981' }}
          />
          <input
            type="number"
            placeholder="Annual Payout Rate (%)"
            value={annualPayoutRate}
            onChange={(e) => setAnnualPayoutRate(Number(e.target.value))}
            style={{ padding: '10px', backgroundColor: '#3f3f3f', color: '#ffffff', border: '1px solid #10b981' }}
          />
          <input
            type="number"
            placeholder="7520 Rate (%)"
            value={interestRate}
            onChange={(e) => setInterestRate(Number(e.target.value))}
            style={{ padding: '10px', backgroundColor: '#3f3f3f', color: '#ffffff', border: '1px solid #10b981' }}
          />
          <input
            type="number"
            placeholder="Years"
            value={years}
            onChange={(e) => setYears(Number(e.target.value))}
            style={{ padding: '10px', backgroundColor: '#3f3f3f', color: '#ffffff', border: '1px solid #10b981' }}
          />
        </div>
        <p style={{ fontSize: '18px', color: '#10b981' }}>
          Estimated Gift Tax Savings: ${giftTaxSavings.toFixed(2)}
        </p>
        <p style={{ color: '#a1a1aa' }}>This is a simplified estimate; consult a tax professional for exact figures.</p>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ fontSize: '24px', display: 'flex', alignItems: 'center' }}>
          <Scale color="#e11d48" size={24} /> CLT vs CRT Comparison Table
        </h2>
        <div className="overflow-x-auto"><table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '20px' }}>
          <thead>
            <tr style={{ backgroundColor: '#3f3f3f', color: '#ffffff' }}>
              <th style={{ padding: '10px', border: '1px solid #10b981' }}>Feature</th>
              <th style={{ padding: '10px', border: '1px solid #10b981' }}>Charitable Lead Trust (CLT)</th>
              <th style={{ padding: '10px', border: '1px solid #10b981' }}>Charitable Remainder Trust (CRT)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style={{ padding: '10px', border: '1px solid #10b981' }}>Primary Beneficiary</td>
              <td>Charity (during trust term)</td>
              <td>Non-charitable beneficiaries (e.g., donor or heirs)</td>
            </tr>
            <tr style={{ backgroundColor: '#2a2a2a' }}>
              <td style={{ padding: '10px', border: '1px solid #10b981' }}>Remainder Beneficiary</td>
              <td>Heirs or family</td>
              <td>Charity</td>
            </tr>
            <tr>
              <td style={{ padding: '10px', border: '1px solid #10b981' }}>Tax Deduction</td>
              <td>Upfront for charitable interest (IRC 2522)</td>
              <td>Upfront for remainder interest</td>
            </tr>
            <tr style={{ backgroundColor: '#2a2a2a' }}>
              <td style={{ padding: '10px', border: '1px solid #10b981' }}>Income Tax</td>
              <td>Trust may be taxable</td>
              <td>Income tax-free for beneficiaries</td>
            </tr>
            <tr>
              <td style={{ padding: '10px', border: '1px solid #10b981' }}>Form Required</td>
              <td>Form 5227 for annual reporting</td>
              <td>Form 5227</td>
            </tr>
          </tbody>
        </table></div>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ fontSize: '24px', display: 'flex', alignItems: 'center' }}>
          <TrendingUp color="#e11d48" size={24} /> 20-Year Growth Projection
        </h2>
        <p>
          This AreaChart projects the growth of the CLT assets over {years} years, accounting for annual payouts to charity.
        </p>
        <ResponsiveContainer width="100%" height={400}>
          <AreaChart data={projectionData}>
            <XAxis dataKey="year" stroke="#10b981" />
            <YAxis stroke="#10b981" />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="projectedValue" stroke="#e11d48" fill="#e11d48" fillOpacity={0.3} />
            <Area type="monotone" dataKey="charitablePayout" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
          </AreaChart>
        </ResponsiveContainer>
      </section>

      <section style={{ marginBottom: '40px' }}>
        <h2 style={{ fontSize: '24px', display: 'flex', alignItems: 'center' }}>
          <Shield color="#e11d48" size={24} /> 7520 Rate Impact Analysis
        </h2>
        <p>
          The 7520 rate (IRC 7520) is used to discount the value of the charitable interest. Lower rates increase deductions.
        </p>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={rateImpactData}>
            <XAxis dataKey="rate" stroke="#10b981" />
            <YAxis stroke="#10b981" />
            <Tooltip />
            <Legend />
            <Bar dataKey="savings" fill="#e11d48" />
          </BarChart>
        </ResponsiveContainer>
        <p style={{ color: '#a1a1aa' }}>Analysis: At {interestRate}%, savings are optimized; higher rates reduce deductions.</p>
      </section>

      <section>
        <h2 style={{ fontSize: '24px', display: 'flex', alignItems: 'center' }}>
          <CheckCircle2 color="#e11d48" size={24} /> IRS Compliance
        </h2>
        <p>
          CLTs must comply with IRC 2522 for charitable deductions, IRC 7520 for valuation, and require annual filing of Form 5227. Key points:
        </p>
        <ul style={{ listStyle: 'none', paddingLeft: 0 }}>
          <li style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
            <Target color="#10b981" size={18} /> IRC 2522: Allows deduction for the present value of the charitable lead.
          </li>
          <li style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
            <Users color="#10b981" size={18} /> IRC 7520: Mandates using the applicable federal rate for discounting.
          </li>
          <li style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
            <Calendar color="#10b981" size={18} /> Form 5227: Annual split-interest trust information return.
          </li>
          <li style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
            <Award color="#10b981" size={18} /> Ensure the trust is irrevocable and properly documented to avoid disputes.
          </li>
        </ul>
        <p style={{ color: '#a1a1aa' }}>Always consult with a tax advisor to ensure full compliance.</p>
      </section>

      {/* Additional footer for completeness */}
      <footer style={{ marginTop: '40px', textAlign: 'center', color: '#a1a1aa' }}>
        <p>Built with React and Recharts | Dark theme with rose (#e11d48) and emerald (#10b981) accents</p>
      </footer>
      <PageInsights section="charitable-lead-trust" />
    </div>
  );
}
