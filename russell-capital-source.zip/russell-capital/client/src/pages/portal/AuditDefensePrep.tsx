// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { ShieldAlert, DollarSign, TrendingUp, Target, Calendar, Percent, ArrowRight, Shield, CheckCircle2, AlertTriangle, FileText, Search } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, AreaChart, Area } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

export default function AuditDefensePrep() {
  const [income, setIncome] = useSharedField("annualIncome", 0);
  const [deductions, setDeductions] = useState(0);
  const [foreignAccounts, setForeignAccounts] = useState(0);
  const [cashBusiness, setCashBusiness] = useState(false);
  const [returnType, setReturnType] = useState('1040');
  const [filingDate, setFilingDate] = useState('');
  const [penaltyAmount, setPenaltyAmount] = useState(0);
  const [defenseFactors, setDefenseFactors] = useState({ illness: false, naturalDisaster: false });
  const [representationHours, setRepresentationHours] = useState(0);
  const [incomeLevel, setIncomeLevel] = useState(50000);

  const calculateRiskScore = useMemo(() => {
    const difScore = (deductions / income) * 100 + (foreignAccounts * 5) + (cashBusiness ? 20 : 0);
    return difScore > 100 ? 100 : difScore;
  }, [income, deductions, foreignAccounts, cashBusiness]);

  const redFlags = useMemo(() => [
    { flag: 'High Deductions', value: deductions > income * 0.5 },
    { flag: 'Cash Business', value: cashBusiness },
    { flag: 'Foreign Accounts', value: foreignAccounts > 0 },
  ], [deductions, income, cashBusiness, foreignAccounts]);

  const documentationChecklist = useMemo(() => {
    switch (returnType) {
      case '1040':
        return ['W-2 Forms', '1099 Forms', 'Receipts for Deductions', 'Bank Statements'];
      case '1120':
        return ['Balance Sheet', 'Income Statement', 'Corporate Tax Records', 'Audit Reports'];
      default:
        return ['General Receipts', 'Income Proof'];
    }
  }, [returnType]);

  const statuteLimits = useMemo(() => {
    const years = new Date().getFullYear() - new Date(filingDate).getFullYear();
    if (years <= 3) return '3 years';
    if (years <= 6) return '6 years';
    return 'Unlimited (fraud suspected)';
  }, [filingDate]);

  const penaltyAbatementScore = useMemo(() => {
    let score = 0;
    if (defenseFactors.illness) score += 30;
    if (defenseFactors.naturalDisaster) score += 40;
    return score;
  }, [defenseFactors]);

  const representationCost = useMemo(() => representationHours * 200, [representationHours]);

  const auditProbabilityData = useMemo(() => [
    { name: 'Under $50k', probability: 0.02 },
    { name: '$50k-$100k', probability: 0.05 },
    { name: '$100k-$200k', probability: 0.10 },
    { name: 'Over $200k', probability: 0.15 },
  ], []);

  return (
    <div style={{ backgroundColor: '#001f3f', color: '#ffffff', padding: '40px', fontFamily: 'Arial, sans-serif', minHeight: '100vh' }}>
      <h1 style={{ color: '#ff8c00', textAlign: 'center', marginBottom: '40px' }}>IRS Audit Defense Preparation Tool</h1>

      {/* Audit Risk Score Calculator Section */}
      <section style={{ marginBottom: '40px', padding: '20px', backgroundColor: '#1a1a2e', borderRadius: '8px' }}>
        <h2 style={{ color: '#ff8c00' }}><ShieldAlert size={24} /> Audit Risk Score Calculator (DIF Score Factors)</h2>
        <p>Calculate your audit risk based on income, deductions, foreign accounts, and cash business status.</p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '20px' }}>
          <input type="number" placeholder="Annual Income" onChange={(e) => setIncome(parseFloat(e.target.value))} style={{ padding: '10px', backgroundColor: '#2c2c34', color: '#fff', border: '1px solid #ff8c00' }} />
          <input type="number" placeholder="Total Deductions" onChange={(e) => setDeductions(parseFloat(e.target.value))} style={{ padding: '10px', backgroundColor: '#2c2c34', color: '#fff', border: '1px solid #ff8c00' }} />
          <input type="number" placeholder="Number of Foreign Accounts" onChange={(e) => setForeignAccounts(parseFloat(e.target.value))} style={{ padding: '10px', backgroundColor: '#2c2c34', color: '#fff', border: '1px solid #ff8c00' }} />
          <label><input type="checkbox" onChange={(e) => setCashBusiness(e.target.checked)} /> Cash-Based Business</label>
        </div>
        <p style={{ fontSize: '18px', color: '#ff8c00' }}>Your DIF Risk Score: {calculateRiskScore.toFixed(2)}</p>
      </section>

      {/* Red Flag Identifier Section */}
      <section style={{ marginBottom: '40px', padding: '20px', backgroundColor: '#1a1a2e', borderRadius: '8px' }}>
        <h2 style={{ color: '#ff8c00' }}><AlertTriangle size={24} /> Red Flag Identifier</h2>
        <p>Identify potential red flags like high deductions, cash businesses, or foreign accounts.</p>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {redFlags.map((flag, index) => (
            <li key={index} style={{ marginBottom: '10px', color: flag.value ? '#ff4500' : '#a9a9a9' }}>
              {flag.flag}: {flag.value ? 'High Risk' : 'Low Risk'}
            </li>
          ))}
        </ul>
      </section>

      {/* Documentation Checklist Section */}
      <section style={{ marginBottom: '40px', padding: '20px', backgroundColor: '#1a1a2e', borderRadius: '8px' }}>
        <h2 style={{ color: '#ff8c00' }}><FileText size={24} /> Documentation Checklist by Return Type</h2>
        <p>Select your return type and view the required documents.</p>
        <select onChange={(e) => setReturnType(e.target.value)} style={{ padding: '10px', backgroundColor: '#2c2c34', color: '#fff', border: '1px solid #ff8c00', marginBottom: '20px' }}>
          <option value="1040">Form 1040 (Individual)</option>
          <option value="1120">Form 1120 (Corporate)</option>
          <option value="1065">Form 1065 (Partnership)</option>
        </select>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {documentationChecklist.map((item, index) => (
            <li key={index} style={{ marginBottom: '10px' }}><CheckCircle2 size={18} /> {item}</li>
          ))}
        </ul>
      </section>

      {/* Statute of Limitations Tracker Section */}
      <section style={{ marginBottom: '40px', padding: '20px', backgroundColor: '#1a1a2e', borderRadius: '8px' }}>
        <h2 style={{ color: '#ff8c00' }}><Calendar size={24} /> Statute of Limitations Tracker</h2>
        <p>Track based on IRC 6501: 3 years for standard, 6 years for substantial omission, unlimited for fraud.</p>
        <input type="date" onChange={(e) => setFilingDate(e.target.value)} style={{ padding: '10px', backgroundColor: '#2c2c34', color: '#fff', border: '1px solid #ff8c00', marginBottom: '20px' }} />
        <p style={{ fontSize: '18px' }}>Statute Period: {statuteLimits}</p>
        <p>Sections: 6651 (Failure to File), 6662 (Accuracy Penalties), 6664 (Reasonable Cause), 7491 (Burden of Proof)</p>
      </section>

      {/* Penalty Abatement Strategy Guide Section */}
      <section style={{ marginBottom: '40px', padding: '20px', backgroundColor: '#1a1a2e', borderRadius: '8px' }}>
        <h2 style={{ color: '#ff8c00' }}><Percent size={24} /> Penalty Abatement Strategy Guide</h2>
        <p>Strategies for section 6662 accuracy-related penalties using reasonable cause from section 6664.</p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <label><input type="checkbox" onChange={(e) => setDefenseFactors({ ...defenseFactors, illness: !defenseFactors.illness })} /> Illness or Disability</label>
          <label><input type="checkbox" onChange={(e) => setDefenseFactors({ ...defenseFactors, naturalDisaster: !defenseFactors.naturalDisaster })} /> Natural Disaster</label>
        </div>
        <p>Abatement Score: {penaltyAbatementScore}%</p>
      </section>

      {/* Reasonable Cause Defense Builder Section */}
      <section style={{ marginBottom: '40px', padding: '20px', backgroundColor: '#1a1a2e', borderRadius: '8px' }}>
        <h2 style={{ color: '#ff8c00' }}><Shield size={24} /> Reasonable Cause Defense Builder</h2>
        <p>Build defenses based on IRC sections for reasonable cause.</p>
        <p>Possible Defenses: {Object.entries(defenseFactors).filter(([key, value]) => value).join(', ')}</p>
      </section>

      {/* Audit Representation Cost Estimator Section */}
      <section style={{ marginBottom: '40px', padding: '20px', backgroundColor: '#1a1a2e', borderRadius: '8px' }}>
        <h2 style={{ color: '#ff8c00' }}><DollarSign size={24} /> Audit Representation Cost Estimator</h2>
        <p>Estimate costs based on hours needed.</p>
        <input type="number" placeholder="Estimated Hours" onChange={(e) => setRepresentationHours(parseFloat(e.target.value))} style={{ padding: '10px', backgroundColor: '#2c2c34', color: '#fff', border: '1px solid #ff8c00', marginBottom: '20px' }} />
        <p>Estimated Cost: ${representationCost}</p>
      </section>

      {/* 50-Year Audit Probability by Income Level Section */}
      <section style={{ marginBottom: '40px', padding: '20px', backgroundColor: '#1a1a2e', borderRadius: '8px' }}>
        <h2 style={{ color: '#ff8c00' }}><TrendingUp size={24} /> 50-Year Audit Probability by Income Level</h2>
        <p>Visualize audit probabilities based on income levels.</p>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={auditProbabilityData}>
            <XAxis dataKey="name" stroke="#ff8c00" />
            <YAxis stroke="#ff8c00" />
            <Tooltip />
            <Legend />
            <Bar dataKey="probability" fill="#ff8c00" />
          </BarChart>
        </ResponsiveContainer>
      </section>

      {/* Compliance Information Section */}
      <section style={{ padding: '20px', backgroundColor: '#1a1a2e', borderRadius: '8px' }}>
        <h2 style={{ color: '#ff8c00' }}><Target size={24} /> Compliance Overview</h2>
        <p>Key IRC Sections:</p>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          <li><ArrowRight size={18} /> IRC 6501: Statute of Limitations (3/6 years/unlimited)</li>
          <li><ArrowRight size={18} /> Section 6651: Failure to File Penalties</li>
          <li><ArrowRight size={18} /> Section 6662: Accuracy-Related Penalties</li>
          <li><ArrowRight size={18} /> Section 6664: Reasonable Cause Exceptions</li>
          <li><ArrowRight size={18} /> Section 7491: Burden of Proof in Audits</li>
        </ul>
        <ResponsiveContainer width="100%" height={300}>
          <RadarChart data={[{ subject: 'Risk', A: calculateRiskScore, fullMark: 100 }]}>
            <PolarGrid stroke="#ff8c00" />
            <PolarAngleAxis dataKey="subject" stroke="#ff8c00" />
            <PolarRadiusAxis angle={90} domain={[0, 100]} stroke="#ff8c00" />
            <Radar name="Risk" dataKey="A" stroke="#ff8c00" fill="#ff8c00" fillOpacity={0.6} />
            <Legend />
            <Tooltip />
          </RadarChart>
        </ResponsiveContainer>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={auditProbabilityData}>
            <Area type="monotone" dataKey="probability" stroke="#ff8c00" fill="#ff4500" />
            <XAxis dataKey="name" stroke="#ff8c00" />
            <YAxis stroke="#ff8c00" />
            <Tooltip />
          </AreaChart>
        </ResponsiveContainer>
      </section>
      <PageInsights section="audit-defense-prep" />
    </div>
  );
}
