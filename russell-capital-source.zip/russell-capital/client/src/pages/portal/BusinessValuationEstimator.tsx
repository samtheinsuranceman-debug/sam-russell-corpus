// @ts-nocheck
import React, { useState } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Activity, Briefcase, Building2, Calculator, DollarSign, LineChartIcon, PieChartIcon, Sliders, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';
import { PageInsights } from '@/components/PageInsights';

const BusinessValuationEstimator: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dcf');
  const [revenue, setRevenue] = useState(5000000);
  const [growthRate, setGrowthRate] = useSharedField("growthRate", 5);
  const [discountRate, setDiscountRate] = useState(10);
  const [dlom, setDlom] = useState(20);
  const [minorityDiscount, setMinorityDiscount] = useState(15);
  const [keyPersonDiscount, setKeyPersonDiscount] = useState(10);
  const [controlPremium, setControlPremium] = useState(25);
  const [projectionYears, setProjectionYears] = useSharedField("projectionYears", 5);

  const sampleData = Array.from({ length: 10 }, (_, i) => ({
    year: 2023 + i,
    revenue: (revenue * Math.pow(1 + growthRate / 100, i)).toFixed(0),
    ebitda: (revenue * 0.2 * Math.pow(1 + growthRate / 100, i)).toFixed(0),
  }));

  const valuationMethods = [
    { id: 'dcf', name: 'Discounted Cash Flow (DCF)', icon: <LineChartIcon className="w-5 h-5 text-emerald-400" /> },
    { id: 'comps', name: 'Comparable Transactions', icon: <Building2 className="w-5 h-5 text-emerald-400" /> },
    { id: 'assets', name: 'Asset-Based', icon: <Briefcase className="w-5 h-5 text-emerald-400" /> },
    { id: 'earnings', name: 'Capitalization of Earnings', icon: <DollarSign className="w-5 h-5 text-emerald-400" /> },
  ];

  const calculateValuation = () => {
    const baseValue = revenue * 5;
    const dlomAdj = baseValue * (dlom / 100);
    const minorityAdj = baseValue * (minorityDiscount / 100);
    const keyPersonAdj = baseValue * (keyPersonDiscount / 100);
    const controlAdj = baseValue * (controlPremium / 100);
    const finalValue = baseValue - dlomAdj - minorityAdj - keyPersonAdj + controlAdj;
    return finalValue.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
  };

  const handleGenerateOutcome = () => {
    toast.success('Valuation Calculated', {
      description: `Estimated Business Value: ${calculateValuation()}`,
      className: 'bg-[#0d1526] text-white border-[#1e3a5f]',
    });
  };

  const pieData = [
    { name: 'Revenue', value: 60 },
    { name: 'EBITDA', value: 20 },
    { name: 'Assets', value: 20 },
  ];

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <Calculator className="w-7 h-7 text-emerald-400" />
          Business Valuation Estimator
        </h1>
        <p className="text-[#7a95b8] mb-6">
          Estimate your business value using multiple methods including DCF, comparable transactions, and asset-based approaches. Adjust for IRS §2031 (fair market value for estate tax) and §409A (stock options).
        </p>

        {/* Tabs */}
        <div className="flex flex-wrap gap-2 mb-6 border-b border-[#1e3a5f]">
          {valuationMethods.map((method) => (
            <button
              key={method.id}
              onClick={() => setActiveTab(method.id)}
              className={`px-4 py-2 rounded-t-md font-medium flex items-center gap-2 border-b-2 ${
                activeTab === method.id ? 'border-emerald-500 text-emerald-400' : 'border-transparent text-[#7a95b8]'
              }`}
            >
              {method.icon}
              {method.name}
            </button>
          ))}
        </div>

        {/* Input Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
          <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f]">
            <label className="block text-[#7a95b8] mb-2">Annual Revenue ($)</label>
            <input
              type="number"
              value={revenue}
              onChange={(e) => setRevenue(Number(e.target.value))}
              className="w-full p-2 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
          <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f]">
            <label className="block text-[#7a95b8] mb-2">Growth Rate (%)</label>
            <input
              type="number"
              value={growthRate}
              onChange={(e) => setGrowthRate(Number(e.target.value))}
              className="w-full p-2 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
          <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f]">
            <label className="block text-[#7a95b8] mb-2">Discount Rate (%)</label>
            <input
              type="number"
              value={discountRate}
              onChange={(e) => setDiscountRate(Number(e.target.value))}
              className="w-full p-2 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
          <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f]">
            <label className="block text-[#7a95b8] mb-2">DLOM (%)</label>
            <input
              type="number"
              value={dlom}
              onChange={(e) => setDlom(Number(e.target.value))}
              className="w-full p-2 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
          <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f]">
            <label className="block text-[#7a95b8] mb-2">Minority Interest Discount (%)</label>
            <input
              type="number"
              value={minorityDiscount}
              onChange={(e) => setMinorityDiscount(Number(e.target.value))}
              className="w-full p-2 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
          <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f]">
            <label className="block text-[#7a95b8] mb-2">Projection Years (1-50)</label>
            <input
              type="number"
              min={1}
              max={50}
              value={projectionYears}
              onChange={(e) => setProjectionYears(Math.min(50, Math.max(1, Number(e.target.value))))}
              className="w-full p-2 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>

        {/* Discounts & Premiums */}
        <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f] mb-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Sliders className="w-5 h-5 text-emerald-400" />
            Adjustments
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-[#7a95b8] mb-2">Key Person Discount (%)</label>
              <input
                type="number"
                value={keyPersonDiscount}
                onChange={(e) => setKeyPersonDiscount(Number(e.target.value))}
                className="w-full p-2 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block text-[#7a95b8] mb-2">Control Premium (%)</label>
              <input
                type="number"
                value={controlPremium}
                onChange={(e) => setControlPremium(Number(e.target.value))}
                className="w-full p-2 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f]">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              Revenue Projection
            </h2>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={sampleData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                  <XAxis dataKey="year" stroke="#7a95b8" />
                  <YAxis stroke="#7a95b8" />
                  <Tooltip contentStyle={{ backgroundColor: '#0d1526', border: '1px solid #1e3a5f', color: 'white' }} />
                  <Area type="monotone" dataKey="revenue" stroke="#34d399" fill="#34d39922" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f]">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <PieChartIcon className="w-5 h-5 text-emerald-400" />
              Value Composition
            </h2>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={sampleData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                  <XAxis dataKey="year" stroke="#7a95b8" />
                  <YAxis stroke="#7a95b8" />
                  <Tooltip contentStyle={{ backgroundColor: '#0d1526', border: '1px solid #1e3a5f', color: 'white' }} />
                  <Bar dataKey="ebitda" fill="#34d399" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Generate Outcome */}
        <div className="bg-[#0d1526] p-6 rounded-lg border border-[#1e3a5f] flex flex-col items-center">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Activity className="w-5 h-5 text-emerald-400" />
            Generate Valuation Outcome
          </h2>
          <button
            onClick={handleGenerateOutcome}
            className="px-6 py-2 bg-emerald-500 hover:bg-emerald-400 text-white rounded-md font-medium transition-colors"
          >
            Calculate Value
          </button>
        </div>

        <PageInsights section="business-valuation-estimator" />
      </div>
    </div>
  );
};

export default BusinessValuationEstimator;