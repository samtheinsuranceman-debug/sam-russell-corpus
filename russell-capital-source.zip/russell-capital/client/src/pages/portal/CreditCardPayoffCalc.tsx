// @ts-nocheck
import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { CreditCard, DollarSign, Clock, TrendingUp } from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function CreditCardPayoffCalc() {
  const autoFill = useCalculatorAutoFill("credit-card-payoff");
  const { reportResult } = useCalcResults();
  const [balance, setBalance] = useState(5000);
  const [annualInterestRate, setAnnualInterestRate] = useState(18);
  const [monthlyPayment, setMonthlyPayment] = useState(200);
  const [income, setIncome] = useSharedField("annualIncome", 50000);
  const [age, setAge] = useSharedField("currentAge", 30);

  const calculations = useMemo(() => {
    let currentBalance = balance;
    let monthlyRate = annualInterestRate / 12 / 100;
    let months = 0;
    let totalInterest = 0;
    let totalPaid = 0;

    while (currentBalance > 0 && months < 1000) {  // Safety limit to prevent infinite loop
      let interest = currentBalance * monthlyRate;
      let principal = monthlyPayment - interest;
      if (principal > currentBalance) principal = currentBalance;
      currentBalance -= principal;
      totalInterest += interest;
      totalPaid += monthlyPayment;
      months++;
    }

    return {
      monthsToPayoff: months,
      totalInterestPaid: totalInterest,
      totalAmountPaid: totalPaid,
    };
  }, [balance, annualInterestRate, monthlyPayment]);
  const projectionData = useMemo(() => {
    const d = [];
    const income = typeof annualIncome !== 'undefined' ? annualIncome : 300000;
    const saveRate = 0.20;
    let nw = 0, cumSave = 0, debtElim = 0, emFund = 0;
    for (let yr = 0; yr <= 50; yr++) {
      const annualSave = income * saveRate * Math.pow(1.03, yr);
      cumSave += annualSave;
      debtElim += Math.min(annualSave * 0.3, 25000 * Math.max(0, 1 - yr / 15));
      emFund = Math.min(income * 0.5, emFund + annualSave * 0.1);
      nw = cumSave * 1.06 + debtElim;
      d.push({ year: yr, netWorth: Math.round(nw), cumulativeSavings: Math.round(cumSave), debtReduction: Math.round(debtElim), emergencyFund: Math.round(emFund) });
    }
    return d;
  }, []);


  return (
    <AppShell
      className="bg-[#0a0f1a] text-white min-h-screen"
      headerTitle="Credit Card Payoff Calculator"
      headerSubtitle="Budgeting & Cash Flow"
    >
      <div className="p-6 space-y-8">
        <AutoFillBanner calcRoute="credit-card-payoff" />
        {/* Input Section */}
        <Card className="bg-[#0d1526] border-[#1e3a5f]">
          <CardHeader>
            <CardTitle className="text-emerald-400 flex items-center">
              <CreditCard className="mr-2" /> Enter Your Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label>Current Balance</Label>
              <div className="flex items-center space-x-4">
                <Input
                  type="number"
                  value={balance}
                  onChange={(e) => setBalance(Number(e.target.value))}
                  className="bg-slate-700 border-[#1e3a5f]"
                />
                <Slider
                  min={0}
                  max={20000}
                  step={100}
                  value={[balance]}
                  onValueChange={(value) => setBalance(value[0])}
                />
              </div>
            </div>
            <div>
              <Label>Annual Interest Rate (%)</Label>
              <div className="flex items-center space-x-4">
                <Input
                  type="number"
                  value={annualInterestRate}
                  onChange={(e) => setAnnualInterestRate(Number(e.target.value))}
                  className="bg-slate-700 border-[#1e3a5f]"
                />
                <Slider
                  min={0}
                  max={30}
                  step={1}
                  value={[annualInterestRate]}
                  onValueChange={(value) => setAnnualInterestRate(value[0])}
                />
              </div>
            </div>
            <div>
              <Label>Monthly Payment</Label>
              <div className="flex items-center space-x-4">
                <Input
                  type="number"
                  value={monthlyPayment}
                  onChange={(e) => setMonthlyPayment(Number(e.target.value))}
                  className="bg-slate-700 border-[#1e3a5f]"
                />
                <Slider
                  min={0}
                  max={1000}
                  step={10}
                  value={[monthlyPayment]}
                  onValueChange={(value) => setMonthlyPayment(value[0])}
                />
              </div>
            </div>
            <div>
              <Label>Annual Income</Label>
              <Input
                type="number"
                value={income}
                onChange={(e) => setIncome(Number(e.target.value))}
                className="bg-slate-700 border-[#1e3a5f]"
              />
            </div>
            <div>
              <Label>Age</Label>
              <Input
                type="number"
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="bg-slate-700 border-[#1e3a5f]"
              />
            </div>
          </CardContent>
        </Card>

        {/* Results Section */}
        {/* State Tax Impact */}
        <StateTaxSelector income={income} filingStatus={'single'} className="mb-6" />
        
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "netWorth", label: "Net Worth", color: "#10b981" }, { key: "cumulativeSavings", label: "Cumulative Savings", color: "#06b6d4" }, { key: "debtReduction", label: "Debt Eliminated", color: "#f59e0b" }, { key: "emergencyFund", label: "Emergency Fund", color: "#a855f7" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader className="flex flex-row items-center space-x-2">
              <Clock className="text-emerald-400" />
              <CardTitle>Months to Payoff</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{calculations.monthsToPayoff} months</p>
            </CardContent>
          </Card>
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader className="flex flex-row items-center space-x-2">
              <DollarSign className="text-emerald-400" />
              <CardTitle>Total Interest Paid</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{formatDollars(calculations.totalInterestPaid)}</p>
            </CardContent>
          </Card>
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader className="flex flex-row items-center space-x-2">
              <DollarSign className="text-emerald-400" />
              <CardTitle>Total Amount Paid</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{formatDollars(calculations.totalAmountPaid)}</p>
            </CardContent>
          </Card>
        </div>

        {/* IUL Advantage Section */}
        <Card className="bg-[#0d1526] border-[#1e3a5f]">
          <CardHeader>
            <CardTitle className="text-emerald-400 flex items-center">
              <TrendingUp className="mr-2" /> IUL Advantage
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>
              With Indexed Universal Life (IUL) insurance, your income of {formatDollars(income)} at age {age} years can grow tax-free, potentially providing funds to accelerate credit card payoff and reduce interest costs.
            </p>
          </CardContent>
        </Card>

        {/* Send to AI Advisor Button */}
        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-500 hover:bg-emerald-600"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("credit-card-payoff", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-credit-card-payoff");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Credit Card Payoff Calculator"
            calculatorRoute="credit-card-payoff"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="credit-card-payoff-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/credit-card-payoff" />
</div>
    </AppShell>
  );
}