// @ts-nocheck
import React, { useState, useEffect, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from '@/components/AppShell';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { trpc } from "@/lib/trpc";
import { CalculatorPDFExport } from "@/components/CalculatorPDFExport";
import { Loader2, TrendingUp, Shield, AlertTriangle, CheckCircle } from 'lucide-react';
import { useReportToHub } from "@/contexts/UnifiedDataBusContext";
import { PageInsights } from "@/components/PageInsights";

const fmt = (v: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(v);
const pct = (v: number) => `${v.toFixed(1)}%`;

export default function CarrierStrengthMonitor() {
  const _reportToHub = useReportToHub("si-carrier-strength", "Carrier Strength Monitor", "si-engine", "/portal/carrier-strength");
  const [showResults, setShowResults] = useState(false);
  const [projectionYears, setProjectionYears] = useSharedField("projectionYears", 30);


  const serverQuery = trpc.si.carrierStrength.useQuery({ carrierNames: [] }, { enabled: false });

  const results = useMemo(() => {
    if (!showResults) return null;
    // Local calculation fallback
    return {
      carriers_monitored: "Calculating...", average_rating: "Calculating...", downgrade_alerts: "Calculating...", portfolio_risk_score: "Calculating...",
      projectionData: Array.from({ length: projectionYears }, (_, i) => ({
        year: i + 1,
        value: Math.round(100000 * Math.pow(1.065, i + 1)),
        baseline: Math.round(100000 * Math.pow(1.03, i + 1)),
      })),
    };
  }, [showResults, projectionYears, ]);
  useEffect(() => {
    if (results) _reportToHub({ computed: true, timestamp: Date.now(), ...Object.fromEntries(Object.entries(results).filter(([_, v]) => typeof v === 'number' || typeof v === 'string' || typeof v === 'boolean').slice(0, 10)) });
  }, [results, _reportToHub]);

  const handleCalculate = async () => {
    setShowResults(true);
    toast.success("Analysis complete — scroll down for results");
  };

  return (
    <AppShell title="Carrier Financial Strength Monitoring" subtitle="Real-time carrier ratings with trend analysis and risk alerts">
      <div className="space-y-6 max-w-6xl mx-auto">
        {/* Input Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-emerald-500" />
              Analysis Parameters
            </CardTitle>
            <CardDescription>Configure your inputs below and click Analyze to generate results</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <Label className="text-sm font-medium text-muted-foreground">Projection Years: {projectionYears}</Label>
                <input type="range" min="5" max="50" value={projectionYears} onChange={(e) => setProjectionYears(Number(e.target.value))} className="w-full mt-1 accent-emerald-500" />
              </div>

            </div>
            <div className="mt-6 flex gap-3">
              <Button onClick={handleCalculate} className="bg-emerald-600 hover:bg-emerald-700">
                <TrendingUp className="h-4 w-4 mr-2" /> Run Analysis
              </Button>
              <CalculatorPDFExport
                calculatorName="Carrier Strength Monitor"
                calculatorRoute="/portal/carrier-strength-monitor"
                inputs={{ projectionYears,  }}
                results={results as any ?? {}}
                projectionData={results?.projectionData}
              />
            </div>
          </CardContent>
        </Card>

        {/* Results Section */}
        {showResults && results && (
          <>
            {/* Key Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">

          <Card className="bg-emerald-500/10 border-emerald-500/20">
            <CardContent className="p-4 text-center">
              <p className="text-xs text-muted-foreground">Carriers Monitored</p>
              <p className="text-2xl font-bold text-emerald-400">{results?.carriers_monitored ?? "—"}</p>
            </CardContent>
          </Card>
          <Card className="bg-blue-500/10 border-blue-500/20">
            <CardContent className="p-4 text-center">
              <p className="text-xs text-muted-foreground">Average Rating</p>
              <p className="text-2xl font-bold text-blue-400">{results?.average_rating ?? "—"}</p>
            </CardContent>
          </Card>
          <Card className="bg-amber-500/10 border-amber-500/20">
            <CardContent className="p-4 text-center">
              <p className="text-xs text-muted-foreground">Downgrade Alerts</p>
              <p className="text-2xl font-bold text-amber-400">{results?.downgrade_alerts ?? "—"}</p>
            </CardContent>
          </Card>
          <Card className="bg-purple-500/10 border-purple-500/20">
            <CardContent className="p-4 text-center">
              <p className="text-xs text-muted-foreground">Portfolio Risk Score</p>
              <p className="text-2xl font-bold text-purple-400">{results?.portfolio_risk_score ?? "—"}</p>
            </CardContent>
          </Card>
      <PageInsights section="carrier-strength-monitor" />
            </div>

            {/* Projection Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Carrier Financial Strength Monitoring — {projectionYears}-Year Projection</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-end gap-1">
                  {results.projectionData.slice(0, Math.min(projectionYears, 50)).map((d: any, i: number) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <div
                        className="w-full bg-emerald-500/80 rounded-t"
                        style={{ height: `${Math.min((d.value / (results.projectionData[projectionYears - 1]?.value || 1)) * 200, 200)}px` }}
                        title={`Year ${d.year}: ${fmt(d.value)}`}
                      />
                      {i % 5 === 0 && <span className="text-[10px] text-muted-foreground">{d.year}</span>}
                    </div>
                  ))}
                </div>
                <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                  <span>Year 1</span>
                  <span className="text-emerald-400 font-medium">Optimized Strategy</span>
                  <span>Year {projectionYears}</span>
                </div>
              </CardContent>
            </Card>

            {/* Detailed Results Table */}
            <Card>
              <CardHeader>
                <CardTitle>Year-by-Year Projection</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-2 px-3">Year</th>
                        <th className="text-right py-2 px-3">Optimized Value</th>
                        <th className="text-right py-2 px-3">Baseline</th>
                        <th className="text-right py-2 px-3">Advantage</th>
                      </tr>
                    </thead>
                    <tbody>
                      {results.projectionData.filter((_: any, i: number) => i % 5 === 4 || i === 0).map((d: any) => (
                        <tr key={d.year} className="border-b border-border/50 hover:bg-muted/30">
                          <td className="py-2 px-3">{d.year}</td>
                          <td className="text-right py-2 px-3 text-emerald-400 font-medium">{fmt(d.value)}</td>
                          <td className="text-right py-2 px-3 text-muted-foreground">{fmt(d.baseline)}</td>
                          <td className="text-right py-2 px-3 text-blue-400">{fmt(d.value - d.baseline)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </AppShell>
  );
}
