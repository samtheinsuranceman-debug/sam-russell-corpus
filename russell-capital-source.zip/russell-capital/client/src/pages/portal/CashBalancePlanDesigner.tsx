// @ts-nocheck
import React, { useState } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Activity, Briefcase, Calculator, DollarSign, Info, Layers, PieChartIcon, TrendingUp, Wallet } from 'lucide-react';
import { toast } from 'sonner';
import { PageInsights } from '@/components/PageInsights';

const CashBalancePlanDesigner: React.FC = () => {
  const [activeTab, setActiveTab] = useState('calculator');
  const [age, setAge] = useSharedField("currentAge", 50);
  const [compensation, setCompensation] = useState(300000);
  const [contributionRate, setContributionRate] = useState(6);
  const [projectionYears, setProjectionYears] = useSharedField("projectionYears", 20);
  const [include401k, setInclude401k] = useState(true);

  // Sample data for charts (50-year projection capability)
  const projectionData = Array.from({ length: 50 }, (_, i) => ({
    year: 2024 + i,
    balance: Math.round(100000 * Math.pow(1.05, i)),
    contribution: Math.round(50000 * Math.pow(1.02, i)),
  }));

  const contributionBreakdown = [
    { name: 'Cash Balance', value: 200000 },
    { name: '401(k)', value: 66000 },
    { name: 'Profit Sharing', value: 30000 },
  ];

  const calculateMaxContribution = () => {
    const compLimit = 345000; // §401(a)(17) compensation limit for 2024
    const maxCredit = age >= 60 ? 265000 : age >= 50 ? 200000 : 150000; // §415(b) limit approximation
    const creditedAmount = Math.min(compensation, compLimit) * (contributionRate / 100);
    return Math.min(creditedAmount, maxCredit);
  };

  const handleGenerateOutcome = () => {
    const maxContrib = calculateMaxContribution();
    toast.success(`Projected Contribution: $${maxContrib.toLocaleString()}`, {
      description: 'Based on IRS limits and actuarial factors.',
    });
  };

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <Briefcase className="w-8 h-8 text-emerald-400" />
          <h1 className="text-3xl font-bold">Cash Balance Plan Designer</h1>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-1 border-b border-[#1e3a5f] mb-8">
          {['calculator', 'projection', 'breakdown'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-3 capitalize ${
                activeTab === tab
                  ? 'text-emerald-400 border-b-2 border-emerald-400'
                  : 'text-[#7a95b8] hover:text-white'
              }`}
            >
              {tab === 'calculator' && <Calculator className="inline w-5 h-5 mr-2" />}
              {tab === 'projection' && <TrendingUp className="inline w-5 h-5 mr-2" />}
              {tab === 'breakdown' && <Layers className="inline w-5 h-5 mr-2" />}
              {tab}
            </button>
          ))}
        </div>

        {/* Content based on active tab */}
        <div className="bg-[#0d1526] p-6 rounded-lg border border-[#1e3a5f]">
          {activeTab === 'calculator' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-semibold flex items-center gap-2">
                <Wallet className="w-6 h-6 text-emerald-400" />
                Contribution Calculator
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-[#7a95b8] mb-2">Age</label>
                  <input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(Math.max(20, parseInt(e.target.value) || 20))}
                    className="w-full p-3 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white"
                  />
                </div>
                <div>
                  <label className="block text-[#7a95b8] mb-2">Annual Compensation</label>
                  <input
                    type="number"
                    value={compensation}
                    onChange={(e) => setCompensation(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full p-3 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white"
                  />
                </div>
                <div>
                  <label className="block text-[#7a95b8] mb-2">Contribution Rate (%)</label>
                  <input
                    type="number"
                    value={contributionRate}
                    onChange={(e) => setContributionRate(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-full p-3 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white"
                  />
                </div>
              </div>
              <div className="flex items-center gap-4">
                <input
                  type="checkbox"
                  checked={include401k}
                  onChange={() => setInclude401k(!include401k)}
                  className="w-5 h-5 accent-emerald-500"
                />
                <label className="text-[#7a95b8]">Integrate with 401(k) Profit Sharing</label>
              </div>
              <div className="flex items-center gap-2 text-[#7a95b8] text-sm">
                <Info className="w-4 h-4" />
                <span>Subject to §415(b) benefit limits and §401(a)(17) compensation limits.</span>
              </div>
              <button
                onClick={handleGenerateOutcome}
                className="px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-white rounded-md font-medium"
              >
                Generate Outcome
              </button>
            </div>
          )}

          {activeTab === 'projection' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-semibold flex items-center gap-2">
                <DollarSign className="w-6 h-6 text-emerald-400" />
                Balance Projection (50-Year Capability)
              </h2>
              <div className="mb-4">
                <label className="block text-[#7a95b8] mb-2">Projection Years (1-50)</label>
                <input
                  type="number"
                  value={projectionYears}
                  onChange={(e) => setProjectionYears(Math.min(50, Math.max(1, parseInt(e.target.value) || 1)))}
                  className="w-32 p-3 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white"
                />
              </div>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={projectionData.slice(0, projectionYears)}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                    <XAxis dataKey="year" stroke="#7a95b8" />
                    <YAxis stroke="#7a95b8" tickFormatter={(v) => `$${v.toLocaleString()}`} />
                    <Tooltip formatter={(v) => `$${v.toLocaleString()}`} contentStyle={{ backgroundColor: '#0d1526', borderColor: '#1e3a5f' }} />
                    <Area type="monotone" dataKey="balance" stroke="#10b981" fill="#10b98133" name="Plan Balance" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {activeTab === 'breakdown' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-semibold flex items-center gap-2">
                <PieChartIcon className="w-6 h-6 text-emerald-400" />
                Contribution Breakdown
              </h2>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={contributionBreakdown}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                    <XAxis dataKey="name" stroke="#7a95b8" />
                    <YAxis stroke="#7a95b8" tickFormatter={(v) => `$${v.toLocaleString()}`} />
                    <Tooltip formatter={(v) => `$${v.toLocaleString()}`} contentStyle={{ backgroundColor: '#0d1526', borderColor: '#1e3a5f' }} />
                    <Bar dataKey="value" fill="#10b981" name="Contribution" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="text-[#7a95b8] text-sm">
                <p>Includes PBGC premium calculations and IRS funding requirements.</p>
                <p>Plan termination strategies and lump sum conversions available upon request.</p>
              </div>
            </div>
          )}
        </div>

        {/* Additional Info */}
        <div className="mt-8 p-4 bg-[#0d1526] border border-[#1e3a5f] rounded-lg text-[#7a95b8] text-sm flex items-start gap-2">
          <Activity className="w-5 h-5 text-emerald-400" />
          <div>
            <p>Age-weighted contribution analysis and actuarial equivalence factors applied.</p>
            <p>Consult IRS guidelines for full compliance details.</p>
          </div>
        </div>

        <PageInsights section="cash-balance-plan-designer" />
      </div>
    </div>
  );
};

export default CashBalancePlanDesigner;