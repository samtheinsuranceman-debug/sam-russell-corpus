// @ts-nocheck

import React, { useState } from 'react';
import { User, Briefcase, Home, DollarSign, Shield, TrendingUp, CheckCircle2, ArrowRight, ArrowLeft, Target, Heart, FileText, Zap } from 'lucide-react';
import { PageInsights } from "@/components/PageInsights";

interface FormData {
  name: string;
  age: number;
  spouse: boolean;
  childrenCount: number;
  occupation: string;
  stateOfResidence: string;
  riskTolerance: number; // 0 to 100
  annualIncome: number;
  businessIncome: number;
  investmentIncome: number;
  rentalIncome: number;
  totalNetWorth: number;
  liquidAssets: number;
  homeValue: number;
  mortgageBalance: number;
  lifeInsurance: number;
  disabilityInsurance: boolean;
  umbrellaPolicy: number;
  longTermCare: boolean;
  estatePlan: boolean;
  estateTrustType: string;
  goals: Array<{ goal: string; rank: number }>; // e.g., [{ goal: 'Tax Reduction', rank: 1 }]
}

const ClientOnboardingWizard: React.FC = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<FormData>({
    name: '',
    age: 0,
    spouse: false,
    childrenCount: 0,
    occupation: '',
    stateOfResidence: '',
    riskTolerance: 50, // Default to medium
    annualIncome: 0,
    businessIncome: 0,
    investmentIncome: 0,
    rentalIncome: 0,
    totalNetWorth: 0,
    liquidAssets: 0,
    homeValue: 0,
    mortgageBalance: 0,
    lifeInsurance: 0,
    disabilityInsurance: false,
    umbrellaPolicy: 0,
    longTermCare: false,
    estatePlan: false,
    estateTrustType: '',
    goals: [],
  });
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMessages, setLoadingMessages] = useState([
    "Analyzing tax bracket optimization...",
    "Calculating retirement income gap...",
    "Evaluating insurance coverage...",
    "Matching strategies to profile...",
    "Generating personalized recommendations...",
  ]);
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);

  const occupations = ['Physician', 'Attorney', 'Business Owner', 'Executive', 'Other'];
  const states = ['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'];

  const goalsList = [
    { name: 'Tax Reduction', icon: <Zap className="text-emerald-500" size={24} /> },
    { name: 'Retirement Income', icon: <TrendingUp className="text-emerald-500" size={24} /> },
    { name: 'Estate Transfer', icon: <Heart className="text-emerald-500" size={24} /> },
    { name: 'Asset Protection', icon: <Shield className="text-emerald-500" size={24} /> },
    { name: 'Wealth Growth', icon: <Target className="text-emerald-500" size={24} /> },
  ];

  const recommendedStrategies = [
    { name: 'Roth IRA Conversion', fitScore: 95 },
    { name: 'High-Yield Savings', fitScore: 88 },
    { name: 'Estate Planning Trust', fitScore: 92 },
    { name: 'Diversified Investments', fitScore: 90 },
    { name: 'Tax-Loss Harvesting', fitScore: 85 },
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value,
    }));
  };

  const handleNumberInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: parseFloat(value) || 0,
    }));
  };

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, riskTolerance: parseInt(e.target.value, 10) }));
  };

  const handleGoalRankChange = (goal: string, rank: number) => {
    setFormData(prev => ({
      ...prev,
      goals: prev.goals.filter(g => g.goal !== goal).concat({ goal, rank }),
    }));
  };

  const startAnalysis = () => {
    setIsLoading(true);
    setCurrentMessageIndex(0);
    const interval = setInterval(() => {
      setCurrentMessageIndex(prev => (prev + 1) % loadingMessages.length);
    }, 2000);  // Change message every 2 seconds
    setTimeout(() => {
      setIsLoading(false);
      clearInterval(interval);
      setStep(6);  // Move to results
    }, 10000);  // Total loading time 10 seconds
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-emerald-500">Step 1: Personal Info</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input type="text" name="name" placeholder="Name" onChange={handleInputChange} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded" />
              <input type="number" name="age" placeholder="Age" onChange={handleNumberInputChange} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded" />
              <select name="occupation" onChange={handleInputChange} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded">
                <option value="">Occupation</option>
                {occupations.map(occ => <option key={occ} value={occ}>{occ}</option>)}
              </select>
              <select name="stateOfResidence" onChange={handleInputChange} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded">
                <option value="">State of Residence</option>
                {states.map(state => <option key={state} value={state}>{state}</option>)}
              </select>
              <label className="flex items-center">
                <input type="checkbox" name="spouse" onChange={handleInputChange} className="mr-2" />
                Spouse (Yes/No)
              </label>
              <input type="number" name="childrenCount" placeholder="Number of Children" onChange={handleNumberInputChange} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded" />
              <div>
                <label>Risk Tolerance</label>
                <input type="range" min="0" max="100" value={formData.riskTolerance} onChange={handleSliderChange} className="w-full" />
                <p>{formData.riskTolerance}% (Conservative to Aggressive)</p>
              </div>
            </div>
          </div>
        );
      case 2:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-emerald-500">Step 2: Income & Assets</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input type="number" name="annualIncome" placeholder="Annual Income (W-2)" onChange={handleNumberInputChange} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded" />
              <input type="number" name="businessIncome" placeholder="Business Income" onChange={handleNumberInputChange} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded" />
              <input type="number" name="investmentIncome" placeholder="Investment Income" onChange={handleNumberInputChange} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded" />
              <input type="number" name="rentalIncome" placeholder="Rental Income" onChange={handleNumberInputChange} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded" />
              <input type="number" name="totalNetWorth" placeholder="Total Net Worth" onChange={handleNumberInputChange} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded" />
              <input type="number" name="liquidAssets" placeholder="Liquid Assets" onChange={handleNumberInputChange} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded" />
              <input type="number" name="homeValue" placeholder="Home Value" onChange={handleNumberInputChange} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded" />
              <input type="number" name="mortgageBalance" placeholder="Mortgage Balance" onChange={handleNumberInputChange} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded" />
            </div>
          </div>
        );
      case 3:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-emerald-500">Step 3: Current Coverage</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input type="number" name="lifeInsurance" placeholder="Life Insurance Amount" onChange={handleNumberInputChange} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded" />
              <label className="flex items-center">
                <input type="checkbox" name="disabilityInsurance" onChange={handleInputChange} className="mr-2" />
                Disability Insurance (Yes/No)
              </label>
              <input type="number" name="umbrellaPolicy" placeholder="Umbrella Policy Amount" onChange={handleNumberInputChange} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded" />
              <label className="flex items-center">
                <input type="checkbox" name="longTermCare" onChange={handleInputChange} className="mr-2" />
                Long-Term Care (Yes/No)
              </label>
              <label className="flex items-center">
                <input type="checkbox" name="estatePlan" onChange={handleInputChange} className="mr-2" />
                Estate Plan (Yes/No)
              </label>
              {formData.estatePlan && (
                <input type="text" name="estateTrustType" placeholder="Trust Type" onChange={handleInputChange} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded" />
              )}
            </div>
          </div>
        );
      case 4:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-emerald-500">Step 4: Goals & Priorities</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {goalsList.map(goal => (
                <div key={goal.name}>
                  {goal.icon}
                  <input type="number" min="1" max="5" placeholder={`Rank ${goal.name}`} onChange={(e) => handleGoalRankChange(goal.name, parseInt(e.target.value, 10))} className="bg-[#0d1526] border border-[#1e3a5f] p-2 rounded" />
                </div>
              ))}
            </div>
          </div>
        );
      case 5:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-emerald-500">Step 5: AI Analysis</h2>
            {isLoading ? (
              <div className="animate-pulse">
                <p>{loadingMessages[currentMessageIndex]}</p>
              </div>
            ) : (
              <button onClick={startAnalysis} className="bg-emerald-500 text-white p-2 rounded">Start Analysis</button>
            )}
          </div>
        );
      case 6:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-emerald-500">Step 6: Results Dashboard</h2>
            <p>Financial Health Score: 847/1000</p>
            <h3>Top 5 Recommended Strategies:</h3>
            <ul>
              {recommendedStrategies.map(strategy => (
                <li key={strategy.name}>{strategy.name} - Fit Score: {strategy.fitScore}%</li>
              ))}
            </ul>
            <p>Estimated Annual Tax Savings: $136,000</p>
            <p>Estimated 10-Year Wealth Growth: +$4.2M</p>
            <button className="bg-emerald-500 text-white p-2 rounded mr-2">Generate Full Report</button>
            <button className="bg-emerald-500 text-white p-2 rounded">Schedule Meeting</button>
          </div>
        );
      default:
        return null;
    }
  };

  const progress = (step / 6) * 100;

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-emerald-500 mb-8">Client Onboarding Wizard</h1>
        <div className="mb-8">
          <div className="bg-gray-700 h-4 rounded-full">
            <div className="bg-emerald-500 h-4 rounded-full" style={{ width: `${progress}%` }}></div>
          </div>
          <p className="text-center mt-2">Step {step} of 6</p>
        </div>
        {renderStep()}
        <div className="flex justify-between mt-8">
          {step > 1 && <button onClick={() => setStep(step - 1)} className="flex items-center bg-gray-700 p-2 rounded"><ArrowLeft className="mr-2" /> Previous</button>}
          {step < 6 && step !== 5 && <button onClick={() => setStep(step + 1)} className="flex items-center bg-emerald-500 p-2 rounded">Next <ArrowRight className="ml-2" /></button>}
          {step === 5 && !isLoading && <button onClick={startAnalysis} className="bg-emerald-500 p-2 rounded">Proceed to Analysis</button>}
        </div>
      </div>
      <PageInsights section="client-onboarding-wizard" />
    </div>
  );
};

export default ClientOnboardingWizard;
