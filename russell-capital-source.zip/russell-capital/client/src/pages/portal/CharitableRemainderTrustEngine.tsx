// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Heart, DollarSign, TrendingUp, Target, Calendar, Percent, ArrowRight, Shield, CheckCircle2, AlertTriangle, PiggyBank, Gift } from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, 
  BarChart, Bar, ComposedChart, Line, PieChart, Pie, Cell 
} from 'recharts';
import { PageInsights } from "@/components/PageInsights";

export default function CharitableRemainderTrustEngine() {
  const [trustValue, setTrustValue] = useState(1000000); // Initial trust value
  const [payoutRate, setPayoutRate] = useState(5); // Payout rate in %
  const [annualReturn, setAnnualReturn] = useSharedField("growthRate", 7); // Expected annual return
  const [rate7520, setrate7520] = useState(2.6); // Section 7520 rate
  const [years, setYears] = useSharedField("projectionYears", 50); // Projection years
  const [selectedTrustType, setSelectedTrustType] = useState('CRUT'); // CRAT or CRUT

  const projections = useMemo(() => {
    const data = [];
    let currentValue = trustValue;
    for (let year = 0; year <= years; year++) {
      const incomePayout = (currentValue * (payoutRate / 100));
      const growth = currentValue * (annualReturn / 100);
      currentValue = currentValue + growth - incomePayout;
      data.push({ year, income: incomePayout, remainder: currentValue });
    }
    return data;
  }, [trustValue, payoutRate, annualReturn, years]);

  const check10PercentRemainder = useMemo(() => {
    const finalRemainder = projections[projections.length - 1].remainder;
    return (finalRemainder / trustValue) >= 0.10 ? true : false;
  }, [projections, trustValue]);

  const check5PercentExhaustion = useMemo(() => {
    const exhaustionYear = projections.findIndex(p => p.remainder <= 0);
    return exhaustionYear >= (years * 0.05) ? true : false; // Simplified check
  }, [projections, years]);

  const incomeTaxDeduction = useMemo(() => {
    const factor = Math.pow(1 + (rate7520 / 100), -years);
    return trustValue * (1 - factor) * (payoutRate / 100);
  }, [trustValue, rate7520, years, payoutRate]);

  const cratVsCrutData = [
    { type: 'CRAT', description: 'Fixed annuity payout', pros: 'Stable income', cons: 'No flexibility' },
    { type: 'CRUT', description: 'Unitrust payout based on value', pros: 'Adjusts with market', cons: 'Variable income' },
  ];

  const nimcrutData = {
    netIncome: trustValue * (annualReturn / 100),
    makeup: trustValue * 0.05, // Example makeup amount
  };

  const flipCrutData = {
    illiquidAssets: trustValue * 0.30, // Assumed 30% illiquid
    flipYear: 5, // Example flip year
  };

  return (
    <div style={{ backgroundColor: '#1a1a2e', color: '#ffffff', minHeight: '100vh', padding: '40px', fontFamily: 'Arial, sans-serif' }}>
      <h1 style={{ color: '#FFD700', textAlign: 'center', marginBottom: '40px' }}><Heart size={32} /> Charitable Remainder Trust Engine</h1>
      
      <section style={{ marginBottom: '30px', padding: '20px', backgroundColor: '#2c2c3e', borderRadius: '8px' }}>
        <h2 style={{ color: '#BA55D3' }}><DollarSign size={24} /> Trust Parameters</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
          <label>
            Trust Value: 
            <input 
              type="number" 
              value={trustValue} 
              onChange={(e) => setTrustValue(Number(e.target.value))} 
              style={{ backgroundColor: '#3a3a4e', color: '#fff', border: '1px solid #BA55D3', padding: '10px', borderRadius: '4px' }} 
            />
          </label>
          <label>
            Payout Rate (%): 
            <input 
              type="number" 
              value={payoutRate} 
              onChange={(e) => setPayoutRate(Number(e.target.value))} 
              style={{ backgroundColor: '#3a3a4e', color: '#fff', border: '1px solid #BA55D3', padding: '10px', borderRadius: '4px' }} 
            />
          </label>
          <label>
            Annual Return (%): 
            <input 
              type="number" 
              value={annualReturn} 
              onChange={(e) => setAnnualReturn(Number(e.target.value))} 
              style={{ backgroundColor: '#3a3a4e', color: '#fff', border: '1px solid #BA55D3', padding: '10px', borderRadius: '4px' }} 
            />
          </label>
          <label>
            7520 Rate (%): 
            <input 
              type="number" 
              value={rate7520} 
              onChange={(e) => setrate7520(Number(e.target.value))} 
              style={{ backgroundColor: '#3a3a4e', color: '#fff', border: '1px solid #BA55D3', padding: '10px', borderRadius: '4px' }} 
            />
          </label>
          <label>
            Projection Years: 
            <input 
              type="number" 
              value={years} 
              onChange={(e) => setYears(Number(e.target.value))} 
              style={{ backgroundColor: '#3a3a4e', color: '#fff', border: '1px solid #BA55D3', padding: '10px', borderRadius: '4px' }} 
            />
          </label>
          <label>
            Trust Type: 
            <select 
              value={selectedTrustType} 
              onChange={(e) => setSelectedTrustType(e.target.value)} 
              style={{ backgroundColor: '#3a3a4e', color: '#fff', border: '1px solid #BA55D3', padding: '10px', borderRadius: '4px' }}
            >
              <option value="CRAT">CRAT</option>
              <option value="CRUT">CRUT</option>
              <option value="NIMCRUT">NIMCRUT</option>
              <option value="FlipCRUT">Flip CRUT</option>
            </select>
          </label>
        </div>
      </section>

      <section style={{ marginBottom: '30px', padding: '20px', backgroundColor: '#2c2c3e', borderRadius: '8px' }}>
        <h2 style={{ color: '#BA55D3' }}><TrendingUp size={24} /> CRAT vs CRUT Comparison</h2>
        <div className="overflow-x-auto"><table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '10px' }}>
          <thead>
            <tr style={{ backgroundColor: '#3a3a4e' }}>
              <th style={{ padding: '10px', border: '1px solid #BA55D3' }}>Type</th>
              <th style={{ padding: '10px', border: '1px solid #BA55D3' }}>Description</th>
              <th style={{ padding: '10px', border: '1px solid #BA55D3' }}>Pros</th>
              <th style={{ padding: '10px', border: '1px solid #BA55D3' }}>Cons</th>
            </tr>
          </thead>
          <tbody>
            {cratVsCrutData.map((item, index) => (
              <tr key={index} style={{ backgroundColor: index % 2 === 0 ? '#2c2c3e' : '#3a3a4e' }}>
                <td style={{ padding: '10px', border: '1px solid #BA55D3' }}>{item.type}</td>
                <td style={{ padding: '10px', border: '1px solid #BA55D3' }}>{item.description}</td>
                <td style={{ padding: '10px', border: '1px solid #BA55D3' }}>{item.pros}</td>
                <td style={{ padding: '10px', border: '1px solid #BA55D3' }}>{item.cons}</td>
              </tr>
            ))}
          </tbody>
        </table></div>
      </section>

      <section style={{ marginBottom: '30px', padding: '20px', backgroundColor: '#2c2c3e', borderRadius: '8px' }}>
        <h2 style={{ color: '#BA55D3' }}><Percent size={24} /> NIMCRUT (Net Income with Makeup)</h2>
        <p>Net Income: ${nimcrutData.netIncome.toFixed(2)}</p>
        <p>Makeup Amount: ${nimcrutData.makeup.toFixed(2)}</p>
      </section>

      <section style={{ marginBottom: '30px', padding: '20px', backgroundColor: '#2c2c3e', borderRadius: '8px' }}>
        <h2 style={{ color: '#BA55D3' }}><ArrowRight size={24} /> Flip CRUT for Illiquid Assets</h2>
        <p>Illiquid Assets Value: ${flipCrutData.illiquidAssets.toFixed(2)}</p>
        <p>Flip Year: Year {flipCrutData.flipYear}</p>
      </section>

      <section style={{ marginBottom: '30px', padding: '20px', backgroundColor: '#2c2c3e', borderRadius: '8px' }}>
        <h2 style={{ color: '#BA55D3' }}><Target size={24} /> 7520 Rate Impact on Deduction</h2>
        <p>Estimated Income Tax Deduction: ${incomeTaxDeduction.toFixed(2)}</p>
      </section>

      <section style={{ marginBottom: '30px', padding: '20px', backgroundColor: '#2c2c3e', borderRadius: '8px' }}>
        <h2 style={{ color: '#BA55D3' }}><Shield size={24} /> 10% Remainder Test</h2>
        <p>{check10PercentRemainder ? <CheckCircle2 size={24} color="green" /> : <AlertTriangle size={24} color="red" />} Result: {check10PercentRemainder ? 'Passes' : 'Fails'}</p>
      </section>

      <section style={{ marginBottom: '30px', padding: '20px', backgroundColor: '#2c2c3e', borderRadius: '8px' }}>
        <h2 style={{ color: '#BA55D3' }}><Calendar size={24} /> 5% Probability of Exhaustion Test</h2>
        <p>{check5PercentExhaustion ? <CheckCircle2 size={24} color="green" /> : <AlertTriangle size={24} color="red" />} Result: {check5PercentExhaustion ? 'Passes' : 'Fails'}</p>
      </section>

      <section style={{ marginBottom: '30px', padding: '20px', backgroundColor: '#2c2c3e', borderRadius: '8px' }}>
        <h2 style={{ color: '#BA55D3' }}><PiggyBank size={24} /> Income Tax Deduction Calculator</h2>
        <p>Calculated Deduction: ${incomeTaxDeduction.toFixed(2)} based on IRC Section 170</p>
      </section>

      <section style={{ marginBottom: '30px', padding: '20px', backgroundColor: '#2c2c3e', borderRadius: '8px' }}>
        <h2 style={{ color: '#BA55D3' }}><Gift size={24} /> Capital Gains Bypass Strategy</h2>
        <p>Strategy Projection: Bypass gains on ${trustValue * 0.20} of assets</p>
      </section>

      <section style={{ marginBottom: '30px', padding: '20px', backgroundColor: '#2c2c3e', borderRadius: '8px' }}>
        <h2 style={{ color: '#BA55D3' }}><TrendingUp size={24} /> 50-Year Income and Remainder Projection</h2>
        <ResponsiveContainer width="100%" height={400}>
          <ComposedChart data={projections}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="income" fill="#BA55D3" stroke="#FFD700" />
            <Line type="monotone" dataKey="remainder" stroke="#FFD700" />
            <Bar dataKey="income" fill="#BA55D3" />
          </ComposedChart>
        </ResponsiveContainer>
      </section>

      <section style={{ marginBottom: '30px', padding: '20px', backgroundColor: '#2c2c3e', borderRadius: '8px' }}>
        <h2 style={{ color: '#BA55D3' }}><Shield size={24} /> Compliance Overview</h2>
        <ul style={{ listStyle: 'none', padding: '0' }}>
          <li><CheckCircle2 size={18} /> IRC 664 CRT Regulations</li>
          <li><CheckCircle2 size={18} /> Section 7520 Valuation Rate</li>
          <li><CheckCircle2 size={18} /> Reg. 1.664-1 through 1.664-4</li>
          <li><CheckCircle2 size={18} /> Section 170(f)(2)(A) 10% Remainder</li>
          <li><CheckCircle2 size={18} /> Rev. Rul. 77-374 NIMCRUT Guidelines</li>
        </ul>
      </section>

      <ResponsiveContainer width="100%" height={400}><PieChart>
        <Pie data={[{name: 'Income', value: projections[0].income}, {name: 'Remainder', value: projections[0].remainder}]} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} fill="#BA55D3">
          <Cell fill="#FFD700" />
        </Pie>
      </PieChart></ResponsiveContainer>
      <PageInsights section="charitable-remainder-trust-engine" />
    </div>
  );
}
