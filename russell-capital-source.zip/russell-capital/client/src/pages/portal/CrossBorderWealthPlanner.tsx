// @ts-nocheck
import React, { useState } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Activity, AlertTriangle, Calculator, Coins, DollarSign, Globe, Info, Sliders, TrendingUp, Wallet, PieChartIcon} from 'lucide-react';
import { toast } from 'sonner';
import { PageInsights } from '@/components/PageInsights';

const CrossBorderWealthPlanner = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [income, setIncome] = useSharedField("annualIncome", 150000);
  const [foreignIncome, setForeignIncome] = useState(50000);
  const [projectionYears, setProjectionYears] = useSharedField("projectionYears", 50);
  const [isGILTIEnabled, setIsGILTIEnabled] = useState(false);

  // Sample data for charts - 5 years historical + 50-year projection capability
  const wealthData = Array.from({ length: 55 }, (_, i) => ({
    year: 2020 + i,
    usWealth: i < 5 ? 200000 + i * 50000 : 400000 + i * 75000,
    foreignWealth: i < 5 ? 100000 + i * 30000 : 200000 + i * 45000,
  }));

  const taxBurdenData = [
    { category: 'US Tax', amount: 35000, color: '#059669' },
    { category: 'Foreign Tax', amount: 15000, color: '#10b981' },
    { category: 'GILTI (§951A)', amount: isGILTIEnabled ? 8000 : 0, color: '#34d399' },
    { category: 'Subpart F (§951)', amount: 5000, color: '#6ee7b7' },
  ];

  const handleGenerateOutcome = () => {
    if (income < 0 || foreignIncome < 0) {
      toast.error('Invalid input: Income cannot be negative.');
      return;
    }
    toast.success('Outcome generated! Review your tax projections below.');
  };

  const projectedData = wealthData.slice(0, projectionYears + 5);

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <Globe className="w-8 h-8 text-emerald-400" />
          <h1 className="text-3xl font-bold">Cross-Border Wealth Planner</h1>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-2 mb-6 border-b border-[#1e3a5f]">
          {['overview', 'tax-compliance', 'projections'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-t-md font-medium ${
                activeTab === tab
                  ? 'bg-[#0d1526] text-emerald-400 border-b-2 border-emerald-500'
                  : 'text-[#7a95b8] hover:bg-[#0d1526]/50'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1).replace('-', ' ')}
            </button>
          ))}
        </div>

        {/* Content Sections */}
        <div className="space-y-6">
          {activeTab === 'overview' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-[#0d1526] p-6 rounded-lg border border-[#1e3a5f]">
                <div className="flex items-center gap-2 mb-4">
                  <Wallet className="w-5 h-5 text-emerald-400" />
                  <h2 className="text-xl font-semibold">Wealth Distribution</h2>
                </div>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={projectedData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                      <XAxis dataKey="year" stroke="#7a95b8" />
                      <YAxis stroke="#7a95b8" />
                      <Tooltip contentStyle={{ backgroundColor: '#0d1526', borderColor: '#1e3a5f', color: 'white' }} />
                      <Area type="monotone" dataKey="usWealth" stackId="1" stroke="#059669" fill="#059669" name="US Wealth" />
                      <Area type="monotone" dataKey="foreignWealth" stackId="1" stroke="#10b981" fill="#10b981" name="Foreign Wealth" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div className="bg-[#0d1526] p-6 rounded-lg border border-[#1e3a5f]">
                <div className="flex items-center gap-2 mb-4">
                  <PieChartIcon className="w-5 h-5 text-emerald-400" />
                  <h2 className="text-xl font-semibold">Tax Burden Breakdown</h2>
                </div>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={taxBurdenData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                      <XAxis dataKey="category" stroke="#7a95b8" />
                      <YAxis stroke="#7a95b8" />
                      <Tooltip contentStyle={{ backgroundColor: '#0d1526', borderColor: '#1e3a5f', color: 'white' }} />
                      <Bar dataKey="amount" fill="color" name="Tax Amount ($)" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'tax-compliance' && (
            <div className="bg-[#0d1526] p-6 rounded-lg border border-[#1e3a5f]">
              <div className="flex items-center gap-2 mb-4">
                <AlertTriangle className="w-5 h-5 text-emerald-400" />
                <h2 className="text-xl font-semibold">Tax Compliance Factors</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[#7a95b8]">
                <div className="p-4 bg-[#0a0f1a] rounded-md">
                  <h3 className="text-lg font-medium text-white mb-2">Foreign Earned Income Exclusion (§911)</h3>
                  <p>Exclude up to $120,000 of foreign income from US taxation.</p>
                </div>
                <div className="p-4 bg-[#0a0f1a] rounded-md">
                  <h3 className="text-lg font-medium text-white mb-2">Foreign Tax Credit (§901)</h3>
                  <p>Offset US tax liability with taxes paid to foreign jurisdictions.</p>
                </div>
                <div className="p-4 bg-[#0a0f1a] rounded-md">
                  <h3 className="text-lg font-medium text-white mb-2">GILTI &amp; Subpart F (§951-965)</h3>
                  <p>Toggle GILTI calculations for controlled foreign corporations.</p>
                  <label className="flex items-center gap-2 mt-2">
                    <input
                      type="checkbox"
                      checked={isGILTIEnabled}
                      onChange={() => setIsGILTIEnabled(!isGILTIEnabled)}
                      className="accent-emerald-500"
                    />
                    Include GILTI
                  </label>
                </div>
                <div className="p-4 bg-[#0a0f1a] rounded-md">
                  <h3 className="text-lg font-medium text-white mb-2">FBAR/FATCA &amp; Foreign Trust (§6048)</h3>
                  <p>Reporting requirements for foreign accounts and trusts.</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'projections' && (
            <div className="space-y-6">
              <div className="bg-[#0d1526] p-6 rounded-lg border border-[#1e3a5f]">
                <div className="flex items-center gap-2 mb-4">
                  <Sliders className="w-5 h-5 text-emerald-400" />
                  <h2 className="text-xl font-semibold">Input Parameters</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[#7a95b8] mb-1">US Income ($)</label>
                    <input
                      type="number"
                      value={income}
                      onChange={(e) => setIncome(Number(e.target.value))}
                      className="w-full p-2 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[#7a95b8] mb-1">Foreign Income ($)</label>
                    <input
                      type="number"
                      value={foreignIncome}
                      onChange={(e) => setForeignIncome(Number(e.target.value))}
                      className="w-full p-2 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[#7a95b8] mb-1">Projection Years (1-50)</label>
                    <input
                      type="number"
                      min={1}
                      max={50}
                      value={projectionYears}
                      onChange={(e) => setProjectionYears(Math.min(50, Math.max(1, Number(e.target.value))))}
                      className="w-full p-2 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>
                <button
                  onClick={handleGenerateOutcome}
                  className="mt-4 px-4 py-2 bg-emerald-500 text-white rounded-md hover:bg-emerald-400 transition-colors flex items-center gap-2"
                >
                  <Calculator className="w-5 h-5" />
                  Generate Outcome
                </button>
              </div>
              <div className="bg-[#0d1526] p-6 rounded-lg border border-[#1e3a5f]">
                <div className="flex items-center gap-2 mb-4">
                  <TrendingUp className="w-5 h-5 text-emerald-400" />
                  <h2 className="text-xl font-semibold">Wealth Projection (50-Year Max)</h2>
                </div>
                <p className="text-[#7a95b8] mb-4">Projected wealth growth based on current inputs over {projectionYears} years.</p>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={projectedData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                      <XAxis dataKey="year" stroke="#7a95b8" />
                      <YAxis stroke="#7a95b8" />
                      <Tooltip contentStyle={{ backgroundColor: '#0d1526', borderColor: '#1e3a5f', color: 'white' }} />
                      <Area type="monotone" dataKey="usWealth" stroke="#059669" fillOpacity={0.3} fill="#059669" name="US Wealth" />
                      <Area type="monotone" dataKey="foreignWealth" stroke="#10b981" fillOpacity={0.3} fill="#10b981" name="Foreign Wealth" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Info Notice */}
        <div className="mt-6 p-4 bg-[#0d1526] border border-[#1e3a5f] rounded-md flex items-start gap-2 text-[#7a95b8]">
          <Info className="w-5 h-5 text-emerald-400 mt-0.5" />
          <p>
            This tool provides estimates based on IRS codes (§901, §911, §951-965, §877A). Consult a tax professional for FBAR/FATCA, PFIC (§1291-1298), and expatriation tax planning.
          </p>
        </div>
      </div>
      <PageInsights section="cross-border-wealth-planner" />
    </div>
  );
};

export default CrossBorderWealthPlanner;