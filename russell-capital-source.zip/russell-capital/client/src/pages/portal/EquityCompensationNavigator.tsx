// @ts-nocheck
import React, { useState } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Activity, AlertTriangle, BarChart3, Calculator, Calendar, DollarSign, Info, Layers, Percent, Settings, Wallet, LineChartIcon, PieChartIcon} from 'lucide-react';
import { toast } from 'sonner';
import { PageInsights } from '@/components/PageInsights';

const EquityCompensationNavigator: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [grantType, setGrantType] = useState('ISO');
  const [exercisePrice, setExercisePrice] = useState(10);
  const [currentPrice, setCurrentPrice] = useState(50);
  const [shares, setShares] = useState(1000);
  const [projectionYears, setProjectionYears] = useSharedField("projectionYears", 10);
  const [amtTrapAlert, setAmtTrapAlert] = useState(false);
  const [section83b, setSection83b] = useState(false);

  // Sample data for charts
  const taxImpactData = [
    { year: 2023, iso: 20000, nqso: 30000, rsu: 25000 },
    { year: 2024, iso: 25000, nqso: 35000, rsu: 30000 },
    { year: 2025, iso: 30000, nqso: 40000, rsu: 35000 },
    { year: 2026, iso: 35000, nqso: 45000, rsu: 40000 },
  ];

  const diversificationData = Array.from({ length: projectionYears }, (_, i) => ({
    year: 2023 + i,
    equity: 100000 + i * 20000,
    diversified: 50000 + i * 10000,
  }));

  const handleGenerateOutcome = () => {
    if (grantType === 'ISO' && currentPrice - exercisePrice * shares > 100000) {
      setAmtTrapAlert(true);
      toast.warning('AMT Trap Detected: Consider smaller exercises to minimize AMT exposure (IRC §56)');
    } else {
      setAmtTrapAlert(false);
      toast.success('Outcome generated: Tax impact and diversification plan updated.');
    }
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: <BarChart3 className="w-4 h-4 text-emerald-400" /> },
    { id: 'tax', label: 'Tax Analysis', icon: <DollarSign className="w-4 h-4 text-emerald-400" /> },
    { id: 'diversification', label: 'Diversification', icon: <Layers className="w-4 h-4 text-emerald-400" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4 text-emerald-400" /> },
  ];

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-emerald-400 mb-6 flex items-center gap-2">
          <Wallet className="w-6 h-6" /> Equity Compensation Navigator
        </h1>

        {/* Tab Navigation */}
        <div className="flex gap-1 border-b border-[#1e3a5f] mb-6">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-3 flex items-center gap-2 rounded-t-md ${
                activeTab === tab.id ? 'bg-[#0d1526] text-emerald-400' : 'text-[#7a95b8] hover:bg-[#0d1526]/50'
              }`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>

        {/* Content Sections */}
        <div className="space-y-6">
          {activeTab === 'overview' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-[#0d1526] p-6 rounded-lg border border-[#1e3a5f]">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-emerald-400" /> Grant Type Analysis
                </h2>
                <p className="text-[#7a95b8] mb-4">Compare ISOs, NQSOs, RSUs, RSAs, and ESPP.</p>
                <select
                  value={grantType}
                  onChange={(e) => setGrantType(e.target.value)}
                  className="w-full bg-[#0a0f1a] border border-[#1e3a5f] p-2 rounded-md text-white mb-4"
                >
                  <option value="ISO">ISO (Incentive Stock Options - IRC §422)</option>
                  <option value="NQSO">NQSO (Non-Qualified Stock Options)</option>
                  <option value="RSU">RSU (Restricted Stock Units)</option>
                  <option value="RSA">RSA (Restricted Stock Awards)</option>
                  <option value="ESPP">ESPP (Employee Stock Purchase Plan - IRC §423)</option>
                </select>
                {amtTrapAlert && grantType === 'ISO' && (
                  <div className="flex items-center gap-2 text-amber-400 mb-4">
                    <AlertTriangle className="w-5 h-5" /> AMT Trap Warning: Exercise may trigger Alternative Minimum Tax.
                  </div>
                )}
              </div>
              <div className="bg-[#0d1526] p-6 rounded-lg border border-[#1e3a5f]">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <PieChartIcon className="w-5 h-5 text-emerald-400" /> Tax Impact (IRC §83)
                </h2>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={taxImpactData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                    <XAxis dataKey="year" stroke="#7a95b8" />
                    <YAxis stroke="#7a95b8" />
                    <Tooltip contentStyle={{ backgroundColor: '#0d1526', border: '1px solid #1e3a5f', color: 'white' }} />
                    <Bar dataKey="iso" fill="#2dd4bf" name="ISO Tax" />
                    <Bar dataKey="nqso" fill="#3b82f6" name="NQSO Tax" />
                    <Bar dataKey="rsu" fill="#fbbf24" name="RSU Tax" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {activeTab === 'tax' && (
            <div className="bg-[#0d1526] p-6 rounded-lg border border-[#1e3a5f]">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-emerald-400" /> Tax Withholding Optimization
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div>
                  <label className="block text-[#7a95b8] mb-1">Exercise Price ($)</label>
                  <input
                    type="number"
                    value={exercisePrice}
                    onChange={(e) => setExercisePrice(Number(e.target.value))}
                    className="w-full bg-[#0a0f1a] border border-[#1e3a5f] p-2 rounded-md text-white"
                  />
                </div>
                <div>
                  <label className="block text-[#7a95b8] mb-1">Current Price ($)</label>
                  <input
                    type="number"
                    value={currentPrice}
                    onChange={(e) => setCurrentPrice(Number(e.target.value))}
                    className="w-full bg-[#0a0f1a] border border-[#1e3a5f] p-2 rounded-md text-white"
                  />
                </div>
                <div>
                  <label className="block text-[#7a95b8] mb-1">Shares</label>
                  <input
                    type="number"
                    value={shares}
                    onChange={(e) => setShares(Number(e.target.value))}
                    className="w-full bg-[#0a0f1a] border border-[#1e3a5f] p-2 rounded-md text-white"
                  />
                </div>
              </div>
              <div className="flex items-center gap-2 mb-4">
                <input
                  type="checkbox"
                  checked={section83b}
                  onChange={() => setSection83b(!section83b)}
                  className="w-4 h-4 bg-[#0a0f1a] border border-[#1e3a5f] text-emerald-400"
                />
                <label className="text-[#7a95b8]">Elect §83(b) for early taxation (potential savings)</label>
                <Info className="w-4 h-4 text-[#7a95b8]" />
              </div>
              <button
                onClick={handleGenerateOutcome}
                className="bg-emerald-500 hover:bg-emerald-400 text-white px-4 py-2 rounded-md"
              >
                Generate Outcome
              </button>
            </div>
          )}

          {activeTab === 'diversification' && (
            <div className="bg-[#0d1526] p-6 rounded-lg border border-[#1e3a5f]">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <LineChartIcon className="w-5 h-5 text-emerald-400" /> Diversification Timeline (50-Year Projection)
              </h2>
              <div className="mb-4">
                <label className="block text-[#7a95b8] mb-1">Projection Years (1-50)</label>
                <input
                  type="number"
                  min={1}
                  max={50}
                  value={projectionYears}
                  onChange={(e) => setProjectionYears(Math.min(50, Math.max(1, Number(e.target.value))))}
                  className="w-32 bg-[#0a0f1a] border border-[#1e3a5f] p-2 rounded-md text-white"
                />
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={diversificationData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                  <XAxis dataKey="year" stroke="#7a95b8" />
                  <YAxis stroke="#7a95b8" />
                  <Tooltip contentStyle={{ backgroundColor: '#0d1526', border: '1px solid #1e3a5f', color: 'white' }} />
                  <Area type="monotone" dataKey="equity" stroke="#2dd4bf" fill="#2dd4bf33" name="Equity Holdings" />
                  <Area type="monotone" dataKey="diversified" stroke="#fbbf24" fill="#fbbf2433" name="Diversified Assets" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="bg-[#0d1526] p-6 rounded-lg border border-[#1e3a5f]">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-emerald-400" /> Blackout Periods &amp; Rule 144
              </h2>
              <p className="text-[#7a95b8]">Configure blackout periods, 10b5-1 trading plans, and track Rule 144 holding periods.</p>
              <div className="flex items-center gap-2 mt-4">
                <Percent className="w-4 h-4 text-emerald-400" />
                <span className="text-[#7a95b8]">Withholding rates and deferred comp rules (IRC §409A) adjustable in advanced settings.</span>
              </div>
            </div>
          )}
        </div>

        <div className="mt-6 bg-[#0d1526] p-4 rounded-lg border border-[#1e3a5f] flex items-center gap-2 text-[#7a95b8]">
          <Activity className="w-5 h-5 text-emerald-400" />
          Cashless exercise, cash exercise, and hold comparisons available in detailed report.
        </div>

        <PageInsights section="EquityCompensationNavigator" />
      </div>
    </div>
  );
};

export default EquityCompensationNavigator;