// @ts-nocheck
import React, { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Heart, Activity, FileText, Stethoscope, AlertTriangle, CheckCircle } from 'lucide-react';
import { PageInsights } from "@/components/PageInsights";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

interface FinancialData {
  income: number;
  netWorth: number;
  studentDebt: number;
  retirementSavings: number;
  annualSavings: number;
  taxRate: number;
  insurance: boolean;
}

const AnnualFinancialPhysical: React.FC = () => {
  const [data, setData] = useState<FinancialData>({
    income: 0,
    netWorth: 0,
    studentDebt: 0,
    retirementSavings: 0,
    annualSavings: 0,
    taxRate: 0,
    insurance: false,
  });

  const healthGrade = useMemo(() => {
    const savingsRate = data.annualSavings / (data.income || 1);
    const debtRatio = data.studentDebt / (data.netWorth || 1);
    const retirementRatio = data.retirementSavings / (data.netWorth || 1);
    let score = 0;
    score += savingsRate > 0.2 ? 2 : savingsRate > 0.1 ? 1 : 0;
    score += debtRatio < 0.3 ? 2 : debtRatio < 0.5 ? 1 : 0;
    score += retirementRatio > 0.5 ? 2 : retirementRatio > 0.3 ? 1 : 0;
    score += data.insurance ? 1 : 0;
    return score >= 6 ? "A+" : score >= 5 ? "A" : score >= 4 ? "B" : score >= 3 ? "C" : score >= 2 ? "D" : "F";
  }, [data]);

  const handleInputChange = (field: keyof FinancialData, value: string | boolean) => {
    setData(prev => ({ ...prev, [field]: typeof value === "string" ? parseFloat(value) || 0 : value }));
  };

  const getStatus = (value: number, thresholds: [number, number]) => {
    return value < thresholds[0] ? "Critical" : value < thresholds[1] ? "Borderline" : "Normal";
  };


  const projectionData = useMemo(() => {
    const d = [];
    let netWorth = 500000, savings = 200000, investments = 300000, debt = 150000;
    for (let yr = 0; yr <= 50; yr++) {
      d.push({ year: yr, netWorth: Math.round(netWorth), savings: Math.round(savings), investments: Math.round(investments), debtRemaining: Math.round(Math.max(0, debt)) });
      investments = investments * 1.078 + 25000;
      savings = savings * 1.04 + 15000;
      debt = Math.max(0, debt - 12000);
      netWorth = investments + savings - debt;
    }
    return d;
  }, []);
  return (
    <div className="min-h-screen bg-[#0a0f1a] text-slate-100 p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        <header className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-emerald-400">Annual Financial Physical Report</h1>
          <Button variant="outline" className="bg-[#0d1526] text-emerald-400 hover:bg-emerald-500 hover:text-white" onClick={() => window.print()}>
            <FileText className="mr-2 h-4 w-4" /> Print Report
          </Button>
        </header>

        <Card className="bg-[#0d1526] border-[#1e3a5f]">
          <CardHeader><CardTitle className="text-emerald-400">Patient Financial Vitals</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {Object.entries(data).map(([key, value]) => (
              <div key={key} className="space-y-2">
                <label className="text-sm capitalize">{key.replace(/([A-Z])/g, " $1")}</label>
                {key === "insurance" ? (
                  <input type="checkbox" checked={value as boolean} onChange={e => handleInputChange(key as keyof FinancialData, e.target.checked)} className="accent-emerald-500" />
                ) : (
                  <Input type="number" value={value || ""} onChange={e => handleInputChange(key as keyof FinancialData, e.target.value)} className="bg-slate-700 border-[#1e3a5f] text-slate-100" />
                )}
              </div>
            ))}
            <div className="col-span-full text-center mt-4"><Badge variant={healthGrade === "A+" ? "default" : "destructive"} className="bg-emerald-600">Overall Grade: {healthGrade}</Badge></div>
          </CardContent>
        </Card>

        <Card className="bg-[#0d1526] border-[#1e3a5f]">
          <CardHeader><CardTitle className="text-emerald-400"><Heart className="inline mr-2" /> Lab Results</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-2 border border-[#1e3a5f] rounded"><strong>Savings Rate:</strong> {(data.annualSavings / (data.income || 1) * 100).toFixed(1)}% - {getStatus(data.annualSavings / (data.income || 1), [0.1, 0.2])}</div>
            <div className="p-2 border border-[#1e3a5f] rounded"><strong>Debt-to-Net Worth:</strong> {(data.studentDebt / (data.netWorth || 1) * 100).toFixed(1)}% - {getStatus(data.studentDebt / (data.netWorth || 1), [0.5, 0.3])}</div>
            <div className="p-2 border border-[#1e3a5f] rounded"><strong>Retirement Ratio:</strong> {(data.retirementSavings / (data.netWorth || 1) * 100).toFixed(1)}% - {getStatus(data.retirementSavings / (data.netWorth || 1), [0.3, 0.5])}</div>
            <div className="p-2 border border-[#1e3a5f] rounded"><strong>Insurance Coverage:</strong> {data.insurance ? "Covered" : "Uninsured"} - {data.insurance ? "Normal" : "Critical"}</div>
          </CardContent>
        </Card>

        <Card className="bg-[#0d1526] border-[#1e3a5f]">
          <CardHeader><CardTitle className="text-emerald-400"><Activity className="inline mr-2" /> Diagnostic Imaging</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div><label>Income vs Savings</label><div className="w-full bg-slate-700 h-4 rounded"><div className="bg-emerald-500 h-4 rounded" style={{ width: `${Math.min(data.annualSavings / (data.income || 1) * 100, 100)}%` }} /></div></div>
            <div><label>Debt vs Net Worth</label><div className="w-full bg-slate-700 h-4 rounded"><div className="bg-emerald-500 h-4 rounded" style={{ width: `${Math.min(data.studentDebt / (data.netWorth || 1) * 100, 100)}%` }} /></div></div>
          </CardContent>
        </Card>

        <Card className="bg-[#0d1526] border-[#1e3a5f]">
          <CardHeader><CardTitle className="text-emerald-400"><Stethoscope className="inline mr-2" /> Assessment and Plan</CardTitle></CardHeader>
          <CardContent>
            <ul className="list-disc pl-5 space-y-2">
              <li>Increase savings rate to 20% of income if below threshold.</li>
              <li>Reduce student debt if debt-to-net worth ratio exceeds 30%.</li>
              <li>Secure comprehensive insurance if currently uninsured.</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-[#0d1526] border-[#1e3a5f]">
          <CardHeader><CardTitle className="text-emerald-400"><AlertTriangle className="inline mr-2" /> Prescriptions</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between"><span>Review Budget</span><Badge className="bg-emerald-600">Urgent</Badge></div>
            <Separator className="bg-slate-700" />
            <div className="flex justify-between"><span>Debt Repayment Plan</span><Badge className="bg-emerald-600">Routine</Badge></div>
            <Separator className="bg-slate-700" />
            <div className="flex justify-between"><span>Retirement Contribution</span><Badge className="bg-emerald-600">Preventive</Badge></div>
          </CardContent>
        </Card>

        <Card className="bg-[#0d1526] border-[#1e3a5f]">
          <CardHeader><CardTitle className="text-emerald-400"><CheckCircle className="inline mr-2" /> Follow-Up Schedule</CardTitle></CardHeader>
          <CardContent>
            <p>Next Financial Physical: <strong>1 Year</strong> or upon significant income/debt change.</p>
          </CardContent>
        </Card>
      </div>

        {/* 50-Year Projection Chart */}
        <ProjectionChart50yr
          data={projectionData}
          series={[
            { key: "netWorth", label: "Net Worth", color: "#22c55e" },
            { key: "investments", label: "Investments", color: "#3b82f6", type: "line" },
            { key: "savings", label: "Savings", color: "#a855f7", type: "line" },
            { key: "debtRemaining", label: "Debt Remaining", color: "#ef4444", type: "line" },
          ]}
          title="50-Year Financial Health Trajectory"
        />
      <PageInsights section="annual-financial-physical" />
    </div>
  );
};

export default AnnualFinancialPhysical;