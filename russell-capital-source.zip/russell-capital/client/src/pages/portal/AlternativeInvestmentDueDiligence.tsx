// @ts-nocheck
import React, { useState } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Activity, AlertTriangle, Calculator, Calendar, CheckCircle2, ChevronDown, ChevronUp, Coins, DollarSign, Info, LineChartIcon, Lock, Percent, PieChartIcon, ShieldCheck, TrendingUp, Wallet } from 'lucide-react';
import { toast } from 'sonner';
import { PageInsights } from '@/components/PageInsights';

const AlternativeInvestmentDueDiligence: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [investmentAmount, setInvestmentAmount] = useState(100000);
  const [lockupPeriod, setLockupPeriod] = useState(5);
  const [feeStructure, setFeeStructure] = useState({ management: 2, performance: 20 });
  const [projectionYears, setProjectionYears] = useSharedField("projectionYears", 10);
  const [isAccredited, setIsAccredited] = useState(false);

  const samplePerformanceData = [
    { year: 2020, return: 8.5, capital: 108500 },
    { year: 2021, return: -2.3, capital: 106000 },
    { year: 2022, return: 12.7, capital: 119500 },
    { year: 2023, return: 15.4, capital: 137900 },
    { year: 2024, return: 9.8, capital: 151400 },
  ];

  const feeImpactData = [
    { name: 'Year 1', baseReturn: 10, fees: 2.4, netReturn: 7.6 },
    { name: 'Year 2', baseReturn: 12, fees: 2.8, netReturn: 9.2 },
    { name: 'Year 3', baseReturn: 8, fees: 2.2, netReturn: 5.8 },
    { name: 'Year 4', baseReturn: 14, fees: 3.1, netReturn: 10.9 },
    { name: 'Year 5', baseReturn: 11, fees: 2.6, netReturn: 8.4 },
  ];

  const handleGenerateOutcome = () => {
    if (investmentAmount < 50000) {
      toast.error('Minimum investment is $50,000 for alternative assets.');
      return;
    }
    if (!isAccredited) {
      toast.warning('Accredited investor status required (SEC Reg D, Rule 501).');
      return;
    }
    toast.success(`Projected outcome generated for $${investmentAmount.toLocaleString()} over ${projectionYears} years.`);
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: <LineChartIcon className="w-4 h-4 mr-2" /> },
    { id: 'fees', label: 'Fee Analysis', icon: <Percent className="w-4 h-4 mr-2" /> },
    { id: 'risks', label: 'Risk & Compliance', icon: <AlertTriangle className="w-4 h-4 mr-2" /> },
    { id: 'projection', label: 'J-Curve Projection', icon: <TrendingUp className="w-4 h-4 mr-2" /> },
  ];

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold mb-2 flex items-center">
          <Wallet className="w-6 h-6 mr-2 text-emerald-400" />
          Alternative Investment Due Diligence
        </h1>
        <p className="text-[#7a95b8] mb-6">Comprehensive evaluation framework for private equity, hedge funds, and real estate syndications.</p>

        {/* Tab Navigation */}
        <div className="flex flex-wrap gap-2 mb-6 border-b border-[#1e3a5f]">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center px-4 py-3 rounded-t-md ${
                activeTab === tab.id ? 'bg-[#0d1526] text-emerald-400' : 'text-[#7a95b8] hover:bg-[#0d1526]/50'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="bg-[#0d1526] p-6 rounded-lg shadow-md border border-[#1e3a5f]">
          {activeTab === 'overview' && (
            <div>
              <h2 className="text-2xl font-semibold mb-4 flex items-center">
                <ShieldCheck className="w-5 h-5 mr-2 text-emerald-400" />
                Investment Overview
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-[#7a95b8] mb-2">Investment Amount</label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-[#7a95b8]" />
                    <input
                      type="number"
                      value={investmentAmount}
                      onChange={(e) => setInvestmentAmount(Number(e.target.value))}
                      className="w-full pl-8 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md p-2 text-white"
                      min="50000"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[#7a95b8] mb-2">Lock-Up Period (Years)</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-[#7a95b8]" />
                    <input
                      type="number"
                      value={lockupPeriod}
                      onChange={(e) => setLockupPeriod(Number(e.target.value))}
                      className="w-full pl-8 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md p-2 text-white"
                      min="1"
                      max="15"
                    />
                  </div>
                </div>
              </div>
              <div className="mt-6">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    checked={isAccredited}
                    onChange={() => setIsAccredited(!isAccredited)}
                    className="w-4 h-4 mr-2 accent-emerald-500"
                  />
                  <label className="text-[#7a95b8]">I am an accredited investor (SEC Reg D, Rule 501)</label>
                </div>
                <p className="text-sm text-[#7a95b8] mt-1 flex items-center">
                  <Info className="w-3 h-3 mr-1" />
                  Must meet income/net worth thresholds per 17 CFR § 230.501.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'fees' && (
            <div>
              <h2 className="text-2xl font-semibold mb-4 flex items-center">
                <Percent className="w-5 h-5 mr-2 text-emerald-400" />
                Fee Structure Analysis (2/20 Model)
              </h2>
              <div className="h-64 mb-6">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={feeImpactData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                    <XAxis dataKey="name" stroke="#7a95b8" />
                    <YAxis stroke="#7a95b8" />
                    <Tooltip backgroundColor="#0a0f1a" contentStyle={{ backgroundColor: '#0d1526', borderColor: '#1e3a5f', color: 'white' }} />
                    <Bar dataKey="baseReturn" stackId="a" fill="#34d399" name="Base Return %" />
                    <Bar dataKey="fees" stackId="a" fill="#f87171" name="Fees %" />
                    <Bar dataKey="netReturn" fill="#a5b4fc" name="Net Return %" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <p className="text-[#7a95b8] text-sm mt-2">Fee impact based on standard 2% management, 20% performance structure.</p>
            </div>
          )}

          {activeTab === 'risks' && (
            <div>
              <h2 className="text-2xl font-semibold mb-4 flex items-center">
                <AlertTriangle className="w-5 h-5 mr-2 text-emerald-400" />
                Risk Factors & Compliance
              </h2>
              <ul className="space-y-3 text-[#7a95b8]">
                <li className="flex items-start">
                  <AlertTriangle className="w-4 h-4 mr-2 mt-1 text-yellow-400" />
                  Liquidity Constraints: Lock-up periods of {lockupPeriod} years typical.
                </li>
                <li className="flex items-start">
                  <AlertTriangle className="w-4 h-4 mr-2 mt-1 text-yellow-400" />
                  Tax Implications: K-1 reporting, potential UBTI for IRA investors (IRC § 511-514).
                </li>
                <li className="flex items-start">
                  <AlertTriangle className="w-4 h-4 mr-2 mt-1 text-yellow-400" />
                  Manager Risk: Track record scoring based on vintage year diversification.
                </li>
              </ul>
            </div>
          )}

          {activeTab === 'projection' && (
            <div>
              <h2 className="text-2xl font-semibold mb-4 flex items-center">
                <TrendingUp className="w-5 h-5 mr-2 text-emerald-400" />
                J-Curve Performance Projection
              </h2>
              <div className="mb-4">
                <label className="block text-[#7a95b8] mb-2">Projection Period (up to 50 years)</label>
                <input
                  type="number"
                  value={projectionYears}
                  onChange={(e) => setProjectionYears(Math.min(50, Number(e.target.value)))}
                  className="w-full bg-[#0a0f1a] border border-[#1e3a5f] rounded-md p-2 text-white"
                  min="1"
                  max="50"
                />
              </div>
              <div className="h-64 mb-6">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={samplePerformanceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                    <XAxis dataKey="year" stroke="#7a95b8" />
                    <YAxis stroke="#7a95b8" />
                    <Tooltip contentStyle={{ backgroundColor: '#0d1526', borderColor: '#1e3a5f', color: 'white' }} />
                    <Area type="monotone" dataKey="capital" stroke="#34d399" fill="#34d399" fillOpacity={0.3} name="Capital ($)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <button
                onClick={handleGenerateOutcome}
                className="flex items-center bg-emerald-500 hover:bg-emerald-400 text-white px-4 py-2 rounded-md"
              >
                <Calculator className="w-4 h-4 mr-2" />
                Generate Outcome
              </button>
            </div>
          )}
        </div>
      </div>
      <PageInsights section="alternative-investment-due-diligence" />
    </div>
  );
};

export default AlternativeInvestmentDueDiligence;