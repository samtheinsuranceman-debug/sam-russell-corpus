// @ts-nocheck

import { useState, useMemo } from "react";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calculator } from 'lucide-react';
import { toast } from "sonner";
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function DCAvsLumpSumCalc() {
  const autoFill = useCalculatorAutoFill("dca-vs-lump-sum");
  const { reportResult } = useCalcResults();
  const [initialAmount, setInitialAmount] = useState(10000);
  const [monthlyInvestment, setMonthlyInvestment] = useState(1000);
  const [numberOfMonths, setNumberOfMonths] = useState(12);
  const [annualReturnRate, setAnnualReturnRate] = useState(0.07);

  const calculations = useMemo(() => {
    const monthlyRate = annualReturnRate / 12;
    const fvLumpSum = initialAmount * Math.pow(1 + monthlyRate, numberOfMonths);
    const fvDCA = monthlyInvestment * ((Math.pow(1 + monthlyRate, numberOfMonths) - 1) / monthlyRate) * (1 + monthlyRate);
    const difference = fvDCA - fvLumpSum;
    return { fvLumpSum, fvDCA, difference };
  }, [initialAmount, monthlyInvestment, numberOfMonths, annualReturnRate]);
  const projectionData = useMemo(() => {
    const d = [];
    const startBal = typeof balance !== 'undefined' ? balance : 500000;
    const annualContrib = typeof contribution !== 'undefined' ? contribution : 25000;
    let port = startBal, contribs = 0, withdrawals = 0;
    for (let yr = 0; yr <= 50; yr++) {
      const isRetired = yr >= 25;
      const withdrawal = isRetired ? port * 0.04 : 0;
      contribs += isRetired ? 0 : annualContrib;
      withdrawals += withdrawal;
      port = isRetired ? (port - withdrawal) * 1.065 : (port + annualContrib) * 1.075;
      const ss = isRetired ? 36000 * Math.pow(1.025, yr - 25) : 0;
      d.push({ year: yr, portfolio: Math.round(Math.max(port, 0)), contributions: Math.round(contribs), withdrawals: Math.round(withdrawals), socialSecurity: Math.round(ss * (yr - 24 > 0 ? yr - 24 : 0)) });
    }
    return d;
  }, []);


  return (
    <AppShell>
      <div className="p-6 bg-[#0a0f1a] min-h-screen text-white">
        <AutoFillBanner calcRoute="dca-vs-lump-sum" />
        <div className="flex items-center mb-6">
          <Calculator className="mr-2 h-6 w-6 text-emerald-400" />
          <h1 className="text-2xl font-bold">Dollar Cost Averaging vs Lump Sum Calculator</h1>
        </div>
        
        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4 text-emerald-400">Inputs</h2>
          <div className="space-y-4">
            <div>
              <Label>Initial Amount ($)</Label>
              <div className="flex space-x-2 mt-2">
                <Input
                  type="number"
                  value={initialAmount}
                  onChange={(e) => setInitialAmount(Number(e.target.value))}
                  className="bg-[#0d1526] border-[#1e3a5f]"
                />
                <Slider
                  min={0}
                  max={50000}
                  step={500}
                  value={[initialAmount]}
                  onValueChange={([value]) => setInitialAmount(value)}
                  className="flex-1"
                />
              </div>
            </div>
            
            <div>
              <Label>Monthly Investment ($)</Label>
              <div className="flex space-x-2 mt-2">
                <Input
                  type="number"
                  value={monthlyInvestment}
                  onChange={(e) => setMonthlyInvestment(Number(e.target.value))}
                  className="bg-[#0d1526] border-[#1e3a5f]"
                />
                <Slider
                  min={0}
                  max={5000}
                  step={100}
                  value={[monthlyInvestment]}
                  onValueChange={([value]) => setMonthlyInvestment(value)}
                  className="flex-1"
                />
              </div>
            </div>
            
            <div>
              <Label>Number of Months</Label>
              <div className="flex space-x-2 mt-2">
                <Input
                  type="number"
                  value={numberOfMonths}
                  onChange={(e) => setNumberOfMonths(Number(e.target.value))}
                  className="bg-[#0d1526] border-[#1e3a5f]"
                />
                <Slider
                  min={1}
                  max={120}
                  step={1}
                  value={[numberOfMonths]}
                  onValueChange={([value]) => setNumberOfMonths(value)}
                  className="flex-1"
                />
              </div>
            </div>
            
            <div>
              <Label>Annual Return Rate (e.g., 0.07 for 7%)</Label>
              <div className="flex space-x-2 mt-2">
                <Input
                  type="number"
                  value={annualReturnRate}
                  onChange={(e) => setAnnualReturnRate(Number(e.target.value))}
                  className="bg-[#0d1526] border-[#1e3a5f]"
                />
                <Slider
                  min={0}
                  max={0.15}
                  step={0.01}
                  value={[annualReturnRate]}
                  onValueChange={([value]) => setAnnualReturnRate(value)}
                  className="flex-1"
                />
              </div>
            </div>
          </div>
        </section>
        
        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4 text-emerald-400">Results</h2>
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />
          
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "portfolio", label: "Portfolio Value", color: "#10b981" }, { key: "contributions", label: "Total Contributions", color: "#06b6d4" }, { key: "withdrawals", label: "Cumulative Withdrawals", color: "#f59e0b" }, { key: "socialSecurity", label: "Social Security Income", color: "#a855f7" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle>Future Value of Lump Sum</CardTitle>
              </CardHeader>
              <CardContent>{formatDollars(calculations.fvLumpSum)}</CardContent>
            </Card>
            
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle>Future Value of DCA</CardTitle>
              </CardHeader>
              <CardContent>{formatDollars(calculations.fvDCA)}</CardContent>
            </Card>
            
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle>Difference (DCA - Lump Sum)</CardTitle>
              </CardHeader>
              <CardContent>{formatDollars(calculations.difference)}</CardContent>
            </Card>
          </div>
        </section>
        
        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4 text-emerald-400">IUL Advantage</h2>
          <Card className="bg-[#0d1526] border-[#1e3a5f] p-4">
            <CardContent>
              Indexed Universal Life (IUL) insurance offers tax-free growth on your investments, which can enhance both Dollar Cost Averaging and Lump Sum strategies by allowing your returns to compound without tax erosion. This could potentially increase your final values by up to 20-30% over time, depending on your tax bracket.
            </CardContent>
          </Card>
        </section>
        
        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-500 hover:bg-emerald-600"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("dca-vs-lump-sum", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-dca-vs-lump-sum");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Dollar Cost Averaging vs Lump Sum Calculator"
            calculatorRoute="dca-vs-lump-sum"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="d-c-avs-lump-sum-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/dca-vs-lump-sum" />
</div>
    </AppShell>
  );
}