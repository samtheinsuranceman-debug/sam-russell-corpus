// @ts-nocheck

import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Circle, CalculatorIcon, ShieldIcon, TrendingUpIcon} from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function AlimonyTaxCalc() {
  const autoFill = useCalculatorAutoFill("alimony-tax-impact");
  const { reportResult } = useCalcResults();
  const [annualIncome, setAnnualIncome] = useSharedField("annualIncome", 100000);
  const [alimonyPaid, setAlimonyPaid] = useState(20000);
  const [childSupportPaid, setChildSupportPaid] = useState(10000);
  const [federalTaxRate, setFederalTaxRate] = useSharedField("currentTaxBracket", 22);
  const [stateTaxRate, setStateTaxRate] = useState(5);

  const results = useMemo(() => {
    const taxableIncome = annualIncome - alimonyPaid;  // Simplified: Alimony is deductible
    const totalTaxRate = federalTaxRate + stateTaxRate;
    const taxesOwed = (taxableIncome * (totalTaxRate / 100));
    const netTakeHome = taxableIncome - taxesOwed;
    const taxSavingsFromAlimony = alimonyPaid * (totalTaxRate / 100);  // Tax savings due to deduction
    return {
      taxableIncome,
      taxesOwed,
      netTakeHome,
      taxSavingsFromAlimony,
    };
  }, [annualIncome, alimonyPaid, childSupportPaid, federalTaxRate, stateTaxRate]);
  const projectionData = useMemo(() => {
    const d = [];
    let opt = 100000, base = 100000, taxSav = 0;
    for (let yr = 0; yr <= 50; yr++) {
      opt *= 1.075;
      base *= 1.05;
      taxSav += (opt - base) * 0.08;
      d.push({ year: yr, optimized: Math.round(opt), baseline: Math.round(base), taxSavings: Math.round(taxSav), netBenefit: Math.round(opt - base + taxSav) });
    }
    return d;
  }, []);


  return (
    <AppShell
      headerTitle="Alimony / Child Support Tax Impact Calculator"
      headerSubtitle="Specialized Planning"
    >
      <div className="p-6 bg-[#0a0f1a] min-h-screen text-white">
        <AutoFillBanner calcRoute="alimony-tax-impact" />
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold mb-6 text-emerald-400">Input Your Financial Details</h2>
          
          {/* Input Section */}
          <Card className="bg-[#0d1526] mb-6">
            <CardHeader>
              <CardTitle className="text-emerald-400">Adjust Parameters</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label>Annual Income</Label>
                  <div className="flex items-center space-x-2">
                    <Slider
                      min={50000}
                      max={500000}
                      step={1000}
                      value={[annualIncome]}
                      onValueChange={(value) => setAnnualIncome(value[0])}
                      className="w-full"
                    />
                    <Input
                      type="number"
                      value={annualIncome}
                      onChange={(e) => setAnnualIncome(Number(e.target.value))}
                      className="w-32"
                    />
                  </div>
                </div>
                
                <div>
                  <Label>Alimony Paid Annually</Label>
                  <div className="flex items-center space-x-2">
                    <Slider
                      min={0}
                      max={100000}
                      step={1000}
                      value={[alimonyPaid]}
                      onValueChange={(value) => setAlimonyPaid(value[0])}
                      className="w-full"
                    />
                    <Input
                      type="number"
                      value={alimonyPaid}
                      onChange={(e) => setAlimonyPaid(Number(e.target.value))}
                      className="w-32"
                    />
                  </div>
                </div>
                
                <div>
                  <Label>Child Support Paid Annually</Label>
                  <div className="flex items-center space-x-2">
                    <Slider
                      min={0}
                      max={50000}
                      step={500}
                      value={[childSupportPaid]}
                      onValueChange={(value) => setChildSupportPaid(value[0])}
                      className="w-full"
                    />
                    <Input
                      type="number"
                      value={childSupportPaid}
                      onChange={(e) => setChildSupportPaid(Number(e.target.value))}
                      className="w-32"
                    />
                  </div>
                </div>
                
                <div>
                  <Label>Federal Tax Rate (%)</Label>
                  <div className="flex items-center space-x-2">
                    <Slider
                      min={10}
                      max={50}
                      step={1}
                      value={[federalTaxRate]}
                      onValueChange={(value) => setFederalTaxRate(value[0])}
                      className="w-full"
                    />
                    <Input
                      type="number"
                      value={federalTaxRate}
                      onChange={(e) => setFederalTaxRate(Number(e.target.value))}
                      className="w-32"
                    />
                  </div>
                </div>
                
                <div>
                  <Label>State Tax Rate (%)</Label>
                  <div className="flex items-center space-x-2">
                    <Slider
                      min={0}
                      max={15}
                      step={1}
                      value={[stateTaxRate]}
                      onValueChange={(value) => setStateTaxRate(value[0])}
                      className="w-full"
                    />
                    <Input
                      type="number"
                      value={stateTaxRate}
                      onChange={(e) => setStateTaxRate(Number(e.target.value))}
                      className="w-32"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Results Section */}
        {/* State Tax Impact */}
        <StateTaxSelector income={annualIncome} filingStatus={'single'} className="mb-6" />
          
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "optimized", label: "Optimized Strategy", color: "#10b981" }, { key: "baseline", label: "Baseline (No Action)", color: "#ef4444" }, { key: "taxSavings", label: "Cumulative Tax Savings", color: "#06b6d4" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="flex items-center text-emerald-400">
                  <CalculatorIcon className="mr-2" /> Taxable Income
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{formatDollars(results.taxableIncome)}</p>
              </CardContent>
            </Card>
            
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="flex items-center text-emerald-400">
                  <TrendingUpIcon className="mr-2" /> Taxes Owed
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{formatDollars(results.taxesOwed)}</p>
              </CardContent>
            </Card>
            
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="flex items-center text-emerald-400">
                  <ShieldIcon className="mr-2" /> Tax Savings from Alimony
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{formatDollars(results.taxSavingsFromAlimony)}</p>
              </CardContent>
            </Card>
          </div>
          
          {/* IUL Advantage Section */}
          <Card className="bg-[#0d1526] mb-6">
            <CardHeader>
              <CardTitle className="text-emerald-400">IUL Advantage</CardTitle>
            </CardHeader>
            <CardContent>
              <p>IUL offers tax-free growth, which can help offset the tax impact of alimony payments by providing a tax-efficient way to build wealth and potentially reduce your overall tax burden.</p>
            </CardContent>
          </Card>
          
          {/* Send to AI Advisor Button */}
          <Button
            onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
            className="bg-emerald-500 hover:bg-emerald-600"
          >
            Send to AI Advisor
          </Button>
        </div>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("alimony-tax-impact", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-alimony-tax-impact");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Alimony / Child Support Tax Impact Calculator"
            calculatorRoute="alimony-tax-impact"
            inputs={typeof results !== 'undefined' ? results : {}}
            results={typeof results !== 'undefined' ? results : {}}
            projectionData={projectionData}
          />
      <PageInsights section="alimony-tax-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/alimony-tax-impact" />
</div>
    </AppShell>
  );
}