// @ts-nocheck
import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Calculator, DollarSign, TrendingUp, Shield } from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function AssetAllocationCalc() {
  const autoFill = useCalculatorAutoFill("asset-allocation");
  const { reportResult } = useCalcResults();
  const [age, setAge] = useSharedField("currentAge", 30);
  const [retirementAge, setRetirementAge] = useSharedField("retirementAge", 65);
  const [balance, setBalance] = useState(100000);
  const [stockAllocation, setStockAllocation] = useState(60);
  const [stockReturn, setStockReturn] = useState(7);
  const [bondReturn, setBondReturn] = useState(3);
  const [rebalanceFrequency, setRebalanceFrequency] = useState("annually");

  const calculations = useMemo(() => {
    const yearsToRetirement = retirementAge - age;
    const effectiveReturn = (stockAllocation / 100) * (stockReturn / 100) + ((100 - stockAllocation) / 100) * (bondReturn / 100);
    const futureValue = balance * Math.pow(1 + effectiveReturn, yearsToRetirement);
    const iulAdvantage = futureValue * 1.15; // Simplified: 15% boost for tax-free growth in IUL
    return {
      projectedValue: futureValue,
      recommendedAllocation: stockAllocation + "% stocks / " + (100 - stockAllocation) + "% bonds",
      iulProjectedValue: iulAdvantage,
    };
  }, [age, retirementAge, balance, stockAllocation, stockReturn, bondReturn]);
  const projectionData = useMemo(() => {
    const d = [];
    const startVal = typeof investmentAmount !== 'undefined' ? investmentAmount : 100000;
    const annualAdd = typeof annualContribution !== 'undefined' ? annualContribution : 20000;
    let agg = startVal, mod = startVal, cons = startVal, infl = startVal;
    for (let yr = 0; yr <= 50; yr++) {
      d.push({ year: yr, aggressive: Math.round(agg), moderate: Math.round(mod), conservative: Math.round(cons), inflation: Math.round(infl) });
      agg = (agg + annualAdd) * 1.085;
      mod = (mod + annualAdd) * 1.065;
      cons = (cons + annualAdd) * 1.045;
      infl = (infl + annualAdd) * 1.03;
    }
    return d;
  }, []);


  return (
    <AppShell
      headerTitle="Asset Allocation & Rebalancing Calculator"
      headerSubtitle="Optimize your investments with IUL advantages"
      className="bg-[#0a0f1a] text-white"
    >
      <div className="p-6 space-y-8">
        <AutoFillBanner calcRoute="asset-allocation" />
        <section className="space-y-4">
          <h2 className="text-2xl font-bold">Input Your Details</h2>
          <div className="space-y-4">
            <div>
              <Label>Current Age</Label>
              <Input
                type="number"
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="bg-[#0d1526] border-[#1e3a5f]"
              />
            </div>
            <div>
              <Label>Retirement Age</Label>
              <Input
                type="number"
                value={retirementAge}
                onChange={(e) => setRetirementAge(Number(e.target.value))}
                className="bg-[#0d1526] border-[#1e3a5f]"
              />
            </div>
            <div>
              <Label>Current Balance</Label>
              <Input
                type="number"
                value={balance}
                onChange={(e) => setBalance(Number(e.target.value))}
                className="bg-[#0d1526] border-[#1e3a5f]"
              />
            </div>
            <div>
              <Label>Stock Allocation (%)</Label>
              <Slider
                min={0}
                max={100}
                step={1}
                value={[stockAllocation]}
                onValueChange={(value) => setStockAllocation(value[0])}
                className="mt-2"
              />
              <p className="text-sm mt-2">{stockAllocation}% in Stocks</p>
            </div>
            <div>
              <Label>Expected Stock Return (%)</Label>
              <Input
                type="number"
                value={stockReturn}
                onChange={(e) => setStockReturn(Number(e.target.value))}
                className="bg-[#0d1526] border-[#1e3a5f]"
              />
            </div>
            <div>
              <Label>Expected Bond Return (%)</Label>
              <Input
                type="number"
                value={bondReturn}
                onChange={(e) => setBondReturn(Number(e.target.value))}
                className="bg-[#0d1526] border-[#1e3a5f]"
              />
            </div>
            <div>
              <Label>Rebalance Frequency</Label>
              <Select onValueChange={(value) => setRebalanceFrequency(value)}>
                <SelectTrigger className="bg-[#0d1526] border-[#1e3a5f]">
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent className="bg-[#0d1526] border-[#1e3a5f]">
                  <SelectItem value="annually">Annually</SelectItem>
                  <SelectItem value="quarterly">Quarterly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold">Calculation Results</h2>
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />
          
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "aggressive", label: "Aggressive (8.5%)", color: "#10b981" }, { key: "moderate", label: "Moderate (6.5%)", color: "#06b6d4" }, { key: "conservative", label: "Conservative (4.5%)", color: "#f59e0b" }, { key: "inflation", label: "Inflation Erosion", color: "#ef4444" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-6 w-6 text-emerald-400" />
                  Projected Portfolio Value
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{formatDollars(calculations.projectedValue)}</p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-6 w-6 text-emerald-400" />
                  Recommended Allocation
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{calculations.recommendedAllocation}</p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-6 w-6 text-emerald-400" />
                  IUL Enhanced Value
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{formatDollars(calculations.iulProjectedValue)}</p>
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold">IUL Advantage</h2>
          <p>IUL provides tax-free growth, potentially increasing your projected value by 15% compared to traditional investments. This helps in preserving more of your earnings for retirement.</p>
        </section>

        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-500 hover:bg-emerald-600"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("asset-allocation", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-asset-allocation");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Asset Allocation & Rebalancing Calculator"
            calculatorRoute="asset-allocation"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="asset-allocation-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/asset-allocation" />
</div>
    </AppShell>
  );
}