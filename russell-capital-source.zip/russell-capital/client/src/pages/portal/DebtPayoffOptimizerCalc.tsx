// @ts-nocheck

import { useState, useMemo } from "react";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Circle, DollarSign, TrendingUp, Shield, CalculatorIcon, ClockIcon} from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function DebtPayoffOptimizerCalc() {
  const autoFill = useCalculatorAutoFill("debt-payoff-optimizer");
  const { reportResult } = useCalcResults();
  const [debtAmount, setDebtAmount] = useState(10000);
  const [interestRate, setInterestRate] = useState(5);
  const [monthlyPayment, setMonthlyPayment] = useState(200);
  const [extraPayment, setExtraPayment] = useState(0);

  const calculations = useMemo(() => {
    const monthlyRate = interestRate / 12 / 100;
    let balance = debtAmount;
    let months = 0;
    let totalInterest = 0;
    let paymentWithExtra = monthlyPayment + extraPayment;

    while (balance > 0 && months < 1000) {
      const interest = balance * monthlyRate;
      totalInterest += interest;
      balance = balance + interest - paymentWithExtra;
      if (balance < 0) balance = 0;
      months++;
    }

    const yearsToPayoff = months / 12;
    const totalPaid = months * paymentWithExtra + totalInterest;
    const iulGrowthAssumption = 6; // Assumed annual growth for IUL
    const iulPotential = extraPayment * months * (1 + iulGrowthAssumption / 12 / 100) ** months;

    return {
      yearsToPayoff,
      totalInterest,
      totalPaid,
      iulAdvantage: iulPotential - extraPayment * months, // Simplified advantage
    };
  }, [debtAmount, interestRate, monthlyPayment, extraPayment]);
  const projectionData = useMemo(() => {
    const d = [];
    const startWealth = typeof netWorth !== 'undefined' ? netWorth : 200000;
    const annualSave = typeof annualSavings !== 'undefined' ? annualSavings : 50000;
    let wealth = startWealth, invest = startWealth * 0.6, savings = startWealth * 0.1, debtPaid = 0;
    for (let yr = 0; yr <= 50; yr++) {
      invest = invest * 1.08 + annualSave * 0.7;
      savings = Math.min(annualSave * 2, savings * 1.04 + annualSave * 0.1);
      debtPaid += Math.min(annualSave * 0.2, 30000);
      wealth = invest + savings + debtPaid;
      d.push({ year: yr, totalWealth: Math.round(wealth), investments: Math.round(invest), savings: Math.round(savings), debtPayoff: Math.round(debtPaid) });
    }
    return d;
  }, []);


  return (
    <AppShell
      headerTitle="Debt Payoff Optimizer"
      headerSubtitle="Wealth Building & Savings"
    >
      <div className="p-6 bg-[#0a0f1a] min-h-screen text-white">
        <AutoFillBanner calcRoute="debt-payoff-optimizer" />
        <div className="max-w-4xl mx-auto">
          <Card className="bg-[#0d1526] mb-6">
            <CardHeader>
              <CardTitle className="flex items-center text-emerald-400">
                <CalculatorIcon className="mr-2" /> Input Your Debt Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="debtAmount">Debt Amount</Label>
                  <div className="flex items-center space-x-2">
                    <Input
                      id="debtAmount"
                      type="number"
                      value={debtAmount}
                      onChange={(e) => setDebtAmount(Number(e.target.value))}
                      className="bg-slate-700"
                    />
                    <Slider
                      min={0}
                      max={100000}
                      step={1000}
                      value={[debtAmount]}
                      onValueChange={(value) => setDebtAmount(value[0])}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="interestRate">Annual Interest Rate (%)</Label>
                  <div className="flex items-center space-x-2">
                    <Input
                      id="interestRate"
                      type="number"
                      value={interestRate}
                      onChange={(e) => setInterestRate(Number(e.target.value))}
                      className="bg-slate-700"
                    />
                    <Slider
                      min={0}
                      max={20}
                      step={0.1}
                      value={[interestRate]}
                      onValueChange={(value) => setInterestRate(value[0])}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="monthlyPayment">Monthly Payment</Label>
                  <div className="flex items-center space-x-2">
                    <Input
                      id="monthlyPayment"
                      type="number"
                      value={monthlyPayment}
                      onChange={(e) => setMonthlyPayment(Number(e.target.value))}
                      className="bg-slate-700"
                    />
                    <Slider
                      min={0}
                      max={5000}
                      step={50}
                      value={[monthlyPayment]}
                      onValueChange={(value) => setMonthlyPayment(value[0])}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="extraPayment">Extra Monthly Payment</Label>
                  <div className="flex items-center space-x-2">
                    <Input
                      id="extraPayment"
                      type="number"
                      value={extraPayment}
                      onChange={(e) => setExtraPayment(Number(e.target.value))}
                      className="bg-slate-700"
                    />
                    <Slider
                      min={0}
                      max={1000}
                      step={10}
                      value={[extraPayment]}
                      onValueChange={(value) => setExtraPayment(value[0])}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />

          
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "totalWealth", label: "Total Wealth", color: "#10b981" }, { key: "investments", label: "Investment Growth", color: "#06b6d4" }, { key: "savings", label: "Emergency Fund", color: "#f59e0b" }, { key: "debtPayoff", label: "Debt Eliminated", color: "#a855f7" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <ClockIcon className="mr-2 text-emerald-400" /> Payoff Time
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{calculations.yearsToPayoff.toFixed(1)} years</p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <DollarSign className="mr-2 text-emerald-400" /> Total Interest Paid
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{formatDollars(calculations.totalInterest)}</p>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1526]">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <DollarSign className="mr-2 text-emerald-400" /> Total Amount Paid
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{formatDollars(calculations.totalPaid)}</p>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-[#0d1526] mb-6">
            <CardHeader>
              <CardTitle className="flex items-center text-emerald-400">
                <Shield className="mr-2" /> IUL Advantage
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p>By redirecting extra payments to an IUL, you could grow your wealth tax-free. Potential IUL growth advantage: {formatDollars(calculations.iulAdvantage)} over the payoff period, assuming 6% annual growth.</p>
              <p>This shows how IUL provides tax-free growth, allowing your money to work harder compared to traditional debt payoff methods.</p>
            </CardContent>
          </Card>

          <Button
            onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
            className="bg-emerald-500 hover:bg-emerald-600"
          >
            Send to AI Advisor
          </Button>
        </div>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("debt-payoff-optimizer", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-debt-payoff-optimizer");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Debt Payoff Optimizer"
            calculatorRoute="debt-payoff-optimizer"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="debt-payoff-optimizer-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/debt-payoff-optimizer" />
</div>
    </AppShell>
  );
}