// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Building2, DollarSign, TrendingUp, Target, Calendar, Percent, ArrowRight, Shield, CheckCircle2, AlertTriangle, Users, Lock } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, AreaChart, Area, ComposedChart, Line } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

const ESOPLeveragedBuyoutPlanner = () => {
  const [companyValue, setCompanyValue] = useState(1000000); // Initial company value in USD
  const [growthRate, setGrowthRate] = useSharedField("growthRate", 5); // Annual growth rate in %
  const [esopLeveraged, setEsopLeveraged] = useState(true); // Leveraged or non-leveraged
  const [sellerRollover, setSellerRollover] = useState(false); // 1042 rollover
  const [sCorpExemption, setSCorpExemption] = useState(false); // S-corp ESOP tax exemption
  const [repurchaseYears, setRepurchaseYears] = useState(5); // Years for repurchase obligation
  const [allocationMethod, setAllocationMethod] = useState('compensation-based'); // Share allocation method
  const [managementBuyoutComparison, setManagementBuyoutComparison] = useState(false); // Compare with MBO
  const [projectionYears, setProjectionYears] = useSharedField("projectionYears", 50); // Years for projection
  const [complianceCheck, setComplianceCheck] = useState({ irc4975: false, section1042: false, section409: false, section415: false, erisa318: false, dolReg: false });

  const projections = useMemo(() => {
    const data = [];
    let currentValue = companyValue;
    for (let year = 0; year <= projectionYears; year++) {
      data.push({ year, companyValue: currentValue, employeeWealth: currentValue * 0.5 }); // Simplified projection
      currentValue *= (1 + growthRate / 100);
    }
    return data;
  }, [companyValue, growthRate, projectionYears]);

  const repurchaseObligation = useMemo(() => {
    let obligation = companyValue * 0.1; // Example: 10% of company value
    for (let year = 1; year <= repurchaseYears; year++) {
      obligation *= (1 + growthRate / 100);
    }
    return obligation;
  }, [companyValue, growthRate, repurchaseYears]);

  const chartData = projections.map((item) => ({
    year: item.year,
    companyValue: item.companyValue,
    employeeWealth: item.employeeWealth,
  }));

  return (
    <div style={{ backgroundColor: '#333333', color: '#FFFFFF', fontFamily: 'Arial, sans-serif', padding: '40px', minHeight: '100vh' }}>
      <header style={{ display: 'flex', alignItems: 'center', marginBottom: '40px' }}>
        <Building2 size={40} color="#DAA520" /> {/* Gold accent */}
        <h1 style={{ marginLeft: '10px', color: '#DAA520' }}>ESOP Leveraged Buyout Planner</h1> {/* Brown/Gold theme */}
      </header>

      <section style={{ marginBottom: '30px' }}>
        <h2 style={{ color: '#A52A2A' }}>ESOP Structure: Leveraged vs Non-Leveraged</h2> {/* Brown accent */}
        <p>Use borrowed funds for leveraged ESOP or direct purchase for non-leveraged. Select below:</p>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button onClick={() => setEsopLeveraged(true)} style={{ padding: '10px', backgroundColor: esopLeveraged ? '#A52A2A' : '#555', color: '#FFD700' }}>
            <DollarSign size={20} /> Leveraged
          </button>
          <button onClick={() => setEsopLeveraged(false)} style={{ padding: '10px', backgroundColor: !esopLeveraged ? '#A52A2A' : '#555', color: '#FFD700' }}>
            <DollarSign size={20} /> Non-Leveraged
          </button>
        </div>
        {esopLeveraged && <p>Leveraged ESOP allows tax-deductible loan interest, enabling larger buyouts.</p>}
      </section>

      <section style={{ marginBottom: '30px' }}>
        <h2 style={{ color: '#A52A2A' }}>1042 Rollover for C-Corp Sellers</h2>
        <p>Enable tax-deferred rollover: <input type="checkbox" checked={sellerRollover} onChange={() => setSellerRollover(!sellerRollover)} /></p>
        {sellerRollover && <p>Section 1042 allows C-corp sellers to defer capital gains taxes by rolling proceeds into qualified securities.</p>}
        <Shield size={30} color="#FFD700" />
      </section>

      <section style={{ marginBottom: '30px' }}>
        <h2 style={{ color: '#A52A2A' }}>S-Corp ESOP Tax Exemption</h2>
        <p>Enable S-corp exemption: <input type="checkbox" checked={sCorpExemption} onChange={() => setSCorpExemption(!sCorpExemption)} /></p>
        {sCorpExemption && <p>ESOP-owned S-corps are exempt from federal income taxes on the portion owned by the ESOP.</p>}
        <Percent size={30} color="#FFD700" />
      </section>

      <section style={{ marginBottom: '30px' }}>
        <h2 style={{ color: '#A52A2A' }}>Repurchase Obligation Projector</h2>
        <p>Years for repurchase: <input type="number" value={repurchaseYears} onChange={(e) => setRepurchaseYears(Number(e.target.value))} style={{ backgroundColor: '#555', color: '#FFF' }} /></p>
        <p>Projected obligation: ${repurchaseObligation.toFixed(2)}</p>
        <TrendingUp size={30} color="#FFD700" />
      </section>

      <section style={{ marginBottom: '30px' }}>
        <h2 style={{ color: '#A52A2A' }}>Share Allocation Methodology</h2>
        <p>Select method: 
          <select value={allocationMethod} onChange={(e) => setAllocationMethod(e.target.value)} style={{ backgroundColor: '#555', color: '#FFF' }}>
            <option value="compensation-based">Compensation-Based</option>
            <option value="age-based">Age-Based</option>
            <option value="service-based">Service-Based</option>
          </select>
        </p>
        {allocationMethod === 'compensation-based' && <p>Allocates shares based on employee compensation, promoting fairness.</p>}
        <Users size={30} color="#FFD700" />
      </section>

      <section style={{ marginBottom: '30px' }}>
        <h2 style={{ color: '#A52A2A' }}>ESOP vs Management Buyout Comparison</h2>
        <p>Compare with MBO: <input type="checkbox" checked={managementBuyoutComparison} onChange={() => setManagementBuyoutComparison(!managementBuyoutComparison)} /></p>
        {managementBuyoutComparison && <p>ESOP offers tax benefits and employee ownership, while MBO focuses on management control.</p>}
        <ArrowRight size={30} color="#FFD700" />
      </section>

      <section style={{ marginBottom: '30px' }}>
        <h2 style={{ color: '#A52A2A' }}>50-Year Company Value and Employee Wealth Projection</h2>
        <p>Projection years: <input type="number" value={projectionYears} onChange={(e) => setProjectionYears(Number(e.target.value))} style={{ backgroundColor: '#555', color: '#FFF' }} /></p>
        <ResponsiveContainer width="100%" height={400}>
          <ComposedChart data={chartData}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="companyValue" fill="#A52A2A" stroke="#FFD700" />
            <Line type="monotone" dataKey="employeeWealth" stroke="#DAA520" />
            <Bar dataKey="year" fill="#555" />
          </ComposedChart>
        </ResponsiveContainer>
        <Target size={30} color="#FFD700" />
      </section>

      <section style={{ marginBottom: '30px' }}>
        <h2 style={{ color: '#A52A2A' }}>Compliance Checklist</h2>
        <ul>
          <li>
            IRC 4975(e)(7) ESOP Definition: <input type="checkbox" checked={complianceCheck.irc4975} onChange={() => setComplianceCheck({...complianceCheck, irc4975: !complianceCheck.irc4975})} />
            {complianceCheck.irc4975 ? <CheckCircle2 size={20} color="#FFD700" /> : <AlertTriangle size={20} color="#FF4500" />}
          </li>
          <li>
            Section 1042 Seller Rollover: <input type="checkbox" checked={complianceCheck.section1042} onChange={() => setComplianceCheck({...complianceCheck, section1042: !complianceCheck.section1042})} />
            {complianceCheck.section1042 ? <CheckCircle2 size={20} color="#FFD700" /> : <AlertTriangle size={20} color="#FF4500" />}
          </li>
          <li>
            Section 409 ESOP Requirements: <input type="checkbox" checked={complianceCheck.section409} onChange={() => setComplianceCheck({...complianceCheck, section409: !complianceCheck.section409})} />
            {complianceCheck.section409 ? <CheckCircle2 size={20} color="#FFD700" /> : <AlertTriangle size={20} color="#FF4500" />}
          </li>
          <li>
            Section 415 Contribution Limits: <input type="checkbox" checked={complianceCheck.section415} onChange={() => setComplianceCheck({...complianceCheck, section415: !complianceCheck.section415})} />
            {complianceCheck.section415 ? <CheckCircle2 size={20} color="#FFD700" /> : <AlertTriangle size={20} color="#FF4500" />}
          </li>
          <li>
            ERISA Section 3(18) Adequate Consideration: <input type="checkbox" checked={complianceCheck.erisa318} onChange={() => setComplianceCheck({...complianceCheck, erisa318: !complianceCheck.erisa318})} />
            {complianceCheck.erisa318 ? <CheckCircle2 size={20} color="#FFD700" /> : <AlertTriangle size={20} color="#FF4500" />}
          </li>
          <li>
            DOL Reg. 2510.3-18: <input type="checkbox" checked={complianceCheck.dolReg} onChange={() => setComplianceCheck({...complianceCheck, dolReg: !complianceCheck.dolReg})} />
            {complianceCheck.dolReg ? <CheckCircle2 size={20} color="#FFD700" /> : <AlertTriangle size={20} color="#FF4500" />}
          </li>
        </ul>
        <Lock size={30} color="#FFD700" />
      </section>

      <footer style={{ marginTop: '50px', textAlign: 'center', color: '#A52A2A' }}>
        <p>Disclaimer: This tool is for illustrative purposes. Consult a professional for actual ESOP planning.</p>
        <Calendar size={20} color="#FFD700" />
      </footer>
      <PageInsights section="e-s-o-p-leveraged-buyout-planner" />
    </div>
  );
};

export default ESOPLeveragedBuyoutPlanner;
