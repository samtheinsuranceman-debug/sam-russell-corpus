// @ts-nocheck
import React, { useState } from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { DollarSign, Percent, BarChart3, PieChartIcon, Info } from 'lucide-react';
import { toast } from 'sonner';
import { PageInsights } from '@/components/PageInsights';

const CharitableGivingOptimizer = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [contribution, setContribution] = useState(10000);
  const [isDAF, setIsDAF] = useState(false);
  const [isAppreciatedStock, setIsAppreciatedStock] = useState(false);

  // Sample data for charts
  const taxBenefitData = [
    { year: '2023', cash: 3000, stock: 4500, daf: 5000 },
    { year: '2024', cash: 3200, stock: 4700, daf: 5200 },
    { year: '2025', cash: 3400, stock: 4900, daf: 5400 },
    { year: '2026', cash: 3600, stock: 5100, daf: 5600 },
  ];

  const agiLimitData = [
    { type: 'Cash', limit: 60, used: 40 },
    { type: 'Appreciated Property', limit: 30, used: 20 },
    { type: 'Private Foundation', limit: 20, used: 10 },
  ];

  const handleContributionChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value) || 0;
    if (value < 0) {
      toast.error('Contribution cannot be negative');
      return;
    }
    setContribution(value);
  };

  const calculateTaxBenefit = () => {
    let multiplier = isAppreciatedStock ? 1.5 : 1.0;
    if (isDAF) multiplier += 0.2;
    return Math.min(contribution * multiplier * 0.3, 50000); // Simplified calculation
  };

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <DollarSign className="text-emerald-400" size={28} />
          Charitable Giving Optimizer
        </h1>
        <p className="text-[#7a95b8] mb-6">Maximize tax benefits through strategic charitable contributions.</p>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 border-b border-[#1e3a5f]">
          {['overview', 'strategies', 'limits', 'tools'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-t-md font-medium ${
                activeTab === tab
                  ? 'bg-emerald-500 text-white'
                  : 'bg-[#0d1526] text-[#7a95b8] hover:bg-[#1e3a5f]'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="bg-[#0d1526] p-6 rounded-lg shadow-md border border-[#1e3a5f]">
          {activeTab === 'overview' && (
            <div>
              <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
                <BarChart3 className="text-emerald-400" size={24} />
                Tax Benefit Projection
              </h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={taxBenefitData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                      <XAxis dataKey="year" stroke="#7a95b8" />
                      <YAxis stroke="#7a95b8" />
                      <Tooltip formatter={(value) => `$${value}`} contentStyle={{ backgroundColor: '#0a0f1a', borderColor: '#1e3a5f' }} />
                      <Line type="monotone" dataKey="cash" stroke="#fff" name="Cash Donation" />
                      <Line type="monotone" dataKey="stock" stroke="#34d399" name="Appreciated Stock" />
                      <Line type="monotone" dataKey="daf" stroke="#10b981" name="DAF Strategy" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={agiLimitData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                      <XAxis dataKey="type" stroke="#7a95b8" />
                      <YAxis stroke="#7a95b8" />
                      <Tooltip formatter={(value) => `${value}%`} contentStyle={{ backgroundColor: '#0a0f1a', borderColor: '#1e3a5f' }} />
                      <Bar dataKey="limit" fill="#34d399" name="AGI Limit" />
                      <Bar dataKey="used" fill="#10b981" name="Used" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'strategies' && (
            <div>
              <h2 className="text-2xl font-semibold mb-4">Contribution Strategies</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 border border-[#1e3a5f] rounded-md">
                  <h3 className="text-lg font-medium mb-2">Donor-Advised Fund (DAF)</h3>
                  <p className="text-[#7a95b8] text-sm">Bunch contributions for maximum deduction. Toggle to see impact.</p>
                  <label className="flex items-center gap-2 mt-2">
                    <input type="checkbox" checked={isDAF} onChange={() => setIsDAF(!isDAF)} className="accent-emerald-500" />
                    Use DAF Strategy
                  </label>
                </div>
                <div className="p-4 border border-[#1e3a5f] rounded-md">
                  <h3 className="text-lg font-medium mb-2">Appreciated Stock Donation</h3>
                  <p className="text-[#7a95b8] text-sm">Avoid capital gains tax by donating stock vs. cash.</p>
                  <label className="flex items-center gap-2 mt-2">
                    <input
                      type="checkbox"
                      checked={isAppreciatedStock}
                      onChange={() => setIsAppreciatedStock(!isAppreciatedStock)}
                      className="accent-emerald-500"
                    />
                    Donate Stock
                  </label>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'limits' && (
            <div>
              <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
                <Percent className="text-emerald-400" size={24} />
                AGI Limitations (§170)
              </h2>
              <p className="text-[#7a95b8] mb-4">
                IRS limits: 60% AGI for cash, 30% for appreciated property, 20% for private foundations. 5-year carryforward available.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 border border-[#1e3a5f] rounded-md text-center">
                  <p className="text-3xl font-bold text-emerald-400">60%</p>
                  <p className="text-[#7a95b8]">Cash Donations</p>
                </div>
                <div className="p-4 border border-[#1e3a5f] rounded-md text-center">
                  <p className="text-3xl font-bold text-emerald-400">30%</p>
                  <p className="text-[#7a95b8]">Appreciated Property</p>
                </div>
                <div className="p-4 border border-[#1e3a5f] rounded-md text-center">
                  <p className="text-3xl font-bold text-emerald-400">20%</p>
                  <p className="text-[#7a95b8]">Private Foundations</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'tools' && (
            <div>
              <h2 className="text-2xl font-semibold mb-4">Contribution Calculator</h2>
              <div className="max-w-md">
                <label className="block text-[#7a95b8] mb-2">Annual Contribution ($)</label>
                <input
                  type="number"
                  value={contribution}
                  onChange={handleContributionChange}
                  className="w-full p-2 bg-[#0a0f1a] border border-[#1e3a5f] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <div className="mt-4 p-4 border border-[#1e3a5f] rounded-md">
                  <p className="text-lg font-medium">Estimated Tax Benefit</p>
                  <p className="text-2xl text-emerald-400">${calculateTaxBenefit().toLocaleString()}</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Info Note */}
        <div className="mt-6 p-4 bg-[#0d1526] border border-[#1e3a5f] rounded-md flex items-start gap-2">
          <Info className="text-emerald-400 mt-1" size={20} />
          <p className="text-[#7a95b8] text-sm">
            Calculations are estimates. Consult a tax professional for Qualified Charitable Distributions (QCD) after age 70.5,
            Charitable Remainder Trusts (CRT), or Charitable Lead Trusts (CLT) for estate planning.
          </p>
        </div>
      </div>
      <PageInsights section="charitable-giving-optimizer" />
    </div>
  );
};

export default CharitableGivingOptimizer;