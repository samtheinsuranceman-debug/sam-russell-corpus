// @ts-nocheck
import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Calculator } from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function CompoundInterestCalc() {
  const autoFill = useCalculatorAutoFill("compound-interest");
  const { reportResult } = useCalcResults();
  const [principal, setPrincipal] = useState(1000);
  const [rate, setRate] = useState(5);
  const [years, setYears] = useSharedField("projectionYears", 10);
  const [annualContribution, setAnnualContribution] = useState(500);

  const calculations = useMemo(() => {
    const futureValue = principal * Math.pow(1 + rate / 100, years) + 
      annualContribution * ((Math.pow(1 + rate / 100, years) - 1) / (rate / 100));
    const totalContributions = principal + annualContribution * years;
    const iulAdvantage = futureValue * 0.10;  // Hypothetical 10% additional growth due to tax-free benefits
    return { futureValue, totalContributions, iulAdvantage };
  }, [principal, rate, years, annualContribution]);
  const projectionData = useMemo(() => {
    const d = [];
    const startWealth = typeof netWorth !== 'undefined' ? netWorth : 200000;
    const annualSave = typeof annualSavings !== 'undefined' ? annualSavings : 50000;
    let wealth = startWealth, invest = startWealth * 0.6, savings = startWealth * 0.1, debtPaid = 0;
    for (let yr = 0; yr <= 50; yr++) {
      invest = invest * 1.08 + annualSave * 0.7;
      savings = Math.min(annualSave * 2, savings * 1.04 + annualSave * 0.1);
      debtPaid += Math.min(annualSave * 0.2, 30000);
      wealth = invest + savings + debtPaid;
      d.push({ year: yr, totalWealth: Math.round(wealth), investments: Math.round(invest), savings: Math.round(savings), debtPayoff: Math.round(debtPaid) });
    }
    return d;
  }, []);


  return (
    <AppShell className="bg-[#0a0f1a] text-white">
      <div className="p-6 max-w-6xl mx-auto">
        <AutoFillBanner calcRoute="compound-interest" />
        <div className="flex items-center mb-6">
          <Calculator className="mr-2 text-emerald-400" />
          <h1 className="text-2xl font-bold">Compound Interest & Time Value of Money Calculator</h1>
        </div>
        
        <p className="mb-6 text-[#94a3b8]">Calculate your savings growth and see how IUL can enhance it with tax-free advantages.</p>

        {/* Input Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="space-y-2">
            <Label>Initial Principal ($)</Label>
            <Input 
              type="number" 
              min="0" 
              max="100000" 
              step="100" 
              value={principal} 
              onChange={(e) => setPrincipal(Number(e.target.value))} 
              className="bg-[#0d1526] border-[#1e3a5f]"
            />
            <Slider 
              min={0} 
              max={100000} 
              step={1000} 
              value={[principal]} 
              onValueChange={(value) => setPrincipal(value[0])} 
              className="mt-2"
            />
          </div>

          <div className="space-y-2">
            <Label>Annual Interest Rate (%)</Label>
            <Input 
              type="number" 
              min="0" 
              max="15" 
              step="0.1" 
              value={rate} 
              onChange={(e) => setRate(Number(e.target.value))} 
              className="bg-[#0d1526] border-[#1e3a5f]"
            />
            <Slider 
              min={0} 
              max={15} 
              step={0.5} 
              value={[rate]} 
              onValueChange={(value) => setRate(value[0])} 
              className="mt-2"
            />
          </div>

          <div className="space-y-2">
            <Label>Number of Years</Label>
            <Input 
              type="number" 
              min="1" 
              max="50" 
              step="1" 
              value={years} 
              onChange={(e) => setYears(Number(e.target.value))} 
              className="bg-[#0d1526] border-[#1e3a5f]"
            />
            <Slider 
              min={1} 
              max={50} 
              step={1} 
              value={[years]} 
              onValueChange={(value) => setYears(value[0])} 
              className="mt-2"
            />
          </div>

          <div className="space-y-2">
            <Label>Annual Contribution ($)</Label>
            <Input 
              type="number" 
              min="0" 
              max="10000" 
              step="100" 
              value={annualContribution} 
              onChange={(e) => setAnnualContribution(Number(e.target.value))} 
              className="bg-[#0d1526] border-[#1e3a5f]"
            />
            <Slider 
              min={0} 
              max={10000} 
              step={500} 
              value={[annualContribution]} 
              onValueChange={(value) => setAnnualContribution(value[0])} 
              className="mt-2"
            />
          </div>
        </div>

        {/* Results Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle>Future Value</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-emerald-400">{formatDollars(calculations.futureValue)}</p>
            </CardContent>
          </Card>

          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle>Total Contributions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-emerald-400">{formatDollars(calculations.totalContributions)}</p>
            </CardContent>
          </Card>

          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle>Estimated IUL Advantage</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-emerald-400">{formatDollars(calculations.iulAdvantage)}</p>
            </CardContent>
          </Card>
        </div>

        {/* IUL Advantage Section */}
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />
        
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "totalWealth", label: "Total Wealth", color: "#10b981" }, { key: "investments", label: "Investment Growth", color: "#06b6d4" }, { key: "savings", label: "Emergency Fund", color: "#f59e0b" }, { key: "debtPayoff", label: "Debt Eliminated", color: "#a855f7" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="mb-8 p-4 bg-[#0d1526] border border-[#1e3a5f] rounded-lg">
          <h2 className="text-xl font-bold mb-2">IUL Advantage</h2>
          <p className="text-[#94a3b8]">
            Indexed Universal Life (IUL) insurance offers tax-free growth on your investments, 
            potentially adding " + formatDollars(calculations.iulAdvantage) + " in extra value compared to traditional compound interest accounts. 
            This calculator assumes a 10% boost from tax advantages, helping you build wealth more efficiently.
          </p>
        </div>

        {/* Send to AI Advisor Button */}
        <Button 
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")} 
          className="bg-emerald-500 hover:bg-emerald-600"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("compound-interest", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-compound-interest");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Compound Interest & Time Value of Money Calculator"
            calculatorRoute="compound-interest"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="compound-interest-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/compound-interest" />
</div>
    </AppShell>
  );
}