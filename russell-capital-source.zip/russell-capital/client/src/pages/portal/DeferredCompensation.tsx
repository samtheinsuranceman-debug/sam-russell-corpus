// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Clock, DollarSign, TrendingUp, Shield, CheckCircle2, AlertTriangle, ArrowRight, Target, Calendar, Award, Lock, Scale } from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  Legend, 
  BarChart, 
  Bar, 
  ComposedChart, 
  Line 
} from 'recharts';
import { PageInsights } from "@/components/PageInsights";

export default function DeferredCompensation() {
  const [currentIncome, setCurrentIncome] = useSharedField("annualIncome", 600000); // Default: $600,000
  const [deferralAmount, setDeferralAmount] = useState(200000); // Default: $200,000
  const [yearsToRetirement, setYearsToRetirement] = useSharedField("projectionYears", 15); // Default: 15 years

  // Calculate tax arbitrage data
  const currentTaxRate = 0.37; // 37%
  const retirementTaxRate = 0.24; // 24% projected
  const currentTax = deferralAmount * currentTaxRate; // $74,000
  const retirementTax = deferralAmount * retirementTaxRate; // $48,000
  const annualTaxSavings = currentTax - retirementTax; // $26,000
  const totalTaxSavings = annualTaxSavings * yearsToRetirement; // $390,000

  // Generate accumulation data with 7% growth rate
  const accumulationData = useMemo(() => {
    const growthRate = 0.07; // 7%
    const data = [];
    let accumulatedValue = 0;
    for (let year = 1; year <= yearsToRetirement; year++) {
      accumulatedValue += deferralAmount * Math.pow(1 + growthRate, year - 1); // Simplified accumulation
      data.push({ year, value: accumulatedValue });
    }
    return data;
  }, [deferralAmount, yearsToRetirement]);

  // Specific values from requirements
  const year5Value = accumulationData[4]?.value || 1150000; // Year 5: $1.15M
  const year10Value = accumulationData[9]?.value || 2760000; // Year 10: $2.76M
  const year15Value = accumulationData[14]?.value || 5020000; // Year 15: $5.02M
  const taxDeferredAdvantage = 1200000; // $1.2M more than taxable

  // Distribution strategies calculations
  const lumpSumAmount = year15Value; // $5.02M
  const lumpSumTaxRate = 0.37; // 37%
  const lumpSumTax = lumpSumAmount * lumpSumTaxRate; // $1.86M

  const installment10YearsAmount = lumpSumAmount / 10; // $502K/yr
  const installment10YearsTaxRate = 0.32; // 32%
  const installment10YearsAnnualTax = installment10YearsAmount * installment10YearsTaxRate; // $160K/yr
  const installment10YearsTotalTax = installment10YearsAnnualTax * 10; // $1.6M
  const installment10YearsSavings = lumpSumTax - installment10YearsTotalTax; // $260K savings

  const installment20YearsAmount = lumpSumAmount / 20; // $251K/yr
  const installment20YearsTaxRate = 0.24; // 24%
  const installment20YearsAnnualTax = installment20YearsAmount * installment20YearsTaxRate; // $60K/yr
  const installment20YearsTotalTax = installment20YearsAnnualTax * 20; // $1.2M
  const installment20YearsSavings = lumpSumTax - installment20YearsTotalTax; // $660K savings

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white font-sans">
      {/* Header Section */}
      <header className="p-8 bg-violet-900 text-center">
        <h1 className="text-4xl font-bold mb-4">Nonqualified Deferred Compensation Planner</h1>
        <div className="flex justify-center space-x-4">
          <div className="flex items-center">
            <DollarSign className="mr-2" size={24} color="emerald" />
            <span>Current Income: ${currentIncome.toLocaleString()}</span>
            <input
              type="number"
              value={currentIncome}
              onChange={(e) => setCurrentIncome(Number(e.target.value))}
              className="ml-2 p-1 bg-[#0d1526] border border-violet-500 rounded"
            />
          </div>
          <div className="flex items-center">
            <Clock className="mr-2" size={24} color="emerald" />
            <span>Deferral Amount: ${deferralAmount.toLocaleString()}</span>
            <input
              type="number"
              value={deferralAmount}
              onChange={(e) => setDeferralAmount(Number(e.target.value))}
              className="ml-2 p-1 bg-[#0d1526] border border-violet-500 rounded"
            />
          </div>
          <div className="flex items-center">
            <Calendar className="mr-2" size={24} color="emerald" />
            <span>Years to Retirement: {yearsToRetirement}</span>
            <input
              type="number"
              value={yearsToRetirement}
              onChange={(e) => setYearsToRetirement(Number(e.target.value))}
              className="ml-2 p-1 bg-[#0d1526] border border-violet-500 rounded"
            />
          </div>
        </div>
      </header>

      {/* Tax Arbitrage Section */}
      <section className="p-8 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#0d1526] p-6 rounded-lg shadow-lg border-l-4 border-emerald-500">
          <TrendingUp size={32} color="emerald" className="mb-4" />
          <h2 className="text-2xl font-semibold mb-2">Current Tax on ${deferralAmount.toLocaleString()}</h2>
          <p className="text-emerald-400">${currentTax.toLocaleString()} (37%)</p>
        </div>
        <div className="bg-[#0d1526] p-6 rounded-lg shadow-lg border-l-4 border-violet-500">
          <ArrowRight size={32} color="violet" className="mb-4" />
          <h2 className="text-2xl font-semibold mb-2">Deferred to Retirement</h2>
          <p>Projected Retirement Bracket: 24%</p>
          <p>Tax on ${deferralAmount.toLocaleString()} at 24%: ${retirementTax.toLocaleString()}</p>
        </div>
        <div className="bg-[#0d1526] p-6 rounded-lg shadow-lg border-l-4 border-emerald-500">
          <Shield size={32} color="emerald" className="mb-4" />
          <h2 className="text-2xl font-semibold mb-2">Tax Savings</h2>
          <p>Per Year: ${annualTaxSavings.toLocaleString()}</p>
          <p>{yearsToRetirement}-Year Savings: ${totalTaxSavings.toLocaleString()}</p>
        </div>
      </section>

      {/* Accumulation Projection Section */}
      <section className="p-8 bg-[#0d1526] rounded-lg shadow-lg">
        <h2 className="text-3xl font-bold mb-4 flex items-center"><Target size={28} color="violet" className="mr-2" /> Accumulation Projection</h2>
        <p>Deferring ${deferralAmount.toLocaleString()}/yr at 7% growth</p>
        <p>Year 5: ${year5Value.toLocaleString()}</p>
        <p>Year 10: ${year10Value.toLocaleString()}</p>
        <p>Year 15: ${year15Value.toLocaleString()}</p>
        <p>Tax-deferred advantage: ${taxDeferredAdvantage.toLocaleString()} more than taxable</p>
        <div className="mt-6 h-96">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={accumulationData}>
              <XAxis dataKey="year" stroke="white" />
              <YAxis stroke="white" />
              <Tooltip />
              <Legend />
              <Area type="monotone" dataKey="value" stroke="emerald" fill="violet" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Distribution Strategies Section */}
      <section className="p-8 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#0d1526] p-6 rounded-lg shadow-lg border-l-4 border-emerald-500">
          <h2 className="text-2xl font-semibold mb-2 flex items-center"><Award size={28} color="emerald" className="mr-2" /> Strategy 1: Lump Sum</h2>
          <p>${lumpSumAmount.toLocaleString()} taxed in one year</p>
          <p>Tax at 37%: ${lumpSumTax.toLocaleString()}</p>
        </div>
        <div className="bg-[#0d1526] p-6 rounded-lg shadow-lg border-l-4 border-violet-500">
          <h2 className="text-2xl font-semibold mb-2 flex items-center"><Lock size={28} color="violet" className="mr-2" /> Strategy 2: 10-Year Installments</h2>
          <p>${installment10YearsAmount.toLocaleString()}/yr for 10 years</p>
          <p>Tax at 32%: ${installment10YearsAnnualTax.toLocaleString()}/yr</p>
          <p>Total Tax: ${installment10YearsTotalTax.toLocaleString()} (Save ${installment10YearsSavings.toLocaleString()} vs Lump Sum)</p>
        </div>
        <div className="bg-[#0d1526] p-6 rounded-lg shadow-lg border-l-4 border-emerald-500">
          <h2 className="text-2xl font-semibold mb-2 flex items-center"><Scale size={28} color="emerald" className="mr-2" /> Strategy 3: 20-Year Installments</h2>
          <p>${installment20YearsAmount.toLocaleString()}/yr for 20 years</p>
          <p>Tax at 24%: ${installment20YearsAnnualTax.toLocaleString()}/yr</p>
          <p>Total Tax: ${installment20YearsTotalTax.toLocaleString()} (Save ${installment20YearsSavings.toLocaleString()} vs Lump Sum)</p>
        </div>
      </section>

      {/* Risks Section */}
      <section className="p-8 bg-[#0d1526] rounded-lg shadow-lg">
        <h2 className="text-3xl font-bold mb-4 flex items-center"><AlertTriangle size={28} color="violet" className="mr-2" /> Risks</h2>
        <ul className="list-disc pl-5 space-y-2">
          <li>Unsecured creditor risk (employer bankruptcy) - <Shield size={18} color="emerald" /></li>
          <li>IRC section 409A penalties (20% + interest) - <AlertTriangle size={18} color="violet" /></li>
          <li>No portability between employers - <ArrowRight size={18} color="emerald" /></li>
          <li>Irrevocable election timing - <Clock size={18} color="violet" /></li>
          <li>FICA tax timing considerations - <DollarSign size={18} color="emerald" /></li>
        </ul>
      </section>

      {/* IRS Compliance Section */}
      <section className="p-8 bg-[#0d1526] rounded-lg shadow-lg">
        <h2 className="text-3xl font-bold mb-4 flex items-center"><CheckCircle2 size={28} color="emerald" className="mr-2" /> IRS Compliance</h2>
        <ul className="list-disc pl-5 space-y-2">
          <li>IRC section 409A deferred compensation rules - <Lock size={18} color="violet" /></li>
          <li>IRC section 3121(v)(2) FICA timing - <Calendar size={18} color="emerald" /></li>
          <li>Treas. Reg. section 1.409A-1 through 1.409A-6 - <Scale size={18} color="violet" /></li>
          <li>6-month delay for specified employees (section 409A(a)(2)(B)) - <Clock size={18} color="emerald" /></li>
        </ul>
      </section>

      {/* Footer for additional spacing */}
      <footer className="p-8 text-center text-gray-500">
        <p>Built with React, Tailwind CSS, and Recharts. Dark theme with violet/emerald accents.</p>
        <p>Disclaimer: This is for illustrative purposes only. Consult a tax professional.</p>
      </footer>
      <PageInsights section="deferred-compensation" />
    </div>
  );
}
