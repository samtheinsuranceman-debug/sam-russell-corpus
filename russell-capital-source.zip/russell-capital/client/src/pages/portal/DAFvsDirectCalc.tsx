// @ts-nocheck

import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Circle, CalculatorIcon} from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function DAFvsDirectCalc() {
  const autoFill = useCalculatorAutoFill("daf-vs-direct-giving");
  const { reportResult } = useCalcResults();
  const [annualDonation, setAnnualDonation] = useState(1000);
  const [growthRate, setGrowthRate] = useSharedField("growthRate", 5);
  const [years, setYears] = useSharedField("projectionYears", 10);
  const [taxRate, setTaxRate] = useSharedField("currentTaxBracket", 25);

  const results = useMemo(() => {
    const directGivingTotal = annualDonation * years;
    const dafFutureValue = annualDonation * Math.pow(1 + growthRate / 100, years);
    const taxSavingsAnnual = (annualDonation * taxRate / 100);
    const totalTaxSavings = taxSavingsAnnual * years;
    
    return {
      directGivingTotal,
      dafFutureValue,
      totalTaxSavings,
    };
  }, [annualDonation, growthRate, years, taxRate]);
  const projectionData = useMemo(() => {
    const d = [];
    let opt = 100000, base = 100000, taxSav = 0;
    for (let yr = 0; yr <= 50; yr++) {
      opt *= 1.075;
      base *= 1.05;
      taxSav += (opt - base) * 0.08;
      d.push({ year: yr, optimized: Math.round(opt), baseline: Math.round(base), taxSavings: Math.round(taxSav), netBenefit: Math.round(opt - base + taxSav) });
    }
    return d;
  }, []);


  return (
    <AppShell>
      <div className="min-h-screen bg-[#0a0f1a] p-6 text-white">
        <AutoFillBanner calcRoute="daf-vs-direct-giving" />
        <div className="flex items-center mb-6">
          <CalculatorIcon className="mr-2 h-6 w-6 text-emerald-400" />
          <h1 className="text-2xl font-bold">DAF vs Direct Giving Calculator</h1>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="space-y-4">
            <div>
              <Label htmlFor="annualDonation">Annual Donation Amount</Label>
              <Slider
                id="annualDonation"
                min={100}
                max={10000}
                step={100}
                value={[annualDonation]}
                onValueChange={(value) => setAnnualDonation(value[0])}
                className="mt-2"
              />
              <Input
                type="number"
                value={annualDonation}
                onChange={(e) => setAnnualDonation(Number(e.target.value))}
                className="mt-2 bg-[#0d1526] border-[#1e3a5f]"
                min={100}
                max={10000}
              />
            </div>
            <div>
              <Label htmlFor="growthRate">Investment Growth Rate (%)</Label>
              <Slider
                id="growthRate"
                min={0}
                max={10}
                step={0.5}
                value={[growthRate]}
                onValueChange={(value) => setGrowthRate(value[0])}
                className="mt-2"
              />
              <Input
                type="number"
                value={growthRate}
                onChange={(e) => setGrowthRate(Number(e.target.value))}
                className="mt-2 bg-[#0d1526] border-[#1e3a5f]"
                min={0}
                max={10}
              />
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <Label htmlFor="years">Time Horizon (Years)</Label>
              <Slider
                id="years"
                min={1}
                max={30}
                step={1}
                value={[years]}
                onValueChange={(value) => setYears(value[0])}
                className="mt-2"
              />
              <Input
                type="number"
                value={years}
                onChange={(e) => setYears(Number(e.target.value))}
                className="mt-2 bg-[#0d1526] border-[#1e3a5f]"
                min={1}
                max={30}
              />
            </div>
            <div>
              <Label htmlFor="taxRate">Tax Rate (%)</Label>
              <Slider
                id="taxRate"
                min={10}
                max={50}
                step={5}
                value={[taxRate]}
                onValueChange={(value) => setTaxRate(value[0])}
                className="mt-2"
              />
              <Input
                type="number"
                value={taxRate}
                onChange={(e) => setTaxRate(Number(e.target.value))}
                className="mt-2 bg-[#0d1526] border-[#1e3a5f]"
                min={10}
                max={50}
              />
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle>Direct Giving Total</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xl text-emerald-400">{formatDollars(results.directGivingTotal)}</p>
              <p className="text-sm text-[#7a95b8]">Total amount donated directly over time</p>
            </CardContent>
          </Card>
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle>DAF Future Value</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xl text-emerald-400">{formatDollars(results.dafFutureValue)}</p>
              <p className="text-sm text-[#7a95b8]">Potential growth in DAF after {years} years</p>
            </CardContent>
          </Card>
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle>Total Tax Savings</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xl text-emerald-400">{formatDollars(results.totalTaxSavings)}</p>
              <p className="text-sm text-[#7a95b8]">Estimated tax deductions over " + years + " years</p>
            </CardContent>
          </Card>
        </div>
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />
        
        
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "optimized", label: "Optimized Strategy", color: "#10b981" }, { key: "baseline", label: "Baseline (No Action)", color: "#ef4444" }, { key: "taxSavings", label: "Cumulative Tax Savings", color: "#06b6d4" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="mb-8 p-4 bg-[#0d1526] border border-[#1e3a5f] rounded-lg">
          <h2 className="text-xl font-bold mb-2">IUL Advantage</h2>
          <p className="text-[#94a3b8]">Indexed Universal Life (IUL) insurance offers tax-free growth, which can significantly enhance your DAF contributions. By using IUL proceeds, you can maximize charitable impact while enjoying tax advantages over direct giving alone.</p>
          <p className="text-[#7a95b8] mt-2">For example, the tax-free growth from IUL could increase your DAF balance by an additional 20-30% compared to traditional investments, providing more funds for your causes.</p>
        </div>
        
        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-500 hover:bg-emerald-600"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("daf-vs-direct-giving", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-daf-vs-direct-giving");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Donor-Advised Fund (DAF) vs Direct Giving Calculator"
            calculatorRoute="daf-vs-direct-giving"
            inputs={typeof results !== 'undefined' ? results : {}}
            results={typeof results !== 'undefined' ? results : {}}
            projectionData={projectionData}
          />
      <PageInsights section="d-a-fvs-direct-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/daf-vs-direct-giving" />
</div>
    </AppShell>
  );
}