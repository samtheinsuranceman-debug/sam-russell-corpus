// @ts-nocheck

import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { Shield, DollarSign, AlertTriangle, CheckCircle2, Target, Heart, Calendar, Users, ArrowRight, Award, TrendingDown, Scale } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, AreaChart, Area, ComposedChart, Line } from 'recharts';
import { PageInsights } from "@/components/PageInsights";

export default function DisabilityGapAnalyzer() {
  const [income, setIncome] = useSharedField("annualIncome", 400000); // Annual income in dollars
  const [groupCoverage, setGroupCoverage] = useState(150000); // Annual group coverage cap

  // Memoized calculations for performance
  const monthlyIncomeNeeded = useMemo(() => income / 12, [income]);
  const monthlyGroupCoverage = useMemo(() => groupCoverage / 12, [groupCoverage]); // e.g., 12500
  const taxRate = 0.37; // 37% tax rate
  const netGroupBenefit = useMemo(() => monthlyGroupCoverage * (1 - taxRate), [monthlyGroupCoverage]); // Net after tax
  const monthlyGap = useMemo(() => monthlyIncomeNeeded - netGroupBenefit, [monthlyIncomeNeeded, netGroupBenefit]);
  const annualGap = useMemo(() => monthlyGap * 12, [monthlyGap]);
  const uninsuredPercentage = useMemo(() => 100 - ((netGroupBenefit / monthlyIncomeNeeded) * 100), [netGroupBenefit, monthlyIncomeNeeded]); // Percentage uninsured

  // Data for charts
  const specialtyData = [
    { specialty: 'Surgeon', rate: 33, duration: 3.2, incomeAtRisk: 1600000 },
    { specialty: 'Cardiologist', rate: 28, duration: 2.8, incomeAtRisk: 1400000 },
    { specialty: 'Orthopedic', rate: 35, duration: 3.5, incomeAtRisk: 2100000 },
    { specialty: 'Dermatologist', rate: 22, duration: 2.0, incomeAtRisk: 800000 },
    { specialty: 'Primary Care', rate: 25, duration: 2.5, incomeAtRisk: 750000 },
    { specialty: 'Anesthesiologist', rate: 30, duration: 3.0, incomeAtRisk: 1500000 },
  ];

  const waitingData = [
    { age: 30, premium: 200, benefit: 15000 },
    { age: 35, premium: 280, benefit: 15000 },
    { age: 40, premium: 400, benefit: 15000 },
    { age: 45, premium: 580, benefit: 15000 },
    { age: 50, premium: 850, benefit: 15000 },
  ];

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white font-sans">
      {/* Header Section */}
      <header className="p-8 text-center bg-gradient-to-r from-gray-800 to-red-900 shadow-lg">
        <h1 className="text-4xl font-bold mb-4">Disability Insurance Gap Analyzer</h1>
        <div className="flex justify-center items-center space-x-4">
          <DollarSign className="text-amber-500" size={24} />
          <input
            type="number"
            value={income}
            onChange={(e) => setIncome(Number(e.target.value))}
            placeholder="Annual Income"
            className="p-2 rounded bg-gray-700 border border-amber-500 text-white"
          />
          <ArrowRight className="text-amber-500" size={24} />
          <Shield className="text-amber-500" size={24} />
          <input
            type="number"
            value={groupCoverage}
            onChange={(e) => setGroupCoverage(Number(e.target.value))}
            placeholder="Group Coverage Cap"
            className="p-2 rounded bg-gray-700 border border-amber-500 text-white"
          />
        </div>
      </header>

      {/* The Gap Section */}
      <section className="p-8 bg-[#0d1526] shadow-md">
        <h2 className="text-3xl font-semibold mb-6 flex items-center text-red-500">
          <AlertTriangle className="mr-2" size={28} /> The Gap: How Group Coverage Leaves You Underinsured
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gray-700 p-6 rounded-lg shadow-inner border-l-4 border-red-500">
            <p className="text-xl"><strong>Monthly Income Needed:</strong> ${monthlyIncomeNeeded.toFixed(2)}</p>
            <p className="text-xl"><strong>Group Coverage Provides:</strong> ${monthlyGroupCoverage.toFixed(2)} (taxable)</p>
            <p className="text-xl"><strong>Net Group Benefit (after 37% tax):</strong> ${netGroupBenefit.toFixed(2)}</p>
            <p className="text-xl"><strong>Monthly Gap:</strong> ${monthlyGap.toFixed(2)}</p>
            <p className="text-xl"><strong>Annual Gap:</strong> ${annualGap.toFixed(2)}</p>
            <p className="text-2xl font-bold text-red-500 mt-4">You're {uninsuredPercentage.toFixed(0)}% Uninsured!</p>
          </div>
          <div className="flex justify-center items-center">
            <div className="w-full h-64 bg-gradient-to-br from-red-900 to-amber-500 rounded-lg flex items-center justify-center text-white shadow-xl">
              <p className="text-4xl font-bold text-center">Dramatic Gap Visual</p>
              <p className="text-xl mt-2">This gap could derail your financial future!</p>
            </div>
          </div>
        </div>
      </section>

      {/* Taxable vs Tax-Free Benefits Section */}
      <section className="p-8 bg-gray-700 shadow-md">
        <h2 className="text-3xl font-semibold mb-6 flex items-center text-amber-500">
          <Scale className="mr-2" size={28} /> Taxable vs Tax-Free Benefits Comparison
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-[#0d1526] p-6 rounded-lg shadow-inner border-l-4 border-red-500">
            <h3 className="text-2xl font-bold mb-4">Group (Employer-Paid)</h3>
            <p><strong>Benefit:</strong> $12,500/mo</p>
            <p><strong>Taxed at 37%:</strong> -$4,625</p>
            <p><strong>Net Benefit:</strong> $7,875/mo</p>
          </div>
          <div className="bg-[#0d1526] p-6 rounded-lg shadow-inner border-l-4 border-amber-500">
            <h3 className="text-2xl font-bold mb-4">Individual (You Pay Premium)</h3>
            <p><strong>Benefit:</strong> $15,000/mo</p>
            <p><strong>Tax-Free:</strong> $0 tax</p>
            <p><strong>Net Benefit:</strong> $15,000/mo</p>
            <p><strong>Combined Net:</strong> $22,875/mo</p>
          </div>
        </div>
        <p className="mt-4 text-center text-red-500">Switching to individual coverage could bridge your gap significantly!</p>
      </section>

      {/* Specialty-Specific Risk Section */}
      <section className="p-8 bg-[#0d1526] shadow-md">
        <h2 className="text-3xl font-semibold mb-6 flex items-center text-red-500">
          <Target className="mr-2" size={28} /> Specialty-Specific Risk
        </h2>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={specialtyData}>
            <XAxis dataKey="specialty" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="rate" fill="#fbbf24" name="Disability Rate (%)" />
            <Bar dataKey="duration" fill="#ef4444" name="Avg Duration (Years)" />
            <Bar dataKey="incomeAtRisk" fill="#a78bfa" name="Income at Risk ($)" />
          </BarChart>
        </ResponsiveContainer>
        <p className="mt-4 text-center text-amber-500">High-risk specialties like Surgery expose you to millions in lost income.</p>
      </section>

      {/* Cost of Waiting Section */}
      <section className="p-8 bg-gray-700 shadow-md">
        <h2 className="text-3xl font-semibold mb-6 flex items-center text-amber-500">
          <Calendar className="mr-2" size={28} /> Cost of Waiting
        </h2>
        <ResponsiveContainer width="100%" height={400}>
          <AreaChart data={waitingData}>
            <XAxis dataKey="age" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="premium" stroke="#fbbf24" fill="#fbbf24" name="Premium ($/mo)" />
            <Area type="monotone" dataKey="benefit" stroke="#ef4444" fill="#ef4444" name="Benefit ($/mo)" opacity={0.6} />
            <Line type="monotone" dataKey="premium" stroke="#a78bfa" name="Premium Trend" />
          </AreaChart>
        </ResponsiveContainer>
        <p className="mt-4 text-center text-red-500">Every year you wait costs 15-20% more in premiums!</p>
      </section>

      {/* Recommended Coverage Stack Section */}
      <section className="p-8 bg-[#0d1526] shadow-md">
        <h2 className="text-3xl font-semibold mb-6 flex items-center text-amber-500">
          <CheckCircle2 className="mr-2" size={28} /> Recommended Coverage Stack
        </h2>
        <ul className="list-disc pl-8 space-y-4">
          <li className="flex items-start"><Award className="mr-2 text-red-500" size={20} /> Own-occupation definition (non-cancelable) for specialized protection.</li>
          <li className="flex items-start"><Heart className="mr-2 text-red-500" size={20} /> Residual/partial disability rider to cover partial income loss.</li>
          <li className="flex items-start"><TrendingDown className="mr-2 text-red-500" size={20} /> Future increase option rider for adjusting coverage as income grows.</li>
          <li className="flex items-start"><Users className="mr-2 text-red-500" size={20} /> COLA rider (3% compound) to combat inflation over time.</li>
          <li className="flex items-start"><DollarSign className="mr-2 text-red-500" size={20} /> Student loan rider to protect educational debt payments.</li>
          <li className="flex items-start"><Shield className="mr-2 text-red-500" size={20} /> Catastrophic disability rider for severe cases.</li>
        </ul>
        <p className="mt-4 text-center text-amber-500">Build this stack to ensure comprehensive protection against income loss.</p>
      </section>

      {/* Footer for additional info */}
      <footer className="p-4 text-center bg-[#0a0f1a] text-[#7a95b8]">
        <p>Disclaimer: This is an illustrative tool. Consult a financial advisor for personalized advice.</p>
        <p>Powered by advanced analytics for high-income physicians.</p>
      </footer>
      <PageInsights section="disability-gap-analyzer" />
    </div>
  );
}
