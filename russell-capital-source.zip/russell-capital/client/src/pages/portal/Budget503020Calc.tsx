// @ts-nocheck
import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Calculator, TrendingUp, Shield } from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function Budget503020Calc() {
  const autoFill = useCalculatorAutoFill("budget-50-30-20");
  const { reportResult } = useCalcResults();
  const [monthlyIncome, setMonthlyIncome] = useState(5000);
  const [age, setAge] = useSharedField("currentAge", 30);

  const calculations = useMemo(() => {
    const needs = monthlyIncome * 0.50;
    const wants = monthlyIncome * 0.30;
    const savings = monthlyIncome * 0.20;
    const yearsToRetirement = 65 - age;
    const annualSavings = savings * 12;
    const r = 0.06;  // 6% annual growth rate for IUL projection
    const iulProjection = annualSavings * ((Math.pow(1 + r, yearsToRetirement) - 1) / r);
    return { needs, wants, savings, iulProjection };
  }, [monthlyIncome, age]);
  const projectionData = useMemo(() => {
    const d = [];
    const income = typeof annualIncome !== 'undefined' ? annualIncome : 300000;
    const saveRate = 0.20;
    let nw = 0, cumSave = 0, debtElim = 0, emFund = 0;
    for (let yr = 0; yr <= 50; yr++) {
      const annualSave = income * saveRate * Math.pow(1.03, yr);
      cumSave += annualSave;
      debtElim += Math.min(annualSave * 0.3, 25000 * Math.max(0, 1 - yr / 15));
      emFund = Math.min(income * 0.5, emFund + annualSave * 0.1);
      nw = cumSave * 1.06 + debtElim;
      d.push({ year: yr, netWorth: Math.round(nw), cumulativeSavings: Math.round(cumSave), debtReduction: Math.round(debtElim), emergencyFund: Math.round(emFund) });
    }
    return d;
  }, []);


  return (
    <AppShell className="bg-[#0a0f1a] text-white">
      <div className="container mx-auto p-6">
        <AutoFillBanner calcRoute="budget-50-30-20" />
        <h1 className="text-3xl font-bold mb-6 flex items-center">
          <Calculator className="mr-2" />
          50/30/20 Budget Calculator
        </h1>
        
        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">Inputs</h2>
          <div className="space-y-4">
            <div>
              <Label htmlFor="monthlyIncome">Monthly Income</Label>
              <div className="flex items-center space-x-2">
                <Slider
                  id="monthlyIncome"
                  min={0}
                  max={20000}
                  step={100}
                  value={[monthlyIncome]}
                  onValueChange={(value) => setMonthlyIncome(value[0])}
                  className="w-full"
                />
                <Input
                  type="number"
                  value={monthlyIncome}
                  onChange={(e) => setMonthlyIncome(Number(e.target.value))}
                  className="w-32 bg-[#0d1526] border-[#1e3a5f]"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="age">Age</Label>
              <div className="flex items-center space-x-2">
                <Slider
                  id="age"
                  min={18}
                  max={65}
                  step={1}
                  value={[age]}
                  onValueChange={(value) => setAge(value[0])}
                  className="w-full"
                />
                <Input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-32 bg-[#0d1526] border-[#1e3a5f]"
                />
              </div>
            </div>
          </div>
        </section>
        
        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">Results</h2>
        {/* State Tax Impact */}
        <StateTaxSelector income={250000} filingStatus={'single'} className="mb-6" />
          
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "netWorth", label: "Net Worth", color: "#10b981" }, { key: "cumulativeSavings", label: "Cumulative Savings", color: "#06b6d4" }, { key: "debtReduction", label: "Debt Eliminated", color: "#f59e0b" }, { key: "emergencyFund", label: "Emergency Fund", color: "#a855f7" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader className="flex items-center">
                <TrendingUp className="mr-2 text-emerald-400" />
                <CardTitle>Needs Budget (50%)</CardTitle>
              </CardHeader>
              <CardContent>{formatDollars(calculations.needs)} per month</CardContent>
            </Card>
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader className="flex items-center">
                <TrendingUp className="mr-2 text-emerald-400" />
                <CardTitle>Wants Budget (30%)</CardTitle>
              </CardHeader>
              <CardContent>{formatDollars(calculations.wants)} per month</CardContent>
            </Card>
            <Card className="bg-[#0d1526] border-[#1e3a5f]">
              <CardHeader className="flex items-center">
                <Shield className="mr-2 text-emerald-400" />
                <CardTitle>Savings (20%)</CardTitle>
              </CardHeader>
              <CardContent>{formatDollars(calculations.savings)} per month</CardContent>
            </Card>
          </div>
        </section>
        
        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">IUL Advantage</h2>
          <Card className="bg-[#0d1526] border-[#1e3a5f] p-4">
            <CardHeader>
              <CardTitle>How IUL Helps</CardTitle>
            </CardHeader>
            <CardContent>
              By allocating your 20% savings to an Indexed Universal Life (IUL) policy, you can benefit from tax-free growth. Estimated IUL projection: {formatDollars(calculations.iulProjection)} after retirement based on your savings and age.
              IUL provides tax-free growth advantages, helping your budget grow securely for future needs.
            </CardContent>
          </Card>
        </section>
        
        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-500 hover:bg-emerald-600"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("budget-50-30-20", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-budget-50-30-20");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="50/30/20 Budget Calculator"
            calculatorRoute="budget-50-30-20"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="budget503020-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/budget-50-30-20" />
</div>
    </AppShell>
  );
}