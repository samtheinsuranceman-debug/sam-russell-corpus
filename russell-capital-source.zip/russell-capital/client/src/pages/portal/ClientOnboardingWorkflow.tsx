// @ts-nocheck
import React, { useState, useMemo } from 'react';
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from '@/components/AppShell';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { trpc } from "@/lib/trpc";
import { CalculatorPDFExport } from "@/components/CalculatorPDFExport";
import { Loader2, TrendingUp, Shield, AlertTriangle, CheckCircle } from 'lucide-react';
import { PageInsights } from "@/components/PageInsights";

const fmt = (v: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(v);
const pct = (v: number) => `${v.toFixed(1)}%`;

export default function ClientOnboardingWorkflow() {
  const [showResults, setShowResults] = useState(false);
  const [projectionYears, setProjectionYears] = useSharedField("projectionYears", 30);
  const [clientType, setClientType] = useState("Individual");
  const [productSuite, setProductSuite] = useState("Life Insurance Only");
  const [complianceLevel, setComplianceLevel] = useState("Standard");

  const serverMutation = trpc.si.clientRetention.useMutation();

  const results = useMemo(() => {
    if (!showResults) return null;
    // Local calculation fallback
    return {
      steps_completed: "Calculating...", documents_pending: "Calculating...", kyc_status: "Calculating...", estimated_completion: "Calculating...",
      projectionData: Array.from({ length: projectionYears }, (_, i) => ({
        year: i + 1,
        value: Math.round(100000 * Math.pow(1.065, i + 1)),
        baseline: Math.round(100000 * Math.pow(1.03, i + 1)),
      })),
    };
  }, [showResults, projectionYears, clientType, productSuite, complianceLevel]);

  const handleCalculate = async () => {
    setShowResults(true);
    toast.success("Analysis complete — scroll down for results");
  };

  return (
    <AppShell title="Automated Client Onboarding Workflow" subtitle="Pipeline management with document checklist and KYC tracking">
      <div className="space-y-6 max-w-6xl mx-auto">
        {/* Input Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-emerald-500" />
              Analysis Parameters
            </CardTitle>
            <CardDescription>Configure your inputs below and click Analyze to generate results</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <Label className="text-sm font-medium text-muted-foreground">Projection Years: {projectionYears}</Label>
                <input type="range" min="5" max="50" value={projectionYears} onChange={(e) => setProjectionYears(Number(e.target.value))} className="w-full mt-1 accent-emerald-500" />
              </div>

            <div>
              <Label className="text-sm font-medium text-muted-foreground">Client Type</Label>
              <select value={clientType} onChange={(e) => setClientType(e.target.value)} className="w-full mt-1 rounded-md border border-border bg-background px-3 py-2 text-sm">
                <option value="Individual">Individual</option>
                <option value="Joint">Joint</option>
                <option value="Trust">Trust</option>
                <option value="Business Entity">Business Entity</option>
                <option value="Non-Profit">Non-Profit</option>
              </select>
            </div>
            <div>
              <Label className="text-sm font-medium text-muted-foreground">Product Suite</Label>
              <select value={productSuite} onChange={(e) => setProductSuite(e.target.value)} className="w-full mt-1 rounded-md border border-border bg-background px-3 py-2 text-sm">
                <option value="Life Insurance Only">Life Insurance Only</option>
                <option value="Annuity Only">Annuity Only</option>
                <option value="Full Suite">Full Suite</option>
                <option value="Investment + Insurance">Investment + Insurance</option>
              </select>
            </div>
            <div>
              <Label className="text-sm font-medium text-muted-foreground">Compliance Level</Label>
              <select value={complianceLevel} onChange={(e) => setComplianceLevel(e.target.value)} className="w-full mt-1 rounded-md border border-border bg-background px-3 py-2 text-sm">
                <option value="Standard">Standard</option>
                <option value="Enhanced Due Diligence">Enhanced Due Diligence</option>
                <option value="PEP/High Risk">PEP/High Risk</option>
              </select>
            </div>
            </div>
            <div className="mt-6 flex gap-3">
              <Button onClick={handleCalculate} className="bg-emerald-600 hover:bg-emerald-700">
                <TrendingUp className="h-4 w-4 mr-2" /> Run Analysis
              </Button>
              <CalculatorPDFExport
                calculatorName="Client Onboarding Workflow"
                calculatorRoute="/portal/client-onboarding-workflow"
                inputs={{ projectionYears, clientType, productSuite, complianceLevel }}
                results={results as any ?? {}}
                projectionData={results?.projectionData}
              />
            </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <span className="text-xs text-muted-foreground mr-2">IRS Citations:</span>
            <Badge variant="outline" className="text-xs">§6050I Cash Reporting</Badge> <Badge variant="outline" className="text-xs">§326 CIP Requirements</Badge>
          </div>
          </CardContent>
        </Card>

        {/* Results Section */}
        {showResults && results && (
          <>
            {/* Key Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">

          <Card className="bg-emerald-500/10 border-emerald-500/20">
            <CardContent className="p-4 text-center">
              <p className="text-xs text-muted-foreground">Steps Completed</p>
              <p className="text-2xl font-bold text-emerald-400">{results?.steps_completed ?? "—"}</p>
            </CardContent>
          </Card>
          <Card className="bg-blue-500/10 border-blue-500/20">
            <CardContent className="p-4 text-center">
              <p className="text-xs text-muted-foreground">Documents Pending</p>
              <p className="text-2xl font-bold text-blue-400">{results?.documents_pending ?? "—"}</p>
            </CardContent>
          </Card>
          <Card className="bg-amber-500/10 border-amber-500/20">
            <CardContent className="p-4 text-center">
              <p className="text-xs text-muted-foreground">KYC Status</p>
              <p className="text-2xl font-bold text-amber-400">{results?.kyc_status ?? "—"}</p>
            </CardContent>
          </Card>
          <Card className="bg-purple-500/10 border-purple-500/20">
            <CardContent className="p-4 text-center">
              <p className="text-xs text-muted-foreground">Estimated Completion</p>
              <p className="text-2xl font-bold text-purple-400">{results?.estimated_completion ?? "—"}</p>
            </CardContent>
          </Card>
      <PageInsights section="client-onboarding-workflow" />
            </div>

            {/* Projection Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Automated Client Onboarding Workflow — {projectionYears}-Year Projection</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-end gap-1">
                  {results.projectionData.slice(0, Math.min(projectionYears, 50)).map((d: any, i: number) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <div
                        className="w-full bg-emerald-500/80 rounded-t"
                        style={{ height: `${Math.min((d.value / (results.projectionData[projectionYears - 1]?.value || 1)) * 200, 200)}px` }}
                        title={`Year ${d.year}: ${fmt(d.value)}`}
                      />
                      {i % 5 === 0 && <span className="text-[10px] text-muted-foreground">{d.year}</span>}
                    </div>
                  ))}
                </div>
                <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                  <span>Year 1</span>
                  <span className="text-emerald-400 font-medium">Optimized Strategy</span>
                  <span>Year {projectionYears}</span>
                </div>
              </CardContent>
            </Card>

            {/* Detailed Results Table */}
            <Card>
              <CardHeader>
                <CardTitle>Year-by-Year Projection</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-2 px-3">Year</th>
                        <th className="text-right py-2 px-3">Optimized Value</th>
                        <th className="text-right py-2 px-3">Baseline</th>
                        <th className="text-right py-2 px-3">Advantage</th>
                      </tr>
                    </thead>
                    <tbody>
                      {results.projectionData.filter((_: any, i: number) => i % 5 === 4 || i === 0).map((d: any) => (
                        <tr key={d.year} className="border-b border-border/50 hover:bg-muted/30">
                          <td className="py-2 px-3">{d.year}</td>
                          <td className="text-right py-2 px-3 text-emerald-400 font-medium">{fmt(d.value)}</td>
                          <td className="text-right py-2 px-3 text-muted-foreground">{fmt(d.baseline)}</td>
                          <td className="text-right py-2 px-3 text-blue-400">{fmt(d.value - d.baseline)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </AppShell>
  );
}
