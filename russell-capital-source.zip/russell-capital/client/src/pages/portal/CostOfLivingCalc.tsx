// @ts-nocheck
import { useState, useMemo } from "react";
import { useSharedField } from "@/context/FinancialDataContext";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Circle, CalculatorIcon, ShieldIcon, TrendingUpIcon} from 'lucide-react';
import { useCalculatorAutoFill, RelatedCalculators, AutoFillBanner, useCalcResults } from "@/components/CalculatorIntegration";
import ProjectionChart50yr from "@/components/ProjectionChart50yr";

import { CalculatorPDFExport } from '@/components/CalculatorPDFExport';

import { StateTaxSelector } from '@/components/StateTaxSelector';
import { PageInsights } from "@/components/PageInsights";

function formatDollars(n: number): string {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(0) + "K";
  return "$" + n.toFixed(0);
}

export default function CostOfLivingCalc() {
  const autoFill = useCalculatorAutoFill("cost-of-living");
  const { reportResult } = useCalcResults();
  const [annualIncome, setAnnualIncome] = useSharedField("annualIncome", 100000);
  const [currentCostIndex, setCurrentCostIndex] = useState(100);
  const [targetCostIndex, setTargetCostIndex] = useState(120);
  const [inflationRate, setInflationRate] = useState(3);
  const [age, setAge] = useSharedField("currentAge", 35);

  const calculations = useMemo(() => {
    const adjustedIncome = (annualIncome * targetCostIndex) / currentCostIndex;
    const annualCostDifference = adjustedIncome - annualIncome;
    const projectedIULGrowth = annualCostDifference * (1 + (inflationRate / 100)) ** (65 - age); // Simplified projection to retirement at 65
    return {
      adjustedIncome,
      annualCostDifference,
      projectedIULGrowth,
    };
  }, [annualIncome, currentCostIndex, targetCostIndex, inflationRate, age]);
  const projectionData = useMemo(() => {
    const d = [];
    let opt = 100000, base = 100000, taxSav = 0;
    for (let yr = 0; yr <= 50; yr++) {
      opt *= 1.075;
      base *= 1.05;
      taxSav += (opt - base) * 0.08;
      d.push({ year: yr, optimized: Math.round(opt), baseline: Math.round(base), taxSavings: Math.round(taxSav), netBenefit: Math.round(opt - base + taxSav) });
    }
    return d;
  }, []);


  return (
    <AppShell
      className="bg-[#0a0f1a] text-white min-h-screen"
      header={
        <div className="flex items-center p-4 bg-[#0d1526]">
          <CalculatorIcon className="mr-2" />
          <h1 className="text-xl font-bold">Cost of Living Comparison Calculator</h1>
        </div>
      }
    >
      <div className="p-6 max-w-4xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div>
            <Label htmlFor="annualIncome">Annual Income</Label>
            <div className="flex items-center space-x-2 mt-2">
              <Input
                id="annualIncome"
                type="number"
                value={annualIncome}
                onChange={(e) => setAnnualIncome(Number(e.target.value))}
                className="bg-[#0d1526] border-[#1e3a5f]"
              />
              <Slider
                min={50000}
                max={500000}
                step={1000}
                value={[annualIncome]}
                onValueChange={(value) => setAnnualIncome(value[0])}
                className="w-full"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="currentCostIndex">Current Cost of Living Index</Label>
            <Input
              id="currentCostIndex"
              type="number"
              value={currentCostIndex}
              onChange={(e) => setCurrentCostIndex(Number(e.target.value))}
              className="bg-[#0d1526] border-[#1e3a5f]"
            />
          </div>
          <div>
            <Label htmlFor="targetCostIndex">Target Cost of Living Index</Label>
            <Input
              id="targetCostIndex"
              type="number"
              value={targetCostIndex}
              onChange={(e) => setTargetCostIndex(Number(e.target.value))}
              className="bg-[#0d1526] border-[#1e3a5f]"
            />
          </div>
          <div>
            <Label htmlFor="inflationRate">Inflation Rate (%)</Label>
            <div className="flex items-center space-x-2 mt-2">
              <Input
                id="inflationRate"
                type="number"
                value={inflationRate}
                onChange={(e) => setInflationRate(Number(e.target.value))}
                className="bg-[#0d1526] border-[#1e3a5f]"
              />
              <Slider
                min={0}
                max={10}
                step={0.1}
                value={[inflationRate]}
                onValueChange={(value) => setInflationRate(value[0])}
                className="w-full"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="age">Current Age</Label>
            <Input
              id="age"
              type="number"
              value={age}
              onChange={(e) => setAge(Number(e.target.value))}
              className="bg-[#0d1526] border-[#1e3a5f]"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUpIcon className="mr-2" /> Adjusted Income Needed
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-emerald-400">{formatDollars(calculations.adjustedIncome)}</p>
              <p className="text-sm">Based on target cost index</p>
            </CardContent>
          </Card>
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="flex items-center">
                <CalculatorIcon className="mr-2" /> Annual Cost Difference
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-emerald-400">{formatDollars(calculations.annualCostDifference)}</p>
              <p className="text-sm">Extra cost per year</p>
            </CardContent>
          </Card>
          <Card className="bg-[#0d1526] border-[#1e3a5f]">
            <CardHeader>
              <CardTitle className="flex items-center">
                <ShieldIcon className="mr-2" /> Projected IUL Growth
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-emerald-400">{formatDollars(calculations.projectedIULGrowth)}</p>
              <p className="text-sm">Tax-free growth potential to retirement</p>
            </CardContent>
          </Card>
        </div>
        {/* State Tax Impact */}
        <StateTaxSelector income={annualIncome} filingStatus={'single'} className="mb-6" />

        
        <ProjectionChart50yr
          data={projectionData}
          series={[{ key: "optimized", label: "Optimized Strategy", color: "#10b981" }, { key: "baseline", label: "Baseline (No Action)", color: "#ef4444" }, { key: "taxSavings", label: "Cumulative Tax Savings", color: "#06b6d4" }, { key: "netBenefit", label: "Net Benefit", color: "#f59e0b" }]}
          title="50-Year Financial Projection"
          height={420}
        />

        <div className="mb-8 p-4 bg-[#0d1526] border border-[#1e3a5f] rounded-lg">
          <h2 className="text-lg font-bold mb-2">IUL Advantage</h2>
          <p>Indexed Universal Life (IUL) insurance offers tax-free growth on your investments, which can help offset the increased costs from a higher cost of living area. By allocating the annual cost difference into an IUL policy, you could potentially grow your savings to " + formatDollars(calculations.projectedIULGrowth) + " by retirement, providing a financial buffer for relocation and inflation.</p>
        </div>

        <Button
          onClick={() => toast.success("Results sent to AI Advisor for tax-optimized planning")}
          className="bg-emerald-500 hover:bg-emerald-600"
        >
          Send to AI Advisor
        </Button>
      

        {/* Generate Outcome Button */}
        <div className="mt-6 mb-4">
          <button
            onClick={() => {
              reportResult("cost-of-living", typeof calculations !== 'undefined' ? calculations : {});
              const el = document.getElementById("calc-results-cost-of-living");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full py-3 px-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-lg shadow-lg hover:shadow-emerald-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Generate Outcome
          </button>
        </div>
        {/* PDF Export */}
        <div className="mt-4 mb-4 flex justify-end">
          <CalculatorPDFExport
            calculatorName="Cost of Living Comparison Calculator"
            calculatorRoute="cost-of-living"
            inputs={typeof calculations !== 'undefined' ? calculations : {}}
            results={typeof calculations !== 'undefined' ? calculations : {}}
            projectionData={projectionData}
          />
      <PageInsights section="cost-of-living-calc" />
        </div>

        {/* Related Calculators */}
        <RelatedCalculators currentRoute="/portal/cost-of-living" />
</div>
    </AppShell>
  );
}