import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

async function run() {
  const conn = await mysql.createConnection({
    uri: process.env.DATABASE_URL,
    multipleStatements: true
  });
  
  // Get all tables
  const [rows] = await conn.execute('SHOW TABLES');
  const tables = rows.map(r => Object.values(r)[0]);
  
  console.log('Current tables:', tables.length);
  
  // Drop all tables except __drizzle_migrations
  await conn.query('SET FOREIGN_KEY_CHECKS = 0');
  
  for (const table of tables) {
    if (table === '__drizzle_migrations') {
      console.log('  Keeping:', table);
      continue;
    }
    console.log('  Dropping:', table);
    await conn.query(`DROP TABLE IF EXISTS \`${table}\``);
  }
  
  await conn.query('SET FOREIGN_KEY_CHECKS = 1');
  
  // Verify
  const [remaining] = await conn.execute('SHOW TABLES');
  console.log('\nRemaining tables:', remaining.length);
  
  await conn.end();
}

run().catch(e => { console.error(e); process.exit(1); });
