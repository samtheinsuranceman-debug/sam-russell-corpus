#!/bin/bash
mkdir -p dist/public/assets
cp client/index.html dist/public/index.html
cp client/public/assets/* dist/public/assets/
npx esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist
