import re

js_path = "/home/ubuntu/russellcap/client/public/assets/index-B357xCpk.js"

with open(js_path, "r", encoding="utf-8", errors="ignore") as f:
    content = f.read()

# 1. Replace the Footer phone link element with null
footer_phone_pattern = r'o\.jsxs\("a",\{"data-loc":"client/src/components/Footer\.tsx:63",href:"tel:\+1-555-0199",className:"flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors",children:\[o\.jsx\(hx,\{"data-loc":"client/src/components/Footer\.tsx:64",size:14\}\)," \(555\) 019-9000"\]\}\)'
print("Matches for footer phone pattern:", len(re.findall(footer_phone_pattern, content)))

# Let's do a direct replace since we know the exact string:
footer_phone_str = 'o.jsxs("a",{"data-loc":"client/src/components/Footer.tsx:63",href:"tel:+1-555-0199",className:"flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors",children:[o.jsx(hx,{"data-loc":"client/src/components/Footer.tsx:64",size:14})," (555) 019-9000"]})'
content = content.replace(footer_phone_str, 'null')

# 2. Replace the Contact page phone link element with null
contact_phone_str = 'o.jsxs("a",{"data-loc":"client/src/pages/Contact.tsx:250",href:"tel:+15550199000",className:"flex items-center gap-3 text-sm text-muted-foreground hover:text-primary transition-colors",children:[o.jsx(hx,{"data-loc":"client/src/pages/Contact.tsx:251",size:14,className:"text-primary"})," (555) 019-9000"]})'
content = content.replace(contact_phone_str, 'null')

# 3. Also handle the demo pages routing
content = content.replace('path:"/demo-warroom",component:O2', 'path:"/demo-warroom",component:ng')
content = content.replace('path:"/demo-folio",component:B2', 'path:"/demo-folio",component:ng')
content = content.replace('path:"/demo-blueprint",component:_2', 'path:"/demo-blueprint",component:ng')

with open(js_path, "w", encoding="utf-8") as f:
    f.write(content)

print("Phone number removed completely and demo pages hidden!")
