import re

js_path = "/home/ubuntu/russellcap/client/public/assets/index-B357xCpk.js"

with open(js_path, "r", encoding="utf-8", errors="ignore") as f:
    content = f.read()

# Replace phone number with "Available online" or similar, and point tel links to contact page
print("Original phone matches:")
print(re.findall(r'href:"tel:[^"]*"', content))
print(re.findall(r'"\s*\(555\) 019-9000"', content))

# Replace tel links
content = content.replace('href:"tel:+1-555-0199"', 'href:"/contact"')
# Replace phone text
content = content.replace('" (555) 019-9000"', '"Contact Online"')

# Let's check for any other occurrences of the phone number
content = content.replace('(555) 019-9000', 'Contact Online')
content = content.replace('+1-555-0199', '')

# Now let's remove or hide the demo pages from the router/App.tsx
# Let's look at the routes in the JS file:
# o.jsx(zt,{"data-loc":"client/src/App.tsx:32",path:"/demo-warroom",component:O2})
# o.jsx(zt,{"data-loc":"client/src/App.tsx:33",path:"/demo-folio",component:B2})
# o.jsx(zt,{"data-loc":"client/src/App.tsx:34",path:"/demo-blueprint",component:_2})
# Let's replace these routes with a redirect or NotFound component (ng)
content = content.replace('path:"/demo-warroom",component:O2', 'path:"/demo-warroom",component:ng')
content = content.replace('path:"/demo-folio",component:B2', 'path:"/demo-folio",component:ng')
content = content.replace('path:"/demo-blueprint",component:_2', 'path:"/demo-blueprint",component:ng')

with open(js_path, "w", encoding="utf-8") as f:
    f.write(content)

print("JS bundle cleaned successfully!")
