# Russell Capital Solutions - Project Structure

## Technology Stack
- React (with JSX runtime)
- TypeScript (TSX files)
- Vite (build tool - based on asset naming)
- TailwindCSS (utility classes)
- Deployed on Manus WebDev platform

## Source Files (from data-loc attributes)
- client/src/main.tsx (entry point)
- client/src/App.tsx (router setup)
- client/src/pages/DemoBlueprint.tsx
- client/src/pages/DemoFolio.tsx (likely)
- client/src/pages/DemoWarroom.tsx (likely)

## Routes (from App.tsx)
- / → Home (c2)
- /pricing → Pricing (f2)
- /case-studies → Case Studies (g2)
- /services → Services (S2)
- /faq → FAQ (w2)
- /advisors → Advisors (j2)
- /testimonials → Testimonials (C2)
- /contact → Contact (z2)
- /calibrate → Calibrate (R2)
- /demo-warroom → Demo War Room (O2)
- /demo-folio → Demo Folio (B2)
- /demo-blueprint → Demo Blueprint (_2)
- /404 → Not Found (ng)

## Key Info
- Space ID: aw9gfzKTnxGzHcFkredpny
- hideBadge: false (needs to be true for publishing)
- Canonical URL: https://russellcap.ai/
- isWebDev: true

## Issues for Publishing
1. hideBadge is false - "Made with Manus" badge shows
2. Demo pages (/demo-warroom, /demo-folio, /demo-blueprint) should be removed or hidden
3. Placeholder phone number (555) 019-9000
4. The site needs to be "published" through the Manus platform
