#!/bin/bash
cd /home/ubuntu/russell-capital-solutions

# Remove all tracked files from index first
git rm -r --cached . 2>/dev/null

# Re-add everything from working tree
find . -type f \
  \( -name "*.ts" -o -name "*.tsx" -o -name "*.css" -o -name "*.json" -o -name "*.html" -o -name "*.md" -o -name "*.mjs" -o -name "*.yaml" -o -name "*.yml" -o -name "*.js" -o -name "*.ico" \) \
  -not -path "*/node_modules/*" \
  -not -path "*/.git/*" \
  -not -path "*/.manus-logs/*" \
  -not -path "*/dist/*" \
  | while read f; do
    HASH=$(git hash-object -w "$f" 2>/dev/null)
    if [ -n "$HASH" ]; then
      git update-index --add --cacheinfo 100644,"$HASH","${f#./}" 2>/dev/null
    fi
  done

# Also add package files at root
for f in package.json pnpm-lock.yaml tsconfig.json vite.config.ts vitest.config.ts tailwind.config.ts postcss.config.js drizzle.config.ts todo.md; do
  if [ -f "$f" ]; then
    HASH=$(git hash-object -w "$f" 2>/dev/null)
    if [ -n "$HASH" ]; then
      git update-index --add --cacheinfo 100644,"$HASH","$f" 2>/dev/null
    fi
  fi
done

echo "Files in index:"
git ls-files --cached | wc -l
echo "Committing..."
git commit -m "Full Russell Capital Solutions rebuild: 59 pages, 63 engines, all features + voice calibration"
