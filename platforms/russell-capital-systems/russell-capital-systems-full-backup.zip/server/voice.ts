import { Router, Request, Response } from "express";

const router = Router();

// ElevenLabs TTS endpoint - speaks text using Sam's cloned voice
router.post("/api/voice/speak", async (req: Request, res: Response) => {
  try {
    const { text } = req.body;
    if (!text) {
      return res.status(400).json({ error: "text required" });
    }

    const apiKey = process.env.ELEVENLABS_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: "ElevenLabs not configured" });
    }

    // Sam's cloned voice ID
    const voiceId = "z0eCl7vM51ddgsBcVPAqHOP9TBT2";

    const response = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`,
      {
        method: "POST",
        headers: {
          "xi-api-key": apiKey,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text,
          model_id: "eleven_monolingual_v1",
          voice_settings: {
            stability: 0.75,
            similarity_boost: 0.85,
            style: 0.4,
            use_speaker_boost: true,
          },
        }),
      }
    );

    if (!response.ok) {
      const err = await response.text();
      console.error("ElevenLabs error:", err);
      return res.status(response.status).json({ error: "TTS generation failed" });
    }

    // Stream audio back to client
    res.setHeader("Content-Type", "audio/mpeg");
    const buffer = await response.arrayBuffer();
    res.send(Buffer.from(buffer));
  } catch (error) {
    console.error("Voice endpoint error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

export function registerVoiceRoutes(app: any) {
  app.use(router);
}

export default router;
