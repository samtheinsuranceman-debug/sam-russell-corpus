import { useEffect, useRef, useState, useCallback } from "react";

// === PURE SENSORY IMMERSION CALIBRATION ===
// NO TEXT ON SCREEN. Voice speaks. Mic listens. Colors react.

const FRAMING_SCRIPT = `Welcome to Russell Capital Solutions. Before we talk about your money, we want to talk about YOU. Most financial advisors spend more time studying the markets than they do studying their clients. Their values, beliefs, family roles, goals, and how they actually make decisions. We don't make that mistake. We are the first financial platform that puts YOU first, before the money. This Calibrate process is a patented technology. It includes five different patents. It is backed by studies from Yale and Harvard that show when advisors and doctors take the time to truly stand in their clients' shoes, the results are dramatically better. We are going to spend real time learning how you see the world, how you process information, what matters most to you, and what your future looks like when everything is working perfectly. This is not just about numbers. This is about giving you an extraordinary human experience with your money. Think of this like going to the gym. You might not feel like doing it at first, but once you get into the flow, you will feel energized, self-aware, and excited. Lets begin.`;

const QUESTIONS = [
  "On a scale of 1 to 10, how comfortable are you with market ups and downs?",
  "When you make a really good decision, what does that feel like in your body?",
  "What is one financial goal you want to hit in the next 5 years?",
  "What does that goal look like, sound like, and feel like when you achieve it?",
  "When you think about your money, what emotion comes up first?",
  "Who in your family shaped how you think about wealth?",
  "If your money could talk, what would it say to you right now?",
  "What does financial freedom actually mean to you, in your own words?",
  "When was the last time you felt truly confident about a financial decision?",
  "What would you do differently if you knew you could not fail?",
  "How do you typically make big decisions? Head first or gut first?",
  "What does your ideal Tuesday look like 5 years from now?",
  "When you hear the word risk, what image comes to mind?",
  "What legacy do you want to leave for the people you love?",
  "If I could solve one financial problem for you today, what would it be?",
  "How do you feel about debt? Is it a tool or a trap?",
  "What does enough mean to you?",
  "When you are stressed about money, where do you feel it in your body?",
  "What would your life look like if money was never a concern again?",
];

export default function Calibrate() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number>(0);
  const [phase, setPhase] = useState<"waiting" | "framing" | "questions" | "listening" | "complete">("waiting");
  const [questionIndex, setQuestionIndex] = useState(0);
  const [isListening, setIsListening] = useState(false);
  const [colors, setColors] = useState({ r: 20, g: 10, b: 40, h: 0.5 });
  const orbsRef = useRef<Array<{x: number; y: number; vx: number; vy: number; r: number; color: string; phase: number}>>([]);
  const breathRef = useRef(0);

  const initMic = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const ctx = new AudioContext();
      audioContextRef.current = ctx;
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      const source = ctx.createMediaStreamSource(stream);
      source.connect(analyser);
      analyserRef.current = analyser;
      setIsListening(true);
    } catch (e) {
      console.error("Mic access denied", e);
    }
  }, []);

  const speak = useCallback(async (text: string): Promise<void> => {
    return new Promise(async (resolve) => {
      try {
        const res = await fetch("/api/voice/speak", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text }),
        });
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const audio = new Audio(url);
        audio.onended = () => { URL.revokeObjectURL(url); resolve(); };
        audio.onerror = () => resolve();
        await audio.play();
      } catch (e) {
        console.error("Speech error:", e);
        await new Promise(r => setTimeout(r, text.length * 50));
        resolve();
      }
    });
  }, []);

  const startCalibration = useCallback(async () => {
    await initMic();
    setPhase("framing");
    await speak(FRAMING_SCRIPT);
    setPhase("questions");
    for (let i = 0; i < QUESTIONS.length; i++) {
      setQuestionIndex(i);
      await speak(QUESTIONS[i]);
      setPhase("listening");
      await new Promise(r => setTimeout(r, 8000));
      setPhase("questions");
    }
    await speak("Thank you. Your Wealth Genome is now being calculated.");
    setPhase("complete");
  }, [initMic, speak]);

  useEffect(() => {
    const analyser = analyserRef.current;
    const dataArray = new Uint8Array(analyser.frequencyBinCount);
    const updateColors = () => {
      analyser.getByteFrequencyData(dataArray);
      const bass = dataArray.slice(0, 10).reduce((a, b) => a + b, 0) / 10;
      const mid = dataArray.slice(10, 60).reduce((a, b) => a + b, 0) / 50;
      const treble = dataArray.slice(60, 128).reduce((a, b) => a + b, 0) / 68;
      const energy = (bass + mid + treble) / 3;
      setColors(prev => ({
        r: Math.floor(prev.r * 0.92 + (bass / 255) * 200 * 0.08 + 20),
        g: Math.floor(prev.g * 0.92 + (mid / 255) * 180 * 0.08 + 10),
        b: Math.floor(prev.b * 0.92 + (treble / 255) * 220 * 0.08 + 40),
        h: prev.h * 0.95 + (energy / 255) * 0.05,
      }));
      animFrameRef.current = requestAnimationFrame(updateColors);
    };
    updateColors();
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [isListening]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let w = window.innerWidth;
    let h = window.innerHeight;
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d")!;
    if (orbsRef.current.length === 0) {
      for (let i = 0; i < 12; i++) {
        orbsRef.current.push({
          x: Math.random() * w, y: Math.random() * h,
          vx: (Math.random() - 0.5) * 0.5, vy: (Math.random() - 0.5) * 0.5,
          r: 60 + Math.random() * 120,
          color: `hsl(${Math.random() * 360}, 70%, 50%)`,
          phase: Math.random() * Math.PI * 2,
        });
      }
    }
    const resize = () => { w = window.innerWidth; h = window.innerHeight; canvas.width = w; canvas.height = h; };
    window.addEventListener("resize", resize);
    let frame = 0;
    const animate = () => {
      frame++;
      breathRef.current += 0.008;
      const breathScale = 1 + Math.sin(breathRef.current) * 0.15;
      const grad = ctx.createRadialGradient(w/2, h/2, 0, w/2, h/2, w*0.7);
      grad.addColorStop(0, `rgb(${Math.floor(colors.r*0.3)}, ${Math.floor(colors.g*0.3)}, ${Math.floor(colors.b*0.5)})`);
      grad.addColorStop(1, `rgb(${Math.floor(colors.r*0.05)}, ${Math.floor(colors.g*0.05)}, ${Math.floor(colors.b*0.1)})`);
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
      orbsRef.current.forEach((orb, i) => {
        orb.phase += 0.01 + colors.h * 0.02;
        orb.x += orb.vx + Math.sin(orb.phase) * 0.3;
        orb.y += orb.vy + Math.cos(orb.phase * 0.7) * 0.3;
        if (orb.x < -orb.r) orb.x = w + orb.r;
        if (orb.x > w + orb.r) orb.x = -orb.r;
        if (orb.y < -orb.r) orb.y = h + orb.r;
        if (orb.y > h + orb.r) orb.y = -orb.r;
        const orbR = orb.r * breathScale * (1 + colors.h * 0.3);
        const hue = (i * 30 + colors.r + frame * 0.1) % 360;
        const sat = 60 + colors.g * 0.2;
        const light = 30 + colors.b * 0.15;
        const orbGrad = ctx.createRadialGradient(orb.x, orb.y, 0, orb.x, orb.y, orbR);
        orbGrad.addColorStop(0, `hsla(${hue}, ${sat}%, ${light}%, 0.6)`);
        orbGrad.addColorStop(0.5, `hsla(${hue}, ${sat}%, ${light*0.7}%, 0.2)`);
        orbGrad.addColorStop(1, `hsla(${hue}, ${sat}%, ${light*0.5}%, 0)`);
        ctx.fillStyle = orbGrad;
        ctx.beginPath();
        ctx.arc(orb.x, orb.y, orbR, 0, Math.PI * 2);
        ctx.fill();
      });
      const ringR = 80 * breathScale + colors.h * 40;
      const ringGrad = ctx.createRadialGradient(w/2, h/2, ringR*0.8, w/2, h/2, ringR);
      ringGrad.addColorStop(0, `hsla(${(frame*0.3)%360}, 80%, 60%, 0)`);
      ringGrad.addColorStop(0.7, `hsla(${(frame*0.3)%360}, 80%, 60%, ${phase === "listening" ? 0.4 : 0.15})`);
      ringGrad.addColorStop(1, `hsla(${(frame*0.3)%360}, 80%, 60%, 0)`);
      ctx.fillStyle = ringGrad;
      ctx.beginPath();
      ctx.arc(w/2, h/2, ringR, 0, Math.PI * 2);
      ctx.fill();
      requestAnimationFrame(animate);
    };
    const id = requestAnimationFrame(animate);
    return () => { cancelAnimationFrame(id); window.removeEventListener("resize", resize); };
  }, [colors, phase]);

  return (
    <div className="fixed inset-0 overflow-hidden cursor-pointer" onClick={phase === "waiting" ? startCalibration : undefined} style={{ background: "#000" }}>
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
      {phase === "waiting" && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-32 h-32 rounded-full animate-pulse opacity-40" style={{ background: "radial-gradient(circle, rgba(120,80,200,0.6) 0%, transparent 70%)", boxShadow: "0 0 80px 40px rgba(120,80,200,0.2)" }} />
        </div>
      )}
    </div>
  );
}
