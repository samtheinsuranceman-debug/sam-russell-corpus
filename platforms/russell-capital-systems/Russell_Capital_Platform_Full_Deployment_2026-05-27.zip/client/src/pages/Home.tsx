import React, { useState } from 'react';
import { StrategyProvider, useStrategy } from '@/contexts/StrategyContext';
import HipaaReleaseGate from '@/components/HipaaReleaseGate';
import PhysicianQuiz from '@/components/PhysicianQuiz';
import ClientFactFinder from '@/components/ClientFactFinder';
import MortgageKiller from '@/components/MortgageKiller';
import MortgageKillerV2 from '@/components/MortgageKillerV2';
import RentalCompoundingEngine from '@/components/RentalCompoundingEngine';
import TaxLeakageDashboard from '@/components/TaxLeakageDashboard';
import LifeForgeSimulator from '@/components/LifeForgeSimulator';
import WealthGenomeReveal from '@/components/WealthGenomeReveal';
import PDFExportSystem from '@/components/PDFExportSystem';
import MeetingPrep from '@/components/MeetingPrep';
import AdminPortal from '@/components/AdminPortal';
import CompetitiveAnalysis from '@/components/CompetitiveAnalysis';

// Import original Tier 3 components from the deployment package
import HybridCalibrateSystem from '@/components/Russell_Capital_Final_Deployment/HybridCalibrateSystem';
import { EmergencyLiquidityEngine as Tier3_EmergencyLiquidityEngine } from '@/components/Russell_Capital_Final_Deployment/Tier3_EmergencyLiquidityEngine';
import { HealthspanWealthspan as Tier3_HealthspanWealthspan } from '@/components/Russell_Capital_Final_Deployment/Tier3_HealthspanWealthspan';
import { LegacyMessageVault as Tier3_LegacyMessageVault } from '@/components/Russell_Capital_Final_Deployment/Tier3_LegacyMessageVault';
import { PredictiveLifeEventsEngine as Tier3_PredictiveLifeEventsEngine } from '@/components/Russell_Capital_Final_Deployment/Tier3_PredictiveLifeEventsEngine';
import { TaxLawSimulator as Tier3_TaxLawSimulator } from '@/components/Russell_Capital_Final_Deployment/Tier3_TaxLawSimulator';
import AdvisorCommandCenter from '@/components/AdvisorCommandCenter';

import { 
  Stethoscope, ShieldAlert, Activity, ClipboardList, TrendingUp, 
  DollarSign, Sparkles, Award, Key, Lock, Eye, Play, Heart, Flame
} from 'lucide-react';

function DashboardContent() {
  const { quizCompleted, quizScore, clientData } = useStrategy();
  const [activeSection, setActiveTab] = useState<string>('calibrate');

  const menuItems = [
    { id: 'calibrate', name: 'Hybrid Calibration', icon: Activity },
    { id: 'fact_finder', name: 'Fact Finder', icon: ClipboardList },
    { id: 'mortgage_killer', name: 'Mortgage Killer', icon: Flame },
    { id: 'mortgage_v2', name: 'Mortgage V2 & STR', icon: TrendingUp },
    { id: 'rental_engine', name: 'Rental Compounding', icon: DollarSign },
    { id: 'tax_leakage', name: 'Tax Leakage', icon: ShieldAlert },
    { id: 'lifeforge', name: 'LifeForge MC', icon: Sparkles },
    { id: 'genome', name: 'Wealth Genome', icon: Award },
    { id: 'tier3_emergency', name: 'Emergency Liquidity', icon: Heart },
    { id: 'tier3_healthspan', name: 'Healthspan Wealthspan', icon: Stethoscope },
    { id: 'tier3_legacy', name: 'Legacy Vault', icon: Lock },
    { id: 'tier3_predictive', name: 'Predictive Life Events', icon: Play },
    { id: 'tier3_taxlaw', name: 'Tax Law Simulator', icon: Key },
    { id: 'pdf_export', name: 'PDF Export', icon: Eye },
    { id: 'meeting_prep', name: 'Meeting Prep', icon: ClipboardList },
    { id: 'admin', name: 'Sam Russell Portal', icon: Lock },
  ];

  return (
    <div className="min-h-screen bg-zinc-950 text-foreground flex flex-col">
      {/* Header Banner with Premium Styling */}
      <header className="border-b border-zinc-900 bg-zinc-950/80 backdrop-blur-md sticky top-0 z-40 px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-2xl border border-emerald-500/20">
              <Stethoscope className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-white font-sans flex items-center gap-2">
                Russell Capital Platform <span className="text-xs bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/20 font-mono font-medium">v2.5 PRO</span>
              </h1>
              <p className="text-xs text-zinc-500 font-mono">Behavioral Wealth Operating System</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3 text-xs text-zinc-400 font-mono bg-zinc-900/50 px-4 py-2 rounded-xl border border-zinc-800">
            <span>Verified Agent Access:</span>
            <span className="text-emerald-400 font-semibold">sam@russellcapitalsystems.com</span>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col lg:flex-row max-w-7xl w-full mx-auto p-4 md:p-6 gap-6">
        {/* Navigation Sidebar */}
        <aside className="w-full lg:w-64 shrink-0 space-y-2">
          <div className="text-zinc-500 text-[10px] tracking-[3px] font-mono mb-4 px-3">NAVIGATION SYSTEMS</div>
          <nav className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-1 gap-1">
            {menuItems.map(item => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition text-left ${
                    isActive 
                      ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/10' 
                      : 'text-zinc-400 hover:text-white hover:bg-zinc-900/60'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.name}</span>
                </button>
              );
            })}
          </nav>
        </aside>

        {/* Dynamic Content Panel */}
        <main className="flex-1 min-w-0 space-y-6">
          {/* Physician Quiz Lead Magnet - Gated if not completed */}
          {!quizCompleted && activeSection !== 'admin' && (
            <div className="mb-6">
              <PhysicianQuiz />
            </div>
          )}

          {/* Render Active Component */}
          {activeSection === 'calibrate' && (
            <div className="space-y-6">
              <HybridCalibrateSystem />
              <AdvisorCommandCenter />
            </div>
          )}
          {activeSection === 'fact_finder' && <ClientFactFinder />}
          {activeSection === 'mortgage_killer' && <MortgageKiller />}
          {activeSection === 'mortgage_v2' && <MortgageKillerV2 />}
          {activeSection === 'rental_engine' && <RentalCompoundingEngine />}
          {activeSection === 'tax_leakage' && <TaxLeakageDashboard />}
          {activeSection === 'lifeforge' && <LifeForgeSimulator />}
          {activeSection === 'genome' && <WealthGenomeReveal />}
          {activeSection === 'tier3_emergency' && <Tier3_EmergencyLiquidityEngine totalNetWorth={clientData.netWorth} />}
          {activeSection === 'tier3_healthspan' && <Tier3_HealthspanWealthspan baseNetWorth={clientData.netWorth} retirementAge={65} />}
          {activeSection === 'tier3_legacy' && <Tier3_LegacyMessageVault />}
          {activeSection === 'tier3_predictive' && <Tier3_PredictiveLifeEventsEngine clientData={clientData} />}
          {activeSection === 'tier3_taxlaw' && <Tier3_TaxLawSimulator currentNetWorth={clientData.netWorth} annualIncome={clientData.annualIncome} currentTaxLeakage={clientData.annualIncome * (clientData.taxBracket / 100)} />}
          {activeSection === 'pdf_export' && <PDFExportSystem />}
          {activeSection === 'meeting_prep' && <MeetingPrep />}
          {activeSection === 'admin' && <AdminPortal />}
        </main>
      </div>

      {/* Footer */}
      <footer className="border-t border-zinc-900 bg-zinc-950/40 py-6 text-center text-xs text-zinc-600 font-mono mt-auto">
        <p>© 2026 Russell Capital Systems LLC. All rights reserved. SEC Registered Investment Advisor. Patent Pending.</p>
      </footer>
    </div>
  );
}

export default function Home() {
  return (
    <StrategyProvider>
      <HipaaReleaseGate>
        <DashboardContent />
      </HipaaReleaseGate>
    </StrategyProvider>
  );
}
