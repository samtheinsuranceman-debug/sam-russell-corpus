import React, { createContext, useContext, useState, useEffect } from 'react';

export interface ClientData {
  age: number;
  annualIncome: number;
  netWorth: number;
  hasKids: boolean;
  married: boolean;
  parentsAlive: boolean;
  healthScore: number;
  schoolDebt: number;
  schoolInterestRate: number;
  taxBracket: number;
  monthlySavings: number;
  currentMortgage: number;
  mortgageRate: number;
  homeValue: number;
  hipaaSigned: boolean;
}

interface StrategyContextType {
  clientData: ClientData;
  updateClientData: (data: Partial<ClientData>) => void;
  selectedGenome: string | null;
  setSelectedGenome: (genome: string | null) => void;
  quizCompleted: boolean;
  setQuizCompleted: (completed: boolean) => void;
  quizScore: number | null;
  setQuizScore: (score: number | null) => void;
}

const defaultClientData: ClientData = {
  age: 42,
  annualIncome: 380000,
  netWorth: 1850000,
  hasKids: true,
  married: true,
  parentsAlive: true,
  healthScore: 82,
  schoolDebt: 120000,
  schoolInterestRate: 6.8,
  taxBracket: 35,
  monthlySavings: 8500,
  currentMortgage: 450000,
  mortgageRate: 6.2,
  homeValue: 850000,
  hipaaSigned: false,
};

const StrategyContext = createContext<StrategyContextType | undefined>(undefined);

export function StrategyProvider({ children }: { children: React.ReactNode }) {
  const [clientData, setClientData] = useState<ClientData>(() => {
    const saved = localStorage.getItem('rc_client_data');
    if (saved) {
      try {
        return { ...defaultClientData, ...JSON.parse(saved) };
      } catch (e) {
        return defaultClientData;
      }
    }
    return defaultClientData;
  });

  const [selectedGenome, setSelectedGenome] = useState<string | null>(null);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [quizScore, setQuizScore] = useState<number | null>(null);

  useEffect(() => {
    localStorage.setItem('rc_client_data', JSON.stringify(clientData));
  }, [clientData]);

  const updateClientData = (data: Partial<ClientData>) => {
    setClientData(prev => ({ ...prev, ...data }));
  };

  return (
    <StrategyContext.Provider value={{
      clientData,
      updateClientData,
      selectedGenome,
      setSelectedGenome,
      quizCompleted,
      setQuizCompleted,
      quizScore,
      setQuizScore,
    }}>
      {children}
    </StrategyContext.Provider>
  );
}

export function useStrategy() {
  const context = useContext(StrategyContext);
  if (!context) {
    throw new Error('useStrategy must be used within a StrategyProvider');
  }
  return context;
}
