import React from 'react';
import { ShieldAlert, Lock, Sparkles, TrendingUp, DollarSign } from 'lucide-react';

interface CompetitiveAnalysisProps {
  isSubscriber: boolean;
}

export default function CompetitiveAnalysis({ isSubscriber }: CompetitiveAnalysisProps) {
  if (!isSubscriber) {
    return (
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-12 text-center max-w-2xl mx-auto my-12 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-yellow-500/5 rounded-full blur-3xl -z-10" />
        <div className="inline-flex p-4 bg-yellow-500/10 text-yellow-500 rounded-full mb-6">
          <Lock className="w-10 h-10" />
        </div>
        <h3 className="text-2xl font-semibold mb-3">Competitive Analysis Center</h3>
        <p className="text-zinc-400 text-sm max-w-md mx-auto mb-8">
          This advanced analysis tool is exclusively available to verified, paid subscribers and Sam Russell. Bypassed subscription rules are enabled for platform administrators.
        </p>
        <button 
          onClick={() => alert('Please contact sam@russellcapitalsystems.com to upgrade your subscription.')}
          className="px-8 py-3 bg-yellow-500 hover:bg-yellow-400 text-black font-semibold rounded-2xl transition"
        >
          Upgrade Subscription to Unlock
        </button>
      </div>
    );
  }

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-10 space-y-8">
      <div className="flex items-center gap-3 border-b border-zinc-900 pb-6">
        <div className="p-2.5 bg-yellow-500/10 text-yellow-500 rounded-xl">
          <Sparkles className="w-6 h-6" />
        </div>
        <div>
          <div className="text-yellow-500 text-[10px] tracking-[3px] font-mono">EXCLUSIVE INTELLIGENCE</div>
          <h3 className="text-2xl font-semibold tracking-tight">Competitive Analysis Center</h3>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 space-y-4">
          <h4 className="font-semibold text-lg flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-yellow-500" />
            Market Share Comparison
          </h4>
          <p className="text-xs text-zinc-400 leading-relaxed">
            Real-time modeling comparing Russell Capital's Policy-First strategy against standard wealth management firms (Merrill Lynch, Morgan Stanley). Projections show up to <strong>42% higher cash-value accumulation</strong> over 30 years.
          </p>
          <div className="border-t border-zinc-800 pt-4 space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">Standard Wealth RIA:</span>
              <span className="font-mono text-red-400">1.2% AUM Drag</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">Russell Capital System:</span>
              <span className="font-mono text-emerald-400">0.0% AUM Drag (IUL-Backed)</span>
            </div>
          </div>
        </div>

        <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 space-y-4">
          <h4 className="font-semibold text-lg flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-yellow-500" />
            Tax Arbitrage Efficiency
          </h4>
          <p className="text-xs text-zinc-400 leading-relaxed">
            Comparative analysis on tax leakage. Traditional stock/bond portfolios leak up to <strong>35% of total gains</strong> to capital gains and NIIT, whereas the Policy-First loop shields 100% of growth.
          </p>
          <div className="border-t border-zinc-800 pt-4 space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">Traditional Capital Gains:</span>
              <span className="font-mono text-red-400">-$420,000 lost</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">Policy-First Tax Shield:</span>
              <span className="font-mono text-emerald-400">$0 tax liability</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
