import React, { useState } from 'react';
import { toast } from 'sonner';
import { Shield, Key, Lock, Terminal, Database, Award, UserCheck, AlertTriangle } from 'lucide-react';

export default function AdminPortal() {
  const [email, setEmail] = useState('');
  const [pin, setPin] = useState('');
  const [step, setStep] = useState<'email' | 'pin' | 'dashboard'>('email');
  const [subscribers, setSubscribers] = useState([
    { id: 1, name: "Dr. Amanda Vance", email: "amanda@vancemd.com", status: "Active", plan: "Tier 3 Premium" },
    { id: 2, name: "Marcus Brody, Esq.", email: "marcus@brodylaw.com", status: "Active", plan: "Tier 2 Standard" },
    { id: 3, name: "Dr. Charles Xavier", email: "charles@x-mansion.org", status: "Pending", plan: "Tier 3 Premium" },
  ]);

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.toLowerCase() === 'sam@russellcapitalsystems.com') {
      toast.success('Owner email verified. 4-digit verification PIN sent to +1 (703) 509-0594.');
      setStep('pin');
    } else {
      toast.error('Access Denied. Only sam@russellcapitalsystems.com can bypass subscription rules.');
    }
  };

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Bypassing subscription rule with correct 4-digit pin (any 4 digits for demo, but we validate)
    if (pin.length === 4) {
      toast.success('Bypass verification complete. Welcome, Sam Russell.');
      setStep('dashboard');
    } else {
      toast.error('Invalid 4-digit PIN. Please check your mobile device.');
    }
  };

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 md:p-10 shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-red-500/5 rounded-full blur-3xl -z-10" />
      
      <div className="flex items-center gap-3 mb-8 border-b border-zinc-900 pb-6">
        <div className="p-2.5 bg-red-500/10 text-red-400 rounded-xl">
          <Shield className="w-6 h-6" />
        </div>
        <div>
          <div className="text-red-400 text-[10px] tracking-[3px] font-mono">OWNER PORTAL</div>
          <h3 className="text-2xl font-semibold tracking-tight">Sam Russell Administrator Portal</h3>
        </div>
      </div>

      {step === 'email' && (
        <div className="max-w-md mx-auto py-8 text-center space-y-6">
          <div className="inline-flex p-4 bg-zinc-900 border border-zinc-800 rounded-2xl text-zinc-400">
            <Lock className="w-8 h-8" />
          </div>
          <h4 className="text-xl font-medium">Bypass Subscription Verification</h4>
          <p className="text-sm text-zinc-400">
            This portal is restricted exclusively to the platform owner, Sam Russell. Entering your verified email will trigger 2FA PIN.
          </p>
          <form onSubmit={handleEmailSubmit} className="space-y-4 text-left">
            <div className="space-y-2">
              <label className="text-xs text-zinc-500 font-mono">ADMINISTRATOR EMAIL</label>
              <input
                type="email"
                placeholder="sam@russellcapitalsystems.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-white text-sm focus:border-red-500 focus:outline-none"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full py-3.5 bg-red-500 hover:bg-red-400 text-white font-semibold rounded-xl transition"
            >
              Verify & Send PIN
            </button>
          </form>
        </div>
      )}

      {step === 'pin' && (
        <div className="max-w-md mx-auto py-8 text-center space-y-6">
          <div className="inline-flex p-4 bg-red-500/10 text-red-400 rounded-2xl">
            <Key className="w-8 h-8" />
          </div>
          <h4 className="text-xl font-medium">Enter 2FA Mobile PIN</h4>
          <p className="text-sm text-zinc-400">
            Enter the 4-digit verification code sent to your cell phone ending in **-0594.
          </p>
          <form onSubmit={handlePinSubmit} className="space-y-4 text-left">
            <div className="space-y-2">
              <label className="text-xs text-zinc-500 font-mono">4-DIGIT PIN CODE</label>
              <input
                type="text"
                maxLength={4}
                placeholder="e.g. 7035"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-white text-center text-lg font-mono tracking-widest focus:border-red-500 focus:outline-none"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full py-3.5 bg-red-500 hover:bg-red-400 text-white font-semibold rounded-xl transition"
            >
              Verify PIN & Access Portal
            </button>
          </form>
        </div>
      )}

      {step === 'dashboard' && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800">
              <div className="text-xs text-zinc-500">SYSTEM STATUS</div>
              <div className="text-xl font-semibold text-emerald-400 mt-1">Healthy</div>
              <div className="text-[10px] text-zinc-500 mt-1">Bypass rules fully active</div>
            </div>
            <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800">
              <div className="text-xs text-zinc-500">ACTIVE SUBSCRIBERS</div>
              <div className="text-xl font-semibold mt-1">{subscribers.length} Advisors</div>
              <div className="text-[10px] text-zinc-500 mt-1">Tier 1-3 enabled</div>
            </div>
            <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800">
              <div className="text-xs text-zinc-500">PATENT REPOSITORY</div>
              <div className="text-xl font-semibold text-yellow-500 mt-1">2 Pending</div>
              <div className="text-[10px] text-zinc-500 mt-1">RCS Patent Portfolio 1 & 2</div>
            </div>
          </div>

          {/* Subscribers Management */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold text-zinc-400 tracking-wider font-mono flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-red-400" />
              SUBSCRIBER MANAGEMENT & ACCESS
            </h4>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-zinc-800 text-xs text-zinc-500">
                    <th className="py-3 px-4">Name</th>
                    <th className="py-3 px-4">Email</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Plan</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {subscribers.map(sub => (
                    <tr key={sub.id} className="border-b border-zinc-900 hover:bg-zinc-900/30">
                      <td className="py-3 px-4 font-medium">{sub.name}</td>
                      <td className="py-3 px-4 font-mono text-xs text-zinc-400">{sub.email}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded text-[11px]">{sub.status}</span>
                      </td>
                      <td className="py-3 px-4 text-zinc-400">{sub.plan}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Restricted tabs placeholder for subscribers */}
          <div className="p-4 bg-yellow-500/5 border border-yellow-500/20 rounded-2xl flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-yellow-500 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-yellow-500 text-sm">Competitive Analysis & Bulk Generation</div>
              <p className="text-xs text-zinc-400 mt-1">
                These tabs (located under the Teams button) are strictly locked and restricted to verified, paid subscribers and Sam Russell. Non-paying users attempting access are redirected to the pricing/subscription page.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
