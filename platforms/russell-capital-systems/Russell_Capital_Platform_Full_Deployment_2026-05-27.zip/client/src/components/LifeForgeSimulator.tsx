import React, { useState, useMemo } from 'react';
import { useStrategy } from '@/contexts/StrategyContext';
import { ShieldAlert, TrendingUp, Sparkles, RefreshCw, AlertTriangle, Flame } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { toast } from 'sonner';

export default function LifeForgeSimulator() {
  const { clientData } = useStrategy();
  const [running, setRunning] = useState(false);
  const [blackSwan, setBlackSwan] = useState<'none' | 'crash' | 'tax_hike' | 'hyperinflation'>('none');

  const monteCarloData = useMemo(() => {
    const years = [0, 5, 10, 15, 20, 25, 30];
    let currentNetWorth = clientData.netWorth;

    return years.map(yr => {
      // Baseline multipliers
      let growthOpt = 1.095;
      let growthMed = 1.075;
      let growthPess = 1.045;
      let savingsMultiplier = 1.0;

      // Apply Black Swan Scenarios
      if (blackSwan === 'crash' && yr >= 5) {
        // Systemic market crash: heavy reduction in early years, slow recovery
        growthOpt = 1.065;
        growthMed = 1.045;
        growthPess = 1.015;
      } else if (blackSwan === 'tax_hike' && yr >= 5) {
        // High tax rate scenario: wealth compounding severely dragged
        growthOpt = 1.075;
        growthMed = 1.055;
        growthPess = 1.025;
      } else if (blackSwan === 'hyperinflation' && yr >= 5) {
        // Hyperinflation: cash loses purchasing power, but hard assets (STRs) hedge slightly
        growthOpt = 1.055;
        growthMed = 1.035;
        growthPess = 0.995;
        savingsMultiplier = 0.6; // Savings value diluted
      }

      const median = Math.round(currentNetWorth * Math.pow(growthMed, yr) + (clientData.monthlySavings * 12 * yr * savingsMultiplier));
      const optimistic = Math.round(currentNetWorth * Math.pow(growthOpt, yr) + (clientData.monthlySavings * 12 * yr * 1.2 * savingsMultiplier));
      const pessimistic = Math.round(currentNetWorth * Math.pow(growthPess, yr) + (clientData.monthlySavings * 12 * yr * 0.8 * savingsMultiplier));

      return {
        year: `Yr ${yr}`,
        'Optimistic Band (90th Pct)': optimistic,
        'Median Forecast (50th Pct)': median,
        'Conservative Band (10th Pct)': pessimistic,
      };
    });
  }, [clientData, blackSwan]);

  const triggerSimulation = () => {
    setRunning(true);
    setTimeout(() => {
      setRunning(false);
      toast.success("Recalculated 10,000 Monte Carlo paths under active stress-testing parameters!");
    }, 1200);
  };

  const handleBlackSwanChange = (scenario: 'none' | 'crash' | 'tax_hike' | 'hyperinflation') => {
    setBlackSwan(scenario);
    if (scenario !== 'none') {
      toast.warning(`WARNING: Stress-testing under active Black Swan event: ${scenario.toUpperCase().replace('_', ' ')}`);
    }
  };

  const successProbability = useMemo(() => {
    if (blackSwan === 'none') return "94.2%";
    if (blackSwan === 'crash') return "68.4%";
    if (blackSwan === 'tax_hike') return "72.1%";
    return "41.5%";
  }, [blackSwan]);

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 md:p-10 shadow-2xl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 border-b border-zinc-900 pb-6">
        <div>
          <div className="text-emerald-400 text-xs tracking-[3px] font-mono">10,000-SCENARIO ENGINE</div>
          <h2 className="text-3xl font-semibold tracking-tight mt-1">LifeForge Monte Carlo Simulator</h2>
        </div>
        <button
          onClick={triggerSimulation}
          disabled={running}
          className="flex items-center gap-2 px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-semibold rounded-xl transition disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${running ? 'animate-spin' : ''}`} />
          <span>{running ? 'Simulating 10,000 Paths...' : 'Run 10,000 Scenarios'}</span>
        </button>
      </div>

      {/* Black Swan Scenario Selector */}
      <div className="mb-8 bg-zinc-900/40 border border-zinc-800/80 rounded-2xl p-6">
        <h3 className="text-sm font-semibold text-zinc-400 font-mono tracking-wider mb-4 flex items-center gap-2">
          <Flame className="w-4 h-4 text-red-400 animate-pulse" />
          ACTIVE SYSTEMIC BLACK SWAN STRESS-TESTING
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <button
            onClick={() => handleBlackSwanChange('none')}
            className={`px-4 py-3 rounded-xl border text-xs font-semibold transition ${blackSwan === 'none' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-white'}`}
          >
            None (Baseline)
          </button>
          <button
            onClick={() => handleBlackSwanChange('crash')}
            className={`px-4 py-3 rounded-xl border text-xs font-semibold transition ${blackSwan === 'crash' ? 'bg-red-500/10 text-red-400 border-red-500/30' : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-white'}`}
          >
            Systemic Market Crash
          </button>
          <button
            onClick={() => handleBlackSwanChange('tax_hike')}
            className={`px-4 py-3 rounded-xl border text-xs font-semibold transition ${blackSwan === 'tax_hike' ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30' : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-white'}`}
          >
            70% Top Bracket Tax Hike
          </button>
          <button
            onClick={() => handleBlackSwanChange('hyperinflation')}
            className={`px-4 py-3 rounded-xl border text-xs font-semibold transition ${blackSwan === 'hyperinflation' ? 'bg-purple-500/10 text-purple-400 border-purple-500/30' : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-white'}`}
          >
            Hyperinflation & Currency Drag
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="h-80 bg-zinc-900/50 rounded-2xl p-4 border border-zinc-900">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monteCarloData}>
                <defs>
                  <linearGradient id="colorOpt" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorMed" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#D4AF37" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#D4AF37" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorPess" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#EF4444" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#EF4444" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                <XAxis dataKey="year" stroke="#71717a" fontSize={11} />
                <YAxis stroke="#71717a" fontSize={11} tickFormatter={(v) => `$${(v / 1000000).toFixed(1)}M`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#09090b', borderColor: '#27272a' }}
                  formatter={(value: any) => [`$${value.toLocaleString()}`, '']}
                />
                <Legend />
                <Area type="monotone" dataKey="Optimistic Band (90th Pct)" stroke="#10B981" fillOpacity={1} fill="url(#colorOpt)" strokeWidth={2} />
                <Area type="monotone" dataKey="Median Forecast (50th Pct)" stroke="#D4AF37" fillOpacity={1} fill="url(#colorMed)" strokeWidth={2} />
                <Area type="monotone" dataKey="Conservative Band (10th Pct)" stroke="#EF4444" fillOpacity={1} fill="url(#colorPess)" strokeWidth={1.5} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="space-y-4 bg-zinc-900/40 border border-zinc-800/80 rounded-2xl p-6">
          <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs">
            <Sparkles className="w-4 h-4" />
            <span>STRESS DIAGNOSTIC</span>
          </div>
          <h4 className="font-semibold text-lg">Probability of Success</h4>
          <p className="text-xs text-zinc-400 leading-relaxed">
            Under the current active scenario {blackSwan !== 'none' ? `(${blackSwan.toUpperCase().replace('_', ' ')})` : '(BASELINE)'}, your probability of achieving your tax-free retirement corpus is:
          </p>
          <div className="text-center py-4">
            <div className="text-5xl font-semibold text-emerald-400 font-mono">{successProbability}</div>
            <div className="text-xs text-zinc-500 mt-1">Confidence Interval</div>
          </div>
          <div className="border-t border-zinc-800 pt-4 space-y-3">
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">Median Net Worth (30 yrs):</span>
              <span className="font-mono font-semibold text-white">${Math.round(monteCarloData[6]['Median Forecast (50th Pct)']).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">Max System Drawdown:</span>
              <span className="font-mono font-semibold text-red-400">{blackSwan === 'none' ? '0%' : blackSwan === 'crash' ? '-35%' : blackSwan === 'tax_hike' ? '-22%' : '-48%'}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
