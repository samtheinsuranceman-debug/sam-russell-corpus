import React, { useState } from 'react';
import { useStrategy } from '@/contexts/StrategyContext';
import { Stethoscope, CheckCircle, Mail, ArrowRight, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

const quizQuestions = [
  {
    id: 1,
    text: "What is your medical specialty / practice type?",
    options: [
      { text: "Surgical / High-Risk Specialty", value: "surgical", points: 20 },
      { text: "Internal Medicine / Primary Care", value: "primary", points: 15 },
      { text: "Pediatrics / Family Medicine", value: "pediatrics", points: 10 },
      { text: "Dentistry / Private Practice Owner", value: "private_owner", points: 25 }
    ]
  },
  {
    id: 2,
    text: "What is your approximate annual household income?",
    options: [
      { text: "$200k - $400k", value: "mid_income", points: 15 },
      { text: "$400k - $800k", value: "high_income", points: 20 },
      { text: "Over $800k", value: "ultra_income", points: 25 },
      { text: "Under $200k", value: "low_income", points: 10 }
    ]
  },
  {
    id: 3,
    text: "What is your current student / school debt balance?",
    options: [
      { text: "Over $250k", value: "debt_heavy", points: 5 },
      { text: "$100k - $250k", value: "debt_mid", points: 12 },
      { text: "Under $100k", value: "debt_low", points: 18 },
      { text: "None / Fully Paid", value: "debt_none", points: 25 }
    ]
  },
  {
    id: 4,
    text: "How many years have you been in active practice?",
    options: [
      { text: "Resident / Fellow / Under 3 years", value: "early", points: 10 },
      { text: "3 - 10 years", value: "mid_career", points: 18 },
      { text: "Over 10 years", value: "veteran", points: 25 }
    ]
  },
  {
    id: 5,
    text: "What is your primary tax-reduction strategy currently?",
    options: [
      { text: "Standard 401k / Backdoor Roth only", value: "standard", points: 10 },
      { text: "Real Estate (STR / Cost Segregation)", value: "real_estate", points: 25 },
      { text: "Cash Balance Plan / Custom IUL structure", value: "advanced", points: 25 },
      { text: "None / W2 tax withholding only", value: "none", points: 5 }
    ]
  }
];

export default function PhysicianQuiz() {
  const { updateClientData, setQuizCompleted, setQuizScore } = useStrategy();
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [email, setEmail] = useState('');
  const [showEmailGate, setShowEmailGate] = useState(false);

  const handleSelectOption = (points: number) => {
    const newAnswers = { ...answers, [currentStep]: points };
    setAnswers(newAnswers);

    if (currentStep < quizQuestions.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setShowEmailGate(true);
    }
  };

  const handleSubmitEmail = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) {
      toast.error('Please enter a valid email address.');
      return;
    }

    // Calculate score
    const totalPoints = Object.values(answers).reduce((sum, pts) => sum + pts, 0);
    
    // Save email & completed state
    updateClientData({ annualIncome: answers[1] === 25 ? 900000 : answers[1] === 20 ? 600000 : 300000 });
    setQuizScore(totalPoints);
    setQuizCompleted(true);
    toast.success('Your Financial Health Score is ready!');
  };

  const currentQuestion = quizQuestions[currentStep];

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 md:p-12 shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl -z-10" />
      
      {!showEmailGate ? (
        <div>
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl">
                <Stethoscope className="w-6 h-6" />
              </div>
              <div>
                <div className="text-emerald-400 text-[10px] tracking-[3px] font-mono">LEAD MAGNET</div>
                <h3 className="text-xl font-semibold">Physician Financial Health Score</h3>
              </div>
            </div>
            <div className="text-xs text-zinc-500 font-mono">
              Step {currentStep + 1} of {quizQuestions.length}
            </div>
          </div>

          <div className="mb-8">
            <div className="h-1.5 bg-zinc-900 rounded-full overflow-hidden">
              <div 
                className="h-full bg-emerald-500 transition-all duration-300"
                style={{ width: `${((currentStep + 1) / quizQuestions.length) * 100}%` }}
              />
            </div>
          </div>

          <h4 className="text-2xl font-medium tracking-tight mb-8 min-h-[64px]">
            {currentQuestion.text}
          </h4>

          <div className="grid gap-3">
            {currentQuestion.options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => handleSelectOption(opt.points)}
                className="w-full text-left p-5 bg-zinc-900 hover:bg-zinc-900/80 border border-zinc-800 hover:border-emerald-500/50 rounded-2xl transition active:scale-[0.99] flex justify-between items-center group"
              >
                <span className="font-medium text-zinc-200 group-hover:text-white">{opt.text}</span>
                <ArrowRight className="w-4 h-4 text-zinc-600 group-hover:text-emerald-400 transition transform group-hover:translate-x-1" />
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="text-center py-6">
          <div className="inline-flex p-4 bg-emerald-500/10 text-emerald-400 rounded-full mb-6">
            <Sparkles className="w-10 h-10 animate-pulse" />
          </div>
          <h3 className="text-3xl font-semibold mb-3">Your Score is Calculated!</h3>
          <p className="text-zinc-400 max-w-md mx-auto mb-8 text-sm">
            We have generated your personalized 25-factor Physician Financial Health Score. Enter your email to reveal your score and custom wealth diagnostic.
          </p>

          <form onSubmit={handleSubmitEmail} className="max-w-md mx-auto space-y-4">
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500" />
              <input
                type="email"
                placeholder="Enter your professional email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl pl-12 pr-5 py-4 text-white focus:border-emerald-500 focus:outline-none transition text-sm"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full py-4 bg-emerald-500 hover:bg-emerald-400 text-black font-semibold rounded-2xl transition flex items-center justify-center gap-2"
            >
              <span>Reveal My Score</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
          <p className="text-[10px] text-zinc-600 mt-4">
            We value privacy. Your details are encrypted and never shared. HIPAA compliant data handling.
          </p>
        </div>
      )}
    </div>
  );
}
