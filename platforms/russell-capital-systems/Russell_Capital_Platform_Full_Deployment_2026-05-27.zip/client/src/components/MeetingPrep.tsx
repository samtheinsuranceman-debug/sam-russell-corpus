import React, { useMemo } from 'react';
import { useStrategy } from '@/contexts/StrategyContext';
import { Sparkles, Calendar, User, FileText, CheckSquare, Presentation } from 'lucide-react';

export default function MeetingPrep() {
  const { clientData } = useStrategy();

  const brief = useMemo(() => {
    const netWorth = clientData.netWorth;
    const schoolDebt = clientData.schoolDebt;
    const taxBracket = clientData.taxBracket;
    
    let priorityTopic = "Tax-Shield & Asset Protection Strategy";
    let demoCalculator = "STR Zero-Tax Shield & Cost Segregation";
    let highlightedAmount = `$${Math.round(schoolDebt * 0.4).toLocaleString()} in student loan optimization savings`;

    if (netWorth > 3000000) {
      priorityTopic = "Multi-Generational Legacy & Trust Circulation";
      demoCalculator = "Legacy Message Vault & Family Council Mode";
      highlightedAmount = `$${Math.round(netWorth * 0.4).toLocaleString()} in estate tax protection`;
    } else if (schoolDebt > 150000) {
      priorityTopic = "Student Loan Amortization & Accelerated Paydown";
      demoCalculator = "Mortgage Killer & School Debt Sync";
      highlightedAmount = `$${Math.round(schoolDebt).toLocaleString()} in active debt restructuring`;
    }

    return {
      priorityTopic,
      demoCalculator,
      highlightedAmount,
      clientType: clientData.annualIncome > 500000 ? "Ultra-High Net Worth Doctor/Attorney" : "High-Income Medical/Legal Professional",
    };
  }, [clientData]);

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 md:p-10 shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl -z-10" />
      
      <div className="flex items-center gap-3 mb-8 border-b border-zinc-900 pb-6">
        <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl">
          <Presentation className="w-6 h-6" />
        </div>
        <div>
          <div className="text-emerald-400 text-[10px] tracking-[3px] font-mono">ADVISOR CO-PILOT</div>
          <h3 className="text-2xl font-semibold tracking-tight">Meeting Prep Auto-Generator</h3>
        </div>
      </div>

      <div className="space-y-6">
        <div className="flex items-center gap-2 text-xs font-mono text-zinc-500">
          <Calendar className="w-4 h-4" />
          <span>AUTO-GENERATED BRIEF FOR UPCOMING CLIENT MEETING</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 space-y-4">
            <h4 className="font-semibold text-lg flex items-center gap-2 text-white">
              <User className="w-5 h-5 text-emerald-400" />
              Client Profile Overview
            </h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-zinc-500">Client Category:</span>
                <span className="text-zinc-300 font-medium">{brief.clientType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">Age / Tax Bracket:</span>
                <span className="text-zinc-300 font-medium">{clientData.age} yrs / {clientData.taxBracket}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">School Debt:</span>
                <span className="text-zinc-300 font-mono">${clientData.schoolDebt.toLocaleString()} ({clientData.schoolInterestRate}%)</span>
              </div>
            </div>
          </div>

          <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 space-y-4">
            <h4 className="font-semibold text-lg flex items-center gap-2 text-white">
              <Sparkles className="w-5 h-5 text-emerald-400" />
              Recommended Topics
            </h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-zinc-500">Priority Strategy:</span>
                <span className="text-emerald-400 font-semibold">{brief.priorityTopic}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">Demo Calculator:</span>
                <span className="text-emerald-400 font-semibold">{brief.demoCalculator}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">Highlight Amount:</span>
                <span className="text-emerald-400 font-semibold">{brief.highlightedAmount}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-zinc-900/50 p-6 rounded-2xl border border-zinc-900 space-y-3">
          <h4 className="font-semibold text-sm text-zinc-400 font-mono flex items-center gap-2">
            <CheckSquare className="w-4 h-4 text-emerald-400" />
            MEETING ACTION ITEMS FOR ADVISOR
          </h4>
          <ul className="text-xs text-zinc-300 space-y-2 list-disc pl-4 leading-relaxed">
            <li>Review HIPAA Signed Release status (Status: <span className="text-emerald-400 font-semibold">{clientData.hipaaSigned ? 'SIGNED' : 'PENDING'}</span>)</li>
            <li>Demo the live <strong>{brief.demoCalculator}</strong>, adjusting variables in real-time.</li>
            <li>Deliver the 1-page personalized brief to the client via their client portal.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
