import React, { useMemo } from 'react';
import { useStrategy } from '@/contexts/StrategyContext';
import { Sparkles, DollarSign, Percent, AlertTriangle, ShieldCheck } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

export default function TaxLeakageDashboard() {
  const { clientData } = useStrategy();

  const taxLeakageData = useMemo(() => {
    const grossIncome = clientData.annualIncome;
    const standardTax = grossIncome * (clientData.taxBracket / 100);
    
    // Russell Capital optimized tax shield (re-characterizing income)
    const optimizedTax = grossIncome * 0.12; // Dynamic cost seg + depreciation reducing tax rate to ~12%
    const leakAmount = standardTax - optimizedTax;

    return [
      {
        name: 'Income & Taxes',
        'Gross Household Income': grossIncome,
        'Standard Tax Leakage': Math.round(standardTax),
        'Russell Capital Optimized Tax': Math.round(optimizedTax),
        'Total Capital Retained': Math.round(leakAmount),
      }
    ];
  }, [clientData]);

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 md:p-10 shadow-2xl">
      <div className="flex items-center gap-3 mb-8 border-b border-zinc-900 pb-6">
        <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl">
          <AlertTriangle className="w-6 h-6" />
        </div>
        <div>
          <div className="text-emerald-400 text-[10px] tracking-[3px] font-mono">TAX ARBITRAGE</div>
          <h3 className="text-2xl font-semibold tracking-tight">Tax Leakage & Retention Analyzer</h3>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <h3 className="text-xl font-medium">Quantifying Your Annual Tax Leakage</h3>
          <p className="text-sm text-zinc-400 leading-relaxed">
            For high-income professionals in the {clientData.taxBracket}% bracket, taxes represent the single largest wealth drag. By utilizing cost segregation, bonus depreciation, and policy-first structures, we can capture and reinvest this leakage.
          </p>

          <div className="h-80 bg-zinc-900/50 rounded-2xl p-4 border border-zinc-900">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={taxLeakageData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                <XAxis dataKey="name" stroke="#71717a" fontSize={11} />
                <YAxis stroke="#71717a" fontSize={11} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#09090b', borderColor: '#27272a' }}
                  formatter={(value: any) => [`$${value.toLocaleString()}`, '']}
                />
                <Legend />
                <Bar dataKey="Standard Tax Leakage" fill="#EF4444" radius={[6, 6, 0, 0]} />
                <Bar dataKey="Russell Capital Optimized Tax" fill="#10B981" radius={[6, 6, 0, 0]} />
                <Bar dataKey="Total Capital Retained" fill="#D4AF37" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="space-y-4 bg-zinc-900/40 border border-zinc-800/80 rounded-2xl p-6">
          <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs">
            <ShieldCheck className="w-4 h-4" />
            <span>ANNUAL RECOVERY DIAGNOSTIC</span>
          </div>
          <h4 className="font-semibold text-lg">Retained Capital</h4>
          <p className="text-xs text-zinc-400 leading-relaxed">
            By shifting from passive asset holding to active tax circulation, you reclaim a massive portion of your household income:
          </p>
          <div className="text-center py-4">
            <div className="text-4xl font-semibold text-emerald-400 font-mono">
              ${(Math.round(clientData.annualIncome * (clientData.taxBracket / 100)) - Math.round(clientData.annualIncome * 0.12)).toLocaleString()}
            </div>
            <div className="text-xs text-zinc-500 mt-1">Annual Reclaimable Capital</div>
          </div>
          <div className="border-t border-zinc-800 pt-4 space-y-3">
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">Unoptimized Tax Leakage:</span>
              <span className="font-mono font-semibold text-red-400">${Math.round(clientData.annualIncome * (clientData.taxBracket / 100)).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">Optimized Annual Tax:</span>
              <span className="font-mono font-semibold text-emerald-400">${Math.round(clientData.annualIncome * 0.12).toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
