import React from 'react';
import { useStrategy } from '@/contexts/StrategyContext';
import { Sparkles, Brain, Award, ShieldCheck, Heart, TrendingUp, DollarSign } from 'lucide-react';
import { toast } from 'sonner';

export default function WealthGenomeReveal() {
  const { selectedGenome, setSelectedGenome } = useStrategy();

  const genomes = [
    {
      id: "policy_first",
      name: "Policy-First Wealth Circulator",
      icon: ShieldCheck,
      color: "text-emerald-400 border-emerald-500/30 bg-emerald-500/5",
      desc: "Optimized for maximum asset protection, high-yield tax arbitrage, and systematic real estate leverage.",
      score: 96,
    },
    {
      id: "debt_accelerator",
      name: "Accelerated Debt Killer",
      icon: TrendingUp,
      color: "text-yellow-400 border-yellow-500/30 bg-yellow-500/5",
      desc: "Designed for high-income professionals with heavy student or mortgage debt seeking rapid debt-freedom via arbitrage.",
      score: 88,
    },
    {
      id: "legacy_builder",
      name: "Legacy Trust Builder",
      icon: Award,
      color: "text-purple-400 border-purple-500/30 bg-purple-500/5",
      desc: "Focused on multi-generational wealth preservation, legacy vault storage, and family council structuring.",
      score: 92,
    }
  ];

  const handleSelect = (id: string) => {
    setSelectedGenome(id);
    toast.success(`Selected Wealth Genome profile: ${genomes.find(g => g.id === id)?.name}`);
  };

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 md:p-10 shadow-2xl">
      <div className="flex items-center gap-3 mb-8 border-b border-zinc-900 pb-6">
        <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl">
          <Brain className="w-6 h-6" />
        </div>
        <div>
          <div className="text-emerald-400 text-[10px] tracking-[3px] font-mono">BEHAVIORAL PROFILING</div>
          <h3 className="text-2xl font-semibold tracking-tight">Wealth Genome Blueprint</h3>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {genomes.map(g => {
          const Icon = g.icon;
          const isSelected = selectedGenome === g.id;

          return (
            <button
              key={g.id}
              onClick={() => handleSelect(g.id)}
              className={`w-full text-left p-6 border rounded-2xl transition-all duration-300 relative overflow-hidden group ${
                isSelected 
                  ? 'border-emerald-500 bg-emerald-500/10' 
                  : 'border-zinc-800 hover:border-zinc-700 bg-zinc-900/40 hover:bg-zinc-900/60'
              }`}
            >
              <div className="flex justify-between items-start mb-4">
                <div className={`p-2.5 rounded-xl ${isSelected ? 'bg-emerald-500 text-black' : 'bg-zinc-900 text-zinc-400 group-hover:text-white'}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="text-xs font-mono font-semibold text-zinc-500">
                  Fit Score: <span className="text-emerald-400">{g.score}%</span>
                </div>
              </div>

              <h4 className="font-semibold text-lg text-white mb-2">{g.name}</h4>
              <p className="text-xs text-zinc-400 leading-relaxed mb-4">{g.desc}</p>

              <div className="border-t border-zinc-800/80 pt-4 flex justify-between items-center text-xs">
                <span className="text-zinc-500">Behavioral Alignment</span>
                <span className="text-emerald-400 font-semibold font-mono">Strong Match</span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
