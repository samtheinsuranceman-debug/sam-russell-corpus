import React, { useState } from 'react';
import { useStrategy } from '@/contexts/StrategyContext';
import { ShieldCheck, FileText, CheckCircle, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

export default function HipaaReleaseGate({ children }: { children: React.ReactNode }) {
  const { clientData, updateClientData } = useStrategy();
  const [signedName, setSignedName] = useState('');
  const [agreed, setAgreed] = useState(false);

  const handleSign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreed) {
      toast.error('You must check the agreement box.');
      return;
    }
    if (!signedName.trim()) {
      toast.error('Please enter your full name to sign.');
      return;
    }

    // Save signed status
    updateClientData({ hipaaSigned: true });
    
    // Log activity
    const logEntry = {
      event: 'HIPAA_RELEASE_SIGNED',
      signer: signedName,
      timestamp: new Date().toISOString(),
      ipPlaceholder: '192.168.1.100',
    };
    localStorage.setItem(`hipaa_log_${Date.now()}`, JSON.stringify(logEntry));
    
    toast.success('HIPAA Release signed successfully. Welcome to Russell Capital.');
  };

  if (clientData.hipaaSigned) {
    return <>{children}</>;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-2xl bg-zinc-950 border border-zinc-800 rounded-3xl p-8 md:p-12 shadow-2xl relative">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl -z-10" />
        
        <div className="flex items-center gap-4 mb-8">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-2xl">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <div>
            <div className="text-emerald-400 text-xs tracking-[3px] font-mono">SECURE ACCESS</div>
            <h2 className="text-3xl font-semibold tracking-tight">HIPAA Disclosure & Release</h2>
          </div>
        </div>

        <div className="prose prose-invert max-h-96 overflow-y-auto border border-zinc-800 bg-zinc-900/50 rounded-2xl p-6 mb-8 text-zinc-300 text-sm leading-relaxed space-y-4">
          <p className="font-semibold text-white">Authorization for Release of Protected Health Information (PHI)</p>
          <p>
            By signing this release, you authorize Russell Capital Systems and its affiliated advisors to collect, process, and analyze your health-related indicators (including healthspan metrics, biometric wearables metadata, and medical background) alongside your wealth profile.
          </p>
          <p>
            <strong>1. Purpose of Release:</strong> This health data is utilized solely within the <em>Healthspan-Wealthspan Integration Engine</em> to dynamically adjust spending projections, retirement age models, longevity buffers, and insurance structures based on real-world biological indicators.
          </p>
          <p>
            <strong>2. Confidentiality & Security:</strong> We employ end-to-end military-grade encryption (AES-256) and secure cloud environments to safeguard your PHI. Your health data is never sold, traded, or shared with unauthorized third parties.
          </p>
          <p>
            <strong>3. Right to Revoke:</strong> You have the right to revoke this authorization at any time by writing to our compliance officer. Revocation will not affect any actions taken prior to receipt of your written notice.
          </p>
          <div className="flex gap-2 items-start p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-xl text-yellow-400 text-xs">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <p>
              Note: Refusal to sign this authorization prevents access to the Healthspan-Wealthspan Integration Engine and advanced life event calculators.
            </p>
          </div>
        </div>

        <form onSubmit={handleSign} className="space-y-6">
          <div className="flex items-start gap-3">
            <input
              type="checkbox"
              id="agree"
              checked={agreed}
              onChange={(e) => setAgreed(e.target.checked)}
              className="mt-1 accent-emerald-500 h-4 w-4 rounded border-zinc-800 bg-zinc-900"
            />
            <label htmlFor="agree" className="text-xs text-zinc-400 cursor-pointer">
              I hereby authorize the release of my PHI as described above and agree that all digital entries and activity will be logged for compliance and security audit trails.
            </label>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-mono text-zinc-500 tracking-wider">DIGITAL SIGNATURE (TYPE FULL NAME)</label>
            <input
              type="text"
              placeholder="e.g. Dr. Samuel Russell"
              value={signedName}
              onChange={(e) => setSignedName(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl px-5 py-4 text-white focus:border-emerald-500 focus:outline-none transition"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full py-4 bg-emerald-500 hover:bg-emerald-400 text-black font-semibold rounded-2xl transition active:scale-[0.985]"
          >
            Authorize & Enter Platform
          </button>
        </form>
      </div>
    </div>
  );
}
