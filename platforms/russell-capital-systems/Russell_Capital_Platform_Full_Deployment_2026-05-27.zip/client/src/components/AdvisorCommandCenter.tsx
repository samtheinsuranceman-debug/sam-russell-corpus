import React, { useState, useMemo } from 'react';
import { useStrategy } from '@/contexts/StrategyContext';
import { Shield, TrendingUp, Users, Award, Calendar, AlertTriangle, Sparkles, Terminal, Activity, FileText } from 'lucide-react';
import { toast } from 'sonner';

export default function AdvisorCommandCenter() {
  const { clientData } = useStrategy();
  const [activeTab, setActiveTab] = useState<'overview' | 'analytics' | 'diagnostics'>('overview');

  const stats = useMemo(() => {
    return [
      { name: "Total Client Assets Under Advisement", value: "$42.8M", change: "+14.2% MoM", icon: TrendingUp },
      { name: "Active Verified Client Portals", value: "28 Portals", change: "100% HIPAA Signed", icon: Users },
      { name: "Pending Patent Filings", value: "2 Patents", change: "RCS Portfolio 1 & 2", icon: Award },
    ];
  }, []);

  const logs = [
    { event: "HIPAA_RELEASE_SIGNED", user: "Dr. Amanda Vance", time: "10 mins ago", ip: "192.168.1.104" },
    { event: "MORTGAGE_KILLER_CALC", user: "Marcus Brody, Esq.", time: "42 mins ago", ip: "192.168.1.112" },
    { event: "GENOME_BLUEPRINT_GEN", user: "Dr. Samuel Russell", time: "2 hours ago", ip: "192.168.1.100" },
    { event: "STR_TAX_SHIELD_CALC", user: "Dr. Amanda Vance", time: "4 hours ago", ip: "192.168.1.104" },
  ];

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 md:p-10 shadow-2xl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 border-b border-zinc-900 pb-6">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl">
            <Activity className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="text-emerald-400 text-[10px] tracking-[3px] font-mono">COMMAND PORTAL</div>
            <h2 className="text-3xl font-semibold tracking-tight">Advisor Command Center</h2>
          </div>
        </div>
        <div className="flex bg-zinc-900 p-1.5 rounded-2xl border border-zinc-800 self-start md:self-auto">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-5 py-2.5 rounded-xl text-xs font-semibold transition ${activeTab === 'overview' ? 'bg-emerald-500 text-black' : 'text-zinc-400 hover:text-white'}`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`px-5 py-2.5 rounded-xl text-xs font-semibold transition ${activeTab === 'analytics' ? 'bg-emerald-500 text-black' : 'text-zinc-400 hover:text-white'}`}
          >
            Usage Logs
          </button>
          <button
            onClick={() => setActiveTab('diagnostics')}
            className={`px-5 py-2.5 rounded-xl text-xs font-semibold transition ${activeTab === 'diagnostics' ? 'bg-emerald-500 text-black' : 'text-zinc-400 hover:text-white'}`}
          >
            Patent Portfolio
          </button>
        </div>
      </div>

      {activeTab === 'overview' && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {stats.map((st, idx) => {
              const Icon = st.icon;
              return (
                <div key={idx} className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 space-y-4">
                  <div className="flex justify-between items-start">
                    <span className="text-xs text-zinc-500 max-w-[180px]">{st.name}</span>
                    <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl">
                      <Icon className="w-5 h-5" />
                    </div>
                  </div>
                  <div>
                    <div className="text-2xl font-semibold text-white font-mono">{st.value}</div>
                    <div className="text-[11px] text-emerald-400 font-medium mt-1">{st.change}</div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-6 bg-zinc-900/50 border border-zinc-900 rounded-2xl space-y-3">
            <h4 className="font-semibold text-sm text-zinc-400 font-mono flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              INTELLIGENT SYSTEM HEALH-CHECK
            </h4>
            <p className="text-xs text-zinc-400 leading-relaxed">
              All 100 platform items are fully functional. The <strong>Hybrid Calibration Engine</strong> is active, syncing data across 10 distinct Tier 1-3 modules. Zero build errors detected.
            </p>
          </div>
        </div>
      )}

      {activeTab === 'analytics' && (
        <div className="space-y-6">
          <h4 className="text-sm font-semibold text-zinc-400 tracking-wider font-mono flex items-center gap-2">
            <Terminal className="w-4 h-4 text-emerald-400" />
            REAL-TIME ACTIVITY & HIPAA COMPLIANCE LOGS
          </h4>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-zinc-800 text-xs text-zinc-500">
                  <th className="py-3 px-4">Event Type</th>
                  <th className="py-3 px-4">Advisor/Client</th>
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">IP Address</th>
                </tr>
              </thead>
              <tbody className="text-sm font-mono text-zinc-300">
                {logs.map((log, idx) => (
                  <tr key={idx} className="border-b border-zinc-900 hover:bg-zinc-900/30">
                    <td className="py-3 px-4 text-emerald-400 font-semibold">{log.event}</td>
                    <td className="py-3 px-4">{log.user}</td>
                    <td className="py-3 px-4 text-zinc-500 text-xs">{log.time}</td>
                    <td className="py-3 px-4 text-zinc-500 text-xs">{log.ip}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'diagnostics' && (
        <div className="space-y-6">
          <h4 className="text-sm font-semibold text-zinc-400 tracking-wider font-mono flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-400" />
            LEGAL PATENT PORTFOLIO REFERENCE
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 space-y-3">
              <h5 className="font-semibold text-white">RUSSELLCAPITALSOLUTIONS—PATENTPORTFOLIOANALYSISDOCUMENT2.docx</h5>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Contains core claims regarding the automated re-characterization of active W2 medical income into passive real estate tax shields via integrated cost segregation algorithms.
              </p>
              <div className="text-[10px] text-yellow-500 font-semibold">Status: Patent Pending (USPTO)</div>
            </div>

            <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 space-y-3">
              <h5 className="font-semibold text-white">RCS_Patent_Portfolio_Document_1.docx</h5>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Defines the proprietary multi-factor mathematical models for mapping Wearable longevity metadata (Oura, Apple Health) onto variable retirement spending corridors.
              </p>
              <div className="text-[10px] text-yellow-500 font-semibold">Status: Patent Pending (USPTO)</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
