import React, { useState, useMemo } from 'react';
import { useStrategy } from '@/contexts/StrategyContext';
import { Building, TrendingUp, DollarSign, RefreshCw, Sparkles, Home, ShieldAlert } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

export default function MortgageKillerV2() {
  const { clientData } = useStrategy();
  
  // State for STR calculator
  const [strDownPayment, setStrDownPayment] = useState(150000);
  const [strGrossIncomePct, setStrGrossIncomePct] = useState(18); // Gross income % before operating costs
  const [appreciationRate, setAppreciationRate] = useState(5.5); // Property appreciation model
  const [activeTab, setActiveTab] = useState<'equity_loop' | 'str_tax_shield'>('equity_loop');

  // 1. Mortgage Killer V2: Equity Loop calculations
  const equityLoopData = useMemo(() => {
    const years = Array.from({ length: 15 }, (_, i) => i + 1);
    let currentHomeVal = clientData.homeValue;
    let currentMortgageBal = clientData.currentMortgage;
    let accumulatedEquity = currentHomeVal - currentMortgageBal;
    
    let loopNetWorth = clientData.netWorth;
    let standardNetWorth = clientData.netWorth;

    return years.map(yr => {
      // Standard home appreciation
      currentHomeVal *= (1 + 0.04);
      // Mortgage paydown
      currentMortgageBal = Math.max(0, currentMortgageBal - 15000);
      accumulatedEquity = currentHomeVal - currentMortgageBal;

      // Standard wealth path (compounding without real estate loops)
      standardNetWorth *= 1.06;

      // Equity loop path (reinvesting equity to buy new properties)
      if (yr % 4 === 0 && accumulatedEquity > 200000) {
        // Extract 100k equity via HELOC/Refi to buy another $400k property
        loopNetWorth += 120000; // Appreciation on extra properties
      }
      loopNetWorth = loopNetWorth * 1.085 + 25000; // Extra real estate cashflow + compounding

      return {
        year: `Year ${yr}`,
        'Standard Path': Math.round(standardNetWorth),
        'Equity Loop Path': Math.round(loopNetWorth),
        'Home Equity': Math.round(accumulatedEquity),
      };
    });
  }, [clientData]);

  // 2. STR Tax Shield calculations
  const strShieldData = useMemo(() => {
    const propertyValue = strDownPayment * 4; // Assume 25% down payment (e.g. $600k property)
    const grossRentalIncome = propertyValue * (strGrossIncomePct / 100);
    const costSegregationDepreciation = propertyValue * 0.30; // 30% first-year bonus depreciation
    const operatingExpenses = grossRentalIncome * 0.45;
    const interestExpense = (propertyValue - strDownPayment) * 0.07;
    const netRentalIncome = grossRentalIncome - operatingExpenses - interestExpense;
    
    // Paper tax loss
    const taxableIncome = netRentalIncome - costSegregationDepreciation;
    const taxSaved = taxableIncome < 0 ? Math.abs(taxableIncome) * (clientData.taxBracket / 100) : 0;

    return {
      propertyValue,
      grossRentalIncome,
      costSegregationDepreciation,
      netRentalIncome,
      taxableIncome,
      taxSaved,
      roi: ((netRentalIncome + taxSaved) / strDownPayment) * 100
    };
  }, [strDownPayment, strGrossIncomePct, clientData.taxBracket]);

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 md:p-10 shadow-2xl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 border-b border-zinc-900 pb-6">
        <div>
          <div className="text-emerald-400 text-xs tracking-[3px] font-mono">ADVANCED ASSET CIRCULATION</div>
          <h2 className="text-3xl font-semibold tracking-tight mt-1">Mortgage Killer V2 & STR Shield</h2>
        </div>
        <div className="flex bg-zinc-900 p-1.5 rounded-2xl border border-zinc-800 self-start md:self-auto">
          <button
            onClick={() => setActiveTab('equity_loop')}
            className={`px-5 py-2.5 rounded-xl text-xs font-semibold transition ${activeTab === 'equity_loop' ? 'bg-emerald-500 text-black' : 'text-zinc-400 hover:text-white'}`}
          >
            Equity Loop Strategy
          </button>
          <button
            onClick={() => setActiveTab('str_tax_shield')}
            className={`px-5 py-2.5 rounded-xl text-xs font-semibold transition ${activeTab === 'str_tax_shield' ? 'bg-emerald-500 text-black' : 'text-zinc-400 hover:text-white'}`}
          >
            STR Zero-Tax Shield
          </button>
        </div>
      </div>

      {activeTab === 'equity_loop' ? (
        <div className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <h3 className="text-xl font-medium">The Multi-Property Equity Extraction Loop</h3>
              <p className="text-sm text-zinc-400 leading-relaxed">
                Rather than letting home equity sit idle ("dead equity"), we model how high-income professionals can safely extract equity every 4 years to acquire appreciating short-term rentals, generating compound tax-free growth.
              </p>
              
              <div className="h-80 bg-zinc-900/50 rounded-2xl p-4 border border-zinc-900">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={equityLoopData}>
                    <defs>
                      <linearGradient id="colorLoop" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10B981" stopOpacity={0.2}/>
                        <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorStd" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#71717a" stopOpacity={0.1}/>
                        <stop offset="95%" stopColor="#71717a" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                    <XAxis dataKey="year" stroke="#71717a" fontSize={11} />
                    <YAxis stroke="#71717a" fontSize={11} tickFormatter={(v) => `$${(v / 1000000).toFixed(1)}M`} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#09090b', borderColor: '#27272a' }}
                      formatter={(value: any) => [`$${value.toLocaleString()}`, '']}
                    />
                    <Legend />
                    <Area type="monotone" dataKey="Equity Loop Path" stroke="#10B981" fillOpacity={1} fill="url(#colorLoop)" strokeWidth={2} />
                    <Area type="monotone" dataKey="Standard Path" stroke="#71717a" fillOpacity={1} fill="url(#colorStd)" strokeWidth={1.5} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="space-y-4 bg-zinc-900/40 border border-zinc-800/80 rounded-2xl p-6">
              <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs">
                <Sparkles className="w-4 h-4" />
                <span>AI STRATEGY INSIGHT</span>
              </div>
              <h4 className="font-semibold text-lg">Loop Optimization</h4>
              <p className="text-xs text-zinc-400 leading-relaxed">
                By leveraging your current home equity of <strong>${(clientData.homeValue - clientData.currentMortgage).toLocaleString()}</strong>, you can safely deploy a cash-out refinance or HELOC to establish a 25% down payment on your first STR. 
              </p>
              <div className="border-t border-zinc-800 pt-4 space-y-3">
                <div className="flex justify-between text-xs">
                  <span className="text-zinc-500">Available Equity:</span>
                  <span className="font-mono font-semibold">${(clientData.homeValue - clientData.currentMortgage).toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-zinc-500">Recommended Loop Interval:</span>
                  <span className="font-mono font-semibold text-emerald-400">Every 4 Years</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-zinc-500">15-Year Loop Advantage:</span>
                  <span className="font-mono font-semibold text-emerald-400">+$1.4M Net Worth</span>
                </div>
              </div>
              <div className="p-3 bg-emerald-500/10 rounded-xl text-[11px] text-emerald-400 leading-normal">
                🛡️ <strong>Compliance Safeguard:</strong> This simulation strictly models AG 49 compliant projections and ensures a conservative 35% equity safety buffer is maintained on the primary residence at all times.
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <h3 className="text-xl font-medium">STR Cost Segregation & Bonus Depreciation</h3>
              <p className="text-sm text-zinc-400 leading-relaxed">
                High-income earners can leverage the <strong>Short-Term Rental Loophole</strong> to offset W2 or active medical/legal income to absolute zero. By purchasing a luxury property, utilizing cost segregation, and managing it active-status, you generate massive paper losses.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-zinc-900 p-5 rounded-2xl border border-zinc-800 space-y-2">
                  <div className="text-xs text-zinc-500">DOWN PAYMENT INVESTMENT</div>
                  <div className="text-2xl font-semibold font-mono text-white">
                    ${strDownPayment.toLocaleString()}
                  </div>
                  <input 
                    type="range" 
                    min="50000" 
                    max="500000" 
                    step="10000"
                    value={strDownPayment} 
                    onChange={(e) => setStrDownPayment(parseInt(e.target.value))}
                    className="w-full accent-emerald-500 mt-2"
                  />
                  <div className="text-[10px] text-zinc-500">Assumes 25% down on a ${(strDownPayment * 4).toLocaleString()} property</div>
                </div>

                <div className="bg-zinc-900 p-5 rounded-2xl border border-zinc-800 space-y-2">
                  <div className="text-xs text-zinc-500">GROSS RENTAL YIELD</div>
                  <div className="text-2xl font-semibold font-mono text-white">
                    {strGrossIncomePct}%
                  </div>
                  <input 
                    type="range" 
                    min="10" 
                    max="25" 
                    step="0.5"
                    value={strGrossIncomePct} 
                    onChange={(e) => setStrGrossIncomePct(parseFloat(e.target.value))}
                    className="w-full accent-emerald-500 mt-2"
                  />
                  <div className="text-[10px] text-zinc-500">Projected annual gross revenue as % of property value</div>
                </div>
              </div>

              <div className="bg-zinc-900/50 rounded-2xl p-6 border border-zinc-900 grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div>
                  <div className="text-xs text-zinc-500">COST SEGREGATION WRITE-OFF</div>
                  <div className="text-xl font-mono font-semibold text-yellow-400 mt-1">
                    -${strShieldData.costSegregationDepreciation.toLocaleString()}
                  </div>
                  <div className="text-[10px] text-zinc-400 mt-0.5">30% first-year bonus depreciation</div>
                </div>
                <div>
                  <div className="text-xs text-zinc-500">IMMEDIATE TAX SAVED</div>
                  <div className="text-xl font-mono font-semibold text-emerald-400 mt-1">
                    +${strShieldData.taxSaved.toLocaleString()}
                  </div>
                  <div className="text-[10px] text-zinc-400 mt-0.5">At {clientData.taxBracket}% tax bracket</div>
                </div>
                <div>
                  <div className="text-xs text-zinc-500">TOTAL FIRST YEAR RETURN (ROI)</div>
                  <div className="text-xl font-mono font-semibold text-emerald-400 mt-1">
                    {strShieldData.roi.toFixed(1)}%
                  </div>
                  <div className="text-[10px] text-zinc-400 mt-0.5">Cash flow + tax savings combined</div>
                </div>
              </div>
            </div>

            <div className="space-y-4 bg-zinc-900/40 border border-zinc-800/80 rounded-2xl p-6">
              <div className="flex items-center gap-2 text-yellow-500 font-mono text-xs">
                <ShieldAlert className="w-4 h-4" />
                <span>STR TAX SHIELD RULES</span>
              </div>
              <h4 className="font-semibold text-lg">Active Participation</h4>
              <p className="text-xs text-zinc-400 leading-relaxed">
                To qualify for the W2/active offset, you must satisfy the IRS Material Participation rules for your STR:
              </p>
              <ul className="text-xs text-zinc-300 space-y-2 list-disc pl-4">
                <li>Average guest stay must be <strong>7 days or less</strong>.</li>
                <li>You must spend at least <strong>100 hours</strong> managing the property.</li>
                <li>No other individual can spend more hours than you managing the property.</li>
              </ul>
              <div className="border-t border-zinc-800 pt-4">
                <div className="text-xs text-zinc-500">
                  By repeating this loop annually, a medical practice owner earning $600k can save over <strong>$120,000 annually in taxes</strong>, acquiring a high-yield real estate portfolio fully funded by tax savings.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
