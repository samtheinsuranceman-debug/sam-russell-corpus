import React from 'react';
import { useStrategy } from '@/contexts/StrategyContext';
import { ClipboardList, GraduationCap, DollarSign, Heart, Shield, Percent } from 'lucide-react';
import { toast } from 'sonner';

export default function ClientFactFinder() {
  const { clientData, updateClientData } = useStrategy();

  const handleInputChange = (field: keyof typeof clientData, value: any) => {
    updateClientData({ [field]: value });
  };

  const handleSave = () => {
    toast.success('Fact Finder data permanently saved and synced across all calculators.');
  };

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 md:p-10 shadow-2xl">
      <div className="flex items-center justify-between mb-8 border-b border-zinc-900 pb-6">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl">
            <ClipboardList className="w-6 h-6" />
          </div>
          <div>
            <div className="text-emerald-400 text-[10px] tracking-[3px] font-mono">CLIENT DISCOVERY</div>
            <h3 className="text-2xl font-semibold tracking-tight">Interactive Fact Finder</h3>
          </div>
        </div>
        <button
          onClick={handleSave}
          className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-semibold rounded-xl transition"
        >
          Save & Sync All
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Left Column: Demographics & Core Wealth */}
        <div className="space-y-6">
          <h4 className="text-sm font-semibold text-zinc-400 tracking-wider font-mono flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-400" />
            DEMOGRAPHICS & NET WORTH
          </h4>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs text-zinc-500">Current Age</label>
              <input
                type="number"
                value={clientData.age}
                onChange={(e) => handleInputChange('age', parseInt(e.target.value) || 0)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm font-mono focus:border-emerald-500 focus:outline-none"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs text-zinc-500">Annual Household Income</label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500 text-xs font-mono">$</span>
                <input
                  type="number"
                  value={clientData.annualIncome}
                  onChange={(e) => handleInputChange('annualIncome', parseInt(e.target.value) || 0)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-8 pr-4 py-3 text-sm font-mono focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs text-zinc-500">Total Net Worth</label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500 text-xs font-mono">$</span>
                <input
                  type="number"
                  value={clientData.netWorth}
                  onChange={(e) => handleInputChange('netWorth', parseInt(e.target.value) || 0)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-8 pr-4 py-3 text-sm font-mono focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs text-zinc-500">Monthly Surplus Savings</label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500 text-xs font-mono">$</span>
                <input
                  type="number"
                  value={clientData.monthlySavings}
                  onChange={(e) => handleInputChange('monthlySavings', parseInt(e.target.value) || 0)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-8 pr-4 py-3 text-sm font-mono focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 pt-2">
            <label className="flex items-center gap-2 text-xs text-zinc-300 cursor-pointer">
              <input
                type="checkbox"
                checked={clientData.married}
                onChange={(e) => handleInputChange('married', e.target.checked)}
                className="accent-emerald-500 rounded bg-zinc-900 border-zinc-800"
              />
              Married
            </label>
            <label className="flex items-center gap-2 text-xs text-zinc-300 cursor-pointer">
              <input
                type="checkbox"
                checked={clientData.hasKids}
                onChange={(e) => handleInputChange('hasKids', e.target.checked)}
                className="accent-emerald-500 rounded bg-zinc-900 border-zinc-800"
              />
              Has Children
            </label>
            <label className="flex items-center gap-2 text-xs text-zinc-300 cursor-pointer">
              <input
                type="checkbox"
                checked={clientData.parentsAlive}
                onChange={(e) => handleInputChange('parentsAlive', e.target.checked)}
                className="accent-emerald-500 rounded bg-zinc-900 border-zinc-800"
              />
              Parents Alive
            </label>
          </div>
        </div>

        {/* Right Column: School Debt & Health/Real Estate */}
        <div className="space-y-6">
          <h4 className="text-sm font-semibold text-zinc-400 tracking-wider font-mono flex items-center gap-2">
            <GraduationCap className="w-4 h-4 text-emerald-400" />
            SCHOOL DEBT & REAL ESTATE
          </h4>

          {/* Standardized School Debt Fields */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs text-zinc-500">School Debt Balance</label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500 text-xs font-mono">$</span>
                <input
                  type="number"
                  value={clientData.schoolDebt}
                  onChange={(e) => handleInputChange('schoolDebt', parseInt(e.target.value) || 0)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-8 pr-4 py-3 text-sm font-mono focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs text-zinc-500">School Debt Interest Rate</label>
              <div className="relative">
                <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-500 text-xs font-mono">%</span>
                <input
                  type="number"
                  step="0.1"
                  value={clientData.schoolInterestRate}
                  onChange={(e) => handleInputChange('schoolInterestRate', parseFloat(e.target.value) || 0)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pr-8 pl-4 py-3 text-sm font-mono focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-xs text-zinc-500">Primary Home Value</label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500 text-xs font-mono">$</span>
                <input
                  type="number"
                  value={clientData.homeValue}
                  onChange={(e) => handleInputChange('homeValue', parseInt(e.target.value) || 0)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-8 pr-4 py-3 text-sm font-mono focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs text-zinc-500">Mortgage Balance</label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500 text-xs font-mono">$</span>
                <input
                  type="number"
                  value={clientData.currentMortgage}
                  onChange={(e) => handleInputChange('currentMortgage', parseInt(e.target.value) || 0)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-8 pr-4 py-3 text-sm font-mono focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs text-zinc-500">Mortgage Rate</label>
              <div className="relative">
                <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-500 text-xs font-mono">%</span>
                <input
                  type="number"
                  step="0.1"
                  value={clientData.mortgageRate}
                  onChange={(e) => handleInputChange('mortgageRate', parseFloat(e.target.value) || 0)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pr-8 pl-4 py-3 text-sm font-mono focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500 flex items-center gap-1">
                <Heart className="w-3.5 h-3.5 text-red-400" /> Health / Wearable Longevity Score
              </span>
              <span className="font-mono text-emerald-400">{clientData.healthScore}/100</span>
            </div>
            <input
              type="range"
              min="30"
              max="100"
              value={clientData.healthScore}
              onChange={(e) => handleInputChange('healthScore', parseInt(e.target.value) || 0)}
              className="w-full accent-emerald-500"
            />
            <div className="text-[10px] text-zinc-600">Dynamic slider adjusting wearable metrics (Oura, Whoop, Apple Health integration)</div>
          </div>
        </div>
      </div>
    </div>
  );
}
