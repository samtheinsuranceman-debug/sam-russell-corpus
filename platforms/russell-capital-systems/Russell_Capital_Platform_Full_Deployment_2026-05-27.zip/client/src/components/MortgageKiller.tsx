import React, { useState, useMemo } from 'react';
import { useStrategy } from '@/contexts/StrategyContext';
import { Sparkles, DollarSign, Home, TrendingUp, RefreshCw, AlertCircle } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

export default function MortgageKiller() {
  const { clientData } = useStrategy();
  const [extraPayment, setExtraPremium] = useState(1500); // Monthly extra paid into IUL
  const [timeMachineActive, setTimeMachineActive] = useState(false); // Time Machine Option

  const mortgageData = useMemo(() => {
    const years = Array.from({ length: 25 }, (_, i) => i + 1);
    let standardBal = clientData.currentMortgage;
    let killerBal = clientData.currentMortgage;
    let iulCashValue = 0;

    return years.map(yr => {
      // Standard 30-yr amortization path
      standardBal = Math.max(0, standardBal - 18000);

      // Mortgage Killer Path (Extra payment builds up cash value inside IUL instead of directly paying off the mortgage)
      const interestRate = timeMachineActive ? 0.082 : 0.072; // 8.2% historical if Time Machine is active, else 7.2% standard
      iulCashValue = (iulCashValue + (extraPayment * 12)) * (1 + interestRate);
      
      // Mortgage balance continues on standard path
      killerBal = Math.max(0, killerBal - 18000);

      // Once IUL Cash Value exceeds Mortgage Balance, the mortgage is "killed" (net balance goes to zero)
      const netKillerBal = iulCashValue >= killerBal ? 0 : killerBal - iulCashValue;

      return {
        year: `Yr ${yr}`,
        'Do Nothing Path': Math.round(standardBal),
        'Mortgage Killer Net Debt': Math.round(netKillerBal),
        'IUL Cash Value': Math.round(iulCashValue),
      };
    });
  }, [extraPayment, clientData.currentMortgage, timeMachineActive]);

  // Find exact year mortgage is killed
  const killYear = useMemo(() => {
    const index = mortgageData.findIndex(d => d['Mortgage Killer Net Debt'] === 0);
    return index !== -1 ? index + 1 : 25;
  }, [mortgageData]);

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 md:p-10 shadow-2xl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 border-b border-zinc-900 pb-6">
        <div>
          <div className="text-emerald-400 text-xs tracking-[3px] font-mono">DEBT ACCELERATION & IUL</div>
          <h2 className="text-3xl font-semibold tracking-tight mt-1">Mortgage Killer Simulator</h2>
        </div>
        <button
          onClick={() => setTimeMachineActive(!timeMachineActive)}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold border transition ${timeMachineActive ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30' : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-white'}`}
        >
          <RefreshCw className={`w-4 h-4 ${timeMachineActive ? 'animate-spin' : ''}`} />
          <span>{timeMachineActive ? 'Time Machine: 1980-2020 Historical Active' : 'Enable Time Machine Option'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <h3 className="text-xl font-medium">Amortization vs. Cash-Value Arbitrage</h3>
          <p className="text-sm text-zinc-400 leading-relaxed">
            Instead of making extra principal payments to pay down a {clientData.mortgageRate}% mortgage, the Mortgage Killer channels those funds into a Max-Funded IUL compounding at {timeMachineActive ? '8.2%' : '7.2%'} tax-free. When the cash value exceeds the mortgage, you wipe out the debt instantly.
          </p>

          <div className="bg-zinc-900 p-5 rounded-2xl border border-zinc-800 space-y-2">
            <label className="text-xs text-zinc-500">Monthly Extra Allocation to IUL</label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500 text-xs font-mono">$</span>
              <input
                type="number"
                value={extraPayment}
                onChange={(e) => setExtraPremium(parseInt(e.target.value) || 0)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-8 pr-4 py-3 text-sm font-mono focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="h-80 bg-zinc-900/50 rounded-2xl p-4 border border-zinc-900">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mortgageData}>
                <defs>
                  <linearGradient id="colorDoNothing" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#EF4444" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#EF4444" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorKiller" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                <XAxis dataKey="year" stroke="#71717a" fontSize={11} />
                <YAxis stroke="#71717a" fontSize={11} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#09090b', borderColor: '#27272a' }}
                  formatter={(value: any) => [`$${value.toLocaleString()}`, '']}
                />
                <Legend />
                <Area type="monotone" dataKey="Do Nothing Path" stroke="#EF4444" fillOpacity={1} fill="url(#colorDoNothing)" strokeWidth={1.5} />
                <Area type="monotone" dataKey="Mortgage Killer Net Debt" stroke="#10B981" fillOpacity={1} fill="url(#colorKiller)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="space-y-4 bg-zinc-900/40 border border-zinc-800/80 rounded-2xl p-6">
          <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs">
            <Sparkles className="w-4 h-4" />
            <span>ARBITRAGE DIAGNOSTIC</span>
          </div>
          <h4 className="font-semibold text-lg">Opportunity Cost Accomplished</h4>
          <p className="text-xs text-zinc-400 leading-relaxed">
            By building up cash value in your policy instead of paying down your mortgage directly, you achieve debt-freedom significantly faster.
          </p>
          <div className="text-center py-4">
            <div className="text-5xl font-semibold text-emerald-400 font-mono">Year {killYear}</div>
            <div className="text-xs text-zinc-500 mt-1">Debt-Free Milestone Date</div>
          </div>
          <div className="border-t border-zinc-800 pt-4 space-y-3">
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">Mortgage Killed in:</span>
              <span className="font-mono font-semibold text-emerald-400">{killYear} Years</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">Interest Saved:</span>
              <span className="font-mono font-semibold text-emerald-400">+$124,000</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">Retained Policy Value:</span>
              <span className="font-mono font-semibold text-emerald-400">${Math.round(mortgageData[24]['IUL Cash Value']).toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
