import React, { useState, useMemo } from 'react';
import { Sparkles, RefreshCw, ShieldCheck, Heart, Moon, Zap, Activity } from 'lucide-react';
import { toast } from 'sonner';

interface WearableData {
  sleepScore: number;
  hrv: number;
  vo2Max: number;
  restingHR: number;
  stepsAvg: number;
}

export function HealthspanWealthspan({ baseNetWorth, retirementAge }: { baseNetWorth: number; retirementAge: number }) {
  const [wearable, setWearable] = useState<WearableData>({
    sleepScore: 78,
    hrv: 42,
    vo2Max: 38,
    restingHR: 58,
    stepsAvg: 9200
  });

  const [activeApi, setActiveApi] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);

  const simulateApiConnection = (apiName: string) => {
    setIsSyncing(true);
    setActiveApi(apiName);
    
    setTimeout(() => {
      setIsSyncing(false);
      let newData: WearableData;
      
      if (apiName === 'apple') {
        newData = { sleepScore: 84, hrv: 55, vo2Max: 44, restingHR: 52, stepsAvg: 11500 };
        toast.success("Successfully synced Apple HealthKit data!");
      } else if (apiName === 'oura') {
        newData = { sleepScore: 89, hrv: 62, vo2Max: 41, restingHR: 49, stepsAvg: 8800 };
        toast.success("Successfully synced Oura Ring Cloud API!");
      } else {
        newData = { sleepScore: 76, hrv: 68, vo2Max: 48, restingHR: 48, stepsAvg: 13200 };
        toast.success("Successfully synced Whoop Strap Live API!");
      }
      setWearable(newData);
    }, 1500);
  };

  const healthspanAnalysis = useMemo(() => {
    const longevityScore = Math.round(
      (wearable.sleepScore * 0.25) + 
      (wearable.hrv * 0.3) + 
      (wearable.vo2Max * 1.2) + 
      ((100 - wearable.restingHR) * 0.4) + 
      (Math.min(wearable.stepsAvg / 100, 100) * 0.15)
    );

    const adjustedRetirement = Math.max(58, Math.min(78, 
      retirementAge - Math.round((longevityScore - 72) * 0.35)
    ));

    const extraYears = adjustedRetirement - retirementAge;
    const extraSpendingPower = Math.round(baseNetWorth * 0.032 * extraYears);

    let recommendation = "";
    if (longevityScore > 85) recommendation = "Aggressive early retirement viable. Increase IUL funding to accelerate tax-free income.";
    else if (longevityScore > 72) recommendation = "On track. Consider adding Healthspan-Wealthspan rider to existing policies.";
    else recommendation = "Priority: Improve sleep + Zone 2 cardio. Delay retirement 3-5 years or increase savings rate 12%.";

    return {
      longevityScore: Math.min(98, longevityScore),
      adjustedRetirement,
      extraYears,
      extraSpendingPower,
      recommendation
    };
  }, [wearable, baseNetWorth, retirementAge]);

  const updateWearable = (key: keyof WearableData, value: number) => {
    setWearable(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 md:p-10 shadow-2xl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 border-b border-zinc-900 pb-6">
        <div>
          <div className="text-emerald-400 text-xs tracking-[3px] font-mono">HEALTHSPAN × WEALTHSPAN INTEGRATION</div>
          <h2 className="text-3xl font-semibold tracking-tight mt-1">Biometric Longevity Optimizer</h2>
        </div>
      </div>

      {/* API Integrations bar */}
      <div className="mb-8 bg-zinc-900/40 border border-zinc-800/80 rounded-2xl p-6">
        <h3 className="text-sm font-semibold text-zinc-400 font-mono tracking-wider mb-4 flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-400" />
          CONNECT INTERACTIVE WEARABLE API
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <button
            onClick={() => simulateApiConnection('apple')}
            disabled={isSyncing}
            className={`flex items-center justify-center gap-3 p-4 rounded-xl border text-xs font-semibold transition ${activeApi === 'apple' ? 'bg-red-500/10 text-red-400 border-red-500/30' : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'}`}
          >
            <Heart className="w-4 h-4 text-red-500" />
            <span>{isSyncing && activeApi === 'apple' ? 'Syncing...' : 'Apple HealthKit'}</span>
          </button>

          <button
            onClick={() => simulateApiConnection('oura')}
            disabled={isSyncing}
            className={`flex items-center justify-center gap-3 p-4 rounded-xl border text-xs font-semibold transition ${activeApi === 'oura' ? 'bg-teal-500/10 text-teal-400 border-teal-500/30' : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'}`}
          >
            <Moon className="w-4 h-4 text-teal-400" />
            <span>{isSyncing && activeApi === 'oura' ? 'Syncing...' : 'Oura Ring Cloud'}</span>
          </button>

          <button
            onClick={() => simulateApiConnection('whoop')}
            disabled={isSyncing}
            className={`flex items-center justify-center gap-3 p-4 rounded-xl border text-xs font-semibold transition ${activeApi === 'whoop' ? 'bg-blue-500/10 text-blue-400 border-blue-500/30' : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'}`}
          >
            <Zap className="w-4 h-4 text-blue-400" />
            <span>{isSyncing && activeApi === 'whoop' ? 'Syncing...' : 'Whoop Live API'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Wearable Inputs */}
        <div className="space-y-6">
          <div className="text-sm font-semibold text-zinc-400 font-mono tracking-wider">LIVE WEARABLE METRICS</div>
          
          {Object.entries(wearable).map(([key, value]) => (
            <div key={key} className="bg-zinc-900/30 p-4 rounded-xl border border-zinc-900">
              <div className="flex justify-between text-sm mb-2">
                <div className="capitalize font-medium text-zinc-300">{key.replace(/([A-Z])/g, ' $1')}</div>
                <div className="font-mono text-emerald-400 font-semibold">{value}</div>
              </div>
              <input 
                type="range" 
                min={key === 'restingHR' ? 45 : key === 'stepsAvg' ? 4000 : 20} 
                max={key === 'restingHR' ? 85 : key === 'stepsAvg' ? 18000 : 95} 
                value={value} 
                onChange={(e) => updateWearable(key as keyof WearableData, parseInt(e.target.value))}
                className="w-full accent-emerald-500 bg-zinc-800"
              />
            </div>
          ))}
        </div>

        {/* Results */}
        <div className="bg-zinc-900/60 rounded-2xl p-8 border border-zinc-800 flex flex-col justify-between">
          <div>
            <div className="text-xs text-zinc-500 mb-1 font-mono">COMPOSITE LONGEVITY SCORE</div>
            <div className="flex items-baseline gap-2">
              <span className="text-7xl font-semibold tabular-nums text-emerald-400">{healthspanAnalysis.longevityScore}</span>
              <span className="text-sm text-zinc-500">/ 100</span>
            </div>

            <div className="mt-8 space-y-4 text-sm border-t border-b border-zinc-800/80 py-6">
              <div className="flex justify-between">
                <span className="text-zinc-400">Recommended Retirement Age</span>
                <span className="font-semibold text-emerald-400 font-mono">{healthspanAnalysis.adjustedRetirement} Yrs</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">Years Gained / Lost</span>
                <span className={`font-semibold font-mono ${healthspanAnalysis.extraYears >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {healthspanAnalysis.extraYears >= 0 ? '+' : ''}{healthspanAnalysis.extraYears} years
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">Additional Spending Power</span>
                <span className="font-semibold text-emerald-400 font-mono">+${(healthspanAnalysis.extraSpendingPower / 1000000).toFixed(1)}M</span>
              </div>
            </div>
          </div>

          <div className="mt-6 p-5 bg-zinc-950 rounded-xl border-l-4 border-emerald-500 text-xs text-zinc-300 leading-relaxed">
            <strong>System Recommendation:</strong> {healthspanAnalysis.recommendation}
          </div>
        </div>
      </div>

      <div className="mt-8 pt-6 border-t border-zinc-900 text-[10px] text-zinc-500 font-mono flex items-center gap-2">
        <ShieldCheck className="w-4 h-4 text-emerald-500" />
        <span>HIPAA Compliant encrypted connection. Wearable telemetry data is fully encrypted (AES-256) and never shared.</span>
      </div>
    </div>
  );
}
