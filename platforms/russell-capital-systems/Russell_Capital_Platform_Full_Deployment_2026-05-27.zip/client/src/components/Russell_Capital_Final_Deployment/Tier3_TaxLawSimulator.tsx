import React, { useState, useMemo } from 'react';

interface TaxLawSimulatorProps {
  currentNetWorth: number;
  annualIncome: number;
  currentTaxLeakage: number;
}

export function TaxLawSimulator({ currentNetWorth, annualIncome, currentTaxLeakage }: TaxLawSimulatorProps) {
  const [capitalGainsRate, setCapitalGainsRate] = useState(23.8); // Current + NIIT
  const [estateTaxExemption, setEstateTaxExemption] = useState(13.61); // Millions
  const [corporateRate, setCorporateRate] = useState(21);

  const projectedImpact = useMemo(() => {
    const newTaxLeakage = Math.round(currentTaxLeakage * (capitalGainsRate / 23.8) * 1.08);
    const estateImpact = Math.round((currentNetWorth * 0.4) * (1 - (estateTaxExemption / 13.61)));
    const totalNewLeakage = newTaxLeakage + (estateImpact / 15); // Annualized

    return {
      newAnnualLeakage: Math.max(currentTaxLeakage, totalNewLeakage),
      additionalLoss: Math.round(totalNewLeakage - currentTaxLeakage),
      recommendedStrategy: totalNewLeakage > currentTaxLeakage * 1.15 
        ? "Accelerate Rental Compounding Engine + Policy-First Strategy" 
        : "Maintain current allocation with LifeForge re-optimization"
    };
  }, [capitalGainsRate, estateTaxExemption, currentTaxLeakage, currentNetWorth]);

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-10">
      <div className="text-emerald-400 text-sm tracking-[3px] mb-4">TAX LAW CHANGE SIMULATOR</div>
      <div className="text-3xl font-semibold mb-2">2030 Tax Law Stress Test</div>
      <div className="text-sm text-zinc-400 mb-8">Adjust proposed legislation and see real-time impact on your Wealth Genome</div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        {/* Capital Gains Slider */}
        <div>
          <div className="flex justify-between text-sm mb-2">
            <div>Long-Term Capital Gains + NIIT</div>
            <div className="font-mono text-emerald-400">{capitalGainsRate}%</div>
          </div>
          <input 
            type="range" 
            min="15" 
            max="35" 
            step="0.1"
            value={capitalGainsRate} 
            onChange={(e) => setCapitalGainsRate(parseFloat(e.target.value))}
            className="w-full accent-emerald-500"
          />
          <div className="text-[10px] text-zinc-500 mt-1">Current: 23.8% • Proposed 2027-2032: 25-35%</div>
        </div>

        {/* Estate Tax Exemption */}
        <div>
          <div className="flex justify-between text-sm mb-2">
            <div>Estate Tax Exemption (Millions)</div>
            <div className="font-mono text-emerald-400">${estateTaxExemption}M</div>
          </div>
          <input 
            type="range" 
            min="5" 
            max="25" 
            step="0.1"
            value={estateTaxExemption} 
            onChange={(e) => setEstateTaxExemption(parseFloat(e.target.value))}
            className="w-full accent-emerald-500"
          />
          <div className="text-[10px] text-zinc-500 mt-1">Current: $13.61M • Sunsets 2026 → Possible $7M</div>
        </div>

        {/* Corporate Rate */}
        <div>
          <div className="flex justify-between text-sm mb-2">
            <div>Corporate Tax Rate</div>
            <div className="font-mono text-emerald-400">{corporateRate}%</div>
          </div>
          <input 
            type="range" 
            min="15" 
            max="35" 
            step="1"
            value={corporateRate} 
            onChange={(e) => setCorporateRate(parseInt(e.target.value))}
            className="w-full accent-emerald-500"
          />
          <div className="text-[10px] text-zinc-500 mt-1">Current: 21% • Proposed hikes: 25-28%</div>
        </div>
      </div>

      {/* Impact Display */}
      <div className="bg-zinc-900 rounded-2xl p-8 border border-zinc-800">
        <div className="text-sm text-zinc-400 mb-4">PROJECTED 15-YEAR IMPACT ON YOUR PLAN</div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <div className="text-4xl font-semibold tabular-nums text-red-400">
              +${(projectedImpact.additionalLoss / 1000).toFixed(0)}k
            </div>
            <div className="text-sm text-zinc-400">Additional Annual Tax Leakage</div>
          </div>
          
          <div>
            <div className="text-4xl font-semibold tabular-nums text-emerald-400">
              ${(projectedImpact.newAnnualLeakage / 1000000).toFixed(1)}M
            </div>
            <div className="text-sm text-zinc-400">New Projected Annual Leakage</div>
          </div>
        </div>

        <div className="mt-6 p-4 bg-zinc-950 rounded-xl border-l-4 border-emerald-500">
          <div className="font-medium text-emerald-400 mb-1">RECOMMENDED DEFENSE:</div>
          <div className="text-sm">{projectedImpact.recommendedStrategy}</div>
        </div>
      </div>

      <div className="mt-6 text-[10px] text-zinc-500">
        Production: Live API feed from Tax Foundation + Joint Committee on Taxation models. 
        Auto-updates every time new legislation is proposed.
      </div>
    </div>
  );
}
