import React, { useState } from 'react';

interface Message {
  id: number;
  title: string;
  recipient: string;
  unlockDate: string;
  type: 'Video' | 'Text' | 'Audio';
  status: 'Recorded' | 'Scheduled' | 'Delivered';
}

export function LegacyMessageVault() {
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, title: "To my son on his 21st birthday", recipient: "Jackson (Son)", unlockDate: "2031-06-15", type: "Video", status: "Recorded" },
    { id: 2, title: "Family values & why we built this", recipient: "All Children & Grandchildren", unlockDate: "2045-01-01", type: "Video", status: "Recorded" },
    { id: 3, title: "The night we almost lost everything", recipient: "My Wife", unlockDate: "2028-12-25", type: "Audio", status: "Scheduled" },
  ]);

  const [newMessage, setNewMessage] = useState({ title: "", recipient: "", unlockDate: "", type: "Video" as const });
  const [recording, setRecording] = useState(false);

  const addMessage = () => {
    if (!newMessage.title || !newMessage.recipient || !newMessage.unlockDate) return;
    
    setMessages([...messages, {
      id: Date.now(),
      ...newMessage,
      status: "Scheduled"
    }]);
    setNewMessage({ title: "", recipient: "", unlockDate: "", type: "Video" });
  };

  const startRecording = (id: number) => {
    setRecording(true);
    setTimeout(() => {
      setRecording(false);
      setMessages(msgs => msgs.map(m => m.id === id ? { ...m, status: "Recorded" } : m));
      alert("✅ Message recorded and encrypted. Will unlock automatically on the chosen date.");
    }, 2400);
  };

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-10">
      <div className="text-emerald-400 text-sm tracking-[3px] mb-4">LEGACY MESSAGE VAULT</div>
      <div className="text-3xl font-semibold mb-2">Messages for Future Generations</div>
      <div className="text-sm text-zinc-400 mb-8">Secure, time-locked messages that unlock on specific dates or life events</div>

      <div className="space-y-4 mb-10">
        {messages.map((msg, index) => (
          <div key={index} className="flex items-center justify-between p-5 bg-zinc-900 rounded-2xl border border-zinc-800">
            <div className="flex-1">
              <div className="font-semibold">{msg.title}</div>
              <div className="text-sm text-zinc-400">{msg.recipient} • Unlocks {msg.unlockDate}</div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className={`px-3 py-1 rounded-full text-xs ${msg.status === 'Recorded' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-yellow-500/10 text-yellow-400'}`}>
                {msg.status}
              </div>
              <div className="text-xs text-zinc-500">{msg.type}</div>
              
              {msg.status === 'Scheduled' && (
                <button 
                  onClick={() => startRecording(msg.id)}
                  disabled={recording}
                  className="px-5 py-1.5 bg-white text-black rounded-xl text-sm font-medium disabled:opacity-50"
                >
                  {recording ? "Recording..." : "Record Now"}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Add New Message */}
      <div className="border-t border-zinc-800 pt-8">
        <div className="text-sm font-medium mb-4">CREATE NEW TIME-LOCKED MESSAGE</div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <input 
            type="text" 
            placeholder="Message Title" 
            value={newMessage.title}
            onChange={(e) => setNewMessage({ ...newMessage, title: e.target.value })}
            className="bg-zinc-900 border border-zinc-700 rounded-2xl px-5 py-3 text-sm"
          />
          <input 
            type="text" 
            placeholder="Recipient (e.g. My Daughter on her wedding day)" 
            value={newMessage.recipient}
            onChange={(e) => setNewMessage({ ...newMessage, recipient: e.target.value })}
            className="bg-zinc-900 border border-zinc-700 rounded-2xl px-5 py-3 text-sm"
          />
          <input 
            type="date" 
            value={newMessage.unlockDate}
            onChange={(e) => setNewMessage({ ...newMessage, unlockDate: e.target.value })}
            className="bg-zinc-900 border border-zinc-700 rounded-2xl px-5 py-3 text-sm"
          />
          <select 
            value={newMessage.type}
            onChange={(e) => setNewMessage({ ...newMessage, type: e.target.value as any })}
            className="bg-zinc-900 border border-zinc-700 rounded-2xl px-5 py-3 text-sm"
          >
            <option value="Video">Video Message</option>
            <option value="Audio">Audio Message</option>
            <option value="Text">Written Letter</option>
          </select>
        </div>

        <button 
          onClick={addMessage}
          className="px-8 py-3 bg-emerald-500 text-black rounded-2xl font-medium"
        >
          Schedule New Legacy Message
        </button>
      </div>

      <div className="mt-8 text-[10px] text-zinc-500">
        Production: End-to-end encrypted. Messages stored on decentralized storage (IPFS/Arweave). 
        Unlocks automatically via smart contract or manual family key. Voice cloning integration available.
      </div>
    </div>
  );
}
