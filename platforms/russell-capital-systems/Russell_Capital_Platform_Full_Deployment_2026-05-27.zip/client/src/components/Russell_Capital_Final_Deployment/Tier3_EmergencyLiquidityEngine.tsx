import React, { useState, useMemo } from 'react';

interface Asset {
  type: string;
  value: number;
  liquidityDays: number;
  penalty: number;
}

export function EmergencyLiquidityEngine({ totalNetWorth }: { totalNetWorth: number }) {
  const [assets, setAssets] = useState<Asset[]>([
    { type: "Taxable Brokerage", value: 1250000, liquidityDays: 2, penalty: 0 },
    { type: "IUL Policy Cash Value", value: 890000, liquidityDays: 3, penalty: 0 },
    { type: "401(k) / IRA", value: 1450000, liquidityDays: 7, penalty: 10 },
    { type: "Short-Term Rentals (Equity)", value: 2100000, liquidityDays: 45, penalty: 6 },
    { type: "Primary Residence (HELOC)", value: 1850000, liquidityDays: 21, penalty: 0 },
  ]);

  const [crisisMode, setCrisisMode] = useState(false);

  const liquidityAnalysis = useMemo(() => {
    const sorted = [...assets].sort((a, b) => a.liquidityDays - b.liquidityDays);
    
    let cumulative = 0;
    const timeline: any[] = [];
    
    sorted.forEach(asset => {
      const accessible = asset.value * (1 - asset.penalty / 100);
      cumulative += accessible;
      timeline.push({
        ...asset,
        accessible: Math.round(accessible),
        cumulative: Math.round(cumulative)
      });
    });

    const fortyEightHour = timeline.filter(t => t.liquidityDays <= 3).reduce((sum, t) => sum + t.accessible, 0);
    const thirtyDay = timeline.filter(t => t.liquidityDays <= 30).reduce((sum, t) => sum + t.accessible, 0);

    return {
      fortyEightHour: Math.round(fortyEightHour),
      thirtyDay: Math.round(thirtyDay),
      totalAccessible: Math.round(cumulative),
      timeline
    };
  }, [assets]);

  const updateAsset = (index: number, field: keyof Asset, value: number) => {
    const newAssets = [...assets];
    newAssets[index] = { ...newAssets[index], [field]: value };
    setAssets(newAssets);
  };

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-10">
      <div className="flex justify-between items-start mb-8">
        <div>
          <div className="text-emerald-400 text-sm tracking-[3px]">EMERGENCY LIQUIDITY ENGINE</div>
          <div className="text-3xl font-semibold">48-Hour Crisis Liquidity Calculator</div>
        </div>
        <button 
          onClick={() => setCrisisMode(!crisisMode)}
          className={`px-6 py-2 rounded-2xl text-sm font-medium transition ${crisisMode ? 'bg-red-500 text-white' : 'bg-zinc-800 text-zinc-400'}`}
        >
          {crisisMode ? 'CRISIS MODE ACTIVE' : 'ACTIVATE CRISIS MODE'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-zinc-900 rounded-2xl p-6">
          <div className="text-xs text-zinc-500">48-HOUR ACCESS</div>
          <div className="text-4xl font-semibold text-emerald-400 tabular-nums mt-2">
            ${(liquidityAnalysis.fortyEightHour / 1000000).toFixed(1)}M
          </div>
          <div className="text-xs text-zinc-400 mt-1">No penalties • Policy loans + brokerage</div>
        </div>
        
        <div className="bg-zinc-900 rounded-2xl p-6">
          <div className="text-xs text-zinc-500">30-DAY ACCESS</div>
          <div className="text-4xl font-semibold text-yellow-400 tabular-nums mt-2">
            ${(liquidityAnalysis.thirtyDay / 1000000).toFixed(1)}M
          </div>
          <div className="text-xs text-zinc-400 mt-1">With minimal penalties</div>
        </div>

        <div className="bg-zinc-900 rounded-2xl p-6">
          <div className="text-xs text-zinc-500">TOTAL ACCESSIBLE</div>
          <div className="text-4xl font-semibold tabular-nums mt-2">
            ${(liquidityAnalysis.totalAccessible / 1000000).toFixed(1)}M
          </div>
          <div className="text-xs text-zinc-400 mt-1">of ${ (totalNetWorth / 1000000).toFixed(1) }M net worth</div>
        </div>
      </div>

      <div className="text-sm font-medium mb-4">ASSET LIQUIDITY BREAKDOWN (Editable)</div>
      
      <div className="space-y-3">
        {assets.map((asset, index) => (
          <div key={index} className="flex items-center gap-4 p-4 bg-zinc-900 rounded-2xl">
            <div className="flex-1 font-medium">{asset.type}</div>
            
            <div className="flex items-center gap-2">
              <div className="text-xs text-zinc-500 w-12">Value</div>
              <input 
                type="number" 
                value={asset.value} 
                onChange={(e) => updateAsset(index, 'value', parseInt(e.target.value) || 0)}
                className="w-28 bg-zinc-950 border border-zinc-700 rounded-lg px-3 py-1 text-sm font-mono"
              />
            </div>

            <div className="flex items-center gap-2">
              <div className="text-xs text-zinc-500 w-16">Days</div>
              <input 
                type="number" 
                value={asset.liquidityDays} 
                onChange={(e) => updateAsset(index, 'liquidityDays', parseInt(e.target.value) || 0)}
                className="w-16 bg-zinc-950 border border-zinc-700 rounded-lg px-3 py-1 text-sm font-mono"
              />
            </div>

            <div className="flex items-center gap-2">
              <div className="text-xs text-zinc-500 w-14">Penalty %</div>
              <input 
                type="number" 
                value={asset.penalty} 
                onChange={(e) => updateAsset(index, 'penalty', parseInt(e.target.value) || 0)}
                className="w-14 bg-zinc-950 border border-zinc-700 rounded-lg px-3 py-1 text-sm font-mono"
              />
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 text-[10px] text-zinc-500">
        Production: Real-time connection to policy admin systems + brokerage APIs. 
        One-click "Crisis Mode" automatically generates loan paperwork and wires instructions.
      </div>
    </div>
  );
}
