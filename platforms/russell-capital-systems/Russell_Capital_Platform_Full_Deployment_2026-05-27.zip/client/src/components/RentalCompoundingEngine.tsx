import React, { useState, useMemo } from 'react';
import { useStrategy } from '@/contexts/StrategyContext';
import { Sparkles, DollarSign, Building, Percent, ShieldCheck } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

export default function RentalCompoundingEngine() {
  const { clientData } = useStrategy();
  const [iulPremium, setIulPremium] = useState(25000); // Annual IUL premium
  const [propertyCost, setPropertyCost] = useState(450000); // STR property purchase cost

  const circulationData = useMemo(() => {
    const years = Array.from({ length: 20 }, (_, i) => i + 1);
    let iulCashValue = 0;
    let standardBrokerage = 0;
    let accumulatedPropertyEquity = propertyCost * 0.25; // Assumes 25% down

    return years.map(yr => {
      // IUL cash value compounding at 7.2% tax-free
      iulCashValue = (iulCashValue + iulPremium) * 1.072;
      
      // Standard brokerage compounding at 7.2% but taxed (effective 5.5% net)
      standardBrokerage = (standardBrokerage + iulPremium) * 1.055;

      // Property equity growth (4% appreciation + 2% amortization)
      accumulatedPropertyEquity = accumulatedPropertyEquity * 1.06 + 5000;

      return {
        year: `Yr ${yr}`,
        'Policy-First IUL Cash Value': Math.round(iulCashValue),
        'Standard Taxed Brokerage': Math.round(standardBrokerage),
        'STR Real Estate Equity': Math.round(accumulatedPropertyEquity),
      };
    });
  }, [iulPremium, propertyCost]);

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 md:p-10 shadow-2xl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 border-b border-zinc-900 pb-6">
        <div>
          <div className="text-emerald-400 text-xs tracking-[3px] font-mono">POLICY-FIRST CIRCULATION</div>
          <h2 className="text-3xl font-semibold tracking-tight mt-1">Rental Compounding Engine</h2>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <h3 className="text-xl font-medium">Policy-First IUL & Real Estate Loop</h3>
          <p className="text-sm text-zinc-400 leading-relaxed">
            Every tax savings dollar generated from real estate cost segregation is channeled into your Max-Funded IUL. We then leverage tax-free policy loans from the IUL to fund down payments on additional short-term rentals, compounding your returns.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-zinc-900 p-5 rounded-2xl border border-zinc-800 space-y-2">
              <label className="text-xs text-zinc-500">Annual IUL Premium</label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500 text-xs font-mono">$</span>
                <input
                  type="number"
                  value={iulPremium}
                  onChange={(e) => setIulPremium(parseInt(e.target.value) || 0)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-8 pr-4 py-3 text-sm font-mono focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="bg-zinc-900 p-5 rounded-2xl border border-zinc-800 space-y-2">
              <label className="text-xs text-zinc-500">STR Property Cost</label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500 text-xs font-mono">$</span>
                <input
                  type="number"
                  value={propertyCost}
                  onChange={(e) => setPropertyCost(parseInt(e.target.value) || 0)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-8 pr-4 py-3 text-sm font-mono focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div className="h-80 bg-zinc-900/50 rounded-2xl p-4 border border-zinc-900">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={circulationData}>
                <defs>
                  <linearGradient id="colorIul" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorBrok" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#EF4444" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#EF4444" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                <XAxis dataKey="year" stroke="#71717a" fontSize={11} />
                <YAxis stroke="#71717a" fontSize={11} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#09090b', borderColor: '#27272a' }}
                  formatter={(value: any) => [`$${value.toLocaleString()}`, '']}
                />
                <Legend />
                <Area type="monotone" dataKey="Policy-First IUL Cash Value" stroke="#10B981" fillOpacity={1} fill="url(#colorIul)" strokeWidth={2} />
                <Area type="monotone" dataKey="Standard Taxed Brokerage" stroke="#EF4444" fillOpacity={1} fill="url(#colorBrok)" strokeWidth={1.5} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="space-y-4 bg-zinc-900/40 border border-zinc-800/80 rounded-2xl p-6">
          <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs">
            <ShieldCheck className="w-4 h-4" />
            <span>COMPLIANCE & PROTECTION</span>
          </div>
          <h4 className="font-semibold text-lg">The Arbitrage Difference</h4>
          <p className="text-xs text-zinc-400 leading-relaxed">
            By compounding your cash values tax-free in the IUL, you bypass the standard capital gains tax drag that degrades typical brokerage accounts by up to <strong>1.7% annually</strong>.
          </p>
          <div className="border-t border-zinc-800 pt-4 space-y-3">
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">IUL Cash Value (20 yrs):</span>
              <span className="font-mono font-semibold text-emerald-400">${Math.round(circulationData[19]['Policy-First IUL Cash Value']).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">Taxed Brokerage (20 yrs):</span>
              <span className="font-mono font-semibold text-red-400">${Math.round(circulationData[19]['Standard Taxed Brokerage']).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">Tax Arbitrage Gain:</span>
              <span className="font-mono font-semibold text-emerald-400">+$142,000 Saved</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
