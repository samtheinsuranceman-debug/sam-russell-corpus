# OpenRouter Research Notes — May 19, 2026

## Core Architecture
- OpenAI-compatible API at `https://openrouter.ai/api/v1/chat/completions`
- Auth: `Authorization: Bearer <OPENROUTER_API_KEY>`
- TypeScript SDK: `@openrouter/sdk` with `OpenRouter` class
- Normalizes schema across ALL models/providers — learn one API, use 400+ models

## Key Features for Russell Labs Integration
1. **Model Routing** — `models: []` array for fallback chains
2. **Provider Routing** — `provider: { order: [], sort: "throughput"|"price"|"latency" }`
3. **Fallbacks** — `route: 'fallback'` + `allow_fallbacks: true/false`
4. **Performance Thresholds** — `preferredMinThroughput`, `preferredMaxLatency` with percentile cutoffs
5. **Nitro shortcut** — append `:nitro` to model slug for throughput priority
6. **Floor shortcut** — append `:floor` for cheapest price
7. **Plugins** — web search, PDF parsing, response healing, context compression
8. **Zero Data Retention** — `zdr: true` for HIPAA-sensitive DrBuddy calls
9. **BYOK** — Bring your own keys for direct provider access
10. **Structured Outputs** — `response_format: { type: 'json_schema' }`
11. **Tool Calling** — Full OpenAI-compatible tool use
12. **Quantization control** — `quantizations: ["int4", "int8"]`
13. **Max Price** — Cap per-request cost

## Provider Preferences Object
```typescript
provider: {
  order: string[],           // Provider priority: ["anthropic", "openai"]
  allow_fallbacks: boolean,  // Default: true
  require_parameters: boolean, // Default: false
  data_collection: "allow"|"deny",
  zdr: boolean,              // Zero Data Retention
  only: string[],            // Whitelist providers
  ignore: string[],          // Blacklist providers
  sort: string | { by: string, partition: "model"|"none" },
  preferredMinThroughput: number | { p50, p75, p90, p99 },
  preferredMaxLatency: number | { p50, p75, p90, p99 },
  max_price: object,
}
```

## Russell Labs Routing Strategy
- **DrBuddy** → `anthropic/claude-sonnet-4.5` (medical reasoning, ZDR enabled)
- **Russell Capital** → `x-ai/grok-3` or `groq/llama-3.3-70b` (fast quant analysis)
- **Church** → uncensored models via `meta-llama/llama-3.3-70b-instruct` 
- **Genome** → `anthropic/claude-sonnet-4.5` (pharmacovigilance accuracy)
- **Weight Loss** → `openai/gpt-5-mini` (cost-efficient daily tracking)

## Headers for App Attribution
```
HTTP-Referer: https://drbuddy.xyz
X-OpenRouter-Title: Russell Labs AI Platform
```

## Cost Tracking
- `usage.cost` in response gives per-request cost
- `/api/v1/generation?id=$ID` for async cost lookup
- Token counts via native tokenizer
