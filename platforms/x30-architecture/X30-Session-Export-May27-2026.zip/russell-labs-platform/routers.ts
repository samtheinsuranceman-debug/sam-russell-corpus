import { z } from "zod";
import { nanoid } from "nanoid";
import { TRPCError } from "@trpc/server";
import { desc } from "drizzle-orm";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { invokeGrok, invokeGrokWithFallback } from "./grok";
import { detectSentiment, assessDifficulty, generateStateRights } from "./openai";
import { getDb } from "./db";
import {
  saveHipaaConsent, getConsentBySession, getConsentByUserId,
  getAllConsents, logActivity, getActivityByUser, getAllActivityLogs,
  getActivityStats, createAssessment, getAssessmentById, updateAssessment,
  getAssessmentsByUser, createDiagnosticReport, getReportById,
  getReportByShareToken, getReportsByUser, updateReport,
  getDigitalTwinByUserId, upsertDigitalTwin,
  createJournalEntry, getJournalEntriesByUser, getJournalEntryById,
  createWellnessPlan, getActiveWellnessPlan, updateWellnessPlan,
  createMedication, getMedicationsByUser, updateMedication, deleteMedication,
  logMedicationTaken, getMedicationLogs,
} from "./db";
import { ACTIVITY_EVENTS, drBuddySessions, doctorPatients, assessments, diagnosticReports, digitalTwins, crisisEvents, users, learnerProfiles, eduAssessments, learningPaths, eduChatSessions, achievements, careerPredictions, taperPlans, taperMilestones, personalityProfiles, personalityResponses, clientLeads } from "../drizzle/schema";
import type { TaperMedication, DrugInteraction, HealthProjection, PubMedCitation, PhysicianReport, PersonalityResponse, NeedsGapItem, TransformationStage } from "../drizzle/schema";
import type { DigitalTwinSnapshot, DigitalTwinAlert } from "../drizzle/schema";
import { eq, and } from "drizzle-orm";

// ─── Digital Twin Domain Definitions (from Grok) ─────────────────────────────
const TWIN_DOMAINS = [
  { id: "moodRegulation", name: "Mood Regulation", criticalThreshold: 20, deteriorationThreshold: 15 },
  { id: "anxietyManagement", name: "Anxiety Management", criticalThreshold: 20, deteriorationThreshold: 15 },
  { id: "psychoticSymptoms", name: "Psychotic Symptoms", criticalThreshold: 25, deteriorationThreshold: 10 },
  { id: "cognitiveFunction", name: "Cognitive Function", criticalThreshold: 25, deteriorationThreshold: 15 },
  { id: "sleepQuality", name: "Sleep Quality", criticalThreshold: 20, deteriorationThreshold: 15 },
  { id: "socialEngagement", name: "Social Engagement", criticalThreshold: 25, deteriorationThreshold: 15 },
  { id: "traumaResponse", name: "Trauma Response", criticalThreshold: 20, deteriorationThreshold: 15 },
  { id: "substanceUse", name: "Substance Use", criticalThreshold: 25, deteriorationThreshold: 10 },
  { id: "eatingBehavior", name: "Eating Behavior", criticalThreshold: 25, deteriorationThreshold: 15 },
  { id: "personalityStability", name: "Personality Stability", criticalThreshold: 25, deteriorationThreshold: 15 },
  { id: "somaticConcerns", name: "Somatic Concerns", criticalThreshold: 25, deteriorationThreshold: 15 },
  { id: "crisisSafety", name: "Crisis & Safety", criticalThreshold: 30, deteriorationThreshold: 10 },
] as const;

function computeCompositeScore(domainScores: Record<string, number>): number {
  const scores = TWIN_DOMAINS.map(d => domainScores[d.id] ?? 50);
  const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
  // Crisis safety veto: if below critical threshold, cap composite at 50
  const crisisScore = domainScores["crisisSafety"] ?? 50;
  if (crisisScore < 30) return Math.min(avg, 50);
  return Math.round(avg * 10) / 10;
}

function classifyState(
  composite: number,
  domainScores: Record<string, number>,
  prevComposite?: number
): "stable" | "improving" | "deteriorating" | "critical" {
  const crisisScore = domainScores["crisisSafety"] ?? 50;
  if (crisisScore < 30 || composite < 30) return "critical";
  if (prevComposite !== undefined) {
    if (composite - prevComposite >= 10) return "improving";
    if (prevComposite - composite >= 10) return "deteriorating";
  }
  const anyDomainCritical = TWIN_DOMAINS.some(d => (domainScores[d.id] ?? 50) < d.criticalThreshold);
  if (anyDomainCritical) return "critical";
  return "stable";
}

function generateAlerts(
  newScores: Record<string, number>,
  prevScores: Record<string, number>
): DigitalTwinAlert[] {
  const alerts: DigitalTwinAlert[] = [];
  for (const domain of TWIN_DOMAINS) {
    const newScore = newScores[domain.id] ?? 50;
    const prevScore = prevScores[domain.id] ?? 50;
    const drop = prevScore - newScore;
    if (newScore < domain.criticalThreshold) {
      alerts.push({
        id: `${domain.id}-${Date.now()}`,
        domain: domain.id,
        domainName: domain.name,
        message: `Your ${domain.name} score (${newScore}) has reached a critical level. Please consider reaching out to your care team or accessing crisis resources.`,
        severity: "critical",
        score: newScore,
        triggeredAt: new Date().toISOString(),
        acknowledged: false,
      });
    } else if (drop >= domain.deteriorationThreshold) {
      alerts.push({
        id: `${domain.id}-${Date.now()}`,
        domain: domain.id,
        domainName: domain.name,
        message: `We've noticed a change in your ${domain.name} (score: ${newScore}). Would you like to connect with your care team or log how you're feeling?`,
        severity: "warning",
        score: newScore,
        triggeredAt: new Date().toISOString(),
        acknowledged: false,
      });
    }
  }
  return alerts;
}

// Map assessment answers to domain scores using DSM-5 question categories
function mapAssessmentToDomainScores(answers: Record<string, number>): Record<string, number> {
  // Question indices are 1-based; map to domains based on DSM-5 clusters
  // Scores are inverted: high symptom severity = low domain score
  const domainQuestions: Record<string, number[]> = {
    moodRegulation: [1, 2, 3, 4, 5, 6, 7, 8],
    anxietyManagement: [9, 10, 11, 12, 13, 14, 15, 16],
    psychoticSymptoms: [17, 18, 19, 20, 21, 22],
    cognitiveFunction: [23, 24, 25, 26, 27, 28],
    sleepQuality: [29, 30, 31, 32, 33],
    socialEngagement: [34, 35, 36, 37, 38, 39],
    traumaResponse: [40, 41, 42, 43, 44, 45, 46],
    substanceUse: [47, 48, 49, 50, 51, 52],
    eatingBehavior: [53, 54, 55, 56, 57],
    personalityStability: [58, 59, 60, 61, 62, 63, 64, 65],
    somaticConcerns: [66, 67, 68, 69, 70, 71],
    crisisSafety: [72, 73, 74, 75, 76, 77, 78, 79, 80],
  };
  const scores: Record<string, number> = {};
  for (const [domain, qNums] of Object.entries(domainQuestions)) {
    const domainAnswers = qNums.map(n => answers[String(n)] ?? 2); // default mid
    // Answers are 1-4 scale; 1=never/none, 4=always/severe
    const avgSeverity = domainAnswers.reduce((a, b) => a + b, 0) / domainAnswers.length;
    // Convert to 0-100 health score (inverted: lower severity = higher health)
    scores[domain] = Math.round(((4 - avgSeverity) / 3) * 100);
  }
  return scores;
}
import type { ProvisionalDiagnosis, SymptomProfile, TreatmentRecommendation, PubmedArticle } from "../drizzle/schema";

export const appRouter = router({
  system: systemRouter,

  // ─── Auth ────────────────────────────────────────────────────────────────────
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
    updateResidentState: protectedProcedure
      .input(z.object({ residentState: z.string().length(2) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        await db.update(users).set({ residentState: input.residentState }).where(eq(users.id, ctx.user.id));
        return { success: true, residentState: input.residentState };
      }),
  }),

  // ─── HIPAA Consent ───────────────────────────────────────────────────────────
  consent: router({
    check: publicProcedure
      .input(z.object({ sessionId: z.string() }))
      .query(async ({ input, ctx }) => {
        // Check by userId if logged in, else by sessionId
        if (ctx.user) {
          const consent = await getConsentByUserId(ctx.user.id);
          return { hasSigned: !!consent, consent };
        }
        const consent = await getConsentBySession(input.sessionId);
        return { hasSigned: !!consent, consent };
      }),

    sign: publicProcedure
      .input(z.object({
        sessionId: z.string(),
        fullName: z.string().min(2),
        email: z.string().email(),
        agreedToTerms: z.boolean(),
        agreedToHipaa: z.boolean(),
        agreedToActivityLogging: z.boolean(),
        residentState: z.string().length(2).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (!input.agreedToTerms || !input.agreedToHipaa) {
          throw new Error("You must agree to all required terms to proceed.");
        }
        const ipAddress = ctx.req.headers["x-forwarded-for"] as string || (ctx.req as any).socket?.remoteAddress || "unknown";
        const userAgent = ctx.req.headers["user-agent"] || "unknown";

        await saveHipaaConsent({
          userId: ctx.user?.id ?? null,
          sessionId: input.sessionId,
          ipAddress,
          userAgent,
          fullName: input.fullName,
          email: input.email,
          consentVersion: "1.0",
          agreedToTerms: input.agreedToTerms,
          agreedToHipaa: input.agreedToHipaa,
          agreedToActivityLogging: input.agreedToActivityLogging,
          residentState: input.residentState ?? null,
          signedAt: new Date(),
        });

        await logActivity({
          userId: ctx.user?.id ?? null,
          sessionId: input.sessionId,
          eventType: ACTIVITY_EVENTS.CONSENT_SIGNED,
          page: "/consent",
          metadata: { consentVersion: "1.0", email: input.email },
          ipAddress,
          userAgent,
        });

        return { success: true };
      }),

    // Admin only
    listAll: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") throw new Error("Forbidden");
      return getAllConsents(500);
    }),
  }),

  // ─── Activity Logging ────────────────────────────────────────────────────────
  activity: router({
    log: publicProcedure
      .input(z.object({
        sessionId: z.string(),
        eventType: z.string(),
        page: z.string().optional(),
        metadata: z.record(z.string(), z.any()).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const ipAddress = ctx.req.headers["x-forwarded-for"] as string || (ctx.req as any).socket?.remoteAddress || "unknown";
        const userAgent = ctx.req.headers["user-agent"] || "unknown";
        const referrer = ctx.req.headers["referer"] as string || "";
        await logActivity({
          userId: ctx.user?.id ?? null,
          sessionId: input.sessionId,
          eventType: input.eventType,
          page: input.page,
          metadata: input.metadata as Record<string, unknown> | undefined,
          ipAddress,
          userAgent,
          referrer,
        });
        return { success: true };
      }),

    myActivity: protectedProcedure.query(async ({ ctx }) => {
      return getActivityByUser(ctx.user.id, 200);
    }),

    // Admin only
    allLogs: protectedProcedure
      .input(z.object({ limit: z.number().default(500), offset: z.number().default(0) }))
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin") throw new Error("Forbidden");
        return getAllActivityLogs(input.limit, input.offset);
      }),

    stats: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") throw new Error("Forbidden");
      return getActivityStats();
    }),
  }),

  // ─── Assessments ─────────────────────────────────────────────────────────────
  assessment: router({
    start: publicProcedure
      .input(z.object({ sessionId: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const result = await createAssessment({
          userId: ctx.user?.id ?? null,
          sessionId: input.sessionId,
          status: "in_progress",
          currentQuestionIndex: 0,
          answers: {},
        });
        return { id: (result as any).insertId };
      }),

    saveProgress: publicProcedure
      .input(z.object({
        id: z.number(),
        currentQuestionIndex: z.number(),
        answers: z.record(z.string(), z.any()),
      }))
      .mutation(async ({ input }) => {
        await updateAssessment(input.id, {
          currentQuestionIndex: input.currentQuestionIndex,
          answers: input.answers,
        });
        return { success: true };
      }),

    complete: publicProcedure
      .input(z.object({
        id: z.number(),
        answers: z.record(z.string(), z.any()),
      }))
      .mutation(async ({ input, ctx }) => {
        await updateAssessment(input.id, {
          status: "completed",
          answers: input.answers,
          completedAt: new Date(),
        });

        // Generate AI diagnostic report
        const diagnosisPrompt = `You are a clinical psychiatrist analyzing a psychiatric intake assessment. 
Based on the following DSM-5 intake responses, generate a differential diagnosis report.

Assessment answers (question_id: answer):
${JSON.stringify(input.answers, null, 2)}

Return a JSON object with:
{
  "provisionalDiagnoses": [array of up to 5 diagnoses, each with: code, name, confidence (0-100), criteriaMatched (array of strings), criteriaTotal (number), dsmLink (URL to DSM-5 criteria), description],
  "symptomProfile": {
    "domains": { "mood": 0-100, "anxiety": 0-100, "psychosis": 0-100, "trauma": 0-100, "ocd": 0-100, "adhd": 0-100, "substanceUse": 0-100, "somatic": 0-100, "sleep": 0-100, "eating": 0-100 },
    "severity": "mild|moderate|severe",
    "duration": "string",
    "onset": "string",
    "functionalImpairment": 0-100
  }
}
Return ONLY valid JSON.`;

        const aiResponse = await invokeLLM({
          messages: [
            { role: "system", content: "You are a clinical psychiatrist. Return only valid JSON." },
            { role: "user", content: diagnosisPrompt },
          ],
          response_format: { type: "json_object" },
        });

        let reportData: { provisionalDiagnoses: ProvisionalDiagnosis[]; symptomProfile: SymptomProfile };
        try {
          const content = (aiResponse as any).choices?.[0]?.message?.content || "{}";
          reportData = JSON.parse(content);
        } catch {
          reportData = {
            provisionalDiagnoses: [],
            symptomProfile: {
              domains: { mood: 0, anxiety: 0, psychosis: 0, trauma: 0, ocd: 0, adhd: 0, substanceUse: 0, somatic: 0, sleep: 0, eating: 0 },
              severity: "mild",
              duration: "unknown",
              onset: "unknown",
              functionalImpairment: 0,
            },
          };
        }

        // ─── Update Digital Twin from assessment answers ───────────────────────
        if (ctx.user?.id) {
          try {
            const answersAsNumbers: Record<string, number> = {};
            for (const [k, v] of Object.entries(input.answers)) {
              answersAsNumbers[k] = typeof v === "number" ? v : Number(v) || 2;
            }
            const newDomainScores = mapAssessmentToDomainScores(answersAsNumbers);
            const existingTwin = await getDigitalTwinByUserId(ctx.user.id);
            const prevScores: Record<string, number> = existingTwin
              ? (existingTwin.domainScores as Record<string, number>)
              : {};
            const composite = computeCompositeScore(newDomainScores);
            const prevComposite = existingTwin?.compositeScore ?? undefined;
            const state = classifyState(composite, newDomainScores, prevComposite);
            const newAlerts = generateAlerts(newDomainScores, prevScores);
            const existingAlerts = (existingTwin?.activeAlerts as DigitalTwinAlert[] ?? []).filter(a => !a.acknowledged);
            const allAlerts = [...existingAlerts, ...newAlerts].slice(-20);
            const snapshot: DigitalTwinSnapshot = {
              timestamp: new Date().toISOString(),
              domainScores: newDomainScores,
              compositeScore: composite,
              state,
              source: "assessment",
            };
            const history = [...(existingTwin?.trajectoryHistory as DigitalTwinSnapshot[] ?? []), snapshot].slice(-90);
            await upsertDigitalTwin(ctx.user.id, {
              domainScores: newDomainScores,
              compositeScore: composite,
              currentState: state,
              trajectoryHistory: history,
              activeAlerts: allAlerts,
              lastUpdateSource: "assessment",
              lastAssessmentId: input.id,
              lastUpdated: new Date(),
            });
          } catch (twinErr) {
            console.warn("[DigitalTwin] Failed to update twin:", twinErr);
          }
        }

        // ─── Compute Psychiatric Risk Score (PRS) ─────────────────────────────
        const PRS_DOMAINS = [
          { name: "Mood", weight: 0.20, symptomKey: "mood" },
          { name: "Anxiety", weight: 0.18, symptomKey: "anxiety" },
          { name: "Trauma", weight: 0.15, symptomKey: "trauma" },
          { name: "Psychotic", weight: 0.12, symptomKey: "psychosis" },
          { name: "Personality", weight: 0.12, symptomKey: "mood" }, // proxy via mood domain
          { name: "Substance", weight: 0.10, symptomKey: "substanceUse" },
          { name: "Neurodevelopmental", weight: 0.08, symptomKey: "adhd" },
          { name: "Somatic", weight: 0.05, symptomKey: "somatic" },
        ];
        const symptomDomains = reportData.symptomProfile?.domains ?? {};
        const prsBreakdown: Record<string, number> = {};
        let prsScore = 0;
        for (const d of PRS_DOMAINS) {
          // symptom score is 0-100 severity; PRS domain = 100 - severity (higher = healthier)
          const severity = (symptomDomains as Record<string, number>)[d.symptomKey] ?? 50;
          const domainHealth = Math.max(0, Math.min(100, 100 - severity));
          prsBreakdown[d.name] = domainHealth;
          prsScore += domainHealth * d.weight;
        }
        // Scale to 0-1000
        const finalPrsScore = Math.round(prsScore * 10);

        const shareToken = nanoid(32);
        const reportResult = await createDiagnosticReport({
          assessmentId: input.id,
          userId: ctx.user?.id ?? null,
          provisionalDiagnoses: reportData.provisionalDiagnoses || [],
          symptomProfile: reportData.symptomProfile,
          shareToken,
          sharedWithProvider: false,
          prsScore: finalPrsScore,
          prsBreakdown,
        });

        return { reportId: (reportResult as any).insertId, shareToken };
      }),

    myAssessments: protectedProcedure.query(async ({ ctx }) => {
      return getAssessmentsByUser(ctx.user.id);
    }),
  }),

  // ─── Diagnostic Reports ───────────────────────────────────────────────────────
  report: router({
    get: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getReportById(input.id);
      }),

    getByToken: publicProcedure
      .input(z.object({ token: z.string() }))
      .query(async ({ input }) => {
        return getReportByShareToken(input.token);
      }),

    myReports: protectedProcedure.query(async ({ ctx }) => {
      return getReportsByUser(ctx.user.id);
    }),

    generateTreatment: publicProcedure
      .input(z.object({ reportId: z.number() }))
      .mutation(async ({ input }) => {
        const report = await getReportById(input.reportId);
        if (!report) throw new Error("Report not found");

        const diagnoses = Array.isArray(report.provisionalDiagnoses)
          ? (report.provisionalDiagnoses as any[]).map((d: any) => d.condition || d).join(", ")
          : String(report.provisionalDiagnoses || "unspecified psychiatric condition");

        const aiResponse = await invokeLLM({
          messages: [
            {
              role: "system",
              content: "You are a board-certified psychiatrist providing evidence-based treatment recommendations. Always include PubMed PMIDs or clinical guideline references in citations. Include a mix of pharmacotherapy, psychotherapy, lifestyle, and referral recommendations.",
            },
            {
              role: "user",
              content: `Generate 6-8 evidence-based treatment recommendations for a patient with the following provisional diagnoses: ${diagnoses}. For each recommendation include: category (pharmacotherapy, psychotherapy, lifestyle, or referral), title, description (2-3 sentences), evidenceLevel (A=RCT evidence, B=observational, C=expert consensus), and citations (array of PubMed PMIDs or guideline names).`,
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "treatment_recommendations",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  recommendations: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        category: { type: "string", enum: ["pharmacotherapy", "psychotherapy", "lifestyle", "referral"] },
                        title: { type: "string" },
                        description: { type: "string" },
                        evidenceLevel: { type: "string", enum: ["A", "B", "C"] },
                        citations: { type: "array", items: { type: "string" } },
                      },
                      required: ["category", "title", "description", "evidenceLevel", "citations"],
                      additionalProperties: false,
                    },
                  },
                },
                required: ["recommendations"],
                additionalProperties: false,
              },
            },
          },
        });

        let treatments: TreatmentRecommendation[] = [];
        try {
          const content = (aiResponse as any).choices?.[0]?.message?.content || "{}";
          const parsed = JSON.parse(content);
          treatments = parsed.recommendations || [];
        } catch { treatments = []; }

        await updateReport(input.reportId, { treatmentRecommendations: treatments });
        return { treatments };
      }),

    share: protectedProcedure
      .input(z.object({ reportId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const report = await getReportById(input.reportId);
        if (!report) throw new Error("Report not found");
        await updateReport(input.reportId, { sharedWithProvider: true });
        return { shareToken: report.shareToken, shareUrl: `/shared/${report.shareToken}` };
      }),
  }),

  // ─── PubMed Research ─────────────────────────────────────────────────────────
  research: router({
    search: publicProcedure
      .input(z.object({ query: z.string().min(2), maxResults: z.number().default(10) }))
      .query(async ({ input }) => {
        try {
          const searchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=${encodeURIComponent(input.query)}&retmax=${input.maxResults}&retmode=json&sort=relevance`;
          const searchResp = await fetch(searchUrl);
          const searchData = await searchResp.json() as any;
          const ids: string[] = searchData?.esearchresult?.idlist || [];

          if (ids.length === 0) return { articles: [] };

          const summaryUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&id=${ids.join(",")}&retmode=json`;
          const summaryResp = await fetch(summaryUrl);
          const summaryData = await summaryResp.json() as any;

          const articles: PubmedArticle[] = ids.map(id => {
            const item = summaryData?.result?.[id];
            if (!item) return null;
            return {
              pmid: id,
              title: item.title || "Untitled",
              authors: (item.authors || []).slice(0, 3).map((a: any) => a.name),
              journal: item.fulljournalname || item.source || "",
              year: parseInt(item.pubdate?.split(" ")[0] || "0"),
              abstract: "",
              url: `https://pubmed.ncbi.nlm.nih.gov/${id}/`,
            };
          }).filter(Boolean) as PubmedArticle[];

          return { articles };
        } catch (err) {
          console.error("PubMed search error:", err);
          return { articles: [] };
        }
      }),

    forDiagnosis: publicProcedure
      .input(z.object({ diagnoses: z.array(z.string()), limit: z.number().default(5) }))
      .query(async ({ input }) => {
        const query = input.diagnoses.slice(0, 3).join(" OR ") + " treatment evidence-based";
        try {
          const searchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=${encodeURIComponent(query)}&retmax=${input.limit}&retmode=json&sort=relevance`;
          const searchResp = await fetch(searchUrl);
          const searchData = await searchResp.json() as any;
          const ids: string[] = searchData?.esearchresult?.idlist || [];
          return { ids, query };
        } catch {
          return { ids: [], query };
        }
      }),
  }),

  // ─── Life Maps ───────────────────────────────────────────────────────────────
  lifeMaps: router({
    generate: publicProcedure
      .input(z.object({
        condition: z.string(),
        currentAge: z.number().min(10).max(80),
        currentTreatmentStatus: z.enum(["untreated", "partial", "treated"]),
      }))
      .mutation(async ({ input }) => {
        const prompt = `You are a clinical psychiatrist and health outcomes researcher.
Generate a dual life trajectory simulation for a person with ${input.condition} who is currently ${input.currentAge} years old and is ${input.currentTreatmentStatus}.

Return JSON with two parallel timelines:
{
  "condition": "${input.condition}",
  "treated": { "milestones": [...] },
  "untreated": { "milestones": [...] }
}

Each milestones array covers ages from ${input.currentAge} to 80 in 5-year increments.
Each milestone: { age, qualityOfLife (0-100), careerStatus, relationshipStatus, healthStatus, financialStatus, keyEvent, riskLevel ("low"|"moderate"|"high"|"critical"), narrative (2 sentences describing life at this age) }

Make the contrast between treated and untreated vivid and clinically accurate.
Return ONLY valid JSON.`;

        const aiResponse = await invokeLLM({
          messages: [
            { role: "system", content: "You are a clinical psychiatrist. Return only valid JSON." },
            { role: "user", content: prompt },
          ],
        });

        try {
          const content = (aiResponse as any).choices?.[0]?.message?.content || "{}";
          return JSON.parse(content);
        } catch {
          return { condition: input.condition, treated: { milestones: [] }, untreated: { milestones: [] } };
        }
      }),
  }),

  // ─── Life Events Engine ──────────────────────────────────────────────────────
  lifeEvents: router({
    analyze: publicProcedure
      .input(z.object({
        events: z.array(z.object({
          id: z.string(),
          name: z.string(),
          age: z.number(),
          category: z.string(),
        })),
        currentAge: z.number(),
        existingConditions: z.array(z.string()).optional(),
      }))
      .mutation(async ({ input }) => {
        const prompt = `You are a clinical psychiatrist analyzing a person's life event history.

Life events experienced:
${input.events.map(e => `- Age ${e.age}: ${e.name} (${e.category})`).join("\n")}

Current age: ${input.currentAge}
${input.existingConditions?.length ? `Existing conditions: ${input.existingConditions.join(", ")}` : ""}

Analyze this life event profile and return JSON:
{
  "overallRisk": "low"|"moderate"|"high"|"critical",
  "riskScore": 0-100,
  "growthScore": 0-100,
  "resilienceScore": 0-100,
  "domainRisks": { "depression": 0-100, "anxiety": 0-100, "ptsd": 0-100, "substanceUse": 0-100, "bipolar": 0-100, "ocd": 0-100 },
  "challengeZones": [ { "period": "age range string", "events": ["event names"], "risk": "description", "recommendation": "action" } ],
  "growthOpportunities": [ { "event": "event name", "opportunity": "description", "action": "specific recommendation" } ],
  "keyInsights": [ "insight string" (4 insights) ],
  "futureRisks": [ { "age": number, "event": "predicted life event", "probability": 0-100, "impact": "description" } (5 predictions) ],
  "narrative": "2-paragraph clinical narrative summarizing this person's life event profile and mental health trajectory"
}
Return ONLY valid JSON.`;

        const aiResponse = await invokeLLM({
          messages: [
            { role: "system", content: "You are a clinical psychiatrist. Return only valid JSON." },
            { role: "user", content: prompt },
          ],
        });

        try {
          const content = (aiResponse as any).choices?.[0]?.message?.content || "{}";
          return JSON.parse(content);
        } catch {
          return {
            overallRisk: "moderate",
            riskScore: 50,
            growthScore: 50,
            resilienceScore: 50,
            domainRisks: { depression: 50, anxiety: 50, ptsd: 30, substanceUse: 20, bipolar: 20, ocd: 20 },
            challengeZones: [],
            growthOpportunities: [],
            keyInsights: ["Analysis unavailable. Please try again."],
            futureRisks: [],
            narrative: "Unable to generate analysis at this time.",
          };
        }
      }),
  }),

  // ─── CDC Data ────────────────────────────────────────────────────────────────
  cdc: router({
    fluData: publicProcedure.query(async () => {
      try {
        // CDC FluView API
        const resp = await fetch(
          "https://gis.cdc.gov/grasp/flu2/GetFlu2Data",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ AppVersion: "Public", DatasourceDT: [], RegionTypeId: 5, SubRegionsDT: [], SeasonsDT: [{ ID: 64 }], VirusTypesDT: [], FlueTypesDT: [] }),
          }
        );
        if (!resp.ok) throw new Error("CDC API error");
        const data = await resp.json() as any;
        return { success: true, data };
      } catch {
        // Return mock data if CDC API unavailable
        return {
          success: false,
          data: null,
          message: "Using cached data — CDC FluView API temporarily unavailable",
        };
      }
    }),

     covidVaccines: publicProcedure.query(async () => {
      try {
        const resp = await fetch(
          "https://data.cdc.gov/resource/unsk-b7fc.json?$limit=50&$order=date DESC",
          { headers: { "X-App-Token": "public" } }
        );
        if (!resp.ok) throw new Error("CDC API error");
        const data = await resp.json();
        return { success: true, data };
      } catch {
        return { success: false, data: null };
      }
    }),
  }),

  // ─── Digital Twin Mental Health Model ────────────────────────────────────────
  digitalTwin: router({
    // Get the current user's digital twin (or create default if none exists)
    getMyTwin: protectedProcedure.query(async ({ ctx }) => {
      let twin = await getDigitalTwinByUserId(ctx.user.id);
      if (!twin) {
        // Initialize with neutral scores
        const defaultScores: Record<string, number> = {};
        for (const d of TWIN_DOMAINS) defaultScores[d.id] = 50;
        await upsertDigitalTwin(ctx.user.id, {
          domainScores: defaultScores,
          compositeScore: 50,
          currentState: "stable",
          trajectoryHistory: [],
          activeAlerts: [],
          lastUpdateSource: "initialization",
        });
        twin = await getDigitalTwinByUserId(ctx.user.id);
      }
      return { twin, domains: TWIN_DOMAINS };
    }),

    // Get trajectory history for charts
    getTwinHistory: protectedProcedure
      .input(z.object({ days: z.number().min(7).max(365).default(30) }))
      .query(async ({ ctx, input }) => {
        const twin = await getDigitalTwinByUserId(ctx.user.id);
        if (!twin) return { history: [], domains: TWIN_DOMAINS };
        const cutoff = new Date();
        cutoff.setDate(cutoff.getDate() - input.days);
        const history = (twin.trajectoryHistory as DigitalTwinSnapshot[] ?? [])
          .filter(s => new Date(s.timestamp) >= cutoff)
          .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
        return { history, domains: TWIN_DOMAINS };
      }),

    // Acknowledge an alert
    acknowledgeAlert: protectedProcedure
      .input(z.object({ alertId: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const twin = await getDigitalTwinByUserId(ctx.user.id);
        if (!twin) throw new Error("Digital twin not found");
        const alerts = (twin.activeAlerts as DigitalTwinAlert[] ?? []).map(a =>
          a.id === input.alertId ? { ...a, acknowledged: true } : a
        );
        await upsertDigitalTwin(ctx.user.id, { activeAlerts: alerts });
        return { success: true };
      }),

    // Manual update from journal/checkin (partial domain update)
    updateFromJournal: protectedProcedure
      .input(z.object({
        moodScore: z.number().min(1).max(10).optional(),
        anxietyScore: z.number().min(1).max(10).optional(),
        sleepHours: z.number().min(0).max(24).optional(),
        socialInteraction: z.number().min(1).max(5).optional(),
        note: z.string().max(2000).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const twin = await getDigitalTwinByUserId(ctx.user.id);
        const prevScores: Record<string, number> = twin ? (twin.domainScores as Record<string, number>) : {};
        const newScores = { ...prevScores };

        // Map journal inputs to domain score adjustments
        if (input.moodScore !== undefined) {
          newScores.moodRegulation = Math.round((input.moodScore / 10) * 100);
        }
        if (input.anxietyScore !== undefined) {
          // Anxiety score is inverted (higher anxiety = lower health)
          newScores.anxietyManagement = Math.round(((10 - input.anxietyScore) / 10) * 100);
        }
        if (input.sleepHours !== undefined) {
          // Optimal sleep 7-9 hours
          const sleepScore = input.sleepHours >= 7 && input.sleepHours <= 9 ? 90
            : input.sleepHours >= 6 ? 70
            : input.sleepHours >= 5 ? 50
            : 30;
          newScores.sleepQuality = sleepScore;
        }
        if (input.socialInteraction !== undefined) {
          newScores.socialEngagement = Math.round((input.socialInteraction / 5) * 100);
        }

        const composite = computeCompositeScore(newScores);
        const prevComposite = twin ? (twin.compositeScore ?? 50) : 50;
        const state = classifyState(composite, newScores, prevComposite);
        const newAlerts = generateAlerts(newScores, prevScores);
        const existingAlerts = (twin?.activeAlerts as DigitalTwinAlert[] ?? []).filter(a => !a.acknowledged);
        const allAlerts = [...existingAlerts, ...newAlerts].slice(-20); // keep last 20

        const snapshot: DigitalTwinSnapshot = {
          timestamp: new Date().toISOString(),
          domainScores: newScores,
          compositeScore: composite,
          state,
          source: "journal",
        };
        const history = [...(twin?.trajectoryHistory as DigitalTwinSnapshot[] ?? []), snapshot].slice(-90);

        await upsertDigitalTwin(ctx.user.id, {
          domainScores: newScores,
          compositeScore: composite,
          currentState: state,
          trajectoryHistory: history,
          activeAlerts: allAlerts,
          lastUpdateSource: "journal",
          lastUpdated: new Date(),
        });

        return { twin: await getDigitalTwinByUserId(ctx.user.id), newAlerts };
      }),
  }),

  // ─── Mood Journal ───────────────────────────────────────────────────────────
  journal: router({
    create: protectedProcedure
      .input(z.object({
        content: z.string().min(1).max(5000),
        moodScore: z.number().min(1).max(10).optional(),
        triggers: z.array(z.string()).optional(),
        sleepHours: z.number().min(0).max(24).optional(),
        anxietyRating: z.number().min(1).max(10).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Check for risk indicators (Grok-generated list)
        const RISK_INDICATORS = [
          "want to die", "end my life", "no point in living", "hurt myself",
          "nobody cares", "can't go on", "plan to end", "goodbye forever",
          "giving up", "worthless",
        ];
        const lowerContent = input.content.toLowerCase();
        const riskFound = RISK_INDICATORS.filter(r => lowerContent.includes(r));
        const riskFlagged = riskFound.length > 0;

        // Use LLM to analyze sentiment and generate insight
        const analysisResult = await invokeLLM({
          messages: [
            { role: "system", content: "You are a clinical psychologist analyzing a patient's journal entry. Return only valid JSON." },
            { role: "user", content: `Analyze this journal entry and return JSON with keys: emotionTags (array of 3-5 emotions from: hopeless,anxious,grateful,angry,sad,joyful,frustrated,calm,overwhelmed,excited,lonely,guilty,hopeful,irritable,content,ashamed,nervous,relieved,confused,proud), sentimentDimensions (object with valence,arousal,dominance,clarity,resilience each 0-100), moodTrend (one of: Stable Positive,Stable Negative,Improving,Declining,Volatile,Neutral), aiInsight (2-3 sentence compassionate reflection on the entry).\n\nJournal entry: ${input.content}` },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "journal_analysis",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  emotionTags: { type: "array", items: { type: "string" } },
                  sentimentDimensions: {
                    type: "object",
                    properties: {
                      valence: { type: "number" }, arousal: { type: "number" },
                      dominance: { type: "number" }, clarity: { type: "number" }, resilience: { type: "number" },
                    },
                    required: ["valence", "arousal", "dominance", "clarity", "resilience"],
                    additionalProperties: false,
                  },
                  moodTrend: { type: "string" },
                  aiInsight: { type: "string" },
                },
                required: ["emotionTags", "sentimentDimensions", "moodTrend", "aiInsight"],
                additionalProperties: false,
              },
            },
          },
        });

        let emotionTags: string[] = [];
        let sentimentDimensions: Record<string, number> = {};
        let moodTrend = "Neutral";
        let aiInsight = "";
        try {
          const parsed = JSON.parse((analysisResult as any).choices?.[0]?.message?.content || "{}");
          emotionTags = parsed.emotionTags || [];
          sentimentDimensions = parsed.sentimentDimensions || {};
          moodTrend = parsed.moodTrend || "Neutral";
          aiInsight = parsed.aiInsight || "";
        } catch { /* use defaults */ }

        const entryId = await createJournalEntry({
          userId: ctx.user.id,
          content: input.content,
          moodScore: input.moodScore ?? null,
          emotionTags,
          sentimentDimensions,
          riskFlagged,
          riskIndicatorsFound: riskFound,
          aiInsight,
          moodTrend,
          triggers: input.triggers ?? null,
          sleepHours: input.sleepHours ?? null,
          anxietyRating: input.anxietyRating ?? null,
        });

        // If risk flagged, notify owner
        if (riskFlagged) {
          try {
            const { notifyOwner } = await import("./_core/notification");
            await notifyOwner({
              title: "⚠️ Crisis Risk Indicator Detected in Journal",
              content: `User ${ctx.user.id} journal entry flagged for risk indicators: ${riskFound.join(", ")}`,
            });
          } catch { /* non-blocking */ }
        }

        // ── Feature 7: Journal → Life Events Auto-Feed (via Brain Events) ──
        try {
          const { emitBrainEvent } = await import("./drBuddy");
          const significance = (input.moodScore ?? 5) <= 3 ? "high_negative" : (input.moodScore ?? 5) >= 8 ? "positive" : "neutral";
          if (significance !== "neutral") {
            await emitBrainEvent(ctx.user.id, "journal-auto-feed", "mood-journal", "entry", {
              moodScore: input.moodScore,
              moodTrend,
              significance,
              aiInsight: aiInsight?.slice(0, 200) || "",
              emotionTags,
            });
          }
        } catch { /* non-blocking */ }
        return { entryId, emotionTags, sentimentDimensions, moodTrend, aiInsight, riskFlagged };
      }),

    list: protectedProcedure
      .input(z.object({ limit: z.number().min(1).max(100).default(30) }))
      .query(async ({ ctx, input }) => {
        return getJournalEntriesByUser(ctx.user.id, input.limit);
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const entry = await getJournalEntryById(input.id);
        if (!entry || entry.userId !== ctx.user.id) throw new Error("Not found");
        return entry;
      }),
  }),

  // ─── Wellness Plans ──────────────────────────────────────────────────────────
  wellness: router({
    generate: protectedProcedure
      .input(z.object({
        diagnoses: z.array(z.string()).min(1),
        focusAreas: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const result = await invokeLLM({
          messages: [
            { role: "system", content: "You are a licensed clinical psychologist creating personalized 30-day wellness plans. Return only valid JSON." },
            { role: "user", content: `Create a personalized 30-day wellness plan for someone with: ${input.diagnoses.join(", ")}. Focus areas: ${(input.focusAreas || ["sleep", "exercise", "mindfulness"]).join(", ")}. Return JSON with: title (string), weeklyThemes (array of 4 strings), categories (array of 6 category names), weeks (array of 4 objects, each with: week number, theme, days array of 7 objects each with: day number, actions array of 2-3 objects each with: type, title, description, durationMinutes).` },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "wellness_plan",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  weeklyThemes: { type: "array", items: { type: "string" } },
                  categories: { type: "array", items: { type: "string" } },
                  weeks: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        week: { type: "number" },
                        theme: { type: "string" },
                        days: {
                          type: "array",
                          items: {
                            type: "object",
                            properties: {
                              day: { type: "number" },
                              actions: {
                                type: "array",
                                items: {
                                  type: "object",
                                  properties: {
                                    type: { type: "string" },
                                    title: { type: "string" },
                                    description: { type: "string" },
                                    durationMinutes: { type: "number" },
                                  },
                                  required: ["type", "title", "description", "durationMinutes"],
                                  additionalProperties: false,
                                },
                              },
                            },
                            required: ["day", "actions"],
                            additionalProperties: false,
                          },
                        },
                      },
                      required: ["week", "theme", "days"],
                      additionalProperties: false,
                    },
                  },
                },
                required: ["title", "weeklyThemes", "categories", "weeks"],
                additionalProperties: false,
              },
            },
          },
        });

        let planData: Record<string, unknown> = {};
        let title = "Personalized 30-Day Wellness Plan";
        let weeklyThemes: string[] = [];
        let categories: string[] = [];
        try {
          const parsed = JSON.parse((result as any).choices?.[0]?.message?.content || "{}");
          planData = parsed;
          title = parsed.title || title;
          weeklyThemes = parsed.weeklyThemes || [];
          categories = parsed.categories || [];
        } catch { /* use defaults */ }

        const planId = await createWellnessPlan({
          userId: ctx.user.id,
          title,
          diagnoses: input.diagnoses,
          planData,
          weeklyThemes,
          categories,
          completedActions: [],
          adherenceScore: 0,
          isActive: true,
        });

        return { planId, title, weeklyThemes, categories, planData };
      }),

    getActive: protectedProcedure.query(async ({ ctx }) => {
      return getActiveWellnessPlan(ctx.user.id);
    }),

    markActionComplete: protectedProcedure
      .input(z.object({ planId: z.number(), actionKey: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const plan = await getActiveWellnessPlan(ctx.user.id);
        if (!plan || plan.id !== input.planId) throw new Error("Plan not found");
        const completed = [...((plan.completedActions as string[]) || []), input.actionKey];
        const uniqueCompleted = Array.from(new Set(completed));
        // Estimate total actions: 4 weeks × 7 days × 2.5 avg actions = ~70
        const adherenceScore = Math.min(100, Math.round((uniqueCompleted.length / 70) * 100));
        await updateWellnessPlan(input.planId, { completedActions: uniqueCompleted, adherenceScore });
        return { adherenceScore, completedCount: uniqueCompleted.length };
      }),
  }),

  // ─── Medication Tracker ──────────────────────────────────────────────────────
  medications: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getMedicationsByUser(ctx.user.id);
    }),

    add: protectedProcedure
      .input(z.object({
        name: z.string().min(1).max(255),
        genericName: z.string().optional(),
        dosage: z.string().optional(),
        frequency: z.string().optional(),
        prescribedFor: z.string().optional(),
        prescribedBy: z.string().optional(),
        startDate: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const id = await createMedication({ ...input, userId: ctx.user.id, isActive: true });
        return { id };
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        dosage: z.string().optional(),
        frequency: z.string().optional(),
        notes: z.string().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        await updateMedication(id, data);
        return { success: true };
      }),

    remove: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await deleteMedication(input.id);
        return { success: true };
      }),

    logTaken: protectedProcedure
      .input(z.object({
        medicationId: z.number(),
        skipped: z.boolean().default(false),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const id = await logMedicationTaken({ ...input, userId: ctx.user.id });
        return { id };
      }),

    getLogs: protectedProcedure.query(async ({ ctx }) => {
      return getMedicationLogs(ctx.user.id);
    }),

    checkInteractions: protectedProcedure
      .input(z.object({ medications: z.array(z.string()).min(2) }))
      .mutation(async ({ input }) => {
        const result = await invokeLLM({
          messages: [
            { role: "system", content: "You are a clinical pharmacist. Return only valid JSON." },
            { role: "user", content: `Check for drug interactions between these medications: ${input.medications.join(", ")}. Return JSON with: interactions (array of objects with: drug1, drug2, severity (mild/moderate/severe), description, recommendation), overallRisk (low/moderate/high), summary (2-3 sentences).` },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "drug_interactions",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  interactions: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        drug1: { type: "string" }, drug2: { type: "string" },
                        severity: { type: "string", enum: ["mild", "moderate", "severe"] },
                        description: { type: "string" }, recommendation: { type: "string" },
                      },
                      required: ["drug1", "drug2", "severity", "description", "recommendation"],
                      additionalProperties: false,
                    },
                  },
                  overallRisk: { type: "string", enum: ["low", "moderate", "high"] },
                  summary: { type: "string" },
                },
                required: ["interactions", "overallRisk", "summary"],
                additionalProperties: false,
              },
            },
          },
        });
        try {
          return JSON.parse((result as any).choices?.[0]?.message?.content || "{}");
        } catch { return { interactions: [], overallRisk: "low", summary: "Unable to analyze interactions." }; }
      }),
  }),

    advisory: router({
    chat: protectedProcedure
      .input(z.object({
        message: z.string().min(1).max(4000),
        history: z.array(z.object({
          role: z.enum(["user", "assistant"]),
          content: z.string(),
        })).max(20).optional().default([]),
        systemPrompt: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        // ── Feature 1: PubMed Brain — search PubMed for every message ──
        const topicRes = await invokeLLM({
          messages: [{ role: "user", content: `Extract 1-3 key medical search terms from this patient message for a PubMed search. Return ONLY the search terms separated by commas, nothing else. Message: "${input.message}"` }]
        });
        const searchQuery = (topicRes as any)?.choices?.[0]?.message?.content?.trim() || input.message.slice(0, 80);
        let pubmedArticles: Array<{pmid: string; title: string; authors: string; journal: string; year: string; url: string}> = [];
        try {
          const searchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=${encodeURIComponent(searchQuery)}&retmode=json&retmax=10`;
          const searchRes = await fetch(searchUrl);
          const searchData = await searchRes.json() as any;
          const pmids = searchData.esearchresult?.idlist || [];
          if (pmids.length > 0) {
            const summaryUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&id=${pmids.join(",")}&retmode=json`;
            const summaryRes = await fetch(summaryUrl);
            const summaryData = await summaryRes.json() as any;
            pubmedArticles = pmids.map((pmid: string) => {
              const info = summaryData.result?.[pmid];
              if (!info) return null;
              return { pmid, title: info.title || "", authors: info.authors?.map((a: any) => a.name).join(", ") || "", journal: info.fulljournalname || info.source || "", year: info.pubdate ? info.pubdate.split(" ")[0] : "", url: `https://pubmed.ncbi.nlm.nih.gov/${pmid}/` };
            }).filter(Boolean) as typeof pubmedArticles;
          }
        } catch (e) { console.error("PubMed fetch error:", e); }
        // ── Feature 4: Personality injection ──
        let personalityContext = "";
        try {
          const pDb = await getDb();
          const [profile] = pDb ? await pDb.select().from(personalityProfiles).where(eq(personalityProfiles.userId, ctx.user.id)).orderBy(desc(personalityProfiles.createdAt)).limit(1) : [null];
          if (profile) {
            const parts: string[] = [];
            const ocean = { O: profile.openness, C: profile.conscientiousness, E: profile.extraversion, A: profile.agreeableness, N: profile.neuroticism };
            parts.push(`Personality (OCEAN): ${Object.entries(ocean).filter(([,v]) => v != null).map(([k,v]) => `${k}=${v}`).join(", ")}`);
            const commParts = [];
            if (profile.commDirect != null) commParts.push(`direct=${profile.commDirect}`);
            if (profile.commEmotional != null) commParts.push(`emotional=${profile.commEmotional}`);
            if (commParts.length) parts.push(`Communication: ${commParts.join(", ")}`);
            const needs = { social: profile.needSocialInteraction, solitude: profile.needSolitude, novelty: profile.needNovelty, routine: profile.needRoutine, autonomy: profile.needAutonomy, connection: profile.needConnection, achievement: profile.needAchievement, creativity: profile.needCreativeExpression };
            parts.push(`Needs: ${Object.entries(needs).filter(([,v]) => v != null).map(([k,v]) => `${k}=${v}/10`).join(", ")}`);
            if (parts.length) personalityContext = `\n\n[Patient Personality Profile]\n${parts.join("\n")}`;
          }
        } catch { /* non-blocking */ }
        // ── Build PubMed context string ──
        let pubmedContext = "";
        if (pubmedArticles.length > 0) {
          pubmedContext = "\n\n[PubMed Research Context — cite these using [PMID: XXXXXXXX] format]\n" +
            pubmedArticles.map(a => `- PMID:${a.pmid} | ${a.title} | ${a.journal} (${a.year})`).join("\n");
        }
        // ── Feature 11: Crisis detection ──
        const crisisKeywords = ["suicide", "kill myself", "end my life", "overdose", "want to die", "self-harm", "cut myself", "hurt myself", "better off dead", "no reason to live", "hopeless", "worthless", "giving up", "can't take this anymore"];
        const lowerMsg = input.message.toLowerCase();
        const crisisFound = crisisKeywords.filter(kw => lowerMsg.includes(kw));
        const crisisDetected = crisisFound.length > 0;
        if (crisisDetected) {
          try {
            const { notifyOwner } = await import("./_core/notification");
            await notifyOwner({ title: "⚠️ Crisis Detected in AI Advisory", content: `User ${ctx.user.id} message flagged: ${crisisFound.join(", ")}` });
          } catch { /* non-blocking */ }
        }
        const systemContent = (input.systemPrompt ||
          `You are the Russell Labs AI Advisory — a clinical-grade AI mental health companion powered by DSM-5 criteria, PubMed research, CDC guidelines, and major psychiatric publications. Always cite sources with PubMed PMIDs. Provide evidence-based pharmacological and non-pharmacological treatment options. Always include a disclaimer that recommendations are educational and not a substitute for professional medical care.`) + personalityContext + pubmedContext + (crisisDetected ? "\n\n⚠️ CRISIS ALERT: Patient message contains crisis indicators. Activate crisis protocol immediately. Provide 988 Lifeline and emergency resources." : "");
        const messages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [
          { role: "system", content: systemContent },
          ...input.history.map(h => ({ role: h.role as "user" | "assistant", content: h.content })),
          { role: "user", content: input.message },
        ];
        const result = await invokeLLM({ messages });
        const response = (result as any)?.choices?.[0]?.message?.content ||
          "I'm unable to process your request at this time. Please try again.";
        return { response, pubmedArticles, crisisDetected };
      }),
    // ── Feature 2: Session Summary Email ──
    sendSessionSummary: protectedProcedure
      .input(z.object({
        sessionMessages: z.array(z.object({ role: z.string(), content: z.string() })),
        pubmedCitations: z.array(z.object({ pmid: z.string(), title: z.string(), url: z.string() })).optional().default([]),
        doctorEmail: z.string().optional(),
        doctorName: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const summaryRes = await invokeLLM({
          messages: [{ role: "user", content: `Generate a professional clinical session summary from these messages. Include key topics discussed, recommendations made, and action items.\n\n${input.sessionMessages.map(m => `${m.role}: ${m.content}`).join("\n")}` }]
        });
        const summaryText = (summaryRes as any)?.choices?.[0]?.message?.content || "Session summary unavailable.";
        const citationsBlock = input.pubmedCitations.length > 0
          ? "\n\n━━━ PubMed References ━━━\n" + input.pubmedCitations.map((c, i) => `${i+1}. ${c.title}\n   https://pubmed.ncbi.nlm.nih.gov/${c.pmid}/`).join("\n\n")
          : "";
        const doctorBlock = input.doctorName ? `\nPrepared for: Dr. ${input.doctorName}${input.doctorEmail ? ` (${input.doctorEmail})` : ""}` : "";
        const fullContent = `Clinical Session Summary — ${new Date().toLocaleDateString()}${doctorBlock}\n\nPatient: ${ctx.user.name || "Patient"}\n\n${summaryText}${citationsBlock}\n\n━━━ Disclaimer ━━━\nThis summary is AI-generated and intended for informational purposes only. It does not constitute medical advice. Please consult with a qualified healthcare provider for clinical decisions.`;
        const { notifyOwner } = await import("./_core/notification");
        const success = await notifyOwner({ title: `Clinical Session Summary — ${ctx.user.name || "Patient"} — ${new Date().toLocaleDateString()}`, content: fullContent });
        // ── Mem0 Bus Auto-Persist (Standing Order: session summary → Mem0) ──
        try {
          const { Mem0Bus } = await import("./mem0");
          const bus = Mem0Bus.getInstance();
          await bus.endSession("dr_buddy", summaryText.slice(0, 2000), undefined, {
            type: "session_summary_email",
            messageCount: input.sessionMessages.length,
          });
        } catch (e) { console.error("[Mem0Bus] Advisory session persist failed (non-blocking):", e); }
        return { success, summaryText: fullContent };
      }),
  }),

  // ─── Dr. Buddy AI Psychiatrist ──────────────────────────────────────────────
  drBuddy: router({
    // Patient-facing: send a message to Dr. Buddy
    chat: protectedProcedure
      .input(z.object({
        message: z.string().min(1).max(4000),
        sessionId: z.number().nullable().optional(),
        history: z.array(z.object({
          role: z.enum(["user", "assistant"]),
          content: z.string(),
          timestamp: z.string(),
        })).max(20).optional().default([]),
      }))
      .mutation(async ({ input, ctx }) => {
        const { drBuddyChat, emitBrainEvent } = await import("./drBuddy");
        const result = await drBuddyChat(
          ctx.user.id,
          input.sessionId ?? null,
          input.message,
          input.history
        );
        // Emit conversation event to UnifiedDataBus
        if (result.crisisDetected) {
          await emitBrainEvent(ctx.user.id, "dr-buddy", "conversation", "crisis_detected", {
            message: input.message.slice(0, 200),
          });
        }
        return result;
      }),

    // Get or create a Dr. Buddy session
    getSession: protectedProcedure
      .input(z.object({ sessionId: z.number().optional() }))
      .query(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) return null;
        if (input.sessionId) {
          const [session] = await db.select().from(drBuddySessions)
            .where(and(eq(drBuddySessions.id, input.sessionId), eq(drBuddySessions.userId, ctx.user.id)))
            .limit(1);
          return session ?? null;
        }
        // Return most recent session
        const [latest] = await db.select().from(drBuddySessions)
          .where(eq(drBuddySessions.userId, ctx.user.id))
          .orderBy(desc(drBuddySessions.updatedAt))
          .limit(1);
        return latest ?? null;
      }),

    // Save session messages
    saveSession: protectedProcedure
      .input(z.object({
        sessionId: z.number().nullable(),
        messages: z.array(z.object({
          role: z.enum(["user", "assistant"]),
          content: z.string(),
          timestamp: z.string(),
          crisisFlag: z.boolean().optional(),
        })),
        title: z.string().optional(),
        sessionType: z.enum(["general", "condition_specific", "treatment_planning", "crisis", "medication_review", "progress_review"]).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const crisisEscalated = input.messages.some((m) => m.crisisFlag);
        if (input.sessionId) {
          await db.update(drBuddySessions)
            .set({ messages: input.messages as any, updatedAt: new Date(), crisisEscalated })
            .where(and(eq(drBuddySessions.id, input.sessionId), eq(drBuddySessions.userId, ctx.user.id)));
        } else {
          const [result] = await db.insert(drBuddySessions).values({
            userId: ctx.user.id,
            title: input.title ?? `Session ${new Date().toLocaleDateString()}`,
            messages: input.messages as any,
            sessionType: input.sessionType ?? "general",
            crisisEscalated,
          });
          input.sessionId = (result as any).insertId;
        }
        // ── Mem0 Bus Auto-Persist (Standing Order: every session end → Mem0) ──
        try {
          const { Mem0Bus } = await import("./mem0");
          const bus = Mem0Bus.getInstance();
          const lastMessages = input.messages.slice(-6);
          const summary = lastMessages.map(m => `${m.role}: ${m.content.slice(0, 200)}`).join(" | ");
          await bus.endSession("dr_buddy", summary, undefined, {
            sessionId: input.sessionId,
            sessionType: input.sessionType ?? "general",
            messageCount: input.messages.length,
            crisisEscalated,
          });
        } catch (e) { console.error("[Mem0Bus] DrBuddy session persist failed (non-blocking):", e); }
        return { sessionId: input.sessionId! };
      }),

    // Get patient context summary (for widget header)
    getPatientContext: protectedProcedure
      .query(async ({ ctx }) => {
        const { synthesizePatientContext } = await import("./drBuddy");
        const context = await synthesizePatientContext(ctx.user.id);
        return { context };
      }),

    // Emit a brain event from the frontend
    emitEvent: protectedProcedure
      .input(z.object({
        featureId: z.string(),
        category: z.string(),
        eventType: z.string(),
        payload: z.record(z.string(), z.unknown()),
      }))
      .mutation(async ({ input, ctx }) => {
        const { emitBrainEvent } = await import("./drBuddy");
        await emitBrainEvent(ctx.user.id, input.featureId, input.category, input.eventType, input.payload);
        return { ok: true };
      }),

    // Doctor Portal: get AI Whisperer suggestions for a patient
    getWhispererSuggestions: protectedProcedure
      .input(z.object({ patientUserId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
        const { generateWhispererSuggestions } = await import("./drBuddy");
        const suggestions = await generateWhispererSuggestions(input.patientUserId);
        return { suggestions };
      }),

    // Doctor Portal: get all patients assigned to this doctor
    getDoctorPatients: protectedProcedure
      .query(async ({ ctx }) => {
        if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
        const db = await getDb();
        if (!db) return [];
        return db.select().from(doctorPatients)
          .where(eq(doctorPatients.doctorUserId, ctx.user.id));
      }),
    // Doctor Portal: update clinical notes for a patient
    updateClinicalNotes: protectedProcedure
      .input(z.object({ patientUserId: z.number(), notes: z.string() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        await db.update(doctorPatients)
          .set({ clinicalNotes: input.notes })
          .where(and(eq(doctorPatients.doctorUserId, ctx.user.id), eq(doctorPatients.patientUserId, input.patientUserId)));
        return { success: true };
      }),
    // Doctor Portal: get detailed patient info (assessments, Digital Twin, PRS)
    logCrisisEvent: publicProcedure
      .input(z.object({
        tier: z.enum(["tier1_emergency", "tier2_high_risk", "tier3_elevated"]),
        triggerText: z.string().optional(),
        triggerSource: z.string().optional(),
        matchedKeywords: z.array(z.string()).optional(),
        deescalationUsed: z.boolean().optional(),
        nearestErShown: z.boolean().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
        await db.insert(crisisEvents).values({
          userId: ctx.user?.id ?? null,
          tier: input.tier,
          triggerText: input.triggerText?.slice(0, 500),
          triggerSource: input.triggerSource,
          matchedKeywords: input.matchedKeywords,
          deescalationUsed: input.deescalationUsed ?? false,
          nearestErShown: input.nearestErShown ?? false,
        });
        return { logged: true };
      }),

    getPatientDetail: protectedProcedure
      .input(z.object({ patientUserId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        // Get patient's assessments
        const patientAssessments = await db.select().from(assessments)
          .where(eq(assessments.userId, input.patientUserId))
          .orderBy(desc(assessments.createdAt))
          .limit(10);
        // Get patient's diagnostic reports
        const patientReports = await db.select().from(diagnosticReports)
          .where(eq(diagnosticReports.userId, input.patientUserId))
          .orderBy(desc(diagnosticReports.createdAt))
          .limit(10);
        // Get patient's Digital Twin
        const patientTwin = await db.select().from(digitalTwins)
          .where(eq(digitalTwins.userId, input.patientUserId))
          .limit(1);
        // Get patient's crisis events
        const patientCrisis = await db.select().from(crisisEvents)
          .where(eq(crisisEvents.userId, input.patientUserId))
          .orderBy(desc(crisisEvents.createdAt))
          .limit(20);
        // Get patient's user info
        const patientUser = await db.select({ id: users.id, name: users.name, email: users.email, createdAt: users.createdAt })
          .from(users)
          .where(eq(users.id, input.patientUserId))
          .limit(1);
        return {
          user: patientUser[0] ?? null,
          assessments: patientAssessments,
          reports: patientReports,
          twin: patientTwin[0] ?? null,
          crisisEvents: patientCrisis,
        };
      }),

    // Dual-AI Therapy Analysis (OpenAI + Grok in parallel)
    analyzeWithGrok: protectedProcedure
      .input(z.object({
        message: z.string().min(1).max(5000),
        sessionHistory: z.array(z.object({
          role: z.enum(["user", "assistant"]),
          content: z.string(),
        })).max(20).optional().default([]),
        sessionType: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const conversationContext = input.sessionHistory.map(m => `${m.role}: ${m.content}`).join("\n").slice(-3000);
        const analysisPrompt = `Analyze this therapy conversation for clinical insights. Patient's latest message: "${input.message}"

Recent conversation context:
${conversationContext}

Provide JSON with: riskLevel (none/low/moderate/high/critical), emotionalState (string), primaryConcerns (array of strings), suggestedTechniques (array of CBT/DBT/ACT technique names), therapeuticAlliance (0-10 rating), sessionProgress (string summary), clinicalFlags (array of any concerning patterns).`;

        // Run both AI models in parallel
        const [openaiResult, grokResult] = await Promise.all([
          invokeLLM({
            messages: [
              { role: "system", content: "You are a clinical psychology AI assistant. Analyze therapy conversations for risk factors, emotional patterns, and therapeutic recommendations. Return structured JSON." },
              { role: "user", content: analysisPrompt }
            ],
            response_format: {
              type: "json_schema",
              json_schema: {
                name: "therapy_analysis",
                strict: true,
                schema: {
                  type: "object",
                  properties: {
                    riskLevel: { type: "string", enum: ["none", "low", "moderate", "high", "critical"] },
                    emotionalState: { type: "string" },
                    primaryConcerns: { type: "array", items: { type: "string" } },
                    suggestedTechniques: { type: "array", items: { type: "string" } },
                    therapeuticAlliance: { type: "number" },
                    sessionProgress: { type: "string" },
                    clinicalFlags: { type: "array", items: { type: "string" } }
                  },
                  required: ["riskLevel", "emotionalState", "primaryConcerns", "suggestedTechniques", "therapeuticAlliance", "sessionProgress", "clinicalFlags"],
                  additionalProperties: false
                }
              }
            }
          }).then(r => {
            try {
              const content = r.choices[0]?.message?.content;
              return typeof content === "string" ? JSON.parse(content) : null;
            } catch { return null; }
          }).catch(() => null),

          invokeGrokWithFallback({
            messages: [
              { role: "system", content: "You are a clinical psychology AI. Analyze this therapy conversation. Return JSON with: riskLevel (none/low/moderate/high/critical), emotionalState (string), primaryConcerns (array), suggestedTechniques (array of CBT/DBT/ACT techniques), therapeuticAlliance (0-10), sessionProgress (string), clinicalFlags (array), grokInsight (string with a unique clinical observation that might be missed)." },
              { role: "user", content: analysisPrompt }
            ],
            response_format: { type: "json_object" }
          }).then(r => {
            try { return JSON.parse(r.choices[0].message.content); } catch { return null; }
          }).catch(() => null)
        ]);

        // Merge: take the higher risk level, combine techniques, merge concerns
        const riskOrder = ["none", "low", "moderate", "high", "critical"];
        const openaiRisk = riskOrder.indexOf(openaiResult?.riskLevel ?? "none");
        const grokRisk = riskOrder.indexOf(grokResult?.riskLevel ?? "none");

        return {
          riskLevel: riskOrder[Math.max(openaiRisk, grokRisk)] ?? "none",
          emotionalState: openaiResult?.emotionalState ?? grokResult?.emotionalState ?? "unknown",
          primaryConcerns: Array.from(new Set([...(openaiResult?.primaryConcerns ?? []), ...(grokResult?.primaryConcerns ?? [])])),
          suggestedTechniques: Array.from(new Set([...(openaiResult?.suggestedTechniques ?? []), ...(grokResult?.suggestedTechniques ?? [])])),
          therapeuticAlliance: Math.round(((openaiResult?.therapeuticAlliance ?? 5) + (grokResult?.therapeuticAlliance ?? 5)) / 2),
          sessionProgress: openaiResult?.sessionProgress ?? grokResult?.sessionProgress ?? "Analysis pending",
          clinicalFlags: Array.from(new Set([...(openaiResult?.clinicalFlags ?? []), ...(grokResult?.clinicalFlags ?? [])])),
          grokInsight: grokResult?.grokInsight ?? null,
          dualAI: { openai: !!openaiResult, grok: !!grokResult },
        };
      }),
  }),
  // ─── EduGenius+ ──────────────────────────────────────────────────────────────────
  edu: router({
    // Get or create learner profile
    getProfile: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return null;
      const [profile] = await db.select().from(learnerProfiles).where(eq(learnerProfiles.userId, ctx.user.id)).limit(1);
      return profile || null;
    }),

    // Update learner profile (learning style quiz result)
    updateProfile: protectedProcedure
      .input(z.object({
        learningStyle: z.string().optional(),
        cognitiveProfile: z.record(z.string(), z.number()).optional(),
        emotionalState: z.record(z.string(), z.number()).optional(),
        knowledgeGraph: z.record(z.string(), z.number()).optional(),
        skillProficiency: z.record(z.string(), z.number()).optional(),
        careerAspirations: z.array(z.string()).optional(),
        accessibilityNeeds: z.array(z.string()).optional(),
        selIndicators: z.record(z.string(), z.number()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const [existing] = await db.select().from(learnerProfiles).where(eq(learnerProfiles.userId, ctx.user.id)).limit(1);
        if (existing) {
          await db.update(learnerProfiles).set({ ...input as any, updatedAt: new Date() }).where(eq(learnerProfiles.userId, ctx.user.id));
          return { id: existing.id };
        } else {
          const [result] = await db.insert(learnerProfiles).values({ userId: ctx.user.id, ...input } as any);
          return { id: result.insertId };
        }
      }),

    // EduBuddy AI chat
    chat: protectedProcedure
      .input(z.object({
        message: z.string().min(1).max(5000),
        subject: z.string().optional(),
        sessionId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        // Get or create session
        let session;
        if (input.sessionId) {
          const [s] = await db.select().from(eduChatSessions).where(and(eq(eduChatSessions.id, input.sessionId), eq(eduChatSessions.userId, ctx.user.id))).limit(1);
          session = s;
        }
        const prevMessages = (session?.messages as Array<{ role: string; content: string; timestamp: number }>) || [];
        const newMessages = [...prevMessages, { role: "user", content: input.message, timestamp: Date.now() }];
        // Get learner profile for context
        const [profile] = await db.select().from(learnerProfiles).where(eq(learnerProfiles.userId, ctx.user.id)).limit(1);
        const systemPrompt = `You are EduBuddy, an AI tutor and mentor from EduGenius+. You are patient, encouraging, and adaptive.
${profile ? `Student learning style: ${profile.learningStyle || "unknown"}. Level: ${profile.level}. XP: ${profile.totalXp}. Streak: ${profile.streakDays} days.` : ""}
${input.subject ? `Current subject: ${input.subject}` : ""}
Adapt your explanations to the student's level. Use analogies, examples, and step-by-step breakdowns.
If the student seems frustrated, offer encouragement and simplify. If they're excelling, challenge them.
Always be supportive and celebrate progress.`;
        const llmMessages = [
          { role: "system" as const, content: systemPrompt },
          ...newMessages.slice(-20).map(m => ({ role: m.role as "user" | "assistant", content: m.content })),
        ];
        const response = await invokeLLM({ messages: llmMessages });
        const reply = response.choices?.[0]?.message?.content || "I'm here to help! Could you rephrase your question?";
        const allMessages = [...newMessages, { role: "assistant", content: reply, timestamp: Date.now() }];
        // Save session
        let sessionId: number;
        if (session) {
          await db.update(eduChatSessions).set({ messages: allMessages as any, updatedAt: new Date(), subject: input.subject || session.subject }).where(eq(eduChatSessions.id, session.id));
          sessionId = session.id;
        } else {
          const [result] = await db.insert(eduChatSessions).values({ userId: ctx.user.id, messages: allMessages as any, subject: input.subject || null });
          sessionId = result.insertId as number;
        }
        // Award XP
        if (profile) {
          const newXp = profile.totalXp + 5;
          const newLevel = Math.floor(newXp / 100) + 1;
          await db.update(learnerProfiles).set({ totalXp: newXp, level: newLevel, lastActiveAt: new Date(), updatedAt: new Date() }).where(eq(learnerProfiles.userId, ctx.user.id));
        }
        return { reply, sessionId };
      }),

    // List chat sessions
    listSessions: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select({ id: eduChatSessions.id, subject: eduChatSessions.subject, createdAt: eduChatSessions.createdAt, updatedAt: eduChatSessions.updatedAt }).from(eduChatSessions).where(eq(eduChatSessions.userId, ctx.user.id)).orderBy(desc(eduChatSessions.updatedAt)).limit(20);
    }),

    // Learning style quiz
    submitLearningStyleQuiz: protectedProcedure
      .input(z.object({ answers: z.array(z.object({ questionId: z.number(), answer: z.string() })) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        // VARK scoring
        const scores: Record<string, number> = { visual: 0, auditory: 0, kinesthetic: 0, reading: 0 };
        for (const a of input.answers) {
          const style = a.answer.toLowerCase();
          if (scores[style] !== undefined) scores[style]++;
        }
        const dominant = Object.entries(scores).sort((a, b) => b[1] - a[1])[0][0];
        // Update profile
        const [existing] = await db.select().from(learnerProfiles).where(eq(learnerProfiles.userId, ctx.user.id)).limit(1);
        if (existing) {
          await db.update(learnerProfiles).set({ learningStyle: dominant, cognitiveProfile: scores, updatedAt: new Date() }).where(eq(learnerProfiles.userId, ctx.user.id));
        } else {
          await db.insert(learnerProfiles).values({ userId: ctx.user.id, learningStyle: dominant, cognitiveProfile: scores });
        }
        // Save as edu assessment
        await db.insert(eduAssessments).values({ userId: ctx.user.id, type: "learning_style", responses: input.answers as any, score: scores[dominant], insights: { strengths: [dominant], weaknesses: [], recommendations: [`Focus on ${dominant} learning materials`] } as any, completedAt: new Date() });
        return { learningStyle: dominant, scores };
      }),

    // Generate adaptive assessment via AI
    generateAssessment: protectedProcedure
      .input(z.object({ subject: z.string(), difficulty: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const [profile] = await db.select().from(learnerProfiles).where(eq(learnerProfiles.userId, ctx.user.id)).limit(1);
        const prompt = `Generate a 10-question adaptive assessment for ${input.subject} at ${input.difficulty || "intermediate"} level.
${profile ? `Student learning style: ${profile.learningStyle}. Level: ${profile.level}.` : ""}
Return JSON: { "questions": [{ "q": "question text", "options": ["A", "B", "C", "D"], "correct": "A", "type": "multiple_choice" }] }`;
        const response = await invokeLLM({
          messages: [{ role: "user", content: prompt }],
          response_format: { type: "json_schema", json_schema: { name: "assessment", strict: true, schema: { type: "object", properties: { questions: { type: "array", items: { type: "object", properties: { q: { type: "string" }, options: { type: "array", items: { type: "string" } }, correct: { type: "string" }, type: { type: "string" } }, required: ["q", "options", "correct", "type"], additionalProperties: false } } }, required: ["questions"], additionalProperties: false } } },
        });
        const parsed = JSON.parse(String(response.choices?.[0]?.message?.content || "{}"));
        const [result] = await db.insert(eduAssessments).values({ userId: ctx.user.id, type: "adaptive", subject: input.subject, questions: parsed.questions, maxScore: parsed.questions?.length || 10 });
        return { id: result.insertId, questions: parsed.questions };
      }),

    // Submit assessment answers
    submitAssessment: protectedProcedure
      .input(z.object({ assessmentId: z.number(), responses: z.array(z.object({ questionIdx: z.number(), answer: z.string() })) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const [assessment] = await db.select().from(eduAssessments).where(and(eq(eduAssessments.id, input.assessmentId), eq(eduAssessments.userId, ctx.user.id))).limit(1);
        if (!assessment) throw new TRPCError({ code: "NOT_FOUND" });
        const questions = assessment.questions as Array<{ q: string; options?: string[]; correct?: string; type: string }> || [];
        let score = 0;
        const graded = input.responses.map(r => {
          const correct = questions[r.questionIdx]?.correct === r.answer;
          if (correct) score++;
          return { ...r, correct };
        });
        await db.update(eduAssessments).set({ responses: graded as any, score, completedAt: new Date(), insights: { strengths: [], weaknesses: [], recommendations: [] } as any }).where(eq(eduAssessments.id, input.assessmentId));
        // Award XP
        const xpEarned = score * 10;
        const [profile] = await db.select().from(learnerProfiles).where(eq(learnerProfiles.userId, ctx.user.id)).limit(1);
        if (profile) {
          const newXp = profile.totalXp + xpEarned;
          await db.update(learnerProfiles).set({ totalXp: newXp, level: Math.floor(newXp / 100) + 1, updatedAt: new Date() }).where(eq(learnerProfiles.userId, ctx.user.id));
        }
        // Award achievement if perfect score
        if (score === questions.length && questions.length > 0) {
          await db.insert(achievements).values({ userId: ctx.user.id, type: "mastery", title: `Perfect Score: ${assessment.subject || "Assessment"}`, description: `Scored ${score}/${questions.length}`, icon: "trophy", xpAwarded: 50 });
        }
        return { score, maxScore: questions.length, xpEarned, responses: graded };
      }),

    // List assessments
    listAssessments: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(eduAssessments).where(eq(eduAssessments.userId, ctx.user.id)).orderBy(desc(eduAssessments.createdAt)).limit(20);
    }),

    // Career prediction
    predictCareer: protectedProcedure
      .input(z.object({ interests: z.array(z.string()), skills: z.array(z.string()) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const prompt = `Based on these interests: ${input.interests.join(", ")} and skills: ${input.skills.join(", ")}, predict 5 career paths.
Return JSON: { "predictions": [{ "career": "name", "matchScore": 0-100, "salary": "$XX,XXX-$XX,XXX", "growth": "XX% by 2030", "skills": ["skill1"] }], "skillGaps": [{ "skill": "name", "importance": 1-10, "currentLevel": 1-10 }] }`;
        const response = await invokeLLM({
          messages: [{ role: "user", content: prompt }],
          response_format: { type: "json_schema", json_schema: { name: "career", strict: true, schema: { type: "object", properties: { predictions: { type: "array", items: { type: "object", properties: { career: { type: "string" }, matchScore: { type: "number" }, salary: { type: "string" }, growth: { type: "string" }, skills: { type: "array", items: { type: "string" } } }, required: ["career", "matchScore", "salary", "growth", "skills"], additionalProperties: false } }, skillGaps: { type: "array", items: { type: "object", properties: { skill: { type: "string" }, importance: { type: "number" }, currentLevel: { type: "number" } }, required: ["skill", "importance", "currentLevel"], additionalProperties: false } } }, required: ["predictions", "skillGaps"], additionalProperties: false } } },
        });
        const parsed = JSON.parse(String(response.choices?.[0]?.message?.content || "{}"));
        const [result] = await db.insert(careerPredictions).values({ userId: ctx.user.id, predictions: parsed.predictions, currentSkills: input.skills, skillGaps: parsed.skillGaps });
        return { id: result.insertId, ...parsed };
      }),

    // Get achievements
    getAchievements: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(achievements).where(eq(achievements.userId, ctx.user.id)).orderBy(desc(achievements.earnedAt)).limit(50);
    }),

    // Get learning paths
    getPaths: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(learningPaths).where(eq(learningPaths.userId, ctx.user.id)).orderBy(desc(learningPaths.createdAt)).limit(20);
    }),

    // Generate learning path via AI
    generatePath: protectedProcedure
      .input(z.object({ subject: z.string(), goal: z.string().optional(), difficulty: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const prompt = `Create a personalized learning path for ${input.subject}${input.goal ? ` with goal: ${input.goal}` : ""}.
Difficulty: ${input.difficulty || "intermediate"}.
Return JSON: { "title": "path title", "modules": [{ "id": "mod1", "title": "Module Title", "status": "not_started", "xp": 50, "order": 1 }], "estimatedHours": 20 }`;
        const response = await invokeLLM({
          messages: [{ role: "user", content: prompt }],
          response_format: { type: "json_schema", json_schema: { name: "path", strict: true, schema: { type: "object", properties: { title: { type: "string" }, modules: { type: "array", items: { type: "object", properties: { id: { type: "string" }, title: { type: "string" }, status: { type: "string" }, xp: { type: "number" }, order: { type: "number" } }, required: ["id", "title", "status", "xp", "order"], additionalProperties: false } }, estimatedHours: { type: "number" } }, required: ["title", "modules", "estimatedHours"], additionalProperties: false } } },
        });
        const parsed = JSON.parse(String(response.choices?.[0]?.message?.content || "{}"));
        const [result] = await db.insert(learningPaths).values({ userId: ctx.user.id, title: parsed.title || `${input.subject} Path`, subject: input.subject, difficulty: input.difficulty || "intermediate", modules: parsed.modules, estimatedHours: parsed.estimatedHours });
        return { id: result.insertId, ...parsed };
      }),
    // ─── Educator Dashboard Procedures ───────────────────────────────────────
    getStudents: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      // Admin-only: get all learner profiles with user info
      if (ctx.user.role !== "admin") return [];
      const results = await db.select({
        id: learnerProfiles.id,
        userId: learnerProfiles.userId,
        name: users.name,
        level: learnerProfiles.level,
        xp: learnerProfiles.totalXp,
        streak: learnerProfiles.streakDays,
        style: learnerProfiles.learningStyle,
        lastActive: learnerProfiles.lastActiveAt,
        progress: learnerProfiles.overallScore,
      }).from(learnerProfiles)
        .innerJoin(users, eq(learnerProfiles.userId, users.id))
        .orderBy(desc(learnerProfiles.totalXp))
        .limit(50);
      return results.map(r => ({
        ...r,
        name: r.name || `Student ${r.userId}`,
        style: r.style || "visual",
        progress: r.progress ?? 0,
        lastActive: r.lastActive ? new Date(r.lastActive).toISOString() : null,
        status: (r.streak === 0 && (!r.lastActive || Date.now() - new Date(r.lastActive).getTime() > 3 * 86400000)) ? "at-risk" : r.level >= 15 ? "excelling" : "active",
      }));
    }),
    getClassStats: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return { totalStudents: 0, activeToday: 0, avgLevel: 0, avgStreak: 0, avgProgress: 0, atRiskCount: 0, totalXpEarned: 0 };
      if (ctx.user.role !== "admin") return { totalStudents: 0, activeToday: 0, avgLevel: 0, avgStreak: 0, avgProgress: 0, atRiskCount: 0, totalXpEarned: 0 };
      const allProfiles = await db.select().from(learnerProfiles);
      const total = allProfiles.length;
      if (total === 0) return { totalStudents: 0, activeToday: 0, avgLevel: 0, avgStreak: 0, avgProgress: 0, atRiskCount: 0, totalXpEarned: 0 };
      const now = Date.now();
      const activeToday = allProfiles.filter(p => p.lastActiveAt && now - new Date(p.lastActiveAt).getTime() < 86400000).length;
      const avgLevel = +(allProfiles.reduce((s, p) => s + p.level, 0) / total).toFixed(1);
      const avgStreak = +(allProfiles.reduce((s, p) => s + p.streakDays, 0) / total).toFixed(1);
      const avgProgress = +(allProfiles.reduce((s, p) => s + (p.overallScore ?? 0), 0) / total).toFixed(0);
      const atRiskCount = allProfiles.filter(p => p.streakDays === 0 && (!p.lastActiveAt || now - new Date(p.lastActiveAt).getTime() > 3 * 86400000)).length;
      const totalXpEarned = allProfiles.reduce((s, p) => s + p.totalXp, 0);
      return { totalStudents: total, activeToday, avgLevel, avgStreak, avgProgress, atRiskCount, totalXpEarned };
    }),
    getLeaderboard: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      const rows = await db.select({
        userId: learnerProfiles.userId,
        level: learnerProfiles.level,
        totalXp: learnerProfiles.totalXp,
        streakDays: learnerProfiles.streakDays,
        name: users.name,
      }).from(learnerProfiles)
        .innerJoin(users, eq(learnerProfiles.userId, users.id))
        .orderBy(desc(learnerProfiles.totalXp))
        .limit(20);
      return rows.map((r, i) => ({
        rank: i + 1,
        name: r.name ? (r.name.split(" ")[0] + (r.name.split(" ")[1] ? " " + r.name.split(" ")[1][0] + "." : "")) : `Learner #${r.userId}`,
        level: r.level,
        xp: r.totalXp,
        streak: r.streakDays,
        badge: r.level >= 20 ? "crown" : r.level >= 10 ? "medal" : "star",
        isMe: r.userId === ctx.user.id,
      }));
    }),

    // Dual-AI Sentiment Analysis for learner messages
    analyzeSentiment: protectedProcedure
      .input(z.object({
        text: z.string().min(1).max(5000),
        sessionId: z.number().optional(),
        subject: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Run OpenAI and Grok in parallel for dual-AI sentiment analysis
        const [openaiResult, grokResult] = await Promise.all([
          detectSentiment(input.text),
          invokeGrokWithFallback({
            messages: [
              { role: "system", content: "Analyze the learner's emotional state from their message. Return JSON with: sentiment (positive/neutral/negative), confidence (0-1), emotions (array), frustrationLevel (0-10), engagementLevel (0-10), learningBlockers (array of strings describing what might be hindering learning)." },
              { role: "user", content: input.text }
            ],
            response_format: { type: "json_object" }
          }).then(r => {
            try { return JSON.parse(r.choices[0].message.content); } catch { return null; }
          }).catch(() => null)
        ]);

        // Merge results from both models
        const merged = {
          sentiment: openaiResult?.sentiment ?? grokResult?.sentiment ?? "neutral",
          confidence: Math.max(openaiResult?.confidence ?? 0, grokResult?.confidence ?? 0),
          emotions: Array.from(new Set([...(openaiResult?.emotions ?? []), ...(grokResult?.emotions ?? [])])),
          frustrationLevel: Math.round(((openaiResult?.frustrationLevel ?? 5) + (grokResult?.frustrationLevel ?? 5)) / 2),
          engagementLevel: Math.round(((openaiResult?.engagementLevel ?? 5) + (grokResult?.engagementLevel ?? 5)) / 2),
          learningBlockers: grokResult?.learningBlockers ?? [],
          dualAI: { openai: !!openaiResult, grok: !!grokResult },
        };
        return merged;
      }),

    // Dual-AI Difficulty Adaptation for mid-assessment adjustment
    adaptDifficulty: protectedProcedure
      .input(z.object({
        answers: z.array(z.object({
          questionId: z.string(),
          correct: z.boolean(),
          difficulty: z.string(),
          timeSpentMs: z.number().optional(),
        })),
        currentDifficulty: z.string(),
        subject: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Run OpenAI and Grok in parallel for dual-AI difficulty recommendation
        const answerSummary = `${input.answers.length} questions answered. Accuracy: ${((input.answers.filter(a => a.correct).length / input.answers.length) * 100).toFixed(0)}%. Current difficulty: ${input.currentDifficulty}. Difficulties attempted: ${input.answers.map(a => a.difficulty).join(", ")}.`;

        const [openaiResult, grokResult] = await Promise.all([
          assessDifficulty(input.answers),
          invokeGrokWithFallback({
            messages: [
              { role: "system", content: "You are an adaptive learning specialist. Analyze the student's answer pattern and recommend the optimal next difficulty level. Return JSON with: recommended (beginner/intermediate/advanced), reasoning (string), confidenceScore (0-1), suggestedTopicFocus (string describing what area to focus on next)." },
              { role: "user", content: answerSummary }
            ],
            response_format: { type: "json_object" }
          }).then(r => {
            try { return JSON.parse(r.choices[0].message.content); } catch { return null; }
          }).catch(() => null)
        ]);

        // Consensus: if both agree, use that; otherwise use the more conservative option
        const difficultyOrder = ["beginner", "intermediate", "advanced"];
        const openaiRec = openaiResult?.recommended ?? input.currentDifficulty;
        const grokRec = grokResult?.recommended ?? input.currentDifficulty;

        let finalRecommendation: string;
        if (openaiRec === grokRec) {
          finalRecommendation = openaiRec;
        } else {
          // Use the more conservative (lower difficulty) when they disagree
          const openaiIdx = difficultyOrder.indexOf(openaiRec);
          const grokIdx = difficultyOrder.indexOf(grokRec);
          finalRecommendation = difficultyOrder[Math.min(openaiIdx >= 0 ? openaiIdx : 1, grokIdx >= 0 ? grokIdx : 1)];
        }

        return {
          recommended: finalRecommendation,
          reasoning: openaiResult?.reasoning ?? grokResult?.reasoning ?? "Based on performance analysis",
          confidenceScore: grokResult?.confidenceScore ?? 0.7,
          suggestedTopicFocus: grokResult?.suggestedTopicFocus ?? null,
          consensus: openaiRec === grokRec,
          dualAI: { openai: openaiRec, grok: grokRec },
        };
      }),
  }),
  // ─── Personality Assessment & Structural Needs ─────────────────────────────────
  // ─── Agentic Memory Bus (Altar-style) ──────────────────────────────────────────
  memory: router({
    store: protectedProcedure
      .input(z.object({
        source: z.enum(["wealth_genome", "drbuddy", "calibration", "manual"]),
        type: z.enum(["insight", "pattern", "anchor", "clinical", "resonance"]),
        title: z.string(),
        content: z.string(),
        dimensions: z.array(z.string()).optional(),
        sheldrakeMapping: z.string().optional(),
        sessionId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { storeMemory } = await import("./agenticMemory");
        return storeMemory({ userId: ctx.user.openId, ...input });
      }),

    getResonant: protectedProcedure
      .input(z.object({
        dimensions: z.array(z.string()).optional(),
        limit: z.number().optional(),
        source: z.string().optional(),
      }))
      .query(async ({ ctx, input }) => {
        const { getResonantMemories } = await import("./agenticMemory");
        return getResonantMemories(ctx.user.openId, { dimensions: input.dimensions, limit: input.limit, source: input.source });
      }),

    synthesize: protectedProcedure
      .mutation(async ({ ctx }) => {
        const { synthesizePatterns } = await import("./agenticMemory");
        return synthesizePatterns(ctx.user.openId);
      }),

    bridgeDrBuddy: protectedProcedure
      .input(z.object({
        sessionSummary: z.string(),
        clinicalInsights: z.array(z.string()),
        riskLevel: z.string(),
        techniques: z.array(z.string()),
      }))
      .mutation(async ({ ctx, input }) => {
        const { bridgeDrBuddyToMemory } = await import("./agenticMemory");
        return bridgeDrBuddyToMemory({ userId: ctx.user.openId, ...input });
      }),

    bridgeGenome: protectedProcedure
      .input(z.object({
        genomeScores: z.record(z.string(), z.number()),
        sessionNumber: z.number(),
        keyAnswers: z.array(z.object({
          question: z.string(),
          answer: z.string(),
          dimension: z.string(),
        })),
      }))
      .mutation(async ({ ctx, input }) => {
        const { bridgeGenomeToDrBuddy } = await import("./agenticMemory");
        return bridgeGenomeToDrBuddy({ userId: ctx.user.openId, ...input });
      }),

    getEnrichment: protectedProcedure
      .input(z.object({
        sessionNumber: z.number(),
        currentDimension: z.string(),
      }))
      .query(async ({ ctx, input }) => {
        const { getSessionEnrichment } = await import("./agenticMemory");
        return getSessionEnrichment(ctx.user.openId, input.sessionNumber, input.currentDimension);
      }),

    // ─── Mem0 Bus Core (X30 Standing Order — ALL memory routes through Mem0Bus) ──
    addToMem0: protectedProcedure
      .input(z.object({
        messages: z.array(z.object({
          role: z.enum(["user", "assistant", "system"]),
          content: z.string(),
        })),
        project: z.enum(["root", "dr_buddy", "russell_capital", "church", "weight_loss", "edu_genius", "med_freedom", "genome"]).default("root"),
        metadata: z.record(z.string(), z.unknown()).optional(),
      }))
      .mutation(async ({ input }) => {
        const { Mem0Bus } = await import("./mem0");
        const bus = Mem0Bus.getInstance();
        return bus.add(input.messages, input.project, input.metadata as Record<string, unknown> | undefined);
      }),

    searchMem0: protectedProcedure
      .input(z.object({
        query: z.string(),
        project: z.enum(["root", "dr_buddy", "russell_capital", "church", "weight_loss", "edu_genius", "med_freedom", "genome"]).default("root"),
        limit: z.number().default(10),
      }))
      .query(async ({ input }) => {
        const { Mem0Bus } = await import("./mem0");
        const bus = Mem0Bus.getInstance();
        return bus.search(input.query, input.project, input.limit);
      }),

    crossSearch: protectedProcedure
      .input(z.object({
        query: z.string(),
        limit: z.number().default(5),
      }))
      .query(async ({ input }) => {
        const { Mem0Bus } = await import("./mem0");
        const bus = Mem0Bus.getInstance();
        return bus.crossSearch(input.query, input.limit);
      }),

    storeGenomeToMem0: protectedProcedure
      .input(z.object({
        dimensions: z.record(z.string(), z.number()),
        sessionNumber: z.number(),
        totalScore: z.number(),
      }))
      .mutation(async ({ input }) => {
        const { Mem0Bus } = await import("./mem0");
        const bus = Mem0Bus.getInstance();
        return bus.storeGenomeScore(input.dimensions, input.sessionNumber, input.totalScore);
      }),

    storeDrBuddyToMem0: protectedProcedure
      .input(z.object({
        insight: z.string(),
        sessionId: z.string().optional(),
        riskLevel: z.string().optional(),
        techniques: z.array(z.string()).optional(),
      }))
      .mutation(async ({ input }) => {
        const { Mem0Bus } = await import("./mem0");
        const bus = Mem0Bus.getInstance();
        return bus.storeDrBuddyInsight(input.insight, {
          sessionId: input.sessionId,
          riskLevel: input.riskLevel,
          techniques: input.techniques,
        });
      }),

    storeMorphicAnchor: protectedProcedure
      .input(z.object({
        anchor: z.string(),
        resonanceType: z.enum(["ancestral", "theological", "consciousness", "intention"]),
      }))
      .mutation(async ({ input }) => {
        const { Mem0Bus } = await import("./mem0");
        const bus = Mem0Bus.getInstance();
        return bus.storeMorphicAnchor(input.anchor, input.resonanceType);
      }),

    // ─── Session-End Auto-Persist (Standing Order: every session end persists) ──
    endDrBuddySession: protectedProcedure
      .input(z.object({
        sessionSummary: z.string(),
        insights: z.array(z.string()),
        riskLevel: z.string(),
        techniques: z.array(z.string()),
      }))
      .mutation(async ({ input }) => {
        const { Mem0Bus } = await import("./mem0");
        const bus = Mem0Bus.getInstance();
        return bus.endDrBuddySession(input.sessionSummary, input.insights, input.riskLevel, input.techniques);
      }),

    endGenomeSession: protectedProcedure
      .input(z.object({
        sessionNumber: z.number(),
        dimensions: z.record(z.string(), z.number()),
        totalScore: z.number(),
        patterns: z.array(z.string()).optional(),
      }))
      .mutation(async ({ input }) => {
        const { Mem0Bus } = await import("./mem0");
        const bus = Mem0Bus.getInstance();
        return bus.endGenomeSession(input.sessionNumber, input.dimensions, input.totalScore, input.patterns);
      }),

    endMedFreedomSession: protectedProcedure
      .input(z.object({
        summary: z.string(),
        medicationsDiscussed: z.array(z.string()),
        decisions: z.array(z.string()),
      }))
      .mutation(async ({ input }) => {
        const { Mem0Bus } = await import("./mem0");
        const bus = Mem0Bus.getInstance();
        return bus.endMedFreedomSession(input.summary, input.medicationsDiscussed, input.decisions);
      }),

    endSession: protectedProcedure
      .input(z.object({
        project: z.enum(["root", "dr_buddy", "russell_capital", "church", "weight_loss", "edu_genius", "med_freedom", "genome"]),
        summary: z.string(),
        keyDecisions: z.array(z.string()).optional(),
      }))
      .mutation(async ({ input }) => {
        const { Mem0Bus } = await import("./mem0");
        const bus = Mem0Bus.getInstance();
        return bus.endSession(input.project, input.summary, input.keyDecisions);
      }),
  }),
  // ─── Client Leads (Email Capture Before Sessions) ────────────────────────────
  leads: router({
    // Capture email before starting assessment sessions
    capture: publicProcedure
      .input(z.object({
        fullName: z.string().min(2),
        email: z.string().email(),
        phone: z.string().optional(),
        agreedToContact: z.boolean().default(false),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        // Check if lead already exists by email
        const existing = await db.select().from(clientLeads).where(eq(clientLeads.email, input.email)).limit(1);
        if (existing.length > 0) {
          // Update and return existing lead
          await db.update(clientLeads).set({ fullName: input.fullName, lastActiveAt: new Date(), userId: ctx.user?.id ?? existing[0].userId }).where(eq(clientLeads.id, existing[0].id));
          return { leadId: existing[0].id, isReturning: true, currentSession: existing[0].currentSession, sessionsCompleted: existing[0].sessionsCompleted || [] };
        }
        const [result] = await db.insert(clientLeads).values({
          userId: ctx.user?.id ?? null,
          fullName: input.fullName,
          email: input.email,
          phone: input.phone || null,
          agreedToContact: input.agreedToContact,
          lastActiveAt: new Date(),
        });
        return { leadId: result.insertId, isReturning: false, currentSession: 0, sessionsCompleted: [] };
      }),

    // Update session progress
    updateProgress: publicProcedure
      .input(z.object({
        leadId: z.number(),
        currentSession: z.number().min(1).max(4),
        completed: z.boolean().default(false),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const lead = await db.select().from(clientLeads).where(eq(clientLeads.id, input.leadId)).limit(1);
        if (!lead.length) throw new TRPCError({ code: "NOT_FOUND" });
        const sessionsCompleted = (lead[0].sessionsCompleted || []) as number[];
        if (input.completed && !sessionsCompleted.includes(input.currentSession)) {
          sessionsCompleted.push(input.currentSession);
        }
        await db.update(clientLeads).set({
          currentSession: input.currentSession,
          sessionsCompleted,
          lastActiveAt: new Date(),
        }).where(eq(clientLeads.id, input.leadId));
        return { success: true, sessionsCompleted };
      }),

    // Get lead by email (for resume)
    getByEmail: publicProcedure
      .input(z.object({ email: z.string().email() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const lead = await db.select().from(clientLeads).where(eq(clientLeads.email, input.email)).limit(1);
        if (!lead.length) return null;
        return lead[0];
      }),
  }),

  personality: router({
    // Start or resume a personality assessment
    startOrResume: protectedProcedure.mutation(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      // Check for existing incomplete profile
      const existing = await db.select().from(personalityProfiles).where(eq(personalityProfiles.userId, ctx.user.id)).orderBy(desc(personalityProfiles.createdAt)).limit(1);
      if (existing.length > 0 && !existing[0].completedAt) {
        const responses = await db.select().from(personalityResponses).where(eq(personalityResponses.profileId, existing[0].id)).limit(1);
        return { profileId: existing[0].id, lastQuestionIndex: responses[0]?.lastQuestionIndex || 0, isResume: true };
      }
      // Create new profile
      const [result] = await db.insert(personalityProfiles).values({ userId: ctx.user.id });
      const profileId = result.insertId;
      await db.insert(personalityResponses).values({ userId: ctx.user.id, profileId, responses: [] });
      return { profileId, lastQuestionIndex: 0, isResume: false };
    }),

    // Save progress (batch of responses)
    saveProgress: protectedProcedure
      .input(z.object({
        profileId: z.number(),
        responses: z.array(z.object({
          questionId: z.number(),
          choiceLabel: z.string(),
          score: z.number(),
          dimension: z.string(),
          subdimension: z.string(),
          answeredAt: z.number(),
        })),
        lastQuestionIndex: z.number(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        await db.update(personalityResponses)
          .set({ responses: input.responses, lastQuestionIndex: input.lastQuestionIndex })
          .where(and(eq(personalityResponses.profileId, input.profileId), eq(personalityResponses.userId, ctx.user.id)));
        return { saved: true, lastQuestionIndex: input.lastQuestionIndex };
      }),

    // Complete assessment — score, calibrate, generate narratives
    complete: protectedProcedure
      .input(z.object({
        profileId: z.number(),
        responses: z.array(z.object({
          questionId: z.number(),
          choiceLabel: z.string(),
          score: z.number(),
          dimension: z.string(),
          subdimension: z.string(),
          answeredAt: z.number(),
        })),
        diagnoses: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

        // Score Big Five (sum per dimension, 10 questions each, max 40)
        const dims: Record<string, number[]> = {};
        for (const r of input.responses) {
          if (!dims[r.dimension]) dims[r.dimension] = [];
          dims[r.dimension].push(r.score);
        }
        const sum = (arr: number[]) => arr.reduce((a, b) => a + b, 0);
        const avg = (arr: number[]) => arr.length ? sum(arr) / arr.length : 0;

        const openness = sum(dims["openness"] || []);
        const conscientiousness = sum(dims["conscientiousness"] || []);
        const extraversion = sum(dims["extraversion"] || []);
        const agreeableness = sum(dims["agreeableness"] || []);
        const neuroticism = sum(dims["neuroticism"] || []);
        const cognitiveAnalytical = sum(dims["cognitive_style"] || []);
        const cognitiveDetail = sum((dims["cognitive_style"] || []).filter((_, i) => i >= 2));
        const commDirect = sum((dims["communication_style"] || []).filter((_, i) => i === 0 || i === 3));
        const commWritten = (dims["communication_style"] || [])[1] || 0;
        const commEmotional = (dims["communication_style"] || [])[2] || 0;

        // Score structural needs (average of 4 questions per need, scale 1-10)
        const needDims: Record<string, number[]> = {};
        for (const r of input.responses) {
          if (r.dimension === "structural_needs") {
            if (!needDims[r.subdimension]) needDims[r.subdimension] = [];
            needDims[r.subdimension].push(r.score);
          }
        }
        const needMap: Record<string, string> = {
          social_interaction_need: "needSocialInteraction",
          solitude_alone_time_need: "needSolitude",
          novelty_new_experiences_need: "needNovelty",
          routine_predictability_need: "needRoutine",
          sensory_stimulation_need: "needSensoryStimulation",
          emotional_security_need: "needEmotionalSecurity",
          autonomy_independence_need: "needAutonomy",
          connection_belonging_need: "needConnection",
          achievement_mastery_need: "needAchievement",
          creative_expression_need: "needCreativeExpression",
        };
        const needScores: Record<string, number> = {};
        for (const [sub, col] of Object.entries(needMap)) {
          needScores[col] = Math.round(avg(needDims[sub] || []) * 10) / 10;
        }

        // Mental health calibration
        const diagnoses = input.diagnoses || [];
        const calibrated: Record<string, number> = { ...needScores };
        if (diagnoses.some(d => d.toLowerCase().includes("depress"))) {
          calibrated.needSocialInteraction = Math.min(10, (calibrated.needSocialInteraction || 5) + 2);
          calibrated.needAchievement = Math.min(10, (calibrated.needAchievement || 5) + 1.5);
          calibrated.needConnection = Math.min(10, (calibrated.needConnection || 5) + 2);
        }
        if (diagnoses.some(d => d.toLowerCase().includes("anxi"))) {
          calibrated.needEmotionalSecurity = Math.min(10, (calibrated.needEmotionalSecurity || 5) + 2);
          calibrated.needRoutine = Math.min(10, (calibrated.needRoutine || 5) + 1.5);
          calibrated.needSocialInteraction = Math.min(10, (calibrated.needSocialInteraction || 5) + 1);
        }
        if (diagnoses.some(d => d.toLowerCase().includes("ptsd"))) {
          calibrated.needEmotionalSecurity = Math.min(10, (calibrated.needEmotionalSecurity || 5) + 3);
          calibrated.needAutonomy = Math.min(10, (calibrated.needAutonomy || 5) + 2);
        }
        if (diagnoses.some(d => d.toLowerCase().includes("adhd"))) {
          calibrated.needNovelty = Math.min(10, (calibrated.needNovelty || 5) + 2);
          calibrated.needSensoryStimulation = Math.min(10, (calibrated.needSensoryStimulation || 5) + 2);
          calibrated.needAchievement = Math.min(10, (calibrated.needAchievement || 5) + 1.5);
        }
        if (diagnoses.some(d => d.toLowerCase().includes("bipolar"))) {
          calibrated.needRoutine = Math.min(10, (calibrated.needRoutine || 5) + 2);
          calibrated.needAutonomy = Math.min(10, (calibrated.needAutonomy || 5) + 1);
        }

        // Generate dual narratives + needs prescription + activity profiles via LLM
        const narrativePrompt = `You are a clinical psychologist, narrative therapist, and wellness architect. Generate a comprehensive personality profile with dual life narratives, a needs prescription, and activity profiles.

PERSONALITY SCORES (0-40 scale):
Openness: ${openness}, Conscientiousness: ${conscientiousness}, Extraversion: ${extraversion}, Agreeableness: ${agreeableness}, Neuroticism: ${neuroticism}
Cognitive Style: Analytical=${cognitiveAnalytical}, Detail=${cognitiveDetail}
Communication: Direct=${commDirect}, Written=${commWritten}, Emotional=${commEmotional}

STRUCTURAL NEEDS (1-10 scale, calibrated for mental health):
Social Interaction: ${calibrated.needSocialInteraction || 5}, Solitude: ${calibrated.needSolitude || 5}, Novelty: ${calibrated.needNovelty || 5}, Routine: ${calibrated.needRoutine || 5}, Sensory Stimulation: ${calibrated.needSensoryStimulation || 5}, Emotional Security: ${calibrated.needEmotionalSecurity || 5}, Autonomy: ${calibrated.needAutonomy || 5}, Connection: ${calibrated.needConnection || 5}, Achievement: ${calibrated.needAchievement || 5}, Creative Expression: ${calibrated.needCreativeExpression || 5}

MENTAL HEALTH: ${diagnoses.length > 0 ? diagnoses.join(", ") : "None reported"}

Generate ALL of the following, tailored precisely to THIS personality profile:

1. DUAL NARRATIVES: "storyTrueSelf" (1-page, second person, who they are without mental health challenges) and "storyCurrentJourney" (1-page, second person, how challenges shape their experience).

2. INTERPRETATION: "interpretationNarrative" (2-paragraph personality summary).

3. NEEDS GAP ANALYSIS: For each of the 10 structural needs, estimate current fulfillment (1-10) and calculate the gap.

4. TRANSFORMATION ROADMAP: 5 stages from current state to flourishing, each with 2-3 goals.

5. NEEDS PRESCRIPTION: Precise daily/weekly recommendations for:
  - Physical: exercise type suited to personality, duration in minutes, frequency per week, best time of day, 3-5 specific activities
  - Emotional: daily minutes of emotional connection, weekly hours, connection type (1-on-1 vs group), expression methods, support structures
  - Psychological: recommended therapy type, daily practices (journaling style, mindfulness type), daily minutes, weekly hours
  - Financial: budgeting style for personality, stress management approach, weekly review minutes, key practices
  - Family Support: weekly hours needed, communication style, boundary type, quality time activities, support needs
  - Daily Schedule: recommended wake/sleep times, time blocks with activity, duration, and category
  - Weekly Schedule: 7 days with focus area and key activities

6. HEALTHY ACTIVITIES: 10-15 specific activities that ENERGIZE this personality type. Each with category, frequency, duration, energy impact (+1 to +10), and a personality-specific explanation of why it matters.

7. DRAINING ACTIVITIES: 10-15 specific activities/events that DEPLETE this personality type. Each with category, frequency they likely encounter it, duration of impact, energy drain (-1 to -10), and why it's particularly draining for their personality.

Be extremely specific and predictive. For example, don't say "exercise" — say "30-minute morning trail walks 4x/week" for a high-openness introvert, or "45-minute group HIIT classes 3x/week" for a high-extraversion achiever. Tailor EVERYTHING to the actual scores.`;

        const llmResponse = await invokeLLM({
          messages: [{ role: "user", content: narrativePrompt }],
          response_format: { type: "json_schema", json_schema: { name: "personality_full", strict: true, schema: {
            type: "object",
            properties: {
              storyTrueSelf: { type: "string" },
              storyCurrentJourney: { type: "string" },
              interpretationNarrative: { type: "string" },
              needsGapAnalysis: { type: "array", items: { type: "object", properties: { need: { type: "string" }, needLabel: { type: "string" }, rawScore: { type: "number" }, calibratedScore: { type: "number" }, currentFulfillment: { type: "number" }, gap: { type: "number" }, priority: { type: "string" }, recommendation: { type: "string" } }, required: ["need", "needLabel", "rawScore", "calibratedScore", "currentFulfillment", "gap", "priority", "recommendation"], additionalProperties: false } },
              transformationRoadmap: { type: "array", items: { type: "object", properties: { stage: { type: "number" }, title: { type: "string" }, timeframe: { type: "string" }, description: { type: "string" }, goals: { type: "array", items: { type: "object", properties: { goal: { type: "string" }, measurable: { type: "string" }, indicator: { type: "string" } }, required: ["goal", "measurable", "indicator"], additionalProperties: false } }, emotionalExperiences: { type: "array", items: { type: "string" } }, progressIndicators: { type: "array", items: { type: "string" } }, potentialSetbacks: { type: "array", items: { type: "string" } }, setbackHandling: { type: "string" }, personalityAdaptation: { type: "string" }, needsAlignment: { type: "string" }, status: { type: "string" } }, required: ["stage", "title", "timeframe", "description", "goals", "emotionalExperiences", "progressIndicators", "potentialSetbacks", "setbackHandling", "personalityAdaptation", "needsAlignment", "status"], additionalProperties: false } },
              needsPrescription: { type: "object", properties: {
                physical: { type: "object", properties: { exerciseType: { type: "string" }, durationMinutes: { type: "number" }, frequencyPerWeek: { type: "number" }, bestTimeOfDay: { type: "string" }, specificActivities: { type: "array", items: { type: "string" } } }, required: ["exerciseType", "durationMinutes", "frequencyPerWeek", "bestTimeOfDay", "specificActivities"], additionalProperties: false },
                emotional: { type: "object", properties: { dailyMinutes: { type: "number" }, weeklyHours: { type: "number" }, connectionType: { type: "string" }, expressionMethods: { type: "array", items: { type: "string" } }, supportStructures: { type: "array", items: { type: "string" } } }, required: ["dailyMinutes", "weeklyHours", "connectionType", "expressionMethods", "supportStructures"], additionalProperties: false },
                psychological: { type: "object", properties: { therapyType: { type: "string" }, dailyPractices: { type: "array", items: { type: "string" } }, dailyMinutes: { type: "number" }, weeklyHours: { type: "number" }, journalingStyle: { type: "string" }, mindfulnessType: { type: "string" } }, required: ["therapyType", "dailyPractices", "dailyMinutes", "weeklyHours", "journalingStyle", "mindfulnessType"], additionalProperties: false },
                financial: { type: "object", properties: { budgetingStyle: { type: "string" }, stressManagement: { type: "string" }, weeklyReviewMinutes: { type: "number" }, keyPractices: { type: "array", items: { type: "string" } } }, required: ["budgetingStyle", "stressManagement", "weeklyReviewMinutes", "keyPractices"], additionalProperties: false },
                familySupport: { type: "object", properties: { weeklyHours: { type: "number" }, communicationStyle: { type: "string" }, boundaryType: { type: "string" }, qualityTimeActivities: { type: "array", items: { type: "string" } }, supportNeeds: { type: "array", items: { type: "string" } } }, required: ["weeklyHours", "communicationStyle", "boundaryType", "qualityTimeActivities", "supportNeeds"], additionalProperties: false },
                dailySchedule: { type: "object", properties: { wakeTime: { type: "string" }, sleepTime: { type: "string" }, blocks: { type: "array", items: { type: "object", properties: { time: { type: "string" }, activity: { type: "string" }, duration: { type: "string" }, category: { type: "string" } }, required: ["time", "activity", "duration", "category"], additionalProperties: false } } }, required: ["wakeTime", "sleepTime", "blocks"], additionalProperties: false },
                weeklySchedule: { type: "array", items: { type: "object", properties: { day: { type: "string" }, focus: { type: "string" }, keyActivities: { type: "array", items: { type: "string" } } }, required: ["day", "focus", "keyActivities"], additionalProperties: false } }
              }, required: ["physical", "emotional", "psychological", "financial", "familySupport", "dailySchedule", "weeklySchedule"], additionalProperties: false },
              healthyActivities: { type: "array", items: { type: "object", properties: { activity: { type: "string" }, category: { type: "string" }, frequency: { type: "string" }, durationMinutes: { type: "number" }, energyImpact: { type: "number" }, whyItMatters: { type: "string" } }, required: ["activity", "category", "frequency", "durationMinutes", "energyImpact", "whyItMatters"], additionalProperties: false } },
              drainingActivities: { type: "array", items: { type: "object", properties: { activity: { type: "string" }, category: { type: "string" }, frequency: { type: "string" }, durationMinutes: { type: "number" }, energyImpact: { type: "number" }, whyItMatters: { type: "string" } }, required: ["activity", "category", "frequency", "durationMinutes", "energyImpact", "whyItMatters"], additionalProperties: false } },
            },
            required: ["storyTrueSelf", "storyCurrentJourney", "interpretationNarrative", "needsGapAnalysis", "transformationRoadmap", "needsPrescription", "healthyActivities", "drainingActivities"],
            additionalProperties: false,
          } } },
        });

        const narratives = JSON.parse(String(llmResponse.choices?.[0]?.message?.content || "{}"));

        // Update profile with all scores, narratives, prescription, and activities
        await db.update(personalityProfiles)
          .set({
            openness, conscientiousness, extraversion, agreeableness, neuroticism,
            cognitiveAnalytical, cognitiveDetail, commDirect, commWritten, commEmotional,
            needSocialInteraction: needScores.needSocialInteraction,
            needSolitude: needScores.needSolitude,
            needNovelty: needScores.needNovelty,
            needRoutine: needScores.needRoutine,
            needSensoryStimulation: needScores.needSensoryStimulation,
            needEmotionalSecurity: needScores.needEmotionalSecurity,
            needAutonomy: needScores.needAutonomy,
            needConnection: needScores.needConnection,
            needAchievement: needScores.needAchievement,
            needCreativeExpression: needScores.needCreativeExpression,
            calibratedNeeds: calibrated,
            needsGapAnalysis: narratives.needsGapAnalysis || [],
            storyTrueSelf: narratives.storyTrueSelf || "",
            storyCurrentJourney: narratives.storyCurrentJourney || "",
            transformationRoadmap: narratives.transformationRoadmap || [],
            interpretationNarrative: narratives.interpretationNarrative || "",
            needsPrescription: narratives.needsPrescription || null,
            healthyActivities: narratives.healthyActivities || [],
            drainingActivities: narratives.drainingActivities || [],
            primaryDiagnoses: diagnoses,
            completedAt: new Date(),
          })
          .where(eq(personalityProfiles.id, input.profileId));

        // Mark responses as complete
        await db.update(personalityResponses)
          .set({ responses: input.responses, isComplete: true, completedAt: new Date(), lastQuestionIndex: 100 })
          .where(and(eq(personalityResponses.profileId, input.profileId), eq(personalityResponses.userId, ctx.user.id)));

        return {
          profileId: input.profileId,
          scores: { openness, conscientiousness, extraversion, agreeableness, neuroticism },
          needs: needScores,
          calibratedNeeds: calibrated,
          storyTrueSelf: narratives.storyTrueSelf,
          storyCurrentJourney: narratives.storyCurrentJourney,
          interpretationNarrative: narratives.interpretationNarrative,
          needsGapAnalysis: narratives.needsGapAnalysis,
          transformationRoadmap: narratives.transformationRoadmap,
          needsPrescription: narratives.needsPrescription,
          healthyActivities: narratives.healthyActivities,
          drainingActivities: narratives.drainingActivities,
        };
      }),

    // Reality calibration — user rates actual behavior, system remodels profile
    realityCalibrate: protectedProcedure
      .input(z.object({
        profileId: z.number(),
        calibrations: z.array(z.object({
          activityId: z.string(),
          label: z.string(),
          category: z.string(),
          isHealthy: z.boolean(),
          currentLevel: z.number().min(1).max(10),
          idealLevel: z.number().min(1).max(10),
        })),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

        // Get existing profile
        const [profile] = await db.select().from(personalityProfiles).where(and(eq(personalityProfiles.id, input.profileId), eq(personalityProfiles.userId, ctx.user.id)));
        if (!profile) throw new TRPCError({ code: "NOT_FOUND" });

        // Calculate gaps
        const calibrationItems = input.calibrations.map(c => ({
          ...c,
          gap: c.idealLevel - c.currentLevel,
        }));

        // Calculate behavior alignment score (0-100%)
        const totalGap = calibrationItems.reduce((sum, c) => sum + Math.abs(c.gap), 0);
        const maxPossibleGap = calibrationItems.length * 9; // max gap per item is 9
        const behaviorAlignment = Math.round((1 - totalGap / maxPossibleGap) * 100);

        // Healthy activities they're NOT doing enough of
        const healthyDeficits = calibrationItems.filter(c => c.isHealthy && c.gap > 2);
        // Draining activities they're doing TOO MUCH of
        const drainingExcesses = calibrationItems.filter(c => !c.isHealthy && c.currentLevel > 5);

        // Remodel personality scores based on actual behavior
        // If they're not getting enough social interaction, their effective extraversion is lower
        const socialCalib = calibrationItems.filter(c => c.category === "social");
        const physicalCalib = calibrationItems.filter(c => c.category === "physical");
        const emotionalCalib = calibrationItems.filter(c => c.category === "emotional");
        const creativeCalib = calibrationItems.filter(c => c.category === "creative");

        const avgGap = (items: typeof calibrationItems) => items.length ? items.reduce((s, i) => s + i.gap, 0) / items.length : 0;

        const adjustedOpenness = Math.max(0, Math.min(40, (profile.openness || 20) + avgGap(creativeCalib) * 2));
        const adjustedConscientiousness = Math.max(0, Math.min(40, (profile.conscientiousness || 20) + avgGap(physicalCalib) * 1.5));
        const adjustedExtraversion = Math.max(0, Math.min(40, (profile.extraversion || 20) + avgGap(socialCalib) * 2));
        const adjustedAgreeableness = Math.max(0, Math.min(40, (profile.agreeableness || 20) + avgGap(emotionalCalib) * 1.5));
        const adjustedNeuroticism = Math.max(0, Math.min(40, (profile.neuroticism || 20) - avgGap(emotionalCalib) * 1.5));

        // Adjust needs based on reality
        const adjustedNeeds: Record<string, number> = { ...(profile.calibratedNeeds || {}) };
        for (const c of calibrationItems) {
          if (c.category === "social" && c.isHealthy) adjustedNeeds.needSocialInteraction = Math.min(10, (adjustedNeeds.needSocialInteraction || 5) + c.gap * 0.3);
          if (c.category === "creative" && c.isHealthy) adjustedNeeds.needCreativeExpression = Math.min(10, (adjustedNeeds.needCreativeExpression || 5) + c.gap * 0.3);
          if (c.category === "physical" && c.isHealthy) adjustedNeeds.needSensoryStimulation = Math.min(10, (adjustedNeeds.needSensoryStimulation || 5) + c.gap * 0.2);
        }

        // Generate remodeled narrative via LLM
        const remodelPrompt = `Based on a reality calibration of this person's actual behavior vs. their personality needs, generate insights.

ORIGINAL PERSONALITY: O=${profile.openness}, C=${profile.conscientiousness}, E=${profile.extraversion}, A=${profile.agreeableness}, N=${profile.neuroticism}
ADJUSTED (based on actual behavior): O=${adjustedOpenness.toFixed(1)}, C=${adjustedConscientiousness.toFixed(1)}, E=${adjustedExtraversion.toFixed(1)}, A=${adjustedAgreeableness.toFixed(1)}, N=${adjustedNeuroticism.toFixed(1)}
BEHAVIOR ALIGNMENT: ${behaviorAlignment}%

HEALTHY DEFICITS (things they need but aren't doing enough): ${healthyDeficits.map(h => `${h.label} (current: ${h.currentLevel}/10, ideal: ${h.idealLevel}/10)`).join(", ") || "None"}
DRAINING EXCESSES (things depleting them that they do too much): ${drainingExcesses.map(d => `${d.label} (current: ${d.currentLevel}/10)`).join(", ") || "None"}
DIAGNOSES: ${(profile.primaryDiagnoses || []).join(", ") || "None"}

Return JSON with:
- keyInsights: 3-5 key insights about the gap between who they are and how they're living
- priorityChanges: 3-5 specific changes ranked by impact, each with area, currentBehavior, idealBehavior, impact description, and difficulty (easy/moderate/hard)
- remodeledNarrative: 2-paragraph updated personality interpretation that accounts for their actual behavior patterns`;

        const remodelResponse = await invokeLLM({
          messages: [{ role: "user", content: remodelPrompt }],
          response_format: { type: "json_schema", json_schema: { name: "remodel", strict: true, schema: {
            type: "object",
            properties: {
              keyInsights: { type: "array", items: { type: "string" } },
              priorityChanges: { type: "array", items: { type: "object", properties: {
                area: { type: "string" }, currentBehavior: { type: "string" }, idealBehavior: { type: "string" }, impact: { type: "string" }, difficulty: { type: "string" }
              }, required: ["area", "currentBehavior", "idealBehavior", "impact", "difficulty"], additionalProperties: false } },
              remodeledNarrative: { type: "string" },
            },
            required: ["keyInsights", "priorityChanges", "remodeledNarrative"],
            additionalProperties: false,
          } } },
        });

        const remodelData = JSON.parse(String(remodelResponse.choices?.[0]?.message?.content || "{}"));

        const remodeledProfile = {
          adjustedOpenness,
          adjustedConscientiousness,
          adjustedExtraversion,
          adjustedAgreeableness,
          adjustedNeuroticism,
          adjustedNeeds,
          behaviorAlignment,
          keyInsights: remodelData.keyInsights || [],
          priorityChanges: (remodelData.priorityChanges || []).map((p: any) => ({ ...p, difficulty: p.difficulty as "easy" | "moderate" | "hard" })),
          remodeledNarrative: remodelData.remodeledNarrative || "",
        };

        // Save to DB
        await db.update(personalityProfiles)
          .set({ realityCalibration: calibrationItems, remodeledScores: remodeledProfile })
          .where(eq(personalityProfiles.id, input.profileId));

        return remodeledProfile;
      }),

    // Get completed profile
    getProfile: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const profiles = await db.select().from(personalityProfiles)
        .where(eq(personalityProfiles.userId, ctx.user.id))
        .orderBy(desc(personalityProfiles.createdAt))
        .limit(1);
      if (!profiles.length) return null;
      return profiles[0];
    }),

    // Get saved responses (for resume)
    getResponses: protectedProcedure
      .input(z.object({ profileId: z.number() }))
      .query(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const responses = await db.select().from(personalityResponses)
          .where(and(eq(personalityResponses.profileId, input.profileId), eq(personalityResponses.userId, ctx.user.id)))
          .limit(1);
        return responses[0] || null;
      }),
  }),

  // ─── MEDICATION FREEDOM ENGINE ─────────────────────────────────────────────
  medFreedom: router({
    // Analyze medications and generate tapering plan
    analyzeMedications: protectedProcedure
      .input(z.object({
        medications: z.array(z.object({
          name: z.string(),
          dosage: z.string(),
          frequency: z.string(),
          yearsOnMed: z.number(),
          reason: z.string(),
        })),
        conditions: z.array(z.string()),
        goals: z.string(),
        residentState: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

        const medList = input.medications.map(m => `${m.name} ${m.dosage} ${m.frequency} (${m.yearsOnMed}yr, for: ${m.reason})`).join("\n");

        const analysis = await invokeLLM({
          messages: [
            { role: "system", content: `You are a clinical pharmacology AI specializing in safe medication tapering and deprescribing. You have access to 24 million PubMed research papers. Your role is to analyze drug interactions, identify the safest tapering order, and create evidence-based plans.

CRITICAL DISCLAIMERS:
- This is NOT medical advice. All plans must be reviewed by a licensed physician.
- Never recommend abrupt discontinuation of any medication.
- Always prioritize patient safety over speed of tapering.
- Flag any medications that are dangerous to stop (benzodiazepines, opioids, anticonvulsants, beta-blockers, corticosteroids).

Respond in JSON matching this schema exactly:
{
  "interactionMatrix": [{ "drug1": string, "drug2": string, "severity": "critical"|"major"|"moderate"|"minor", "description": string, "pubmedIds": string[] }],
  "taperOrder": [{ "order": number, "medication": string, "rationale": string, "riskLevel": "low"|"medium"|"high", "interactionsRemoved": number, "benefitGained": string, "pubmedIds": string[] }],
  "taperSchedules": [{ "medication": string, "currentDose": string, "phases": [{ "week": number, "dose": string, "reductionPercent": number, "expectedSymptoms": string[], "monitoringRequired": string[] }], "totalWeeks": number, "withdrawalRisk": "low"|"medium"|"high", "pubmedIds": string[] }],
  "sideEffectTimeline": { "week1to2": string[], "week3to4": string[], "month2to3": string[], "month4to6": string[], "month7to12": string[] },
  "lifeProjections": {
    "threeMonths": { "improvements": string[], "risks": string[], "healthMetrics": { "metric": string, "currentRisk": string, "projectedRisk": string, "changePercent": number }[] },
    "sixMonths": { "improvements": string[], "risks": string[], "healthMetrics": { "metric": string, "currentRisk": string, "projectedRisk": string, "changePercent": number }[] },
    "oneYear": { "improvements": string[], "risks": string[], "healthMetrics": { "metric": string, "currentRisk": string, "projectedRisk": string, "changePercent": number }[] },
    "fiveYears": { "improvements": string[], "risks": string[], "healthMetrics": { "metric": string, "currentRisk": string, "projectedRisk": string, "changePercent": number }[] },
    "tenYears": { "improvements": string[], "risks": string[], "healthMetrics": { "metric": string, "currentRisk": string, "projectedRisk": string, "changePercent": number }[] },
    "fifteenYears": { "improvements": string[], "risks": string[], "healthMetrics": { "metric": string, "currentRisk": string, "projectedRisk": string, "changePercent": number }[] }
  },
  "riskReductions": [{ "condition": string, "currentRiskPercent": number, "projectedRiskPercent": number, "timeframe": string, "pubmedIds": string[] }],
  "pubmedCitations": [{ "pmid": string, "title": string, "authors": string, "journal": string, "year": number, "relevance": string, "url": string }],
  "physicianNotes": string,
  "criticalWarnings": string[],
  "overallSafetyScore": number
}` },
            { role: "user", content: `Patient medications:\n${medList}\n\nConditions: ${input.conditions.join(", ")}\nGoals: ${input.goals}\nState: ${input.residentState || "Not specified"}\n\nAnalyze all drug interactions, determine the safest order to remove medications (least interactions, most benefit first), create detailed tapering schedules, project life improvements at 3mo/6mo/1yr/5yr/10yr/15yr, and cite as many PubMed papers as relevant. If 500 papers are relevant, cite 500. If 1000, cite 1000. Be exhaustive with citations.` }
          ],
          response_format: { type: "json_schema", json_schema: { name: "medication_analysis", strict: true, schema: { type: "object", properties: { interactionMatrix: { type: "array", items: { type: "object", properties: { drug1: { type: "string" }, drug2: { type: "string" }, severity: { type: "string" }, description: { type: "string" }, pubmedIds: { type: "array", items: { type: "string" } } }, required: ["drug1", "drug2", "severity", "description", "pubmedIds"], additionalProperties: false } }, taperOrder: { type: "array", items: { type: "object", properties: { order: { type: "number" }, medication: { type: "string" }, rationale: { type: "string" }, riskLevel: { type: "string" }, interactionsRemoved: { type: "number" }, benefitGained: { type: "string" }, pubmedIds: { type: "array", items: { type: "string" } } }, required: ["order", "medication", "rationale", "riskLevel", "interactionsRemoved", "benefitGained", "pubmedIds"], additionalProperties: false } }, taperSchedules: { type: "array", items: { type: "object", properties: { medication: { type: "string" }, currentDose: { type: "string" }, phases: { type: "array", items: { type: "object", properties: { week: { type: "number" }, dose: { type: "string" }, reductionPercent: { type: "number" }, expectedSymptoms: { type: "array", items: { type: "string" } }, monitoringRequired: { type: "array", items: { type: "string" } } }, required: ["week", "dose", "reductionPercent", "expectedSymptoms", "monitoringRequired"], additionalProperties: false } }, totalWeeks: { type: "number" }, withdrawalRisk: { type: "string" }, pubmedIds: { type: "array", items: { type: "string" } } }, required: ["medication", "currentDose", "phases", "totalWeeks", "withdrawalRisk", "pubmedIds"], additionalProperties: false } }, sideEffectTimeline: { type: "object", properties: { week1to2: { type: "array", items: { type: "string" } }, week3to4: { type: "array", items: { type: "string" } }, month2to3: { type: "array", items: { type: "string" } }, month4to6: { type: "array", items: { type: "string" } }, month7to12: { type: "array", items: { type: "string" } } }, required: ["week1to2", "week3to4", "month2to3", "month4to6", "month7to12"], additionalProperties: false }, lifeProjections: { type: "object", properties: { threeMonths: { type: "object", properties: { improvements: { type: "array", items: { type: "string" } }, risks: { type: "array", items: { type: "string" } }, healthMetrics: { type: "array", items: { type: "object", properties: { metric: { type: "string" }, currentRisk: { type: "string" }, projectedRisk: { type: "string" }, changePercent: { type: "number" } }, required: ["metric", "currentRisk", "projectedRisk", "changePercent"], additionalProperties: false } } }, required: ["improvements", "risks", "healthMetrics"], additionalProperties: false }, sixMonths: { type: "object", properties: { improvements: { type: "array", items: { type: "string" } }, risks: { type: "array", items: { type: "string" } }, healthMetrics: { type: "array", items: { type: "object", properties: { metric: { type: "string" }, currentRisk: { type: "string" }, projectedRisk: { type: "string" }, changePercent: { type: "number" } }, required: ["metric", "currentRisk", "projectedRisk", "changePercent"], additionalProperties: false } } }, required: ["improvements", "risks", "healthMetrics"], additionalProperties: false }, oneYear: { type: "object", properties: { improvements: { type: "array", items: { type: "string" } }, risks: { type: "array", items: { type: "string" } }, healthMetrics: { type: "array", items: { type: "object", properties: { metric: { type: "string" }, currentRisk: { type: "string" }, projectedRisk: { type: "string" }, changePercent: { type: "number" } }, required: ["metric", "currentRisk", "projectedRisk", "changePercent"], additionalProperties: false } } }, required: ["improvements", "risks", "healthMetrics"], additionalProperties: false }, fiveYears: { type: "object", properties: { improvements: { type: "array", items: { type: "string" } }, risks: { type: "array", items: { type: "string" } }, healthMetrics: { type: "array", items: { type: "object", properties: { metric: { type: "string" }, currentRisk: { type: "string" }, projectedRisk: { type: "string" }, changePercent: { type: "number" } }, required: ["metric", "currentRisk", "projectedRisk", "changePercent"], additionalProperties: false } } }, required: ["improvements", "risks", "healthMetrics"], additionalProperties: false }, tenYears: { type: "object", properties: { improvements: { type: "array", items: { type: "string" } }, risks: { type: "array", items: { type: "string" } }, healthMetrics: { type: "array", items: { type: "object", properties: { metric: { type: "string" }, currentRisk: { type: "string" }, projectedRisk: { type: "string" }, changePercent: { type: "number" } }, required: ["metric", "currentRisk", "projectedRisk", "changePercent"], additionalProperties: false } } }, required: ["improvements", "risks", "healthMetrics"], additionalProperties: false }, fifteenYears: { type: "object", properties: { improvements: { type: "array", items: { type: "string" } }, risks: { type: "array", items: { type: "string" } }, healthMetrics: { type: "array", items: { type: "object", properties: { metric: { type: "string" }, currentRisk: { type: "string" }, projectedRisk: { type: "string" }, changePercent: { type: "number" } }, required: ["metric", "currentRisk", "projectedRisk", "changePercent"], additionalProperties: false } } }, required: ["improvements", "risks", "healthMetrics"], additionalProperties: false } }, required: ["threeMonths", "sixMonths", "oneYear", "fiveYears", "tenYears", "fifteenYears"], additionalProperties: false }, riskReductions: { type: "array", items: { type: "object", properties: { condition: { type: "string" }, currentRiskPercent: { type: "number" }, projectedRiskPercent: { type: "number" }, timeframe: { type: "string" }, pubmedIds: { type: "array", items: { type: "string" } } }, required: ["condition", "currentRiskPercent", "projectedRiskPercent", "timeframe", "pubmedIds"], additionalProperties: false } }, pubmedCitations: { type: "array", items: { type: "object", properties: { pmid: { type: "string" }, title: { type: "string" }, authors: { type: "string" }, journal: { type: "string" }, year: { type: "number" }, relevance: { type: "string" }, url: { type: "string" } }, required: ["pmid", "title", "authors", "journal", "year", "relevance", "url"], additionalProperties: false } }, physicianNotes: { type: "string" }, criticalWarnings: { type: "array", items: { type: "string" } }, overallSafetyScore: { type: "number" } }, required: ["interactionMatrix", "taperOrder", "taperSchedules", "sideEffectTimeline", "lifeProjections", "riskReductions", "pubmedCitations", "physicianNotes", "criticalWarnings", "overallSafetyScore"], additionalProperties: false } } },
        });

        const parsed = JSON.parse(String(analysis.choices[0].message.content) || "{}");

        // Save to DB — map LLM output to the typed schema interfaces
        const taperMeds: import("../drizzle/schema").TaperMedication[] = input.medications.map((m, idx) => ({
          id: `med-${idx}`,
          name: m.name,
          genericName: m.name,
          category: "Unknown",
          dosage: m.dosage,
          frequency: m.frequency,
          prescribedFor: m.reason,
          startedDate: "",
          yearsOnMedication: m.yearsOnMed,
          dependenceRisk: 0,
          withdrawalSeverity: 0,
          interactionCount: (parsed.interactionMatrix || []).filter((i: any) => i.drug1 === m.name || i.drug2 === m.name).length,
          benefitScore: 0,
          removalPriority: (parsed.taperOrder || []).findIndex((t: any) => t.medication === m.name) + 1,
          taperDurationWeeks: (parsed.taperSchedules || []).find((s: any) => s.medication === m.name)?.totalWeeks || 0,
          taperMethod: "gradual",
        }));

        const drugInteractions: import("../drizzle/schema").DrugInteraction[] = (parsed.interactionMatrix || []).map((i: any) => ({
          drug1: i.drug1,
          drug2: i.drug2,
          severity: i.severity === "critical" ? 5 : i.severity === "major" ? 4 : i.severity === "moderate" ? 3 : i.severity === "minor" ? 2 : 1 as 1|2|3|4|5,
          severityLabel: i.severity,
          description: i.description,
          clinicalEffect: i.description,
          recommendation: (i.pubmedIds || []).join(", "),
          pubmedIds: i.pubmedIds || [],
        }));

        const projTimeframes = ["threeMonths", "sixMonths", "oneYear", "fiveYears", "tenYears", "fifteenYears"];
        const projLabels = ["3 months", "6 months", "1 year", "5 years", "10 years", "15 years"];
        const projMonths = [3, 6, 12, 60, 120, 180];
        const healthProj: import("../drizzle/schema").HealthProjection = {
          timeframes: projTimeframes.map((key, idx) => ({
            label: projLabels[idx],
            months: projMonths[idx],
            metrics: ((parsed.lifeProjections as any)?.[key]?.healthMetrics || []).map((hm: any) => ({
              name: hm.metric,
              currentRisk: hm.currentRisk,
              projectedRisk: hm.projectedRisk,
              improvementPercent: hm.changePercent || 0,
              description: `${hm.metric}: ${hm.currentRisk} → ${hm.projectedRisk}`,
            })),
          })),
          qualityOfLifeScore: { current: 50, projected3mo: 60, projected1yr: 70, projected5yr: 80, projected10yr: 85, projected15yr: 90 },
        };
        // Store extra data (schedules, citations, warnings, side effects) in healthProjections as extended fields
        (healthProj as any)._taperSchedules = parsed.taperSchedules;
        (healthProj as any)._pubmedCitations = parsed.pubmedCitations;
        (healthProj as any)._criticalWarnings = parsed.criticalWarnings;
        (healthProj as any)._sideEffectTimeline = parsed.sideEffectTimeline;
        (healthProj as any)._riskReductions = parsed.riskReductions;

        const [plan] = await db.insert(taperPlans).values({
          userId: ctx.user.id,
          currentMedications: taperMeds,
          removalOrder: parsed.taperOrder.map((t: any) => t.medication),
          interactions: drugInteractions,
          interactionSeverityScore: parsed.overallSafetyScore,
          healthProjections: healthProj,
          physicianReport: {
            generatedAt: "",
            patientSummary: parsed.physicianNotes || "",
            currentMedicationAnalysis: "",
            interactionAnalysis: "",
            proposedTaperProtocol: "",
            riskAssessment: "",
            monitoringPlan: "",
            citations: (parsed.pubmedCitations || []).map((c: any) => ({ ...c, relevanceScore: 80, year: String(c.year) })),
            totalCitationCount: (parsed.pubmedCitations || []).length,
            sections: [],
          },
          estimatedDurationWeeks: (parsed.taperSchedules || []).reduce((sum: number, s: any) => sum + (s.totalWeeks || 0), 0),
          notes: `Goals: ${input.goals}\nConditions: ${input.conditions.join(", ")}`,
          status: "draft",
        });

        return { id: plan.insertId, ...parsed };
      }),

    // Get user's tapering plans
    getPlans: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const plans = await db.select().from(taperPlans)
        .where(eq(taperPlans.userId, ctx.user.id))
        .orderBy(desc(taperPlans.createdAt));
      return plans;
    }),

    // Get single plan detail
    getPlan: protectedProcedure
      .input(z.object({ planId: z.number() }))
      .query(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const [plan] = await db.select().from(taperPlans)
          .where(and(eq(taperPlans.id, input.planId), eq(taperPlans.userId, ctx.user.id)));
        if (!plan) throw new TRPCError({ code: "NOT_FOUND" });
        return plan;
      }),

    // Generate physician report with exhaustive PubMed citations
    generatePhysicianReport: protectedProcedure
      .input(z.object({ planId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const [plan] = await db.select().from(taperPlans)
          .where(and(eq(taperPlans.id, input.planId), eq(taperPlans.userId, ctx.user.id)));
        if (!plan) throw new TRPCError({ code: "NOT_FOUND" });

        const meds = plan.currentMedications || [];
        const projections = plan.healthProjections as any || {};
        const citations = projections.pubmedCitations || [];
        const schedules = projections.taperSchedules || [];
        const interactions = plan.interactions || [];

        const report = await invokeLLM({
          messages: [
            { role: "system", content: `You are generating a formal physician report for a patient's medication tapering plan. This report will be sent to the patient's doctor. Include EVERY relevant PubMed citation. If there are 500 relevant papers, cite all 500. Be exhaustive. The report must be professional, evidence-based, and formatted for a physician audience.

Format as a comprehensive medical report with:
1. Patient Summary
2. Current Medication Profile
3. Drug Interaction Analysis (with PubMed citations)
4. Proposed Tapering Protocol (with PubMed citations for each step)
5. Expected Side Effects & Monitoring Requirements
6. Risk-Benefit Analysis
7. Life Outcome Projections
8. Complete Bibliography (every PubMed citation)

Use markdown formatting. Cite papers as [PMID: XXXXX] inline.` },
            { role: "user", content: `Generate physician report for:\nMedications: ${JSON.stringify(meds)}\nInteractions: ${JSON.stringify(interactions)}\nTaper Schedules: ${JSON.stringify(schedules)}\nExisting Citations: ${JSON.stringify(citations)}\nPhysician Notes: ${(plan.physicianReport as any)?.notes || ""}` }
          ],
        });

        return { report: report.choices[0].message.content || "" };
      }),
    // ── Feature 10: Taper Milestone Notifications ──
    checkMilestones: protectedProcedure
      .mutation(async ({ ctx }) => {
        const mDb = await getDb();
        if (!mDb) throw new Error("Database unavailable");
        const activePlans = await mDb.select().from(taperPlans).where(and(eq(taperPlans.userId, ctx.user.id), eq(taperPlans.status, "active")));
        let notificationsSent = 0;
        const milestones: Array<{medication: string; week: number}> = [];
        for (const plan of activePlans) {
          const startDate = new Date(plan.createdAt);
          const diffDays = Math.floor((Date.now() - startDate.getTime()) / (1000 * 60 * 60 * 24));
          const currentWeek = Math.floor(diffDays / 7);
          const schedule = (plan.interactions || []) as Array<{week: number; dose: string; expectedSymptoms?: string; notified?: boolean}> & any[];
          let updated = false;
          for (const step of schedule) {
            if (step.week <= currentWeek && !step.notified) {
              const { notifyOwner } = await import("./_core/notification");
              await notifyOwner({ title: `🎯 Taper Milestone: Week ${step.week}`, content: `You've reached Week ${step.week} of your tapering plan. Expected: ${step.expectedSymptoms || "mild adjustments"}. Keep going!` });
              step.notified = true;
              updated = true;
              notificationsSent++;
              milestones.push({ medication: plan.currentMedications?.[0]?.name || "medication", week: step.week });
            }
          }
          if (updated) {
            await mDb.update(taperPlans).set({ interactions: schedule as any }).where(eq(taperPlans.id, plan.id));
          }
        }
        return { notificationsSent, milestones };
      }),
    // ── Feature 12: Share Diagnostic Report with Doctor Email ──
    emailToDoctor: protectedProcedure
      .input(z.object({
        planId: z.number(),
        doctorEmail: z.string(),
        doctorName: z.string(),
        patientMessage: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const eDb = await getDb();
        if (!eDb) throw new Error("Database unavailable");
        const [plan] = await eDb.select().from(taperPlans).where(and(eq(taperPlans.id, input.planId), eq(taperPlans.userId, ctx.user.id)));
        if (!plan) throw new Error("Plan not found");
        const citations = ((plan.physicianReport as any)?.citations || []) as Array<{pmid: string; title: string; url: string}>;
        const citationsBlock = citations.length > 0
          ? "\n\nPubMed References:\n" + citations.map((c, i) => `${i+1}. ${c.title} — https://pubmed.ncbi.nlm.nih.gov/${c.pmid}/`).join("\n")
          : "";
        const emailContent = `Dear Dr. ${input.doctorName},\n\nYour patient ${ctx.user.name || "a Russell Labs user"} has shared their Medication Freedom tapering plan with you.${input.patientMessage ? `\n\nPatient message: "${input.patientMessage}"` : ""}\n\nMedications: ${((plan.currentMedications || []) as any[]).map((m: any) => m.name).join(", ")}\nSeverity Score: ${plan.interactionSeverityScore || "N/A"}/100\nStatus: ${plan.status}${citationsBlock}\n\nThis report was generated by Russell Labs AI and is intended to support clinical decision-making. It does not replace professional medical judgment.`;
        const { notifyOwner } = await import("./_core/notification");
        const success = await notifyOwner({ title: `Medication Freedom Report — Shared with Dr. ${input.doctorName}`, content: emailContent });
        return { success };
      }),

    // ─── Medication Intelligence Systems (Patent Ideas 16-30) ────────────────
    cascadeRisk: protectedProcedure
      .input(z.object({ medications: z.array(z.string()).min(2), planId: z.number().optional() }))
      .mutation(async ({ ctx, input }) => {
        const { analyzeCascadeRisk } = await import("./medIntelligence");
        return analyzeCascadeRisk(ctx.user.id, input);
      }),

    chronotherapy: protectedProcedure
      .input(z.object({
        medications: z.array(z.object({ name: z.string(), currentTime: z.string() })),
        chronotype: z.enum(["early_bird", "night_owl", "intermediate"]),
        wakeTime: z.string(),
        sleepTime: z.string(),
        mealTimes: z.array(z.string()).optional(),
        activityPeaks: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { optimizeChronotherapy } = await import("./medIntelligence");
        return optimizeChronotherapy(ctx.user.id, input);
      }),

    withdrawalPredictor: protectedProcedure
      .input(z.object({
        medication: z.string(),
        currentDosage: z.string(),
        durationYears: z.number(),
        previousTaperAttempts: z.number().default(0),
        concurrentMedications: z.array(z.string()).default([]),
        planId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { predictWithdrawalSeverity } = await import("./medIntelligence");
        return predictWithdrawalSeverity(ctx.user.id, input);
      }),

    nutrientMatrix: protectedProcedure
      .input(z.object({ medications: z.array(z.string()).min(1) }))
      .mutation(async ({ ctx, input }) => {
        const { analyzeNutrientInteractions } = await import("./medIntelligence");
        return analyzeNutrientInteractions(ctx.user.id, input);
      }),

    adherencePrediction: protectedProcedure
      .input(z.object({ medicationNames: z.array(z.string()).optional() }))
      .mutation(async ({ ctx, input }) => {
        const { predictAdherence } = await import("./medIntelligence");
        return predictAdherence(ctx.user.id, input);
      }),

    reviewTriggers: protectedProcedure
      .input(z.object({
        medications: z.array(z.object({ name: z.string(), prescribedFor: z.string(), yearsOnMed: z.number() })),
        recentDiagnoses: z.array(z.string()).default([]),
        symptomRemissionMonths: z.number().default(0),
      }))
      .mutation(async ({ ctx, input }) => {
        const { checkReviewTriggers } = await import("./medIntelligence");
        return checkReviewTriggers(ctx.user.id, input);
      }),

    pharmacovigilance: protectedProcedure
      .input(z.object({
        medication: z.string(),
        reportedSymptoms: z.array(z.object({ symptom: z.string(), count: z.number() })).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { detectPharmacovigilanceSignals } = await import("./medIntelligence");
        return detectPharmacovigilanceSignals(ctx.user.id, input);
      }),

    costComparator: protectedProcedure
      .input(z.object({
        medication: z.string(),
        currentCostMonthly: z.number().optional(),
        insuranceType: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { compareCostEffectiveness } = await import("./medIntelligence");
        return compareCostEffectiveness(ctx.user.id, input);
      }),

    taperVelocity: protectedProcedure
      .input(z.object({
        planId: z.number(),
        medication: z.string(),
        week: z.number(),
        currentDose: z.string(),
        targetDose: z.string(),
        symptomScore: z.number().min(0).max(100),
        recentSymptoms: z.array(z.string()).default([]),
      }))
      .mutation(async ({ ctx, input }) => {
        const { adjustTaperVelocity } = await import("./medIntelligence");
        return adjustTaperVelocity(ctx.user.id, input);
      }),

    supplementInteractions: protectedProcedure
      .input(z.object({
        medications: z.array(z.string()),
        supplements: z.array(z.string()),
      }))
      .mutation(async ({ ctx, input }) => {
        const { analyzeSupplementInteractions } = await import("./medIntelligence");
        return analyzeSupplementInteractions(ctx.user.id, input);
      }),

    sideEffectAttribution: protectedProcedure
      .input(z.object({
        symptom: z.string(),
        symptomOnsetDate: z.string(),
        currentMedications: z.array(z.object({ name: z.string(), startDate: z.string(), lastDoseChange: z.string().optional() })),
        confounders: z.array(z.string()).default([]),
      }))
      .mutation(async ({ ctx, input }) => {
        const { attributeSideEffect } = await import("./medIntelligence");
        return attributeSideEffect(ctx.user.id, input);
      }),

    shortageAlerts: protectedProcedure
      .input(z.object({ medications: z.array(z.string()) }))
      .mutation(async ({ ctx, input }) => {
        const { checkShortageAlerts } = await import("./medIntelligence");
        return checkShortageAlerts(ctx.user.id, input);
      }),

    metabolizerInference: protectedProcedure
      .input(z.object({
        medicationHistory: z.array(z.object({
          medication: z.string(),
          standardDose: z.string(),
          doseRequired: z.string(),
          response: z.string(),
        })),
      }))
      .mutation(async ({ ctx, input }) => {
        const { inferMetabolizerStatus } = await import("./medIntelligence");
        return inferMetabolizerStatus(ctx.user.id, input);
      }),

    severityContext: protectedProcedure
      .input(z.object({
        drug1: z.string(),
        drug2: z.string(),
        patientFactors: z.object({
          age: z.number().optional(),
          renalFunction: z.string().optional(),
          hepaticFunction: z.string().optional(),
          weight: z.number().optional(),
          concurrentConditions: z.array(z.string()).default([]),
        }),
      }))
      .mutation(async ({ ctx, input }) => {
        const { contextualizeSeverity } = await import("./medIntelligence");
        return contextualizeSeverity(ctx.user.id, input);
      }),

    tdmSchedule: protectedProcedure
      .input(z.object({
        medications: z.array(z.object({ name: z.string(), dosage: z.string(), frequency: z.string() })),
        renalFunction: z.string().optional(),
        hepaticFunction: z.string().optional(),
        metabolizerStatus: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { generateTDMSchedule } = await import("./medIntelligence");
        return generateTDMSchedule(ctx.user.id, input);
      }),
  }),
  // ─── Mental Credit Score (MCS) ─────────────────────────────────────────────
  mcs: router({
    calculate: protectedProcedure
      .input(z.object({
        triggerSource: z.enum(["therapy_start", "therapy_end", "journal", "assessment", "checkin", "manual"]),
        referenceId: z.number().optional(),
        referenceType: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { calculateMCS, saveMentalCreditScore, getLatestMCS } = await import("./db");
        const { score, riskZone, breakdown } = await calculateMCS(ctx.user.id);
        const previous = await getLatestMCS(ctx.user.id);
        const delta = previous ? score - previous.score : 0;
        const id = await saveMentalCreditScore({
          userId: ctx.user.id,
          score,
          riskZone,
          breakdown,
          triggerSource: input.triggerSource,
          referenceId: input.referenceId ?? null,
          referenceType: input.referenceType ?? null,
          delta,
        });
        return { id, score, riskZone, breakdown, delta, previousScore: previous?.score ?? null };
      }),
    getScore: protectedProcedure.query(async ({ ctx }) => {
      const { getLatestMCS } = await import("./db");
      return await getLatestMCS(ctx.user.id);
    }),
    getHistory: protectedProcedure
      .input(z.object({ limit: z.number().min(1).max(100).default(30) }))
      .query(async ({ ctx, input }) => {
        const { getMCSHistory } = await import("./db");
        return await getMCSHistory(ctx.user.id, input.limit);
      }),
    recalculate: protectedProcedure.mutation(async ({ ctx }) => {
      const { calculateMCS } = await import("./db");
      const { score, riskZone, breakdown } = await calculateMCS(ctx.user.id);
      return { score, riskZone, breakdown };
    }),
  }),

  // --- Clinician Review Loop ---
  clinicianReview: router({
    getReports: protectedProcedure
      .input(z.object({ status: z.string().optional() }))
      .query(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
        const db = (await getDb())!;
        const { diagnosticReports, users } = await import("../drizzle/schema");
        const { eq, desc } = await import("drizzle-orm");
        let query = db.select({
          id: diagnosticReports.id,
          userId: diagnosticReports.userId,
          reviewStatus: diagnosticReports.reviewStatus,
          provisionalDiagnoses: diagnosticReports.provisionalDiagnoses,
          prsScore: diagnosticReports.prsScore,
          createdAt: diagnosticReports.createdAt,
          reviewedAt: diagnosticReports.reviewedAt,
          reviewNotes: diagnosticReports.reviewNotes,
        }).from(diagnosticReports).orderBy(desc(diagnosticReports.createdAt)).limit(50);
        const results = await query;
        return results;
      }),
    updateStatus: protectedProcedure
      .input(z.object({
        reportId: z.number(),
        status: z.enum(["under_review", "approved", "rejected", "requires_revision"]),
        notes: z.string().optional(),
        signature: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
        const db = (await getDb())!;
        const { diagnosticReports } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        await db.update(diagnosticReports).set({
          reviewStatus: input.status,
          reviewedBy: ctx.user.id,
          reviewedAt: new Date(),
          reviewNotes: input.notes || null,
          clinicianSignature: input.signature || null,
        }).where(eq(diagnosticReports.id, input.reportId));
        // Log the review action via audit middleware (already handled by tRPC middleware)
        return { success: true };
      }),
    getReportReviewStatus: protectedProcedure
      .input(z.object({ reportId: z.number() }))
      .query(async ({ ctx, input }) => {
        const db = (await getDb())!;
        const { diagnosticReports } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        const [report] = await db.select({
          reviewStatus: diagnosticReports.reviewStatus,
          reviewedAt: diagnosticReports.reviewedAt,
          reviewNotes: diagnosticReports.reviewNotes,
          clinicianSignature: diagnosticReports.clinicianSignature,
        }).from(diagnosticReports).where(eq(diagnosticReports.id, input.reportId)).limit(1);
        return report || null;
      }),
  }),

  // --- Compliance & Legal ---
  compliance: router({
    requestDeletion: protectedProcedure
      .input(z.object({ reason: z.string().min(1).max(1000) }))
      .mutation(async ({ ctx, input }) => {
        const { requestDeletion } = await import("./compliance/dataDeletion");
        return await requestDeletion(ctx.user.id, input.reason);
      }),
    getDeletionStatus: protectedProcedure.query(async ({ ctx }) => {
      const { getDeletionRequests } = await import("./compliance/dataDeletion");
      const all = await getDeletionRequests();
      return all.filter((r: any) => r.userId === ctx.user.id);
    }),
    cancelDeletion: protectedProcedure
      .input(z.object({ requestId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const { cancelDeletion } = await import("./compliance/dataDeletion");
        return await cancelDeletion(input.requestId, ctx.user.id, "User cancelled");
      }),
    // Admin-only: approve/execute deletion
    approveDeletion: protectedProcedure
      .input(z.object({ requestId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
        const { approveDeletion } = await import("./compliance/dataDeletion");
        return await approveDeletion(input.requestId, ctx.user.id);
      }),
    executeDeletion: protectedProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
        const { executeDeletion } = await import("./compliance/dataDeletion");
        return await executeDeletion(input.userId, ctx.user.id);
      }),
    getAllDeletionRequests: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
      const { getDeletionRequests } = await import("./compliance/dataDeletion");
      return await getDeletionRequests();
    }),
    // Breach reporting
    reportBreach: protectedProcedure
      .input(z.object({
        breachType: z.string(),
        description: z.string(),
        severity: z.enum(["low", "medium", "high", "critical"]),
        affectedUsers: z.array(z.number()),
        containmentActions: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
        const { reportBreach } = await import("./compliance/breachNotification");
        return await reportBreach({ ...input, reportedBy: ctx.user.id });
      }),
    getBreachHistory: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
      const { getBreachHistory } = await import("./compliance/breachNotification");
      return await getBreachHistory(50);
    }),
    resolveBreachIncident: protectedProcedure
      .input(z.object({ breachId: z.number(), notes: z.string() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
        const { resolveBreachIncident } = await import("./compliance/breachNotification");
        return await resolveBreachIncident(input.breachId, input.notes);
      }),
    // Audit logs
    getAuditLogs: protectedProcedure
      .input(z.object({ userId: z.number().optional(), limit: z.number().default(50) }))
      .query(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
        const { getAuditLogs } = await import("./compliance/auditLog");
        return await getAuditLogs({ userId: input.userId, limit: input.limit });
      }),

    // Dual-AI State-Aware Privacy Rights
    getStateRights: protectedProcedure
      .input(z.object({ state: z.string().min(2).max(50) }))
      .query(async ({ ctx, input }) => {
        // Run OpenAI and Grok in parallel for comprehensive state-specific privacy rights
        const [openaiResult, grokResult] = await Promise.all([
          generateStateRights(input.state),
          invokeGrokWithFallback({
            messages: [
              { role: "system", content: "You are a US privacy law expert. Provide state-specific privacy and health data rights for the given state. Return JSON with: state (string), keyLaws (array of {name, summary}), patientRights (array of strings), hipaaAdditions (array of strings), dataBreachNotice (string describing state breach notification requirements), mentalHealthSpecific (array of strings about mental health data protections)." },
              { role: "user", content: `State: ${input.state}` }
            ],
            response_format: { type: "json_object" }
          }).then(r => {
            try { return JSON.parse(r.choices[0].message.content); } catch { return null; }
          }).catch(() => null)
        ]);

        return {
          state: input.state,
          laws: openaiResult?.laws ?? [],
          rights: openaiResult?.rights ?? [],
          healthDataSpecific: openaiResult?.healthDataSpecific ?? [],
          optOutInstructions: openaiResult?.optOutInstructions ?? "Contact us to opt out of data processing.",
          contactInfo: openaiResult?.contactInfo ?? "privacy@russelllabs.com",
          // Grok additions
          keyLaws: grokResult?.keyLaws ?? [],
          patientRights: grokResult?.patientRights ?? [],
          hipaaAdditions: grokResult?.hipaaAdditions ?? [],
          dataBreachNotice: grokResult?.dataBreachNotice ?? null,
          mentalHealthSpecific: grokResult?.mentalHealthSpecific ?? [],
          dualAI: { openai: !!openaiResult, grok: !!grokResult },
        };
      }),
  }),

  // ─── Document Analysis (AlterAI Reverse-Engineering) ─────────────────────────
  documentAnalysis: router({
    analyzeDocument: protectedProcedure
      .input(z.object({
        text: z.string().min(100),
        documentType: z.enum(["clinical_trial", "meta_analysis", "observational_study", "case_report", "review_article", "press_release", "fda_label", "patient_leaflet", "other"]),
        title: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { analyzeDocument } = await import("./documentAnalysis");
        return analyzeDocument(input.text, input.documentType);
      }),

    compareNarratives: protectedProcedure
      .input(z.object({
        topic: z.string().min(5),
        context: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { compareNarratives } = await import("./documentAnalysis");
        return compareNarratives(input.topic, input.context);
      }),
  }),

  // ─── OpenRouter Universal Model Router (X30) ─────────────────────────────────
  openRouter: router({
    /** Chat with automatic project-based model routing + Mem0 context */
    chat: protectedProcedure
      .input(z.object({
        messages: z.array(z.object({
          role: z.enum(["system", "user", "assistant"]),
          content: z.string(),
        })),
        project: z.enum(["root", "dr_buddy", "russell_capital", "church", "weight_loss", "edu_genius", "med_freedom", "genome"]).default("root"),
        model: z.string().optional(),
        temperature: z.number().min(0).max(2).optional(),
        max_tokens: z.number().optional(),
        injectMem0Context: z.boolean().default(true),
        persistToMem0: z.boolean().default(true),
      }))
      .mutation(async ({ input }) => {
        const { OpenRouterBus } = await import("./openrouter");
        const router = OpenRouterBus.getInstance();
        const result = await router.chatWithFallback({
          messages: input.messages,
          project: input.project as any,
          model: input.model,
          temperature: input.temperature,
          max_tokens: input.max_tokens,
          injectMem0Context: input.injectMem0Context,
          persistToMem0: input.persistToMem0,
        });
        return {
          content: result.choices?.[0]?.message?.content || "",
          model: result.model,
          provider: result.provider,
          usage: result.usage,
        };
      }),

    /** List available models */
    listModels: protectedProcedure
      .query(async () => {
        const { OpenRouterBus } = await import("./openrouter");
        const router = OpenRouterBus.getInstance();
        const models = await router.listModels();
        return models.slice(0, 50).map(m => ({
          id: m.id,
          name: m.name,
          pricing: m.pricing,
          contextLength: m.context_length,
        }));
      }),

    /** Get credit balance */
    getCredits: protectedProcedure
      .query(async () => {
        const { OpenRouterBus } = await import("./openrouter");
        const router = OpenRouterBus.getInstance();
        return router.getCredits();
      }),

    /** Get session stats */
    getStats: protectedProcedure
      .query(async () => {
        const { OpenRouterBus } = await import("./openrouter");
        const router = OpenRouterBus.getInstance();
        return router.getStats();
      }),

    /** Validate API key */
    validate: protectedProcedure
      .query(async () => {
        const { OpenRouterBus } = await import("./openrouter");
        const router = OpenRouterBus.getInstance();
        return { valid: await router.validate() };
      }),
  }),
});
export type AppRouter = typeof appRouter;
